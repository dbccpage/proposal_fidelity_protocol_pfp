"""Bounded benchmark runner, with an injected billing-aware provider port.

There is deliberately no filesystem/retrieval/tool interface in model requests.
This module has no answer-key input and implements no automatic accuracy judge.
The live OpenRouter adapter requires a finite campaign admission and conservative
quotes. Its external provider-enforcement premises are explicit, not proved here.
"""
from __future__ import annotations
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import time
from typing import Protocol

from budget_ledger import BudgetError, RunLedger
from rational_workflows import EXPERIMENTS, public_context, panel_for
from rational_panel import check_panel

HERE = Path(__file__).resolve().parent
PLANS = {
    'direct': [
        'Solve every part of the original task. State assumptions, exceptional cases and checks. Return your complete derivation and final results.',
    ],
    'self_critique': [
        'Draft a complete solution to every part of the original task. State assumptions, exceptional cases and checks.',
        'Audit the preceding draft against the unchanged original task. Correct unsupported steps and missing parameter cases. Return a complete final solution, with unresolved issues stated explicitly.',
    ],
}
PLANS.update(EXPERIMENTS)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def canonical(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')

@dataclass(frozen=True)
class Reply:
    text: str
    actual_microusd: int | None
    input_tokens: int | None
    output_tokens: int | None
    reasoning_tokens: int | None = None
    finish_reason: str = 'unavailable'
    provider_request_id: str | None = None
    provider_evidence: dict | None = None
    accounting_error: str | None = None

class Provider(Protocol):
    name: str
    offline: bool
    def upper_quote(self, request: dict) -> int:
        """Must cover all billable tokens/fees under externally enforced limits."""
    def complete(self, request: dict) -> Reply:
        """Exactly one dispatch. No hidden retries, fallback, tools or paid judges."""

class OfflineTape:
    name = 'offline-tape-no-provider-execution'
    offline = True
    def __init__(self, responses: list[str]):
        self.responses = iter(responses)
        self.requests = []
    def upper_quote(self, request):
        return 0
    def complete(self, request):
        self.requests.append(request)
        return Reply(next(self.responses), 0, None, None, finish_reason='offline_fixture')

def token_value(value):
    if value is not None and (type(value) is not int or value < 0):
        raise ValueError('Token usage must be an exact nonnegative integer or unavailable')
    return value


def freeze_json(path, value):
    data = canonical(value) + b'\n'
    with path.open('xb') as handle:
        handle.write(data)
        handle.flush()
        os.fsync(handle.fileno())
    return sha(data)

def run(plan: str, provider: Provider, output: Path, run_id: str, *, max_output_tokens=4000, live_admission=None):
    """Freeze a run receipt, including failures. Directory creation is exclusive.

    Live dispatch requires the installed OpenRouter adapter and exact membership
    in an initialized, finite campaign. Only explicitly registered adaptations
    are executable; research DAG nodes do not become generic executable stages.
    """
    if plan not in PLANS:
        raise ValueError('Unsupported plan; proposed research hosts are not generic executable stages')
    if plan in EXPERIMENTS:
        for name, expected in EXPERIMENTS[plan]['source_pins'].items():
            if sha((HERE / name).read_bytes()) != expected:
                raise ValueError('Loaded experiment source changed; restart and prepare a newly bound campaign')
        if sha(canonical(EXPERIMENTS[plan]['contract'])) != EXPERIMENTS[plan]['contract_sha256']:
            raise ValueError('Experiment contract changed')
    offline = provider.offline is True
    if not offline:
        from campaign_ledger import CampaignAdmission
        from openrouter_provider import OpenRouterProvider
        if not isinstance(provider, OpenRouterProvider) or not isinstance(live_admission, CampaignAdmission):
            raise ValueError('Live provider requires the guarded OpenRouter adapter and campaign admission')
    if type(max_output_tokens) is not int or max_output_tokens <= 0:
        raise ValueError('Positive exact output-token limit required')
    commitment = json.loads((HERE / 'commitment.json').read_text(encoding='utf-8'))
    seed = (HERE / 'seed_prompt.txt').read_bytes()
    if sha(seed) != commitment['seed_sha256']:
        raise ValueError('Frozen seed changed')
    seed_text = seed.decode('utf-8')
    output.mkdir(parents=True, exist_ok=False)
    (output / 'calls').mkdir()
    run_cap = 100_000
    if not offline:
        run_cap = live_admission.admit(run_id, plan, provider.admission_identity, sha(seed), max_output_tokens)
    ledger = RunLedger(output / 'ledger.sqlite3')
    ledger.start(run_id, sha(seed), run_cap)
    started = time.perf_counter()
    records = []; previous = None; responses = {}; status = 'offline_fixture_completed' if offline else 'completed'
    experiment = EXPERIMENTS.get(plan)
    stages = experiment['stages'] if experiment else [
        {'id': f'control_{index}', 'instruction': instruction, 'max_output_tokens': max_output_tokens,
         'visible_artifacts': [f'control_{index - 1}'] if index else []}
        for index, instruction in enumerate(PLANS[plan])]
    try:
        for index, stage in enumerate(stages):
            # The seed is one exact, unchanged user message in every call.
            messages = [{'role': 'system', 'content': stage['instruction']}, {'role': 'user', 'content': seed_text}]
            if experiment:
                messages.append({'role': 'user', 'content': 'Frozen public contract:\n' + canonical(public_context(sha(seed))).decode('utf-8')})
            for visible in stage['visible_artifacts']:
                messages.append({'role': 'user', 'content': 'Untrusted previous candidate follows. It is not the answer key.\n' + responses[visible]})
            request = {'messages': messages, 'max_output_tokens': min(max_output_tokens, stage['max_output_tokens']), 'tools': [], 'retries': 0}
            request_hash = sha(canonical(request))
            call_id = f'{run_id}:call:{index}'
            quote = provider.upper_quote(request)
            ledger.reserve(run_id, call_id, request_hash, quote)
            record = {'call_id': call_id, 'stage_id': stage['id'], 'request': request, 'request_sha256': request_hash, 'quote_microusd': quote,
                      'visible_artifact_sha256s': {name: sha(responses[name].encode('utf-8')) for name in stage['visible_artifacts']}}
            if not offline:
                record['provider_request_evidence'] = provider.request_evidence()
            records.append(record)
            freeze_json(output / 'calls' / f'{index:03d}.request.json', record)
            call_started = time.perf_counter()
            try:
                reply = provider.complete(request)
                record['provider_duration_seconds'] = time.perf_counter() - call_started
                record['actual_microusd'] = reply.actual_microusd
                # Persist a known charge before text/usage validation or artifact
                # I/O can fail. The raw provider digest binds malformed replies too.
                billing_digest = (reply.provider_evidence or {}).get('response_sha256')
                if billing_digest is None:
                    billing_digest = sha(str(reply.text).encode('utf-8', errors='backslashreplace'))
                record['billing_response_sha256'] = billing_digest
                if reply.actual_microusd is None:
                    ledger.mark_uncertain(call_id)
                else:
                    ledger.settle(call_id, reply.actual_microusd, billing_digest)
                if not isinstance(reply.text, str):
                    raise ValueError('Provider text missing')
                record.update(response_text=reply.text, response_sha256=sha(reply.text.encode()), actual_microusd=reply.actual_microusd,
                              input_tokens=token_value(reply.input_tokens), output_tokens=token_value(reply.output_tokens),
                              reasoning_tokens=token_value(reply.reasoning_tokens), finish_reason=reply.finish_reason,
                              provider_request_id=reply.provider_request_id, provider_evidence=reply.provider_evidence,
                              accounting_error=reply.accounting_error)
                freeze_json(output / 'calls' / f'{index:03d}.response.json', record)
                if reply.actual_microusd is None:
                    status = 'incomplete_accounting'
                    break
                if reply.accounting_error:
                    ledger.block(run_id)
                    status = 'provider_or_accounting_failure'
                    break
                previous = reply.text
                responses[stage['id']] = reply.text
            except Exception as exc:
                record.setdefault('provider_duration_seconds', time.perf_counter() - call_started)
                record.update(error_class=type(exc).__name__, error=str(exc)[:300])
                # An overrun is already durably settled; other errors keep their hold.
                try:
                    ledger.mark_uncertain(call_id)
                except BudgetError:
                    ledger.block(run_id)
                status = 'provider_or_accounting_failure'
                break
    except Exception as exc:
        status = 'admission_failure'
        records.append({'error_class': type(exc).__name__, 'error': str(exc)[:300], 'dispatched': False})
    finally:
        summary = ledger.summary(run_id)
        ledger.close()
    host_receipt = None
    if experiment:
        candidate_text = responses.get('solve')
        panel_text = panel_for(plan, responses, sha(seed), canonical)
        # A critic output is evidence only and can never become the answer.
        previous = candidate_text
        try:
            host_receipt, previous = check_panel(candidate_text, panel_text, sha(seed))
            host_receipt['visibility'] = {
                'mode': experiment['visibility'],
                'visible_artifacts_by_stage': {stage['id']: stage['visible_artifacts'] for stage in stages},
                'solver_artifact_withheld_from_challenger': experiment['visibility'] == 'blind',
                'scope': 'Broker request visibility only; no claim of statistical error independence or provider-side isolation.',
            }
            freeze_json(output / 'host_checks.json', host_receipt)
            if panel_text is not None:
                freeze_json(output / 'panel_artifact.json', {'text': panel_text, 'sha256': sha(panel_text.encode('utf-8'))})
            if host_receipt['artifact_errors'] and status in ('completed', 'offline_fixture_completed'):
                status = 'artifact_validation_failure'
        except Exception as exc:
            host_receipt = {'status': 'HOST_INFRASTRUCTURE_FAILURE', 'error_class': type(exc).__name__}
            status = 'host_infrastructure_failure' if status in ('completed', 'offline_fixture_completed') else status
    wall = time.perf_counter() - started
    def total(field):
        values = [r.get(field) for r in records if 'request' in r]
        return sum(values) if values and all(v is not None for v in values) else None
    receipt = {'schema_version': '1.0', 'run_id': run_id, 'plan': plan, 'provider': provider.name,
               'status': status, 'offline': offline, 'seed_sha256': sha(seed),
               'answer_text': previous, 'answer_sha256': sha(previous.encode()) if previous is not None else None,
               'accuracy_score': None, 'accuracy_status': 'unscored_no_evaluator_feedback',
               'wall_time_seconds': wall, 'sum_provider_duration_seconds': sum(r.get('provider_duration_seconds', 0) for r in records),
               'input_tokens': total('input_tokens'), 'output_tokens': total('output_tokens'), 'reasoning_tokens': total('reasoning_tokens'),
               'budget': summary, 'calls': records,
               'host_checks': host_receipt,
               'plan_sha256': sha(canonical(PLANS[plan])),
               'implementation_sha256': {name: sha((HERE / name).read_bytes()) for name in
                                         ('reference_runner.py', 'budget_ledger.py', 'campaign_ledger.py', 'openrouter_provider.py',
                                          'rational_panel.py', 'rational_workflows.py')},
               'scope': 'Orchestration/checker fixture only. No live model performance observation.' if offline else
                        'One frozen-seed provider run. Cost bound is conditional on recorded provider premises; accuracy requires independent post-freeze review.'}
    receipt_hash = freeze_json(output / 'run.json', receipt)
    (output / 'run.sha256').write_text(receipt_hash + '\n', encoding='ascii')
    if not offline:
        live_admission.finish(run_id, receipt, receipt_hash)
    return receipt

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', choices=PLANS, default='direct')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--run-id', required=True)
    args = parser.parse_args()
    count = len(EXPERIMENTS[args.plan]['stages']) if args.plan in EXPERIMENTS else len(PLANS[args.plan])
    receipt = run(args.plan, OfflineTape(['Synthetic fixture; no QM answer supplied.'] * count), args.output, args.run_id)
    print(json.dumps({k: receipt[k] for k in ('run_id', 'status', 'accuracy_status', 'offline')}))

# synthetic changed runner source after preparation
