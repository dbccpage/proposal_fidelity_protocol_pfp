def existing_algorithm(x):
    return x + 7

if __name__ == "__main__":
    raise RuntimeError("historical script side effect")
