def verify(case,answer):
    return False
