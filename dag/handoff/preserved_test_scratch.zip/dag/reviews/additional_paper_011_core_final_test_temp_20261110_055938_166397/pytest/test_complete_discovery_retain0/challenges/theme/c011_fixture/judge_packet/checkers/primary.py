def check(case,answer):
    return True
