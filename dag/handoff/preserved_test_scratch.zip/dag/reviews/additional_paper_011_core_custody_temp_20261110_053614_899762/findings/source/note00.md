# Synthetic note
fixture
