import Lake
open Lake DSL
package probe
lean_lib Probe where
  roots := #[`Probe]
