import sys, json, io, contextlib
from pathlib import Path
from types import SimpleNamespace
from omega_engine_woland.entrypoints.cli import main
work=Path.cwd()/'.scratch/oewas012/woland-final'
source=(work/'drive.py').read_text(encoding='utf-8-sig').replace('subprocess.run(command,capture_output=True)', '_run_cli(command)')
def _run_cli(command):
    output=io.StringIO(); error=io.StringIO()
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(error):
        code=main(command[4:])
    return SimpleNamespace(returncode=code,stdout=output.getvalue().encode(),stderr=error.getvalue().encode())
print('READY: sequential current IDE contribution transport; existing CLI main only',flush=True)
for line in sys.stdin:
    packet=json.loads(line)
    if 'answer' in packet:
        (work/'answer.json').write_text(json.dumps(packet['answer'],ensure_ascii=False),encoding='utf-8')
    sys.argv=['drive.py',*packet['argv']]
    try: exec(compile(source,str(work/'drive.py'),'exec'),globals())
    except SystemExit as exc: print('COMMAND_EXIT',exc.code,flush=True)
    except Exception as exc: print('COMMAND_ERROR',type(exc).__name__,str(exc),flush=True)
    print('READY',flush=True)
