import json, sys, subprocess, os
from pathlib import Path
from hashlib import sha256
root=Path.cwd(); work=root/'.scratch/oewas012/woland-final'
state=work/'state.json'; latest=work/'latest.json'
os.environ['OMEGA_SYMBOL_GAME_HOST']=str(root/'.scratch/oewas012/oewas012-native.exe')
os.environ['PYTHONDONTWRITEBYTECODE']='1'; os.environ['PYTHONPATH']=str(root)
def read(path): return json.loads(path.read_text(encoding='utf-8-sig'))
def diff(old,new,path=''):
    if type(old) is dict and type(new) is dict:
        for key in new:
            if key not in old: print(path+'/'+key, json.dumps(new[key],ensure_ascii=False))
            else: diff(old[key],new[key],path+'/'+key)
        for key in old.keys()-new.keys(): print(path+'/'+key,'REMOVED')
    elif type(old) is list and type(new) is list and new[:len(old)]==old:
        for i,value in enumerate(new[len(old):],len(old)): print(path+'/'+str(i),json.dumps(value,ensure_ascii=False))
    elif old!=new: print(path,json.dumps(new,ensure_ascii=False))
def show(report):
    print('STATUS',report['work_status'],'NEXT', (report.get('next_action') or {}).get('role_id'))
    turn=report.get('pfp_turn')
    if turn:
        full=dict(system=turn['system'],user=json.loads(turn['user']),response_schema=turn['response_schema'])
        seen=work/'seen-prompt.json'; old=read(seen) if seen.exists() else {}
        print('EXACT PREPARED PFP DELTA; omitted values equal the previously read values:')
        diff(old,full)
        seen.write_text(json.dumps(full,ensure_ascii=False),encoding='utf-8')
        print('BINDING',json.dumps(turn['binding']))
    else: print('HOST ACTION',json.dumps(report.get('next_action')))
if sys.argv[1]=='init':
    report=read(work/sys.argv[2]); latest.write_text(json.dumps(report),encoding='utf-8'); show(report)
elif sys.argv[1]=='submit':
    current=read(latest); role=sys.argv[2]; assert current['next_action']['role_id']==role
    answer=read(work/'answer.json')
    reply={k:current['pfp_turn']['binding'][k] for k in ('task_id','attempt_id','input_sha256')}; reply['answer']=answer
    index=len(read(state)['observations']); raw=work/f'{index:02d}-{role}.reply.json'
    raw.write_text(json.dumps(reply,ensure_ascii=False),encoding='utf-8')
    command=[sys.executable,'-B','-m','omega_engine_woland.entrypoints.cli','teamwork','submit','--state',str(state),'--raw-reply',str(raw),'--worker','current IDE /root/o12_woland; one worker using Retinue perspectives']
    if len(sys.argv)>3:
        files=read(work/sys.argv[3]); artifacts={f:sha256((root/f).read_bytes()).hexdigest() for f in files}
        host=work/f'{index:02d}-{role}.host.json';host.write_text(json.dumps(dict(action_id=current['next_action']['action_id'],worker='actual IDE host file readback',summary='Read actual candidate bytes',artifacts=artifacts)),encoding='utf-8')
        command+=['--host-result',str(host)]
    outcome=subprocess.run(command,capture_output=True); (work/f'{index:02d}-{role}.stdout').write_bytes(outcome.stdout); (work/f'{index:02d}-{role}.stderr').write_bytes(outcome.stderr)
    if outcome.returncode: print(outcome.stdout.decode(),outcome.stderr.decode());raise SystemExit(outcome.returncode)
    report=json.loads(outcome.stdout); latest.write_text(json.dumps(report),encoding='utf-8');show(report)
elif sys.argv[1]=='host':
    current=read(latest);index=len(read(state)['observations']);kind=sys.argv[2]
    command=[sys.executable,'-B','-m','omega_engine_woland.entrypoints.cli','teamwork',kind,'--state',str(state),*sys.argv[3:]]
    outcome=subprocess.run(command,capture_output=True);(work/f'{index:02d}-{kind}.stdout').write_bytes(outcome.stdout);(work/f'{index:02d}-{kind}.stderr').write_bytes(outcome.stderr)
    if outcome.returncode: print(outcome.stdout.decode(),outcome.stderr.decode());raise SystemExit(outcome.returncode)
    report=json.loads(outcome.stdout);latest.write_text(json.dumps(report),encoding='utf-8');show(report)
