Retained DDC procedure; fresh task-specific checks are required before acceptance.
