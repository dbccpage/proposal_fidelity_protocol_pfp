"""Frozen original-task check for the final OEWAS-012 implementation run."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / '.scratch/oewas012'
os.chdir(ROOT)
env = dict(os.environ, PYTHONPATH=str(ROOT), PYTHONDONTWRITEBYTECODE='1',
    PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', TMP=str(WORK), TEMP=str(WORK))
host = WORK / 'oewas012-native.exe'
if not host.is_file():
    raise SystemExit('SOURCE_CURRENT_NATIVE_HOST_REQUIRED')
env['OMEGA_SYMBOL_GAME_HOST'] = str(host)
campaign = json.loads((WORK / 'pilot/campaign.json').read_bytes())
if campaign['status'] != 'COMPLETED_BOUNDED' or campaign['P0']['status'] != 'PASS':
    raise SystemExit('BOUNDED_PILOT_NOT_COMPLETED')
accounting = campaign['accounting']
if not 0 <= accounting['spent'] <= 2_000_000:
    raise SystemExit('CAMPAIGN_CAP_EXCEEDED')
if set(campaign['stages']) != {'P1','P2','P3','P4'}:
    raise SystemExit('MISSING_PILOT_STAGE_RECORD')
if not any(row.get('outcome',{}).get('dispatch') == 'REPLIED'
    for result in campaign['results'] for row in result['calls']):
    raise SystemExit('NO_REAL_PROVIDER_REPLY')
groups = (
    ('omega_engine_workflows_agents_skills/skill_operad/resolver/tests/test_resolver_run_refusals.py',
     'omega_engine_workflows_agents_skills/skill_operad/tests/test_operad_laws_on_values.py'),
    ('omega_engine_workflows_agents_skills/tests/unit/test_operad_registry_defects.py',
     'omega_engine_workflows_agents_skills/tests/integration/test_operad_native_runtime.py'),
    ('omega_engine_woland/tests/spine/test_op_term_binding.py',
     'omega_engine_woland/tests/spine/test_skill_reference_resolution.py'),
    ('omega_engine_pfp/tests/test_pilot_grade_status.py',
     'omega_engine_woland/tests/test_model_backend_budget_reservation.py'),
    ('omega_engine_pfp/tests/test_seat_gateway_error_cost.py',
     'omega_engine_pfp/tests/test_management_ladder.py'),
    ('omega_engine_pfp/tests/test_prompt_environment_compression.py',
     'omega_engine_workflows_agents_skills/tests/unit/test_operad_treg_checked_controls.py'),
)
capture = WORK / 'acceptance' / str(time.time_ns())
capture.mkdir(parents=True)
records = []
for index, group in enumerate(groups):
    command = [sys.executable, '-B', '-m', 'pytest', *group, '-q', '-p', 'no:cacheprovider',
        '--basetemp', str(capture / f'tmp-{index}')]
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True)
    (capture / f'{index}.stdout').write_bytes(result.stdout)
    (capture / f'{index}.stderr').write_bytes(result.stderr)
    records.append(dict(command=command, exit_code=result.returncode,
        stdout_sha256=hashlib.sha256(result.stdout).hexdigest()))
    if result.returncode:
        print(result.stdout.decode(errors='replace'))
        print(result.stderr.decode(errors='replace'))
        raise SystemExit(result.returncode)
report = dict(checker_id='oewas012-completion-v2', scope='Focused current-source finite checks and actual bounded pilot',
    authority_effect='None', status='PASS', commands=records,
    native_host_sha256=hashlib.sha256(host.read_bytes()).hexdigest(),
    campaign_sha256=hashlib.sha256((WORK/'pilot/campaign.json').read_bytes()).hexdigest(),
    external='MUB exact-count item remains with its owner')
(capture/'result.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,sort_keys=True))
