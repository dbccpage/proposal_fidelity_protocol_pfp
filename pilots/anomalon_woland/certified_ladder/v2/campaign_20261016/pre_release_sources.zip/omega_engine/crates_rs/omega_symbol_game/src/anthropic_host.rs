//! The Anthropic Messages transport as a Symbol Game host action.
//!
//! The outcome says what happened to the request, which decides how the caller settles its
//! budget reservation: `NOT_SENT` (release it), `OUTCOME_UNKNOWN` (keep it charged) or
//! `REPLIED` (settle at `metered_cost_microusd`, or at the quote when that is null). A cost
//! ceiling of 0 is answered before the key is read or a socket is opened.
//!
//! AuthorityEffect: None.

use omega_providers::anthropic::raw_store::DirectoryRawSink;
use omega_providers::anthropic::request::{AdvisorPairings, MessagesRequest};
use omega_providers::anthropic::response::{parse_response, MessagesResponse};
use omega_providers::anthropic::transport::{meter_response, worst_case, AnthropicMessagesTransport, SendError, ANTHROPIC_MAX_REPLY_BYTES};
use omega_providers::budget::{PriceTable, PricingObservation};
use omega_providers::credentials::AnthropicApiKey;
use omega_providers::transport::VerifiedHttpClient;
use omega_providers::Refusal;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::path::{Component, Path};
use std::io::Read;
use std::time::Duration;

const TIMEOUT: Duration = Duration::from_secs(600);

fn invalid(message: impl Into<String>) -> Refusal {
    Refusal::new("ANTHROPIC_HOST_INPUT_INVALID", message)
}

fn not_sent(refusal: Refusal) -> Value {
    json!({"dispatch": "NOT_SENT", "refusal": refusal, "authority_effect": "None"})
}

fn response_value(reply: &MessagesResponse) -> Value {
    json!({"id": reply.id, "model": reply.model, "stop_reason": reply.stop_reason.wire(),
        "assistant_message": reply.assistant_message(), "text": reply.text(),
        "usage": reply.usage.raw, "container_id": reply.container_id})
}

pub fn execute(payload: &Value) -> Result<Value, Refusal> {
    let request: MessagesRequest = serde_json::from_value(payload["request"].clone())
        .map_err(|e| invalid(format!("request: {e}")))?;
    let ceiling = payload["ceiling_microusd"]
        .as_u64()
        .ok_or_else(|| invalid("ceiling_microusd must be a non-negative integer"))?;
    let quote_only = payload.get("quote_only").and_then(Value::as_bool).unwrap_or(false);
    let replay_raw = payload.get("replay_raw").filter(|value| !value.is_null());
    if ceiling == 0 && !quote_only && replay_raw.is_none() {
        return Ok(not_sent(Refusal::new(
            "PAID_DISPATCH_DISABLED",
            "the cost ceiling is 0: paid dispatch is off",
        )));
    }
    let raw_dir = payload["raw_dir"]
        .as_str()
        .ok_or_else(|| invalid("raw_dir must be a string"))?;
    // The caller names the run folder; it must be absolute and must not climb out of it.
    let dir = Path::new(raw_dir);
    if !dir.is_absolute() || dir.components().any(|c| c == Component::ParentDir) {
        return Err(invalid("raw_dir must be an absolute path without '..'"));
    }
    let raw_name = payload["raw_name"]
        .as_str()
        .ok_or_else(|| invalid("raw_name must be a string"))?;
    let observations = payload["observations"]
        .as_array()
        .ok_or_else(|| invalid("observations must be an array"))?
        .iter()
        .map(PricingObservation::from_json)
        .collect::<Result<Vec<_>, _>>()?;
    let prices = PriceTable::new(observations)?;
    let pairs = payload["advisor_pairings"]
        .as_array()
        .map(|rows| {
            rows.iter()
                .map(|row| match (row[0].as_str(), row[1].as_str()) {
                    (Some(executor), Some(advisor)) => {
                        Ok((executor.to_owned(), advisor.to_owned()))
                    }
                    _ => Err(invalid("advisor_pairings rows are [executor, advisor]")),
                })
                .collect::<Result<Vec<_>, _>>()
        })
        .transpose()?
        .unwrap_or_default();
    let pairings = AdvisorPairings::new(pairs);
    if let Some(raw) = replay_raw {
        if quote_only { return Err(invalid("replay and quote-only are distinct operations")); }
        let path = Path::new(raw["path"].as_str().ok_or_else(|| invalid("replay path missing"))?);
        let expected = dir.join(raw_name);
        if std::fs::canonicalize(path).map_err(|e| invalid(e.to_string()))?
            != std::fs::canonicalize(expected).map_err(|e| invalid(e.to_string()))? {
            return Err(invalid("replay raw path differs from the selected retained file"));
        }
        if std::fs::canonicalize(path.parent().ok_or_else(|| invalid("replay parent missing"))?)
            .map_err(|e| invalid(e.to_string()))?
            != std::fs::canonicalize(dir).map_err(|e| invalid(e.to_string()))? {
            return Err(invalid("replay file escapes the retained directory"));
        }
        let size = raw["bytes"].as_u64().ok_or_else(|| invalid("replay size missing"))?;
        if size > ANTHROPIC_MAX_REPLY_BYTES as u64 {
            return Err(invalid("replay size exceeds the retained reply limit"));
        }
        let digest = raw["sha256"].as_str().ok_or_else(|| invalid("replay digest missing"))?;
        let status = raw["status"].as_u64().ok_or_else(|| invalid("replay status missing"))?;
        if !(200..300).contains(&status) { return Err(invalid("replay HTTP status mismatch")); }
        let file = std::fs::File::open(path).map_err(|e| invalid(e.to_string()))?;
        let metadata = file.metadata().map_err(|e| invalid(e.to_string()))?;
        if !metadata.is_file() || metadata.len() != size { return Err(invalid("replay file size mismatch")); }
        let mut bytes = Vec::new();
        file.take(ANTHROPIC_MAX_REPLY_BYTES as u64 + 1).read_to_end(&mut bytes)
            .map_err(|e| invalid(e.to_string()))?;
        let actual = hex::encode(Sha256::digest(&bytes));
        if actual != digest.strip_prefix("sha256:").unwrap_or(digest) || size != bytes.len() as u64 {
            return Err(invalid("replay bytes, digest or HTTP status mismatch"));
        }
        request.build(&pairings)?;
        let response = parse_response(&bytes)?;
        if response.model != request.model { return Err(invalid("replay model differs from request")); }
        let cost = meter_response(&request, &response, &prices, &payload["at_utc"]);
        return Ok(json!({"dispatch":"REPLIED", "status":status,
            "raw":{"path":raw["path"],"sha256":raw["sha256"],"bytes":bytes.len()},
            "metered_cost_microusd":cost,"response":response_value(&response),
            "parse_refusal":null,"authority_effect":"None","replayed":true,"provider_calls":0}));
    }
    if quote_only {
        let (body, _) = request.build(&pairings)?;
        let quote = worst_case(&request, &body, &prices, &payload["at_utc"])?;
        return Ok(json!({"dispatch": "NOT_SENT", "quote_microusd": quote.total_microusd,
            "input_token_bound": quote.input_token_bound, "authority_effect": "None"}));
    }
    let key = match AnthropicApiKey::from_process_env() {
        Ok(key) => key,
        Err(refusal) => return Ok(not_sent(refusal)),
    };
    let client = VerifiedHttpClient::new(TIMEOUT)?;
    let mut transport = AnthropicMessagesTransport::new(
        key,
        client,
        DirectoryRawSink::new(raw_dir),
        pairings,
    );
    match transport.send(&request, raw_name, &prices, &payload["at_utc"], ceiling) {
        Err(SendError::NotSent(refusal)) => Ok(not_sent(refusal)),
        Err(SendError::OutcomeUnknown(refusal)) => Ok(
            json!({"dispatch": "OUTCOME_UNKNOWN", "refusal": refusal, "authority_effect": "None"}),
        ),
        Ok(outcome) => {
            let response = match &outcome.parsed {
                Ok(reply) => response_value(reply),
                Err(_) => Value::Null,
            };
            Ok(json!({
                "dispatch": "REPLIED",
                "status": outcome.status,
                "raw": {"path": outcome.raw.path, "sha256": outcome.raw.sha256, "bytes": outcome.raw.bytes},
                "quote_microusd": outcome.quote.total_microusd,
                "metered_cost_microusd": outcome.metered_cost_microusd,
                "response": response,
                "parse_refusal": outcome.parsed.as_ref().err(),
                "authority_effect": "None",
            }))
        }
    }
}
