"""Frozen Woland routes remain readable after the active sink moves."""
from hashlib import sha256
import json
from pathlib import Path

import pytest

from omega_engine_operating_system.adapters.intelligence_custody.ic_migration import (
    InventoryFile, MigrationInventory,
)
from omega_engine_operating_system.adapters.intelligence_custody.ic_routing import (
    HISTORY, IcMigrationRefusal, historical_snapshot_path, ic_relative_path,
    intelligence_source_locator, json_bytes, resolve_historical_path, resolve_source_directory,
)


def _packet(root, *, destination='_ic/darpa/woland/packet/data.json'):
    origin='_intelligence/_woland/packet/data.json'
    raw=b'{"original":"bytes"}\r\n'
    row=InventoryFile(origin,ic_relative_path(origin),sha256(raw).hexdigest(),len(raw))
    inventory=MigrationInventory(str(root),'dbccpage/the_symbol_game','a'*40,
        (row,),('_intelligence/_woland/packet',),())
    value=json.loads(inventory.bytes); value['files'][0]['destination']=destination
    frozen=json_bytes(value)
    history=root/HISTORY; history.mkdir(parents=True)
    (history/'inventory.json').write_bytes(frozen)
    (history/'receipt.json').write_bytes(json_bytes(dict(schema='omega.ic.portable_history.v1',
        repository=inventory.repository,source_revision=inventory.source_revision,
        inventory_sha256=sha256(frozen).hexdigest(),authority_effect='None')))
    path=root/destination; path.parent.mkdir(parents=True); path.write_bytes(raw)
    return origin, raw, frozen, path


def test_frozen_route_file_and_directory_round_trip(tmp_path):
    origin,raw,frozen,path=_packet(tmp_path)
    assert resolve_historical_path(tmp_path,origin)==path
    assert resolve_source_directory(tmp_path,origin.rsplit('/',1)[0])==path.parent
    assert intelligence_source_locator(tmp_path,path.parent)==origin.rsplit('/',1)[0]
    assert (tmp_path/HISTORY/'inventory.json').read_bytes()==frozen
    assert ic_relative_path(origin)=='_ic/woland/packet/data.json'
    with pytest.raises(IcMigrationRefusal,match='INVENTORY_INVALID'):
        MigrationInventory.from_bytes(frozen)


def test_historical_snapshot_and_changed_bytes(tmp_path):
    origin,raw,_,path=_packet(tmp_path)
    path.write_bytes(b'changed')
    snapshot=tmp_path/historical_snapshot_path(origin)
    snapshot.parent.mkdir(parents=True); snapshot.write_bytes(raw)
    assert resolve_historical_path(tmp_path,origin)==snapshot
    snapshot.write_bytes(b'changed too')
    with pytest.raises(IcMigrationRefusal,match='HISTORICAL_BYTES_MISMATCH'):
        resolve_historical_path(tmp_path,origin)


@pytest.mark.parametrize('destination',[
    '_ic/fbi/woland/packet/data.json','_ic/darpa/woland/other.json',
    '_ic/darpa/woland/../packet/data.json'])
def test_unrecognized_or_foreign_route_never_becomes_history(tmp_path,destination):
    origin,_,_,_=_packet(tmp_path,destination=destination)
    with pytest.raises(IcMigrationRefusal,match='INVENTORY_INVALID'):
        resolve_historical_path(tmp_path,origin)


def test_actual_frozen_inventory_is_readable_without_rewriting():
    root=Path(__file__).resolve().parents[2]
    path=root/HISTORY/'inventory.json'; raw=path.read_bytes()
    inventory=MigrationInventory.from_bytes(raw,historical=True)
    assert len(inventory.files)==6677
    assert inventory.bytes==raw
