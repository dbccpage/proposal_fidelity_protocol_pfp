# Epic 011: OEWAS development integration closeout

**Epic ID:** `EPIC-OE-OEWAS-011`
**AuthorityEffect:** None
**Status:** `IMPLEMENTED, TESTED`
**Delivery scope:** `COMPLETED_DEV_SCOPE`
**Owner:** OEWAS maintainers; admission, PFP and custody retain their existing owners.
**Delivery selection:** the local development system, current Codex `/woland`,
single-consumer planar workflows and the existing SQLite receipt subscriber.
**System:** [omega_engine_workflows_agents_skills](../../../../omega_engine_workflows_agents_skills).
**Registry relationship:** `INTEGRATION_HYPOTHESIS`; no direct registry assignment.
**Supersedes:** OEWAS001–010. Their completed details and unselected proposals
remain in [the previous consolidated plan](https://github.com/dbccpage/the_symbol_game/blob/63c050d92456e2c2e0ac842232d754493f96ec39/omega_engine_product_planning_office/plans/epics/oewas/epic_oe_oewas_011_consolidated_residual_plan.md).

The development implementation is complete at the selected consumers below.
This closeout removes already delivered work and unselected production/general
research proposals from active scheduling. It does not promote them to completed
implementation. [OEWAS-012](epic_oe_oewas_012_woland_operad_binding_and_management_ladder_pilot_plan.md)
separately owns the bounded management experiment and operation execution.

## R1–R8 disposition

| Workstream | Actual development consumer and completion boundary |
| --- | --- |
| R1: canonical contracts | Existing typed compiler/catalog combines generated contracts, frontmatter and V3 declarations. The lossless parser supports the selected CommonMark fence/container/HTML boundary. Explicit malformed effects, tools, operands, dependencies, observations, child IDs and output now refuse instead of erasing restrictions. SQLite ingress writes no catalog/event/outbox/idempotency rows on those refusals. Omitted legacy fields retain their compatibility defaults. |
| R2: composition | Existing Python/native ports validate ordered full interfaces, occurrence identity, source/operation pins, units and nullary operations. The current native estate wire accepts the actual optional retirement/replacement field. Foreign colour/schema/validator contracts refuse at the persisted consumer. Shared output, loops and automatic permutations remain outside this selected planar contract. |
| R3: challenge and feedback | Woland's finite independent checker is separate from StructureBench bundle coverage, candidate custody and OEEIS admission. Actual task/candidate/checker/snapshot bindings and cross-run transplant refusals are exercised. Pilot 035's separately admitted rules retain their narrow scope; there is no generalized automatic admission claim. |
| R4: native ingress | Native `pharmacy_detect` consumes raw-ingress receipts before JSON collapse and checks exact task/stage/request/report bindings. Unicode, malformed and foreign-byte controls exercise the consuming port. No global allocation, panic-freedom or cryptographic-delegation claim is made. |
| R5: retirement and host | Signed Woland ingress consumes current source-bound retirement and replacement projections. Generated selected host packages preserve host-owned resources. This actual Codex `/woland` run establishes the current host's use only; package parity does not establish activation in other IDEs. |
| R6: cross-engine stages | Existing PRE_DISPATCH, POST_PRODUCTION, PRE_SELECTION and PRE_SEAL composition paths retain candidate, task, stage and detector bindings. Instruction admission and OEEIS admission remain separate; CLEAR cannot supply either decision. |
| R7: custody and delivery | The selected SQLite subscriber has atomic local effects, stable deduplication, signed-intent and retained-tip process recovery. Frozen OEWAS-007 inventory routes remain readable after the active Woland sink moves to `_ic/woland`. Historical bytes are not rewritten. External exactly-once delivery, protected production keys and physical power-loss durability have no selected DEV deployment and are not claimed. |
| R8: contextual source experiment | The actual retained claim-audit source is checked against an independently specified literal ordered interface. Production signed admission now recomputes the supplied task shape; swapped/omitted inputs, foreign schemas, changed effects, source pins and candidate bodies refuse. A temporary fixture signer demonstrates checking and installs no production trust. |

## Concrete repairs and reusable commands

The [source/context experiment](../../../../omega_engine_workflows_agents_skills/documentation/source_contract_experiment_v1.md)
contains the source digest, literal signature, runtime command, refusal controls
and limits. It uses the existing compiler, selector and instruction-admission
port, without a new verifier or registry.

From the repository root, with the current source-matched native host selected:

```powershell
python -B -m omega_engine_workflows_agents_skills.documentation.examples.prior_art_contract_binding --repo-root . --output .scratch/source-contract/result.json
python -B -m pytest -q omega_engine_workflows_agents_skills/tests/integration/test_prior_art_contract_binding.py omega_engine_workflows_agents_skills/tests/integration/test_catalog_composition_contract.py --basetemp .scratch/oewas-contract-check
python -B -m pytest -q omega_engine_workflows_agents_skills/tests/unit/test_ingress_no_silent_schema_repair.py omega_engine_workflows_agents_skills/tests/integration/test_ingress_catalog_port_order_and_idempotency.py --basetemp .scratch/oewas-ingress-check
python -B -m pytest -q omega_engine_operating_system/tests/test_ic_historical_route_compatibility.py omega_engine_product_planning_office/tests/test_prior_art_historical_sources.py --basetemp .scratch/oewas-history-check
```

Use separate writable temporary directories. The delivery report records actual
commands/results rather than inheriting historical test totals. Existing
StructureBench, native raw-ingress, retirement, task-binding and SQLite recovery
controls remain in their owning test files. A build or passing fixture is not
proof that an arbitrary host function satisfies every operad law.

## Retained research and external limits

**RESEARCH_HOLD:** general source interpretation, automatic factorization,
effect-aware shared execution and arbitrary-paper semantic preservation have no
selected theorem or experiment here. No HoTT goal is retained.

The retained [PICARD source](../../../research_papers/library/01_generation_control/01_picard_parsing_incrementally_for_constrained_auto.md),
SHA-256 `2b29a9d1faf2f1a1bd08d8c5ef6e9cc2535464347bf0bf8fe9cc3adc62c1d654`,
and [homotopy-invariance source](../../../../omega_engine_library/coda_library/markdown/LIB-000023_on_homotopy_invarian.md),
SHA-256 `21945a07136f08d63939e0b1b2ea9f75932cd3b60b42417884eb32da2e63e942`,
remain hypotheses for integration, not correctness certificates. The concrete R8
experiment does not claim to extract either paper's semantics.

The wider 880-source custody audit remains distinct. Restoring the frozen
Woland-route reader removes `INVENTORY_INVALID`; it then correctly reports
`HISTORICAL_BYTES_UNAVAILABLE` for a missing retained research PDF. This closeout
does not fabricate or repin the missing source. Original inventory, predecessor
maps and evidence remain unchanged.

## Engineering evidence boundary

- **INVARIANT:** actual supplied task, ordered contract, source and candidate
  agree at the real consuming port; authority remains None.
- **BREAK:** malformed restrictions become defaults, a stale selected task is
  signed for different inputs, or active sink changes invalidate historical reads.
- **WITNESS:** retained source bytes, exact typed refusals, literal interfaces,
  real signature controls and source-matched native execution.
- **MUTATION:** bypassing the new current-task guard makes the four contextual
  controls fail. Finite negative controls do not establish unrestricted semantics.

Existing [ownership](../../decisions/adr_20261010_epic_integration_ownership.md)
and [IC custody](../../decisions/adr_20261010_oewas_intelligence_migration.md)
decisions remain. A specifically selected future production deployment, IDE or
research question can justify new work; it is not an unfinished DEV prerequisite.
