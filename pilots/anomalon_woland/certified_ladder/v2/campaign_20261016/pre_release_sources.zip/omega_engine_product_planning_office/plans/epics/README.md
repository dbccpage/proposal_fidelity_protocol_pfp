# Omega Engine epic and prior-art index

AuthorityEffect: None.

The [prior-art registry](epic_relevance_5_prior_art.yaml) contains 880 file rows assigned to 15 systems. Its current summary lists 31 system paths after council-package absorption. The 32 source-linked records below cover those 31 paths; seventeen mappings are explicit integration hypotheses, not direct registry assignments. The OERUST rows consolidate into a WDP-to-Rust architecture specification plus a separate solver leaf. Their shared path records ownership; implemented finite routes and remaining gaps appear in the [OERUST roadmap](oerust/README.md) and its source-to-code registry.

The [shared-review reconciliation](../../receipts/epic_design_review_20261010.md) records the publicly readable ChatGPT findings and the unavailable attachment boundary. Existing broad lifecycle labels do not establish design readiness. The [baseline custody map](../../receipts/prior_art_epic_map_20261010.json) pins the registry and selected source bytes; the [WDP architecture successor](../../receipts/prior_art_epic_map_20261012_oerust_architecture_successor.json) retains the OERUST consolidation, the [OEWAS successor](../../receipts/prior_art_epic_map_20261015_oewas_completion_successor.json) binds its consolidated owner, and the [current Woland successor](../../receipts/prior_art_epic_map_20261016_woland_consolidation_successor.json) preserves custody through Woland consolidation. Historical map bytes are recovered exactly from their retained Git revision. Registry/source audit refusals remain explicit; none of these maps is an independent audit of 880 scientific claims.

| System | Direct rows | Relationship | New epic |
| --- | ---: | --- | --- |
| [omega_engine](../../../omega_engine) | 221 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_certifiers](../../../omega_engine/crates_rs/omega_certifiers) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_higher_category_theory](../../../omega_engine/crates_rs/omega_higher_category_theory) | 129 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_homology](../../../omega_engine/crates_rs/omega_homology) | 8 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_homotopy_type_theory](../../../omega_engine/crates_rs/omega_homotopy_type_theory) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_mub](../../../omega_engine/crates_rs/omega_mub) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_operad_theory](../../../omega_engine/crates_rs/omega_operad_theory) | 128 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_quantum_physics](../../../omega_engine/crates_rs/omega_quantum_physics) | 15 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_search](../../../omega_engine/crates_rs/omega_search) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_sheaf_theory](../../../omega_engine/crates_rs/omega_sheaf_theory) | 88 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine/crates_rs/omega_solvers](../../../omega_engine/crates_rs/omega_solvers) | 42 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-PRIOR-ART-011](oerust/epic_oe_oerust_011_verified_reduction_round_trip_plan.md) |
| [omega_engine/crates_rs/omega_wdp](../../../omega_engine/crates_rs/omega_wdp) | 4 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERUST-ARCH-013](oerust/epic_oe_oerust_013_wdp_to_rust_v1rc_architecture_dag_plan.md) |
| [omega_engine_applications](../../../omega_engine_applications) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEAPPS-PRIOR-ART-001](oeapps/epic_oe_oeapps_001_diagnostic_receipt_presentation_plan.md) |
| [omega_engine_atlas](../../../omega_engine_atlas) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEATLAS-PRIOR-ART-001](oeatlas/epic_oe_oeatlas_001_prior_art_assumption_graph_plan.md) |
| [omega_engine_cognitive_operations](../../../omega_engine_cognitive_operations) | 1 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OECOGOPS-PRIOR-ART-001](oecogops/epic_oe_oecogops_001_licensing_oracle_falsifiers_plan.md) |
| [omega_engine_education](../../../omega_engine_education) | 2 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OEED-PRIOR-ART-001](oeed/epic_oe_oeed_001_dec_and_gate_counterexample_lessons_plan.md) |
| [omega_engine_epistemic_immune_system](../../../omega_engine_epistemic_immune_system) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEEIS-PRIOR-ART-004](oeeis/epic_oe_oeeis_004_witness_bound_negative_selection_plan.md) |
| [omega_engine_governance](../../../omega_engine_governance) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEGOV-PRIOR-ART-001](oegov/epic_oe_oegov_001_source_to_policy_admission_plan.md) |
| [omega_engine_governance](../../../omega_engine_governance) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEGOV-PRIOR-ART-002](oegov/epic_oe_oegov_002_retinue_dissent_and_gate_routes_plan.md) |
| [omega_engine_library](../../../omega_engine_library) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OELIBRARY-PRIOR-ART-001](oelibrary/epic_oe_oelibrary_001_registry_source_adoption_boundary_plan.md) |
| [omega_engine_moscow](../../../omega_engine_moscow) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEMOSCOW-PRIOR-ART-001](oemoscow/epic_oe_oemoscow_001_transition_telemetry_and_diversion_plan.md) |
| [omega_engine_operating_system](../../../omega_engine_operating_system) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEOS-PRIOR-ART-001](oeos/epic_oe_oeos_001_immutable_diagnostic_custody_plan.md) |
| [omega_engine_operations](../../../omega_engine_operations) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEOPS-PRIOR-ART-001](oeops/epic_oe_oeops_001_paired_replay_campaign_plan.md) |
| [omega_engine_product_planning_office](../..) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEPPO-PRIOR-ART-001](oeppo/epic_oe_oeppo_001_source_bound_design_readiness_plan.md) |
| [omega_engine_projects/fsp](../../../omega_engine_projects/fsp) | 2 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OEPROJECTS_FSP-PRIOR-ART-001](oeprojects/fsp/epic_oe_oeprojects_fsp_001_leakage_free_meron_replay_plan.md) |
| [omega_engine_projects/mub6](../../../omega_engine_projects/mub6) | 7 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OEPROJECTS_MUB6-PRIOR-ART-001](oeprojects/mub6/epic_oe_oeprojects_mub6_001_external_claim_certificate_audit_plan.md) |
| [omega_engine_prompt_civilization](../../../omega_engine_prompt_civilization) | 54 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OEPCIV-PRIOR-ART-001](oepciv/epic_oe_oepciv_001_grammar_validity_and_distribution_plan.md) |
| [omega_engine_providers](../../../omega_engine_providers) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEPROVIDERS-PRIOR-ART-001](oeproviders/epic_oe_oeproviders_001_decode_capability_receipts_plan.md) |
| [omega_engine_research_papers](../../../omega_engine_research_papers) | 177 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-OERPAPERS-PRIOR-ART-001](oerpapers/epic_oe_oerpapers_001_proof_and_claim_assumption_matrix_plan.md) |
| [omega_engine_pfp](../../../omega_engine_pfp) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-PFP-007](oepfp/epic_oe_pfp_007_source_bound_checker_protocol_plan.md) |
| [omega_engine_woland](../../../omega_engine_woland) | 2 | DIRECT_REGISTRY_ASSIGNMENT | [EPIC-OE-WOLAND-CONSOLIDATED-RESIDUAL-001](oewoland/epic_oe_woland_consolidated_residual_plan.md) |
| [omega_engine_workflows_agents_skills](../../../omega_engine_workflows_agents_skills) | 0 | INTEGRATION_HYPOTHESIS | [EPIC-OE-OEWAS-011](oewas/epic_oe_oewas_011_consolidated_residual_plan.md) |

## Design sequencing

Start with source custody and source-to-local assumption maps. Settle checker trust, compiler semantics, recovery and host activation before production admission. Connect Woland diagnostic results through a specified native transition port before claiming automatic bout enforcement. Run any acceptance suites in small batches and preserve dissent and negative evidence.

The product byte manifest recursively registers all 28 current formal epic plans matching `epic_oe_*_plan.md` across the subsystem suites. The [single Woland residual epic](oewoland/epic_oe_woland_consolidated_residual_plan.md) is closed after its selected native consumer, finite bridge and full22 demonstration; the Woland suite has no active epic. The [Woland register](oewoland/README.md) preserves stable IDs and pinned historical plans for delivered work. A content mutation or removed plan must invalidate custody. The separate prior-art custody map is checked with:

```powershell
py -3.12 -m omega_engine_product_planning_office.infrastructure.prior_art_sources
```

## Existing epic review and complete inventory

The earlier review loop covered 58 epic plans: 26 revised existing plans and the 32 source-linked additions above. The nine DeepMind research drafts and their index were reviewed separately; they are research hypotheses, not epic implementations. Those historical plans retain their proposed TDD slices in Git. The current recursive inventory is 28 plans after the subsequent OERUST, PFP and estate consolidation, removal of completed OEWAS003/004/007, addition of OEWOLAND004 and consolidation of the seven remaining OEWAS plans into 011, and coalescing five Woland plans into one residual owner. The current inventory is counted from disk rather than inherited from a historical register. The [current OEPFP roadmap](oepfp/README.md) owns canonical migration, mandatory Woland/PFP model mediation and the requested pilot work; OERUST retains a bounded exact-certificate solver leaf and the architecture research hold. No broad implementation-completion or mathematical-purity claim follows.

| Existing plan | Current status |
| --- | --- |
| [EPIC-OE-EIS-001](oeeis/epic_oe_eis_001_innate_pharmacy_and_role_partitioning_plan.md) | LIVE |
| [EPIC-OE-EIS-002](oeeis/epic_oe_eis_002_central_tolerance_thymus_gate_and_two_signal_activation_plan.md) | LIVE |
| [EPIC-OE-EIS-003](oeeis/epic_oe_eis_003_clonal_affinity_regulatory_anergy_and_human_admission_plan.md) | LIVE |
| [EPIC-OE-AGENTS-CONSOLIDATION-001](oegov/epic_oe_agents_consolidation_and_estate_usability_plan.md) | LIVE |
| [EPIC-OE-GOV-CONTRACT-CODEGEN-001](oegov/epic_oe_gov_contract_compilation_and_codegen_plan.md) | LIVE |
| [EPIC-OE-GOV-COUNCILS-PARITY-001](oegov/epic_oe_gov_councils_lifecycle_and_multihost_parity_plan.md) | LIVE |
| [EPIC-OE-GOV-COUNCILS-SWARM-001](oegov/epic_oe_gov_councils_swarm_and_universal_file_governance_plan.md) | RESEARCH_HOLD |
| [EPIC-OE-INTEL-DIGESTION-ARCHIVE-001](oegov/epic_oe_intelligence_digestion_transmutation_and_archival_plan.md) | LIVE |
| [EPIC-OE-PFP-000](oepfp/epic_oe_pfp_000_pilot_audit_findings_and_preflight_remediation_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-001](oepfp/epic_oe_pfp_001_ingress_protocol_and_spk001_pipeline_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-002](oepfp/epic_oe_pfp_002_symbol_game_pilot_lab_service_and_storage_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-003](oepfp/epic_oe_pfp_003_first_slice_tdd_contracts_and_replay_idempotency_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-004](oepfp/epic_oe_pfp_004_repeatable_pfp_demonstration_and_extensions_plan.md) | SUNSET; declined by OOUTWIRE, optional ideas in PFP-009. |
| [EPIC-OE-PFP-005](oepfp/epic_oe_pfp_005_bounded_comparison_and_practical_release_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-006](oepfp/epic_oe_pfp_006_genesis_recomposition_and_level_engine_estate_resettlement_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-007](oepfp/epic_oe_pfp_007_source_bound_checker_protocol_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-008](oepfp/epic_oe_pfp_008_woland_exclusive_pfp_mediation_plan.md) | SUNSET; current handoff in PFP-009. |
| [EPIC-OE-PFP-009](oepfp/epic_oe_pfp_009_practical_residuals_and_selected_extensions_plan.md) | LIVE; final migration, exclusive Woland/PFP routing and requested demo completion. |
| [EPIC-OE-OEWAS-011](oewas/epic_oe_oewas_011_consolidated_residual_plan.md) | IMPLEMENTED, TESTED (selected DEV scope); real compiler/admission, native ingress, retirement, local delivery and contextual-source controls. Historical and unselected external limits remain explicit. |
| [EPIC-OE-OEWAS-012](oewas/epic_oe_oewas_012_woland_operad_binding_and_management_ladder_pilot_plan.md) | IMPLEMENTED, TESTED (selected DEV scope); I0–I4 integration and P0–P4 completed within the original $2 cap. No active OEWAS implementation epic remains. |
| [EPIC-OE-WOLAND-CONSOLIDATED-RESIDUAL-001](oewoland/epic_oe_woland_consolidated_residual_plan.md) | PROTOTYPE |
| [EPIC-OE-RIS-AUTOPOIESIS-001](ris/epic_oe_ris_autopoietic_semantic_closure_and_receipt_learning_plan.md) | LIVE |

The [ownership decision](../decisions/adr_20261010_epic_integration_ownership.md) resolves duplicate ownership and retains the four-file sink contract. The [baseline obstruction walk](../../receipts/epic_obstruction_walk_20261010.md) and [machine-readable inventory](../../receipts/epic_obstruction_walk_20261010.json) pin reviewed bytes and proposed tests; the [current OERUST architecture successor](../../receipts/epic_obstruction_walk_20261012_oerust_architecture_successor.json) records the active inventory change. The [DeepMind research index](ris/deepmind/index.md) retains explicit proof obligations and finite counterexamples.

The [current OEPFP planning overlay](../../receipts/epic_obstruction_walk_20261012_pfp_final_migration_successor.json) pins the ten revised PFP plans without rewriting its predecessor evidence. It records plan review only, not implementation completion.

Run the custody and test-plan checks after an intentional edit, regenerating only the manifest whose new bytes have been reviewed:

```powershell
py -3.12 -m omega_engine_product_planning_office.use_cases.epic_manifest_audit --write
py -3.12 -m omega_engine_product_planning_office.infrastructure.prior_art_sources
py -3.12 -m omega_engine_product_planning_office.use_cases.epic_tdd_plan_audit
```

The manifest covers all `epic_oe_*_plan.md` files recursively. READMEs, research drafts, the prior-art YAML and placeholders are not epic plans; source/decision/research custody is recorded separately. The audits verify coverage, reviewed bytes, structure and links. They cannot certify implementation readiness or settle research obligations.

## OEGOV government delivery expansion

The [OEGOV register](oegov/README.md) retains seven existing owners and adds three `SPEC_ONLY` implementation epics:

- [Council runtime and institutional memory](oegov/epic_oe_oegov_003_council_runtime_and_institutional_memory_plan.md)
- [Blackrod warrants and observed enforcement](oegov/epic_oe_oegov_004_blackrod_warrants_and_observed_enforcement_plan.md)
- [4E situated governance](oegov/epic_oe_oegov_005_four_e_situated_governance_plan.md)

The [successor walk](../../receipts/epic_obstruction_walk_20261010_oegov_successor.json) and [successor source map](../../receipts/prior_art_epic_map_20261010_oegov_successor.json) bind current bytes while preserving the preceding receipts unchanged. Imported source specifications are separately accounted for by the [migration manifest](../../receipts/oegov_planning_20261010/migration_manifest.json). This expansion specifies future integration; it does not establish online councils, Blackrod or human cognitive equivalence.
