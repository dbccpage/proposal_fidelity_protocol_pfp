"""Preselected real-port checks; no swarm recursion or inference calls."""
from pathlib import Path
from hashlib import sha256
import json, os, subprocess, sys
root=Path(__file__).resolve().parents[2]; base=Path(__file__).parent
groups=(
 ('omega_engine_workflows_agents_skills/tests/integration/test_prior_art_contract_binding.py',
  'omega_engine_workflows_agents_skills/tests/integration/test_catalog_composition_contract.py'),
 ('omega_engine_pfp/tests/test_management_ladder_continuation.py',
  'omega_engine_pfp/tests/test_management_ladder.py'),
 ('omega_engine_workflows_agents_skills/tests/integration/test_retired_route_projection_contract.py',
  'omega_engine_workflows_agents_skills/tests/integration/test_raw_ingress_receipt_consumer.py',
  'omega_engine_workflows_agents_skills/tests/integration/test_structurebench_production_bundle_contract.py'),
)
for i,targets in enumerate(groups):
 result=subprocess.run([sys.executable,'-B','-m','pytest','--override-ini','addopts=','-q',*targets,
  '--basetemp',str(base/f'original-check-{i}')],cwd=root,capture_output=True,timeout=150)
 sys.stdout.buffer.write(result.stdout); sys.stderr.buffer.write(result.stderr)
 if result.returncode: raise SystemExit(result.returncode)
for pin in json.loads((base/'historical-before.json').read_bytes()):
 assert sha256(Path(pin['path']).read_bytes()).hexdigest()==pin['sha256'],pin['path']
report=json.loads((base/'campaign-final.json').read_bytes())
assert set(report['stages'])=={'P0','P1','P2','P3','P4'}
assert report['status'] in {'COMPLETED_BOUNDED','PREREQUISITE_FAILED'},report['status']
assert report['continuing_cap_microusd']==2_000_000
assert report['liability_microusd']<=2_000_000
print('OEWAS_REAL_PORTS_AND_CONTINUING_CAMPAIGN_CHECKED')
