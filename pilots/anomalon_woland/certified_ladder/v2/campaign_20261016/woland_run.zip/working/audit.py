"""One read-only replay and direct readback of the completed real IDE run."""
from hashlib import sha256
import json
import os
from pathlib import Path
import sqlite3
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[2]
BASE=Path(__file__).parent
os.environ['PYTHONUTF8']='1'
os.environ['OMEGA_SYMBOL_GAME_HOST']=str(BASE/'runtime/host.exe')
os.environ['TEMP']=os.environ['TMP']=str(ROOT/'.scratch/woland-history')
tempfile.tempdir=os.environ['TEMP']
sys.path.insert(0,str(ROOT))
from omega_engine_woland.use_cases.teamwork import TeamworkRun, next_action
from omega_engine_woland.domain.native import value
from omega_engine_woland.infrastructure.teamwork_reporting import read_checkpoint_reports
from omega_engine_woland.use_cases.teamwork_pfp import prepare_teamwork_turn
from omega_engine_woland.infrastructure.teamwork_native_gates import replay_native_gate_reference

state=BASE/'teamwork.json'
raw=state.read_bytes()
run=TeamworkRun.model_validate_json(raw)
assert next_action(run) is None and run.work_status=='completed', 'Wait for the saved run to finish before final replay'
prefix=run.model_copy(update={'observations': (), 'pending_prompt': None})
for record in run.observations:
    action=next_action(prefix)
    assert action.action_id == record.action_id
    if action.communication == 'pfp':
        turn=prepare_teamwork_turn(action, observe=False)
        turn.replay(record.metadata['pfp'])
    if 'native_gate_receipt' in record.metadata:
        replay_native_gate_reference(action, record.metadata['native_gate_receipt'])
    prefix=prefix.model_copy(update={'observations': (*prefix.observations, record)})
assert prefix.model_dump(mode='json') == run.model_dump(mode='json')
assert next_action(run) is None and run.work_status=='completed'
assert run.retinue_coverage['complete'] and len(run.retinue_coverage['observed'])==22
assert not any(item.blocked for item in run.observations)
captures=[item for item in run.observations if item.metadata.get('execution_kind')=='pfp']
assert len(captures)==22
learned=[item for item in run.observations if item.metadata.get('role_id')=='bezdomny']
assert len(learned)==1
checks=[item for item in run.observations if item.check and item.check.checker_id=='oewas-completion-v1']
assert len(checks)==2 and all(item.check.exit_status==0 for item in checks)
for item in checks:
    capture=item.metadata['checker_capture']
    output=bytes.fromhex(capture['stdout_hex'])+b'\n--- stderr ---\n'+bytes.fromhex(capture['stderr_hex'])
    assert sha256(output).hexdigest()==item.check.output_sha256
with sqlite3.connect(Path(run.episode_binding['path']).as_uri()+'?mode=ro',uri=True) as ledger:
    episodes=ledger.execute('SELECT action_id,ordinal,result FROM episodes ORDER BY ordinal').fetchall()
assert len(episodes)==2 and {item[0] for item in episodes}=={item.action_id for item in checks}
status=read_checkpoint_reports(state)
assert status['status']=='FINALIZED'
folder=Path(status['bundle_directory'])
assert {path.name for path in folder.iterdir() if path.is_file()}=={'uns.md','uts.jsonl','ddc.jsonl','summary.json','receipt.json'}
assert {path.name for path in folder.iterdir() if path.is_dir()} <= {'mam'}
assert value('verify_reported_bundle',run_dir=str(folder))==status['receipt_id']
assert value('recompute_receipt',run_dir=str(folder))==status['receipt_id']
summary=json.loads((folder/'summary.json').read_bytes())
receipt=json.loads((folder/'receipt.json').read_bytes())
assert summary['source_history']==json.loads(raw)
for name,key in [('uns.md','uns_sha256'),('ddc.jsonl','ddc_sha256'),('uts.jsonl','uts_sha256'),('summary.json','summary_sha256')]:
    assert sha256((folder/name).read_bytes()).hexdigest()==receipt[key]
ddc=[json.loads(line) for line in (folder/'ddc.jsonl').read_bytes().splitlines()]
actions=[item['payload'] for item in ddc if item['payload']['record_kind']=='observed_action']
assert [item['action_id'] for item in actions]==[item.action_id for item in run.observations]
last_program=next(item.ddc_program for item in reversed(run.observations) if item.ddc_program)
steps=[item['payload']['step'] for item in ddc if item['payload']['record_kind']=='retained_ddc_step']
assert steps==list(last_program.steps)
tape=value('tape',steps_json=json.dumps([item['payload'] for item in ddc],ensure_ascii=False))
assert bytes.fromhex(tape['bytes_hex'])==(folder/'ddc.jsonl').read_bytes()
assert tape['head_sha256']==receipt['ddc_head_sha256']
uts=[json.loads(line) for line in (folder/'uts.jsonl').read_bytes().splitlines()]
assert len({item['event_id'] for item in uts})==len(uts)
assert [item['sequence'] for item in uts]==list(range(len(uts)))
assert uts[-1]['work_status']=='completed'
uns=(folder/'uns.md').read_text(encoding='utf-8')
assert all(not item.content or item.content in uns for item in run.observations)
assert all(item.worker in uns for item in run.observations)
for path,digest in run.observations[-1].artifacts.items():
    assert sha256(Path(path).read_bytes()).hexdigest()==digest.removeprefix('sha256:')
historical=json.loads((BASE/'historical-before.json').read_bytes())
assert all(sha256(Path(item['path']).read_bytes()).hexdigest()==item['sha256'] for item in historical)
assert last_program.host_observation.provider_attempt_count==0
assert last_program.host_observation.billing_status=='UNOBSERVED'
print(json.dumps({'status':'REPLAY_AND_READBACK_OK','run_id':run.run_id,'work_status':run.work_status,
    'roles':len(run.retinue_coverage['observed']),'observations':len(run.observations),'checked_ide_captures':len(captures),
    'original_checks':len(checks),'learning_finishes':1,'provider_dispatches':0,'ide_billing':'UNOBSERVED',
    'ddc_records':len(ddc),'observed_actions':len(actions),'retained_procedure_steps':len(steps),'uts_events':len(uts),
    'historical_pins_unchanged':len(historical),'state_sha256':sha256(raw).hexdigest(),
    'bundle_directory':str(folder),'receipt_id':status['receipt_id'],
    'native_diagnostics':run.native_gate_coverage.get('counts'),'candidate_native_host_sha256':sha256((BASE/'candidate-runtime/host.exe').read_bytes()).hexdigest(),
    'files':{path.name:{'bytes':path.stat().st_size,'sha256':sha256(path.read_bytes()).hexdigest()} for path in folder.iterdir() if path.is_file()}},ensure_ascii=False))

assert run.native_gate_check.policy == 'require_pass'
assert all(not x.blocked and x.metadata['native_gate_summary']['all_pass'] for x in run.observations if 'native_gate_summary' in x.metadata)
