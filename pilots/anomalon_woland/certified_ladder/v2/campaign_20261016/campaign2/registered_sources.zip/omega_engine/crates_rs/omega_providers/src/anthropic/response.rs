//! Messages API replies: typed blocks for what the host reads, raw blocks for history.
//!
//! The assistant content is kept verbatim (`raw_content`) so it can be sent back unchanged
//! on the next turn; this matters for redacted advisor output, which the host cannot read
//! and must still return. Block types this parser does not know are kept as `Unknown`.
//!
//! AuthorityEffect: None.

use crate::Refusal;
use serde_json::Value;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum StopReason {
    EndTurn,
    MaxTokens,
    StopSequence,
    ToolUse,
    /// A server tool loop paused; send the assistant content back to continue the turn.
    PauseTurn,
    Refusal,
    Other(String),
}

impl StopReason {
    /// The value as the API spells it.
    pub fn wire(&self) -> &str {
        match self {
            Self::EndTurn => "end_turn",
            Self::MaxTokens => "max_tokens",
            Self::StopSequence => "stop_sequence",
            Self::ToolUse => "tool_use",
            Self::PauseTurn => "pause_turn",
            Self::Refusal => "refusal",
            Self::Other(text) => text,
        }
    }

    fn parse(text: &str) -> Self {
        match text {
            "end_turn" => Self::EndTurn,
            "max_tokens" => Self::MaxTokens,
            "stop_sequence" => Self::StopSequence,
            "tool_use" => Self::ToolUse,
            "pause_turn" => Self::PauseTurn,
            "refusal" => Self::Refusal,
            other => Self::Other(other.to_owned()),
        }
    }
}

/// Whether the host can read a block's payload.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Readability {
    Readable,
    /// Encrypted advisor output: kept and replayed, never read.
    NotReadable,
}

#[derive(Debug, Clone, PartialEq)]
pub enum ContentBlock {
    /// Preserved verbatim and billed within output_tokens; never a final answer.
    Thinking(Value),
    Text {
        text: String,
    },
    ToolUse {
        id: String,
        name: String,
        input: Value,
    },
    ServerToolUse {
        id: String,
        name: String,
        input: Value,
    },
    AdvisorResult {
        tool_use_id: String,
        text: String,
        stop_reason: Option<String>,
    },
    AdvisorRedactedResult {
        tool_use_id: String,
        encrypted_content: String,
        stop_reason: Option<String>,
    },
    AdvisorError {
        tool_use_id: String,
        error_code: String,
    },
    /// `bash_code_execution_tool_result`, `text_editor_code_execution_tool_result` or
    /// `code_execution_tool_result`; `content` is the result object as sent.
    CodeExecutionResult {
        block_type: String,
        tool_use_id: String,
        content: Value,
    },
    Unknown(Value),
}

impl ContentBlock {
    pub fn readability(&self) -> Readability {
        match self {
            ContentBlock::AdvisorRedactedResult { .. } => Readability::NotReadable,
            _ => Readability::Readable,
        }
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct Usage {
    pub input_tokens: u64,
    pub output_tokens: u64,
    pub cache_creation_input_tokens: u64,
    pub cache_read_input_tokens: u64,
    pub code_execution_requests: u64,
    /// The usage object as sent, including counters this parser does not model.
    pub raw: Value,
}

#[derive(Debug, Clone, PartialEq)]
pub struct MessagesResponse {
    pub id: String,
    pub model: String,
    pub stop_reason: StopReason,
    pub content: Vec<ContentBlock>,
    pub raw_content: Vec<Value>,
    pub usage: Usage,
    pub container_id: Option<String>,
}

impl MessagesResponse {
    /// The assistant turn to append to history, unchanged.
    pub fn assistant_message(&self) -> Value {
        serde_json::json!({"role": "assistant", "content": self.raw_content})
    }

    pub fn text(&self) -> String {
        self.content
            .iter()
            .filter_map(|block| match block {
                ContentBlock::Text { text } => Some(text.as_str()),
                _ => None,
            })
            .collect::<Vec<_>>()
            .join("")
    }
}

fn unparseable(message: impl Into<String>) -> Refusal {
    Refusal::new("ANTHROPIC_RESPONSE_UNPARSEABLE", message)
}

fn string(value: &Value, field: &str) -> Result<String, Refusal> {
    value
        .get(field)
        .and_then(Value::as_str)
        .map(str::to_owned)
        .ok_or_else(|| unparseable(format!("{field} must be a string")))
}

fn count(value: &Value, field: &str, required: bool) -> Result<u64, Refusal> {
    match value.get(field) {
        None | Some(Value::Null) if !required => Ok(0),
        Some(number) => number
            .as_u64()
            .ok_or_else(|| unparseable(format!("usage.{field} must be a non-negative integer"))),
        None => Err(unparseable(format!("usage.{field} missing"))),
    }
}

fn block(raw: &Value) -> Result<ContentBlock, Refusal> {
    let kind = raw.get("type").and_then(Value::as_str).unwrap_or_default();
    Ok(match kind {
        "text" => ContentBlock::Text {
            text: string(raw, "text")?,
        },
        "thinking" if raw.get("thinking").is_some_and(Value::is_string)
            && raw.get("signature").is_some_and(Value::is_string) => ContentBlock::Thinking(raw.clone()),
        "redacted_thinking" if raw.get("data").is_some_and(Value::is_string) => ContentBlock::Thinking(raw.clone()),
        "tool_use" | "server_tool_use" => {
            let (id, name) = (string(raw, "id")?, string(raw, "name")?);
            let input = raw.get("input").cloned().unwrap_or(Value::Null);
            if kind == "tool_use" {
                ContentBlock::ToolUse { id, name, input }
            } else {
                ContentBlock::ServerToolUse { id, name, input }
            }
        }
        "advisor_tool_result" => {
            let tool_use_id = string(raw, "tool_use_id")?;
            let content = raw.get("content").cloned().unwrap_or(Value::Null);
            let stop_reason = content
                .get("stop_reason")
                .and_then(Value::as_str)
                .map(str::to_owned);
            match content.get("type").and_then(Value::as_str) {
                Some("advisor_result") => ContentBlock::AdvisorResult {
                    tool_use_id,
                    text: string(&content, "text")?,
                    stop_reason,
                },
                Some("advisor_redacted_result") => ContentBlock::AdvisorRedactedResult {
                    tool_use_id,
                    encrypted_content: string(&content, "encrypted_content")?,
                    stop_reason,
                },
                Some("advisor_tool_result_error") => ContentBlock::AdvisorError {
                    tool_use_id,
                    error_code: string(&content, "error_code")?,
                },
                _ => ContentBlock::Unknown(raw.clone()),
            }
        }
        "bash_code_execution_tool_result"
        | "text_editor_code_execution_tool_result"
        | "code_execution_tool_result" => ContentBlock::CodeExecutionResult {
            block_type: kind.to_owned(),
            tool_use_id: string(raw, "tool_use_id")?,
            content: raw.get("content").cloned().unwrap_or(Value::Null),
        },
        _ => ContentBlock::Unknown(raw.clone()),
    })
}

/// Parse a 2xx reply body.
pub fn parse_response(bytes: &[u8]) -> Result<MessagesResponse, Refusal> {
    let value: Value = serde_json::from_slice(bytes)
        .map_err(|error| unparseable(format!("reply is not JSON: {error}")))?;
    if value.get("type").and_then(Value::as_str) != Some("message") {
        return Err(unparseable("reply type is not message"));
    }
    let raw_content = value
        .get("content")
        .and_then(Value::as_array)
        .cloned()
        .ok_or_else(|| unparseable("content must be an array"))?;
    let content = raw_content
        .iter()
        .map(block)
        .collect::<Result<Vec<_>, _>>()?;
    let usage_raw = value
        .get("usage")
        .cloned()
        .ok_or_else(|| unparseable("usage missing"))?;
    let usage = Usage {
        input_tokens: count(&usage_raw, "input_tokens", true)?,
        output_tokens: count(&usage_raw, "output_tokens", true)?,
        cache_creation_input_tokens: count(&usage_raw, "cache_creation_input_tokens", false)?,
        cache_read_input_tokens: count(&usage_raw, "cache_read_input_tokens", false)?,
        code_execution_requests: usage_raw
            .get("server_tool_use")
            .map(|server| count(server, "code_execution_requests", false))
            .transpose()?
            .unwrap_or(0),
        raw: usage_raw,
    };
    let stop_reason = StopReason::parse(&string(&value, "stop_reason")?);
    let container_id = value
        .get("container")
        .and_then(|c| c.get("id"))
        .and_then(Value::as_str)
        .map(str::to_owned);
    Ok(MessagesResponse {
        id: string(&value, "id")?,
        model: string(&value, "model")?,
        stop_reason,
        content,
        raw_content,
        usage,
        container_id,
    })
}

/// A typed refusal for a non-2xx reply: `ANTHROPIC_<ERROR_TYPE>` when the body is the
/// documented error envelope, `ANTHROPIC_HTTP_<status>` otherwise.
pub fn error_refusal(status: u16, bytes: &[u8]) -> Refusal {
    let parsed: Option<(String, String)> =
        serde_json::from_slice::<Value>(bytes)
            .ok()
            .and_then(|value| {
                let error = value.get("error")?;
                let kind = error.get("type")?.as_str()?;
                let message = error
                    .get("message")
                    .and_then(Value::as_str)
                    .unwrap_or_default();
                let safe = kind.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'_')
                    && !kind.is_empty();
                safe.then(|| (kind.to_ascii_uppercase(), message.to_owned()))
            });
    match parsed {
        Some((kind, message)) => Refusal::new(
            &format!("ANTHROPIC_{kind}"),
            format!("HTTP {status}: {message}"),
        ),
        None => Refusal::new(
            &format!("ANTHROPIC_HTTP_{status}"),
            format!("HTTP {status} without an error envelope"),
        ),
    }
}
