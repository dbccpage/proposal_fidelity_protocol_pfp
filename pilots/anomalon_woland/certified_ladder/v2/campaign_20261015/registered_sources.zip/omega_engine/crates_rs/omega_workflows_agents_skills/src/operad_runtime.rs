//! Bounded planar inventory terms, normalized by the existing sovereign kernel.
use crate::Refusal;
use omega_operad_theory::kernel::{model::{OperationSpec, OperationSpecInput, PortSpec, InvocationGrade, AuthorityEffect}, terms::{OperationTerm, normalize_term}};
use serde::Deserialize;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::BTreeMap;

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Request {
    command: String,
    inventory_json: String,
    wire: Value,
    #[serde(default)] values: Option<Vec<Value>>,
}
#[derive(Deserialize)]
struct Inventory { schema_version: String, skills: Vec<Skill> }
#[derive(Deserialize)]
struct Skill { ops: Vec<Op>, #[serde(default)] anti_ops: Vec<Guard> }
#[derive(Clone,Deserialize)]
struct Op { op_id: String, inputs: Vec<String>, output: String, binding: Option<Value> }
#[derive(Deserialize,serde::Serialize)]
struct Guard { op_id: String, guards: String, slot: usize, inspects: String, refusal: String }
fn bad(code:&str, message:impl Into<String>)->Refusal { Refusal::new(code,message) }
fn sha(bytes:&[u8])->String { hex::encode(Sha256::digest(bytes)) }
fn port(index:usize, colour:&str)->Result<PortSpec,Refusal> {
    PortSpec::new(&format!("slot{index}"),colour,&format!("inventory:{colour}:v1")).map_err(|e|bad("PORT_INVALID",e.to_string()))
}
fn primitive(op:&Op)->Result<OperationTerm,Refusal> {
    let binding=serde_json::to_vec(&op.binding).map_err(|e|bad("BINDING_INVALID",e.to_string()))?;
    let spec=OperationSpec::new(OperationSpecInput {
        operation_id:&op.op_id,version:"v3",input_ports:op.inputs.iter().enumerate().map(|(i,c)|port(i,c)).collect::<Result<_,_>>()?,
        output_port:port(0,&op.output)?,executor_ref:"inventory-binding",executor_digest:&format!("sha256:{}",sha(&binding)),
        tool_refs:vec![],effects:vec![],invocation_grade:InvocationGrade::Discipline,authority_effect:AuthorityEffect::None,authority_ceiling:AuthorityEffect::None,
    }).map_err(|e|bad("OPERATION_INVALID",e.to_string()))?;
    Ok(OperationTerm::Primitive(spec))
}
fn term(w:&Value, ops:&BTreeMap<String,Op>, leaves:&mut Vec<String>, used:&mut Vec<String>, depth:usize)->Result<OperationTerm,Refusal> {
    if depth>32 || used.len()>128 || leaves.len()>128 { return Err(bad("TERM_LIMIT","maximum depth32 and128 occurrences")); }
    if let Some(colour)=w.as_str() { leaves.push(colour.into()); return Ok(OperationTerm::Identity(port(leaves.len()-1,colour)?)); }
    let obj=w.as_object().ok_or_else(||bad("WIRE_INVALID","wire must be input or op/args"))?;
    if obj.len()!=2 { return Err(bad("WIRE_INVALID","only op/args allowed")); }
    let id=w["op"].as_str().ok_or_else(||bad("WIRE_INVALID","missing op"))?;
    let op=ops.get(id).ok_or_else(||bad("UNKNOWN_OPERATION",id))?;
    let args=w["args"].as_array().ok_or_else(||bad("WIRE_INVALID","missing args"))?;
    if args.len()!=op.inputs.len() { return Err(bad("ARITY_MISMATCH",id)); }
    used.push(id.into());
    let mut result=primitive(op)?;
    let mut slot=0;
    for child in args {
        let child_term=term(child,ops,leaves,used,depth+1)?;
        let child_norm=normalize_term(&child_term).map_err(|e|bad(&e.code,e.message))?;
        let arity=child_norm.boundary().inputs.len();
        result=OperationTerm::Substitute { outer:Box::new(result),slot,inner:Box::new(child_term) };
        normalize_term(&result).map_err(|e|bad(&e.code,e.message))?;
        slot+=arity;
    }
    Ok(result)
}
fn eval(w:&Value,ops:&BTreeMap<String,Op>,values:&[Value],cursor:&mut usize)->Result<Value,Refusal> {
    if w.is_string() { let result=values.get(*cursor).cloned().ok_or_else(||bad("MISSING_INPUT","input occurrence"))?; *cursor+=1; return Ok(result); }
    let id=w["op"].as_str().ok_or_else(||bad("WIRE_INVALID","op"))?;
    let op=&ops[id];
    let args=w["args"].as_array().ok_or_else(||bad("WIRE_INVALID","args"))?.iter().map(|a|eval(a,ops,values,cursor)).collect::<Result<Vec<_>,_>>()?;
    let target=op.binding.as_ref().and_then(|v|v.get("target")).and_then(Value::as_str).unwrap_or("");
    match target {
        "native:identity" if args.len()==1 => Ok(args[0].clone()),
        "native:pair" if args.len()==2 => Ok(json!(args)),
        "native:sum" => {
            let mut total=0i64;
            for arg in args { total=total.checked_add(arg.as_i64().ok_or_else(||bad("VALUE_INVALID","exact i64 expected"))?).ok_or_else(||bad("VALUE_OVERFLOW","sum"))?; }
            Ok(json!(total))
        },
        _=>Err(bad("NOT_EXECUTABLE",format!("{id}: external host/PFP binding needs its registered executor"))),
    }
}
fn execution_plan(w:&Value,leaves:&mut usize,steps:&mut Vec<Value>,guards:&[Guard])->Value {
    if w.is_string() { let index=*leaves; *leaves+=1; return json!({"input":index}); }
    let args=w["args"].as_array().into_iter().flatten().map(|a|execution_plan(a,leaves,steps,guards)).collect::<Vec<_>>();
    let id=w["op"].as_str().unwrap_or("");
    let index=steps.len();
    steps.push(json!({"op_id":id,"args":args,"guards":guards.iter().filter(|g|g.guards==id).collect::<Vec<_>>()}));
    json!({"step":index})
}
pub fn execute(payload:&Value)->Result<Value,Refusal> {
    let req:Request=serde_json::from_value(payload.clone()).map_err(|e|bad("BAD_INPUT",e.to_string()))?;
    if req.command!="operad" || req.inventory_json.len()>49152 { return Err(bad("INVENTORY_INVALID","command or inventory limit")); }
    let inv:Inventory=serde_json::from_str(&req.inventory_json).map_err(|e|bad("INVENTORY_INVALID",e.to_string()))?;
    if !["omega.oewas.op_inventory.v2","omega.oewas.op_inventory.v3"].contains(&inv.schema_version.as_str()) { return Err(bad("INVENTORY_VERSION",inv.schema_version)); }
    let mut ops=BTreeMap::new(); let mut guards=vec![];
    for skill in inv.skills { for op in skill.ops { if ops.insert(op.op_id.clone(),op).is_some() { return Err(bad("DUPLICATE_OPERATION","inventory")); } } guards.extend(skill.anti_ops); }
    for g in &guards { let op=ops.get(&g.guards).ok_or_else(||bad("GUARD_SLOT_INVALID",&g.op_id))?; if op.inputs.get(g.slot)!=Some(&g.inspects) { return Err(bad("GUARD_SLOT_INVALID",&g.op_id)); } }
    let mut leaves=vec![]; let mut used=vec![];
    let parsed=term(&req.wire,&ops,&mut leaves,&mut used,0)?;
    let normalized=normalize_term(&parsed).map_err(|e|bad(&e.code,e.message))?;
    let selected:Vec<_>=guards.into_iter().filter(|g|used.contains(&g.guards)).collect();
    let output=if let Some(values)=req.values {
        if values.len()!=leaves.len() { return Err(bad("MISSING_INPUT","ordered leaf count")); }
        if !selected.is_empty() { return Err(bad("NOT_EXECUTABLE","host detectors are required")); }
        Some(eval(&req.wire,&ops,&values,&mut 0)?)
    } else { None };
    let mut plan=vec![]; let output_ref=execution_plan(&req.wire,&mut 0,&mut plan,&selected);
    Ok(json!({"execution_plan":plan,"output_ref":output_ref,"status":"VALID","term_id":normalized.canonical_id().map_err(|e|bad("TERM_INVALID",e.to_string()))?,"inventory_sha256":sha(req.inventory_json.as_bytes()),"operation_ids":used,"leaves":leaves,"guards":selected,"normal_form":normalized.to_canonical(),"output":output,"authority_effect":"None"}))
}


#[cfg(test)]
mod tests {
    use super::*;
    fn pair(id:&str)->OperationTerm {
        primitive(&Op {op_id:id.into(),inputs:vec!["Code".into(),"Code".into()],output:"Code".into(),binding:Some(json!({"kind":"host","target":"native:pair"}))}).unwrap()
    }
    fn sub(a:OperationTerm,i:usize,b:OperationTerm)->OperationTerm {
        OperationTerm::Substitute{outer:Box::new(a),slot:i,inner:Box::new(b)}
    }
    fn key(a:&OperationTerm)->String {normalize_term(a).unwrap().canonical_id().unwrap()}
    #[test]
    fn nested_reindexing_disjoint_interchange_and_units() {
        let (a,b,c)=(pair("a"),pair("b"),pair("c"));
        for i in 0..2 {for j in 0..2 {
            let lhs=sub(sub(a.clone(),i,b.clone()),i+j,c.clone());
            let rhs=sub(a.clone(),i,sub(b.clone(),j,c.clone()));
            assert_eq!(key(&lhs),key(&rhs));
        }}
        assert_eq!(key(&sub(sub(a.clone(),0,b.clone()),2,c.clone())),key(&sub(sub(a.clone(),1,c.clone()),0,b.clone())));
        assert_ne!(key(&sub(sub(a.clone(),1,b.clone()),0,c.clone())),key(&sub(a.clone(),1,sub(b,0,c))));
        for i in 0..2 {assert_eq!(key(&a),key(&sub(a.clone(),i,OperationTerm::Identity(port(i,"Code").unwrap()))));}
        assert_eq!(key(&a),key(&sub(OperationTerm::Identity(port(0,"Code").unwrap()),0,a.clone())));
    }
}
