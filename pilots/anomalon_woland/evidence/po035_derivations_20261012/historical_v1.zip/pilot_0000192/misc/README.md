Aggregate campaign material belongs in ../matrix; individual prompts and replies belong only in tests/test_XX.
