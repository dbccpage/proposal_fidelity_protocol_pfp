# pilot_0000193: Finite central-difference current conservation

AuthorityEffect: None.

This pilot preserves one foundational PO-035 seed and runs it through five sequential loops. Each loop has one live provider certificate stage and four deterministic stages: requested-lift handling, exact host checking, a negative mutation control, and a prompt-container refinement. This is **25 test capsules**, of which five are provider calls.

PFP Mode 12 (`PFP-12-SIMPLICIAL-CARRIER`) carries the finite simplicial/cochain structure. `PFP-14-TYPED-REFUSAL` fails closed when a response does not meet the strict JSON or exact-witness contract. The supplied carrier and the host checker confine every result to the named finite instance.

## Claim hygiene

- Supports: replayable observations about the finite carrier and a particular provider response.
- Does not support: a continuum limit, ambient geometry, physical causality, or a general model capability claim.
- Narrowest defensible claim: an exact host predicate accepted or rejected a retained candidate certificate.
- Next test: review the final tagged prompt container before dispatching a new independent round.

Run targeted preparation and replay with `py -3.12 -m omega_engine_education.pilots.po035_derivation_trials.run --replay`. Individual prompt and response custody remains inside `tests/test_XX`; aggregate findings and candidate artifacts are written under `../matrix/po035_derivation_loops_20261011/`.
