# PO-035 bounded derivation campaign

AuthorityEffect: None. This report consolidates finite provider observations after offline replay. It is not a claim about continuum limits, physical spacetime, ambient geometry, or a model class.

## Observed finite results

| Pilot | Task family | Provider calls | Host accepted |
|---|---|---:|---:|
| pilot_0000192 | relational_causal_cone_refinement | 5 | 0 |
| pilot_0000193 | discrete_current_conservation | 5 | 0 |
| pilot_0000194 | relational_spine_construction | 5 | 2 |
| pilot_0000195 | gauge_invariant_holonomy | 5 | 0 |
| pilot_0000196 | finite_l1_dual_certificate | 5 | 0 |

Each derivation has a possible finite solution only when its retained certificate appears in `consolidated_findings.yaml`. The result remains scoped to that carrier and exact host predicate. Each loop's deliberately mutated certificate was independently rejected by the same host checker.

## Learned artifacts and next-round prompts

`learning/candidate_artifacts.yaml` contains evidence-linked candidate skills, antiskills, rules, patterns, prompt families, and antibodies. Every artifact is `admitted: false`; none automatically changes a prompt policy or checker. The five user-review prompt containers under `final_prompts/` preserve the foundational seed and SPK-001 template relation while carrying their candidate artifact IDs.

## Replay and limits

The replay receipt binds each raw provider reply, exact request wire, prompt input, source environment, model identity, host verdict, deterministic lift stage, and mutation control. The campaign recorded 25 provider calls, 47308 reported tokens, and $0.000000 provider-reported cost under the configured $0.05 cap. No retry or provider fallback was used.
