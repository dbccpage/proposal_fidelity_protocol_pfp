"""Consolidate replayed PO-035 observations into unadmitted candidate artifacts."""
from __future__ import annotations

import json
from collections import Counter
from typing import Any

import yaml

from omega_engine_providers.infrastructure.wire import decode_reply

from .cases import BY_PILOT, CAMPAIGN, MAX_LOOPS, PILOTS, canonical, capsule, prompt_container, sha
from .checking import evaluate
from .prepare import write_once
from .run import load_input, replay


def root():
    return PILOTS / "matrix" / CAMPAIGN


def _read_yaml(path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def _payload(folder, document: dict[str, Any]) -> dict[str, Any] | None:
    raw = (folder / "provider_response.json").read_bytes()
    reply = decode_reply(raw)
    content = reply["choices"][0]["message"]["content"]
    return evaluate(document["task"], content)["payload"]


def _artifact(kind: str, candidate_id: str, prompt: dict[str, Any], provider: dict[str, Any], mutation: dict[str, Any], text: str) -> dict[str, Any]:
    return {
        "schema": "pfp.po035-candidate-artifact.v1",
        "candidate_id": candidate_id,
        "kind": kind,
        "admitted": False,
        "authority_effect": "None",
        "status": "candidate_only",
        "tied_prompt": {
            "prompt_id": prompt["prompt_id"],
            "original_seed_sha256": prompt["original_seed_sha256"],
            "user_prompt_sha256": sha(prompt["prompt"]["user_prompt"].encode("utf-8")),
            "prompt_path": f"{capsule(prompt['pilot_id'], prompt['loop'], 'provider_certificate')}/input.yaml",
        },
        "evidence": {
            "provider_response_sha256": provider["provider_response_sha256"],
            "host_status": provider["status"],
            "host_code": provider["code"],
            "negative_control": mutation["mutation_code"],
            "negative_control_rejected": mutation["negative_control_passed"],
        },
        "text": text,
    }


def _candidate_rows() -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    artifacts: list[dict[str, Any]] = []
    observations: list[dict[str, Any]] = []
    for definition in BY_PILOT.values():
        pilot = f"pilot_{definition['number']:07d}"
        for loop in range(1, MAX_LOOPS + 1):
            folder, prompt, _ = load_input(pilot, loop)
            provider = _read_yaml(folder / "response.yaml")
            mutation = _read_yaml(PILOTS / capsule(pilot, loop, "negative_mutation_control") / "response.yaml")
            grants = _read_yaml(PILOTS / capsule(pilot, loop, "grant_requested_lifts") / "response.yaml")
            payload = _payload(folder, prompt)
            prefix = f"PO035_{definition['number']}_{loop:02d}"
            status_text = "accepted" if provider["status"] == "HOST_ACCEPTED" else "refused"
            artifacts.extend([
                _artifact("skill", f"{prefix}_SKILL", prompt, provider, mutation,
                          f"Candidate procedure: substitute the proposed finite witness into the declared {definition['family']} carrier before emission; observed host outcome was {status_text}."),
                _artifact("antiskill", f"{prefix}_ANTISKILL", prompt, provider, mutation,
                          "Candidate prohibition: do not promote a finite carrier certificate into a continuum, ambient-geometric, or physical conclusion."),
                _artifact("pattern", f"{prefix}_PATTERN", prompt, provider, mutation,
                          "Candidate pattern: retain the original SPK-001 seed/template relation, then bind every new loop to the exact prior-lift receipt."),
                _artifact("rule", f"{prefix}_RULE", prompt, provider, mutation,
                          "Candidate rule: a typed envelope and a recomputed finite predicate must both pass; a response string is never a host verdict."),
                _artifact("antibody", f"{prefix}_ANTIBODY", prompt, provider, mutation,
                          f"Candidate antibody: reject the deterministic mutation class {mutation['mutation_code']} for this prompt/container binding."),
            ])
            observations.append({
                "pilot_id": pilot,
                "loop": loop,
                "prompt_id": prompt["prompt_id"],
                "provider_response_sha256": provider["provider_response_sha256"],
                "host_status": provider["status"],
                "host_code": provider["code"],
                "requested_lifts": grants["requested_lifts"],
                "granted_lifts": grants["granted_lifts"],
                "mutation_code": mutation["mutation_code"],
                "negative_control_passed": mutation["negative_control_passed"],
                "certificate_present": payload is not None,
            })
        first_prompt = prompt_container(pilot, 1, [])
        artifacts.append({
            "schema": "pfp.po035-candidate-artifact.v1",
            "candidate_id": f"PO035_{definition['number']}_PROMPT_FAMILY",
            "kind": "prompt_family",
            "admitted": False,
            "authority_effect": "None",
            "status": "candidate_only",
            "tied_prompt": {
                "prompt_id": first_prompt["prompt_id"],
                "original_seed_sha256": first_prompt["original_seed_sha256"],
                "user_prompt_sha256": sha(first_prompt["prompt"]["user_prompt"].encode("utf-8")),
            },
            "text": "Candidate prompt family: PFP-12 finite carrier with PFP-14 typed refusal, sequential lift grants, and an independent negative mutation control.",
        })
    return artifacts, observations


def _final_prompts(artifacts: list[dict[str, Any]], observations: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    final_root = root() / "final_prompts"
    for definition in BY_PILOT.values():
        pilot = f"pilot_{definition['number']:07d}"
        refinement = _read_yaml(PILOTS / capsule(pilot, MAX_LOOPS, "prompt_refinement") / "response.yaml")
        tags = [item["candidate_id"] for item in artifacts if item["candidate_id"].startswith(f"PO035_{definition['number']}_")]
        container = prompt_container(pilot, MAX_LOOPS, refinement["cumulative_granted_lifts"])
        container = dict(container)
        container.update({
            "schema": "pfp.po035-final-prompt.v1",
            "candidate_for_user_review": True,
            "authority_effect": "None",
            "generation_id": MAX_LOOPS + 1,
            "parent_prompt_id": container["prompt_id"],
            "candidate_artifact_ids": tags,
            "learning_status": "unadmitted_candidates_only",
        })
        container["prompt"] = dict(container["prompt"])
        container["prompt"]["user_prompt"] += (
            "\n\nCandidate learning tags (unadmitted; retain host verification): " + json.dumps(tags, separators=(",", ":"))
        )
        path = final_root / f"{pilot}.yaml"
        write_once(path, container)
        rows.append({
            "pilot_id": pilot,
            "path": path.relative_to(PILOTS).as_posix(),
            "final_prompt_sha256": sha(path.read_bytes()),
            "candidate_artifact_ids": tags,
        })
    return rows


def consolidate() -> dict[str, Any]:
    replayed = replay()
    required = len(BY_PILOT) * MAX_LOOPS
    if replayed.get("provider_completed") != required:
        raise ValueError("CAMPAIGN_INCOMPLETE")
    artifacts, observations = _candidate_rows()
    artifact_path = root() / "learning" / "candidate_artifacts.yaml"
    write_once(artifact_path, {
        "schema": "pfp.po035-candidate-artifact-set.v1",
        "authority_effect": "None",
        "admitted": False,
        "campaign": CAMPAIGN,
        "artifacts": artifacts,
    })
    final_prompts = _final_prompts(artifacts, observations)
    findings = []
    for definition in BY_PILOT.values():
        pilot = f"pilot_{definition['number']:07d}"
        subset = [row for row in observations if row["pilot_id"] == pilot]
        accepted = [row for row in subset if row["host_status"] == "HOST_ACCEPTED"]
        findings.append({
            "pilot_id": pilot,
            "task_family": definition["family"],
            "source_pointer": definition["source_pointer"],
            "provider_calls": len(subset),
            "statuses": dict(Counter(row["host_status"] for row in subset)),
            "granted_lifts": sorted({lift for row in subset for lift in row["granted_lifts"]}),
            "negative_controls_rejected": all(row["negative_control_passed"] for row in subset),
            "possible_solution": (
                {
                    "scope": "retained finite carrier certificate only",
                    "accepted_prompt_ids": [row["prompt_id"] for row in accepted],
                    "receipt_sha256s": [row["provider_response_sha256"] for row in accepted],
                }
                if accepted else None
            ),
            "limitation": "No finite trial promotes a continuum result, ambient geometry, physical causality, or general model capability claim.",
        })
    result = {
        "schema": "pfp.po035-consolidated-findings.v1",
        "authority_effect": "None",
        "campaign": CAMPAIGN,
        "replay": {key: value for key, value in replayed.items() if key != "rows"},
        "candidate_artifacts_path": artifact_path.relative_to(PILOTS).as_posix(),
        "findings": findings,
        "final_prompts": final_prompts,
    }
    write_once(root() / "consolidated_findings.yaml", result)
    write_once(root() / "consolidated_findings.json", canonical(result) + b"\n")
    table = "\n".join(
        f"| {row['pilot_id']} | {row['task_family']} | {row['provider_calls']} | {row['statuses'].get('HOST_ACCEPTED', 0)} |"
        for row in findings
    )
    report = f"""# PO-035 bounded derivation campaign

AuthorityEffect: None. This report consolidates finite provider observations after offline replay. It is not a claim about continuum limits, physical spacetime, ambient geometry, or a model class.

## Observed finite results

| Pilot | Task family | Provider calls | Host accepted |
|---|---|---:|---:|
{table}

Each derivation has a possible finite solution only when its retained certificate appears in `consolidated_findings.yaml`. The result remains scoped to that carrier and exact host predicate. Each loop's deliberately mutated certificate was independently rejected by the same host checker.

## Learned artifacts and next-round prompts

`learning/candidate_artifacts.yaml` contains evidence-linked candidate skills, antiskills, rules, patterns, prompt families, and antibodies. Every artifact is `admitted: false`; none automatically changes a prompt policy or checker. The five user-review prompt containers under `final_prompts/` preserve the foundational seed and SPK-001 template relation while carrying their candidate artifact IDs.

## Replay and limits

The replay receipt binds each raw provider reply, exact request wire, prompt input, source environment, model identity, host verdict, deterministic lift stage, and mutation control. The campaign recorded {replayed['provider_completed']} provider calls, {replayed['total_tokens']} reported tokens, and ${replayed['cost_microusd'] / 1_000_000:.6f} provider-reported cost under the configured $0.05 cap. No retry or provider fallback was used.
"""
    write_once(root() / "REPORT.md", report)
    return result


if __name__ == "__main__":
    final = consolidate()
    print(json.dumps({key: value for key, value in final.items() if key not in {"findings", "final_prompts"}}, indent=2))
