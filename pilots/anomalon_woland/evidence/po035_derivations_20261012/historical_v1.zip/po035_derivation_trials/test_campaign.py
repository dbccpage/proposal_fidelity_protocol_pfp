"""Targeted checks for finite PO-035 carrier gates and immutable planning."""
from __future__ import annotations

import json
from fractions import Fraction as Q
from itertools import product

import pytest
import yaml

from . import learn, run
from . import prepare as preparation
from .cases import BY_PILOT, MAX_LOOPS, PILOTS, STAGES, capsule, prompt_container, sha, task_for
from .checking import check_certificate, evaluate, mutation_is_rejected
from .prepare import prepare
from .run import grade, microusd


def reference(task):
    kind = task["kind"]
    if kind == "causal_cone_refinement":
        a, v = Q(task["a"]), Q(task["v_lr"])
        rows = []
        for index, event in enumerate(task["events"]):
            x, t = Q(event["x"]), Q(event["t"])
            if t < 0:
                rows.append({"index": index, "relation": "NON_FORWARD", "scaled_gap": "0"})
            elif x <= v * t:
                rows.append({"index": index, "relation": "INSIDE", "scaled_gap": "0"})
            else:
                rows.append({"index": index, "relation": "OUTSIDE", "scaled_gap": str((x - v * t) / a)})
        return {"classifications": rows}
    if kind == "discrete_current_conservation":
        time_part = (Q(task["nu_plus"]) - Q(task["nu_minus"])) / (2 * Q(task["dt"]))
        space_part = (Q(task["j_plus"]) - Q(task["j_minus"])) / (2 * Q(task["dx"]))
        return {"time_derivative": str(time_part), "space_derivative": str(space_part), "divergence": str(time_part + space_part)}
    if kind == "relational_spine_construction":
        order = task["required_order"]
        return {"stage_order": order, "transitions": [[order[i], order[i + 1]] for i in range(7)],
                "obstruction_stage": "obstruction", "curvature_stage": "curvature"}
    if kind == "gauge_invariant_holonomy":
        return {"d1_d0": ["0", "0", "0"], "curvature_before": "1", "curvature_after": "1", "gauge_invariant": True}
    if kind == "finite_l1_dual_certificate":
        loop = abs(int(task["delta"][0]))
        return {"potential": ["0", str(loop), "0"], "dual": ["1", "1", "1"],
                "residual": ["0", "0", "1"], "objective": "1"}
    raise AssertionError(kind)


def envelope(task):
    return {
        "derived_under_policy": "SPK-001",
        "requested_lifts": ["EXACT_RATIONAL_ARITHMETIC"],
        "certificate": reference(task),
        "summary": {
            "narrowest_defensible_thesis": "Finite carrier certificate only.",
            "evidence_scope": "The declared finite carrier.",
            "next_concrete_test": "Change one finite carrier datum.",
        },
        "process_integrity": {"seed_allows_theory_refutation": True, "should_continue": True},
    }


@pytest.mark.parametrize("pilot,loop", product(sorted(BY_PILOT), range(1, MAX_LOOPS + 1)))
def test_independent_finite_checker_and_negative_control(pilot, loop):
    task = task_for(pilot, loop)
    witness = reference(task)
    assert check_certificate(task, witness)
    payload = envelope(task)
    assert evaluate(task, json.dumps(payload))["status"] == "HOST_ACCEPTED"
    mutation = mutation_is_rejected(task, payload)
    assert mutation["negative_control_passed"] is True


@pytest.mark.parametrize("pilot", sorted(BY_PILOT))
def test_each_loop_changes_or_reorders_a_real_carrier(pilot):
    carriers = [task_for(pilot, loop) for loop in range(1, MAX_LOOPS + 1)]
    assert len({sha(json.dumps(item, sort_keys=True).encode()) for item in carriers}) == MAX_LOOPS


@pytest.mark.parametrize("pilot,loop", product(sorted(BY_PILOT), range(1, MAX_LOOPS + 1)))
def test_prompt_container_preserves_seed_and_excludes_answer_oracle(pilot, loop):
    prompt = prompt_container(pilot, loop, ["FINITE_SCOPE_FENCE"] if loop > 1 else [])
    public = prompt["prompt"]["system_prompt"] + prompt["prompt"]["user_prompt"]
    assert prompt["original_seed"] in prompt["prompt"]["user_prompt"]
    assert prompt["prompt_template_sha256"]
    assert "expected_answer" not in public
    assert "WITNESS_VALID" not in public
    assert "private reasoning" in prompt["prompt"]["user_prompt"]
    assert prompt["task"] == task_for(pilot, loop)


def test_strict_parser_and_numeric_coercion_refuse():
    pilot = "pilot_0000196"
    task = task_for(pilot, 1)
    valid = envelope(task)
    valid["certificate"]["objective"] = 1
    assert evaluate(task, json.dumps(valid))["status"] == "TYPED_REFUSAL"
    assert evaluate(task, '{"certificate":{},"certificate":{}}')["status"] == "TYPED_REFUSAL"


def test_grade_requires_usage_cost_and_exact_model():
    prompt = prompt_container("pilot_0000192", 1, [])
    raw = json.dumps({
        "id": "fixture-generation", "model": "fixture/model",
        "choices": [{"message": {"content": json.dumps(envelope(prompt["task"]))}, "finish_reason": "stop"}],
        "usage": {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2, "cost": 0},
    }).encode()
    result, _ = grade(prompt, raw, "fixture/model")
    assert result["status"] == "HOST_ACCEPTED"
    for value in (None, True, "NaN", -1):
        with pytest.raises(ValueError):
            microusd(value)


def test_pricing_accepts_a_zero_priced_route_without_cache_fields(monkeypatch):
    raw = json.dumps({
        "data": [{
            "id": "fixture/free",
            "pricing": {"prompt": "0", "completion": "0"},
            "supported_parameters": ["max_tokens", "temperature", "reasoning", "seed"],
        }],
    }).encode()

    class Reply:
        def read(self):
            return raw

        def __enter__(self):
            return self

        def __exit__(self, *_):
            return False

    monkeypatch.setattr(run.urllib.request, "urlopen", lambda *_args, **_kwargs: Reply())
    price, catalog = run.pricing("fixture/free")
    assert catalog == raw
    assert price["row"]["pricing"] == {"prompt": "0", "completion": "0"}


def test_materialized_pilots_are_typed_and_have_25_capsules():
    prepare()
    from omega_engine_education.pfp.domain import PilotSpec, SeedPrompt
    from omega_engine_education.pfp.domain.types.rewrite_test_plan import RewriteTestPlan

    for definition in BY_PILOT.values():
        pilot = f"pilot_{definition['number']:07d}"
        folder = PILOTS / pilot
        PilotSpec.from_yaml(folder / "spec.yaml")
        SeedPrompt.from_yaml(folder / "seed.yaml")
        plan = RewriteTestPlan.from_yaml(folder / "testplan.yaml")
        assert len(plan.tests) == 25
        tests = sorted((folder / "tests").glob("test_[0-9][0-9]"))
        assert len(tests) == 25
        assert all((path / "test_spec.yaml").is_file() for path in tests)
        assert sum("provider_certificate" in item.test_id for item in plan.tests) == 5


def test_campaign_plan_declares_host_vs_provider_stages():
    plan = yaml.safe_load((PILOTS / "matrix" / "po035_derivation_loops_20261011.yaml").read_text(encoding="utf-8"))
    assert plan["tests"] == 125
    assert plan["provider_calls"] == 25
    assert plan["per_pilot_tests"] == 25
    assert {row["stage"] for row in plan["cases"]} == set(STAGES)
    assert sum(row["observation_mode"] == "INDEPENDENT_MODEL_TRIAL" for row in plan["cases"]) == 25
    assert sum(row["observation_mode"] == "HOST_DETERMINISTIC_STAGE" for row in plan["cases"]) == 100


def test_loop_stages_grant_lifts_and_materialize_next_prompt(tmp_path, monkeypatch):
    monkeypatch.setattr(run, "PILOTS", tmp_path)
    pilot = "pilot_0000195"
    task = task_for(pilot, 1)
    receipt = {
        "provider_response_sha256": "a" * 64,
        "status": "HOST_ACCEPTED",
        "code": "WITNESS_VALID",
    }
    payload = envelope(task)
    payload["requested_lifts"] = ["ORIENTATION_CONVENTION", "UNRECOGNIZED_LIFT"]
    cumulative = run._complete_loop(pilot, 1, receipt, payload, [])
    assert cumulative == ["ORIENTATION_CONVENTION"]
    grant = yaml.safe_load((tmp_path / capsule(pilot, 1, "grant_requested_lifts") / "response.yaml").read_text())
    assert grant["denied_lifts"] == ["UNRECOGNIZED_LIFT"]
    next_prompt = tmp_path / capsule(pilot, 2, "provider_certificate") / "input.yaml"
    assert next_prompt.is_file()
    assert yaml.safe_load(next_prompt.read_text())["granted_lifts"] == cumulative


def test_source_manifest_binds_current_source_bytes():
    manifest = yaml.safe_load((PILOTS / "matrix" / "po035_derivation_loops_20261011" / "source_manifest.yaml").read_text(encoding="utf-8"))
    assert manifest["files"]
    for row in manifest["files"]:
        assert sha((PILOTS.parents[1] / row["path"]).read_bytes()) == row["sha256"]


def test_learning_refuses_to_manufacture_results_for_a_planned_campaign(tmp_path, monkeypatch):
    monkeypatch.setattr(preparation, "PILOTS", tmp_path)
    monkeypatch.setattr(run, "PILOTS", tmp_path)
    monkeypatch.setattr(learn, "PILOTS", tmp_path)
    with pytest.raises(ValueError, match="CAMPAIGN_INCOMPLETE"):
        learn.consolidate()
