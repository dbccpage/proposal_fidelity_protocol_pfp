"""Finite PO-035 carriers and immutable prompt containers.

The carriers are deliberately finite.  They exercise named derivations from
PO-035 without treating a finite response as support for its broader prose
claims.  Public prompt containers carry no expected certificate.
"""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any

import yaml

ROOT = Path(__file__).resolve().parents[3]
PILOTS = ROOT / "omega_engine_education" / "pilots"
CAMPAIGN = "po035_derivation_loops_20261011"
SOURCE = (
    "omega_engine_atlas/coda_atlas/F004_papers/002_projection_obstruction/"
    "035_zero_container_relational_spacetime_and_witness_holonomy"
)
MODE = "PFP-12-SIMPLICIAL-CARRIER"
REFUSAL_GATE = "PFP-14-TYPED-REFUSAL"
MAX_LOOPS = 5
STAGES = (
    "provider_certificate",
    "grant_requested_lifts",
    "host_witness_check",
    "negative_mutation_control",
    "prompt_refinement",
)


def canonical(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def sha(value: bytes | bytearray | memoryview) -> str:
    return hashlib.sha256(bytes(value)).hexdigest()


def stage_index(loop: int, stage: str) -> int:
    if loop not in range(1, MAX_LOOPS + 1):
        raise ValueError("LOOP_OUT_OF_RANGE")
    return (loop - 1) * len(STAGES) + STAGES.index(stage)


def capsule(pilot_id: str, loop: int, stage: str) -> str:
    return f"{pilot_id}/tests/test_{stage_index(loop, stage):02d}"


def _causal(loop: int) -> dict[str, Any]:
    velocity = f"{loop + 2}/2"
    a = "1/4"
    # The three points include a forward-cone point, a finite outside gap and a
    # negative-time refusal case.  None encodes a continuum conclusion.
    return {
        "kind": "causal_cone_refinement",
        "a": a,
        "v_lr": velocity,
        "events": [
            {"x": velocity, "t": "1"},
            {"x": f"{loop + 3}/2", "t": "1"},
            {"x": "0", "t": "-1"},
        ],
        "scope": "finite_lattice_envelope_only",
    }


def _current(loop: int) -> dict[str, Any]:
    # Central differences evaluate to (loop)/(2) and -(loop)/(2).
    return {
        "kind": "discrete_current_conservation",
        "dt": "1",
        "dx": "1",
        "nu_minus": "0",
        "nu_plus": str(loop),
        "j_minus": str(loop),
        "j_plus": "0",
        "scope": "finite_central_difference_only",
    }


_SPINE = (
    "presentation",
    "family",
    "representation",
    "fiber_bundle",
    "fact",
    "compression",
    "obstruction",
    "curvature",
)


def _spine(loop: int) -> dict[str, Any]:
    offset = (loop * 3) % len(_SPINE)
    return {
        "kind": "relational_spine_construction",
        "shuffled_stages": list(_SPINE[offset:] + _SPINE[:offset]),
        "required_order": list(_SPINE),
        "scope": "formal_vocabulary_order_only",
    }


def _holonomy(loop: int) -> dict[str, Any]:
    # d1*d0=0 for an oriented triangle.  The chosen alpha alters the edges
    # but cannot alter the finite d1 curvature scalar.
    return {
        "kind": "gauge_invariant_holonomy",
        "d0": [["-1", "1", "0"], ["0", "-1", "1"], ["1", "0", "-1"]],
        "d1": [["1", "1", "1"]],
        "delta": [str(loop), str(-loop), "1"],
        "alpha": ["0", str(loop), "0"],
        "scope": "finite_cochain_identity_only",
    }


def _dual(loop: int) -> dict[str, Any]:
    return {
        "kind": "finite_l1_dual_certificate",
        "d0": [["-1", "1", "0"], ["0", "-1", "1"], ["1", "0", "-1"]],
        "delta": [str(loop), str(-loop), "1"],
        "weights": ["1", "1", "1"],
        "scope": "finite_l1_quotient_only",
    }


PILOT_DEFINITIONS: tuple[dict[str, Any], ...] = (
    {
        "number": 192,
        "slug": "causal-cone-refinement",
        "family": "relational_causal_cone_refinement",
        "checker": "PFP-192-CAUSAL-CONE-REFINEMENT",
        "title": "Finite causal-cone refinement",
        "source_pointer": "PO-035 §3",
        "seed": (
            "On a declared finite lattice carrier, classify each supplied event as inside, outside, or "
            "non-forward relative to its stated Lieb-Robinson envelope. Return the exact scaled outside gap. "
            "Do not infer a continuum limit or physical light cone."
        ),
        "task": _causal,
    },
    {
        "number": 193,
        "slug": "central-difference-current",
        "family": "discrete_current_conservation",
        "checker": "PFP-193-DISCRETE-CURRENT-CONSERVATION",
        "title": "Finite central-difference current conservation",
        "source_pointer": "PO-035 §4",
        "seed": (
            "Compute the supplied finite central time and space differences, then certify their exact sum. "
            "The certificate is restricted to the listed stencil and does not establish continuum conservation."
        ),
        "task": _current,
    },
    {
        "number": 194,
        "slug": "relational-spine",
        "family": "relational_spine_construction",
        "checker": "PFP-194-RELATIONAL-SPINE",
        "title": "Eight-stage relational spine",
        "source_pointer": "PO-035 §5",
        "seed": (
            "Recover the declared eight-stage relational vocabulary in its mandated order and list adjacent "
            "transitions. Treat it as a scoped formal vocabulary, not an ambient geometric construction."
        ),
        "task": _spine,
    },
    {
        "number": 195,
        "slug": "gauge-holonomy",
        "family": "gauge_invariant_holonomy",
        "checker": "PFP-195-GAUGE-HOLONOMY",
        "title": "Gauge-invariant finite cochain holonomy",
        "source_pointer": "PO-035 §6",
        "seed": (
            "Use only the supplied finite cochain matrices to check d1*d0, calculate curvature before and "
            "after the declared gauge increment, and state whether the listed scalar is invariant."
        ),
        "task": _holonomy,
    },
    {
        "number": 196,
        "slug": "l1-dual-witness",
        "family": "finite_l1_dual_certificate",
        "checker": "PFP-196-FINITE-L1-DUAL-CERTIFICATE",
        "title": "Finite L1 primal-dual witness",
        "source_pointer": "PO-035 §7",
        "seed": (
            "Produce an exact finite primal-dual certificate for the declared L1 quotient problem. Verify "
            "residual, dual feasibility, and zero gap without claiming a continuous operator result."
        ),
        "task": _dual,
    },
)

BY_NUMBER = {row["number"]: row for row in PILOT_DEFINITIONS}
BY_PILOT = {f"pilot_{row['number']:07d}": row for row in PILOT_DEFINITIONS}
ALLOWED_LIFTS = (
    "EXACT_RATIONAL_ARITHMETIC",
    "ORIENTATION_CONVENTION",
    "FINITE_SCOPE_FENCE",
    "DUAL_FEASIBILITY_CHECK",
    "CENTRAL_DIFFERENCE_STENCIL",
    "ORDERED_STAGE_LEGEND",
)


def pilot_id(number: int) -> str:
    if number not in BY_NUMBER:
        raise ValueError("UNKNOWN_PO035_PILOT")
    return f"pilot_{number:07d}"


def task_for(pilot: str, loop: int) -> dict[str, Any]:
    if pilot not in BY_PILOT:
        raise ValueError("UNKNOWN_PO035_PILOT")
    if loop not in range(1, MAX_LOOPS + 1):
        raise ValueError("LOOP_OUT_OF_RANGE")
    return copy.deepcopy(BY_PILOT[pilot]["task"](loop))


def template_bytes() -> bytes:
    return (PILOTS / "pilot_0000000" / "prompt_template.yaml").read_bytes()


def template() -> dict[str, Any]:
    return yaml.safe_load(template_bytes())


def original_seed(pilot: str) -> str:
    return BY_PILOT[pilot]["seed"]


def source_files() -> list[Path]:
    root = ROOT / SOURCE
    return [path for path in sorted(root.rglob("*")) if path.is_file() and "__pycache__" not in path.parts]


def prompt_container(pilot: str, loop: int, granted_lifts: list[str]) -> dict[str, Any]:
    """Compile the exact SPK-001-wrapped prompt dispatched for one loop."""
    if any(item not in ALLOWED_LIFTS for item in granted_lifts):
        raise ValueError("UNLICENSED_LIFT")
    from .checking import envelope_schema

    definition = BY_PILOT[pilot]
    source_template = template()
    task = task_for(pilot, loop)
    schema = envelope_schema(task)
    prompt_id = f"prompt_{definition['number']:07d}_loop_{loop:02d}"
    user = (
        "This is a bounded finite derivation trial. Use the declared carrier only and return one JSON object, "
        "with no Markdown and no private reasoning. Preserve the supplied scope fence in the summary.\n\n"
        f"Original foundational seed ({definition['source_pointer']}):\n{original_seed(pilot)}\n\n"
        f"PFP mode: {MODE}. Refusal gate: {REFUSAL_GATE}.\n"
        f"Granted lifts from prior loops: {json.dumps(granted_lifts, separators=(',', ':'))}\n"
        "You may request only a genuinely useful additional lift in requested_lifts; an unknown lift will be "
        "recorded as denied and does not license new structure.\n\n"
        f"Finite carrier for loop {loop}:\n{json.dumps(task, ensure_ascii=False, separators=(',', ':'))}\n\n"
        "Response schema:\n"
        f"{json.dumps(schema, ensure_ascii=False, separators=(',', ':'))}"
    )
    return {
        "schema": "pfp.po035-stage-input.v1",
        "authority_effect": "None",
        "campaign": CAMPAIGN,
        "pilot_id": pilot,
        "prompt_id": prompt_id,
        "loop": loop,
        "stage": "provider_certificate",
        "mode": MODE,
        "refusal_gate": REFUSAL_GATE,
        "original_seed": original_seed(pilot),
        "original_seed_sha256": sha(original_seed(pilot).encode("utf-8")),
        "prompt_template_sha256": sha(template_bytes()),
        "template_lineage": source_template["lineage"],
        "granted_lifts": list(granted_lifts),
        "task": task,
        "prompt": {
            "system_prompt": source_template["system_prompt"],
            "user_prompt": user,
            "response_schema": schema,
        },
    }
