"""Independent finite host gates for the PO-035 derivation pilots.

No checker consumes a stored expected answer.  Each recomputes the relevant
finite predicate from the carrier and accepts alternative L1 potentials where
they satisfy the same exact constraints.
"""
from __future__ import annotations

import copy
import re
from fractions import Fraction as Q
from typing import Any

from jsonschema import Draft202012Validator, validators
from jsonschema.exceptions import ValidationError

from omega_engine_education.pfp.domain.pilots.checker_registry import strict_json

StrictValidator = validators.extend(
    Draft202012Validator,
    type_checker=Draft202012Validator.TYPE_CHECKER.redefine("integer", lambda _, value: type(value) is int),
)
RATIONAL = {"type": "string", "pattern": r"^-?(0|[1-9][0-9]*)(/[1-9][0-9]*)?$", "maxLength": 80}
NONNEGATIVE_INTEGER = {"type": "integer", "minimum": 0}
LIFT = {"type": "string", "pattern": r"^[A-Z][A-Z0-9_]{2,80}$"}


def record(**properties: Any) -> dict[str, Any]:
    return {"type": "object", "properties": properties, "required": list(properties), "additionalProperties": False}


def array(items: dict[str, Any], length: int | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {"type": "array", "items": items, "maxItems": 100}
    if length is not None:
        result.update({"minItems": length, "maxItems": length})
    return result


def rational(value: Any) -> Q:
    if type(value) is not str or not re.fullmatch(RATIONAL["pattern"], value):
        raise ValueError("EXACT_RATIONAL_REQUIRED")
    return Q(value)


def matrix_vector(matrix: list[list[str]], vector: list[Q]) -> list[Q]:
    if not matrix or any(len(row) != len(vector) for row in matrix):
        raise ValueError("DIMENSION_MISMATCH")
    return [sum((rational(value) * item for value, item in zip(row, vector)), Q(0)) for row in matrix]


def transpose(matrix: list[list[str]]) -> list[list[str]]:
    if not matrix or not matrix[0] or any(len(row) != len(matrix[0]) for row in matrix):
        raise ValueError("MATRIX_SHAPE_INVALID")
    return [list(row) for row in zip(*matrix)]


def answer_schema(task: dict[str, Any]) -> dict[str, Any]:
    kind = task["kind"]
    if kind == "causal_cone_refinement":
        event = record(index=NONNEGATIVE_INTEGER, relation={"enum": ["INSIDE", "OUTSIDE", "NON_FORWARD"]}, scaled_gap=RATIONAL)
        return record(classifications=array(event, len(task["events"])))
    if kind == "discrete_current_conservation":
        return record(time_derivative=RATIONAL, space_derivative=RATIONAL, divergence=RATIONAL)
    if kind == "relational_spine_construction":
        transition = array({"type": "string", "minLength": 1, "maxLength": 80}, 2)
        return record(stage_order=array({"type": "string", "minLength": 1, "maxLength": 80}, 8),
                      transitions=array(transition, 7), obstruction_stage={"const": "obstruction"},
                      curvature_stage={"const": "curvature"})
    if kind == "gauge_invariant_holonomy":
        return record(d1_d0=array(RATIONAL, len(task["d0"][0])), curvature_before=RATIONAL,
                      curvature_after=RATIONAL, gauge_invariant={"type": "boolean"})
    if kind == "finite_l1_dual_certificate":
        width = len(task["d0"][0])
        height = len(task["d0"])
        return record(potential=array(RATIONAL, width), dual=array(RATIONAL, height),
                      residual=array(RATIONAL, height), objective=RATIONAL)
    raise ValueError("UNKNOWN_TASK_KIND")


def envelope_schema(task: dict[str, Any]) -> dict[str, Any]:
    summary = record(narrowest_defensible_thesis={"type": "string", "minLength": 1, "maxLength": 320},
                     evidence_scope={"type": "string", "minLength": 1, "maxLength": 320},
                     next_concrete_test={"type": "string", "minLength": 1, "maxLength": 320})
    integrity = record(seed_allows_theory_refutation={"type": "boolean"}, should_continue={"type": "boolean"})
    return record(derived_under_policy={"const": "SPK-001"}, requested_lifts=array(LIFT),
                  certificate=answer_schema(task), summary=summary, process_integrity=integrity)


def _causal(task: dict[str, Any], answer: dict[str, Any]) -> bool:
    a, v = rational(task["a"]), rational(task["v_lr"])
    expected = []
    for index, event in enumerate(task["events"]):
        x, t = rational(event["x"]), rational(event["t"])
        if t < 0:
            expected.append({"index": index, "relation": "NON_FORWARD", "scaled_gap": "0"})
        elif x <= v * t:
            expected.append({"index": index, "relation": "INSIDE", "scaled_gap": "0"})
        else:
            expected.append({"index": index, "relation": "OUTSIDE", "scaled_gap": str((x - v * t) / a)})
    return answer["classifications"] == expected


def _current(task: dict[str, Any], answer: dict[str, Any]) -> bool:
    time_part = (rational(task["nu_plus"]) - rational(task["nu_minus"])) / (2 * rational(task["dt"]))
    space_part = (rational(task["j_plus"]) - rational(task["j_minus"])) / (2 * rational(task["dx"]))
    return (rational(answer["time_derivative"]) == time_part
            and rational(answer["space_derivative"]) == space_part
            and rational(answer["divergence"]) == time_part + space_part)


def _spine(task: dict[str, Any], answer: dict[str, Any]) -> bool:
    order = task["required_order"]
    return (answer["stage_order"] == order
            and answer["transitions"] == [[order[index], order[index + 1]] for index in range(len(order) - 1)]
            and answer["obstruction_stage"] == "obstruction"
            and answer["curvature_stage"] == "curvature")


def _holonomy(task: dict[str, Any], answer: dict[str, Any]) -> bool:
    delta = list(map(rational, task["delta"]))
    alpha = list(map(rational, task["alpha"]))
    d0_alpha = matrix_vector(task["d0"], alpha)
    d1_d0 = [
        sum((rational(task["d1"][0][edge]) * rational(task["d0"][edge][column])
             for edge in range(len(task["d0"]))), Q(0))
        for column in range(len(task["d0"][0]))
    ]
    before = matrix_vector(task["d1"], delta)[0]
    after = matrix_vector(task["d1"], [left + right for left, right in zip(delta, d0_alpha)])[0]
    return (list(map(rational, answer["d1_d0"])) == d1_d0
            and rational(answer["curvature_before"]) == before
            and rational(answer["curvature_after"]) == after
            and answer["gauge_invariant"] is (before == after))


def _dual(task: dict[str, Any], answer: dict[str, Any]) -> bool:
    matrix = task["d0"]
    delta = list(map(rational, task["delta"]))
    weights = list(map(rational, task["weights"]))
    potential = list(map(rational, answer["potential"]))
    dual = list(map(rational, answer["dual"]))
    residual = [left - right for left, right in zip(delta, matrix_vector(matrix, potential))]
    primal = sum((weight * abs(item) for weight, item in zip(weights, residual)), Q(0))
    dual_value = sum((item * witness for item, witness in zip(delta, dual)), Q(0))
    return (list(map(rational, answer["residual"])) == residual
            and all(item == 0 for item in matrix_vector(transpose(matrix), dual))
            and all(abs(item) <= weight for item, weight in zip(dual, weights))
            and rational(answer["objective"]) == primal == dual_value)


def check_certificate(task: dict[str, Any], answer: dict[str, Any]) -> bool:
    StrictValidator(answer_schema(task)).validate(answer)
    kind = task["kind"]
    if kind == "causal_cone_refinement":
        return _causal(task, answer)
    if kind == "discrete_current_conservation":
        return _current(task, answer)
    if kind == "relational_spine_construction":
        return _spine(task, answer)
    if kind == "gauge_invariant_holonomy":
        return _holonomy(task, answer)
    if kind == "finite_l1_dual_certificate":
        return _dual(task, answer)
    raise ValueError("UNKNOWN_TASK_KIND")


def evaluate(task: dict[str, Any], raw: str) -> dict[str, Any]:
    """Parse a provider content string and return a fail-closed host outcome."""
    try:
        payload = strict_json(raw)
        StrictValidator(envelope_schema(task)).validate(payload)
        valid = check_certificate(task, payload["certificate"])
        return {
            "status": "HOST_ACCEPTED" if valid else "TYPED_REFUSAL",
            "code": "WITNESS_VALID" if valid else "WITNESS_INVALID",
            "payload": payload,
        }
    except (ValueError, TypeError, KeyError, ZeroDivisionError) as exc:
        return {"status": "TYPED_REFUSAL", "code": type(exc).__name__, "payload": None}
    except ValidationError:
        return {"status": "TYPED_REFUSAL", "code": "SCHEMA_INVALID", "payload": None}


def mutated_certificate(task: dict[str, Any], payload: dict[str, Any] | None) -> dict[str, Any]:
    """Return a deterministic malformed or wrong witness for a negative control."""
    if payload is None or type(payload.get("certificate")) is not dict:
        return {"not_a_certificate": True}
    answer = copy.deepcopy(payload["certificate"])
    kind = task["kind"]
    if kind == "causal_cone_refinement":
        answer["classifications"][0]["relation"] = "OUTSIDE"
    elif kind == "discrete_current_conservation":
        answer["divergence"] = "1"
    elif kind == "relational_spine_construction":
        answer["stage_order"] = list(reversed(answer["stage_order"]))
    elif kind == "gauge_invariant_holonomy":
        answer["gauge_invariant"] = not answer["gauge_invariant"]
    elif kind == "finite_l1_dual_certificate":
        answer["objective"] = str(rational(answer["objective"]) + 1)
    else:
        raise ValueError("UNKNOWN_TASK_KIND")
    return answer


def mutation_is_rejected(task: dict[str, Any], payload: dict[str, Any] | None) -> dict[str, Any]:
    candidate = mutated_certificate(task, payload)
    try:
        accepted = check_certificate(task, candidate)
        return {"negative_control_passed": not accepted, "mutation_code": "WITNESS_INVALID" if not accepted else "MUTATION_ACCEPTED"}
    except (ValueError, TypeError, KeyError, ZeroDivisionError, ValidationError) as exc:
        return {"negative_control_passed": True, "mutation_code": type(exc).__name__}
