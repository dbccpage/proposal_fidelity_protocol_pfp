"""Materialize the five PO-035 pilot directories without manufacturing results."""
from __future__ import annotations

import json
import subprocess
from typing import Any

import yaml

from .cases import (
    CAMPAIGN,
    MAX_LOOPS,
    MODE,
    PILOT_DEFINITIONS,
    PILOTS,
    REFUSAL_GATE,
    ROOT,
    SOURCE,
    STAGES,
    capsule,
    original_seed,
    pilot_id,
    prompt_container,
    sha,
    source_files,
    stage_index,
    template_bytes,
)


def write_once(path, value: bytes | str | dict[str, Any] | list[Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(value, bytes):
        data = value
    elif isinstance(value, str):
        data = value.encode("utf-8")
    else:
        data = yaml.safe_dump(value, sort_keys=False, allow_unicode=True).encode("utf-8")
    if path.exists():
        if path.read_bytes() != data:
            raise ValueError(f"IMMUTABLE_ARTIFACT_CONFLICT: {path}")
        return
    with path.open("xb") as stream:
        stream.write(data)


def source_manifest() -> dict[str, Any]:
    rows = []
    for path in source_files():
        raw = path.read_bytes()
        rows.append({"path": path.relative_to(ROOT).as_posix(), "sha256": sha(raw), "bytes": len(raw)})
    return {
        "schema": "pfp.po035-source-manifest.v1",
        "authority_effect": "None",
        "source_root": SOURCE,
        "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "files": rows,
    }


def _spec(definition: dict[str, Any]) -> dict[str, Any]:
    pilot = pilot_id(definition["number"])
    return {
        "schema": "pfp.pilot-spec.v1",
        "authority_effect": "None",
        "pilot_id": pilot,
        "prompt_id": f"prompt_{definition['number']:07d}",
        "generation_id": 1,
        "phase": "po035_bounded_derivation_loops",
        "split": "development",
        "coordinates": {
            "task_family": definition["family"],
            "difficulty_rung": 3,
            "representation_rewrite": "structured_spans",
            "rewrite_count": MAX_LOOPS,
            "legend_present": False,
            "mode": MODE,
            "stage_count": len(STAGES),
            "pass_count": MAX_LOOPS,
            "single_shot": False,
            "antibody_active": True,
            "antibody_ids": ["AB_PO035_TYPED_WITNESS", "AB_PO035_SCOPE_FENCE"],
            "model_class": "8B",
            "model_id": "nvidia/nemotron-3.5-lightning:free",
            "temperature": 0.0,
            "target_spend_usd": 0.05,
        },
        "ingress": {
            "task_mode_fidelity": "finite_deduction",
            "variable_identifier_permutation": "canonical",
            "floating_point_approximation_risk": "exact_rational",
            "arm_template": "A0",
            "missing_premise": "answerable",
            "cohomology_defect_class": "curvature_defect",
            "magma_associativity_type": "none",
        },
        "host_gate": {
            "checker_id": definition["checker"],
            "response_schema": "PO035 certificate envelope, exact rational task-specific fields",
            "residual_logging": True,
            "structure_delta_metric": "exact_rational_delta",
            "expected_outcome": "HOST_CHECKED_WITNESS",
        },
        "test_plan": {"path": "testplan.yaml", "tests": 25, "cases": MAX_LOOPS, "seed": "seed.yaml", "prompt_template": "prompt_template.yaml"},
        "responses": {"directory": "tests"},
        "models": ["nvidia/nemotron-3.5-lightning:free"],
    }


def _seed(definition: dict[str, Any]) -> dict[str, Any]:
    pilot = pilot_id(definition["number"])
    return {
        "schema": "pfp.seed-prompt.v1",
        "authority_effect": "None",
        "pilot_id": pilot,
        "task_family": definition["family"],
        "difficulty_rung": 3,
        "request_id": f"{pilot}_po035_seed",
        "input_typing": {
            "lexical_alphabet": "UTF-8 exact-rational finite carrier",
            "syntactic_category": "FiniteDerivationCertificate",
            "semantic_carrier": definition["family"],
            "dialect_tier": "SPK-001",
            "boundary_format": "JSON within prompt container",
        },
        "seed_prompt": original_seed(pilot),
        "expected_outcome": {"answer": None, "status": "HOST_CHECKED_WITNESS"},
    }


def _testplan(definition: dict[str, Any]) -> dict[str, Any]:
    pilot = pilot_id(definition["number"])
    tests = []
    for loop in range(1, MAX_LOOPS + 1):
        for stage in STAGES:
            index = stage_index(loop, stage)
            tests.append({
                "test_id": f"{pilot}_{loop:02d}_{stage}",
                "kind": "wrapped_provider_trial" if stage == "provider_certificate" else "host_deterministic_stage",
                "artifact": f"tests/test_{index:02d}/input.yaml",
                "prompt_id": f"prompt_{definition['number']:07d}_loop_{loop:02d}",
                "case_id": f"loop_{loop:02d}",
            })
    return {
        "schema": "pfp.rewrite-test-plan.v1",
        "authority_effect": "None",
        "pilot_id": pilot,
        "spec": "spec.yaml",
        "responses": "tests",
        "description": (
            "Five sequential loops, each containing one independent provider certificate and four deterministic "
            "custody/check/refinement stages. Provider calls are not inflated by host stages."
        ),
        "prompt_template": {"path": "prompt_template.yaml", "shared_by_all_tests": True},
        "seed": {"path": "seed.yaml", "seed_prompt": original_seed(pilot), "prompt_id": f"prompt_{definition['number']:07d}"},
        "expected_outcome": {"answer": None, "status": "HOST_CHECKED_WITNESS"},
        "counts": {"unique_cases": MAX_LOOPS, "rewrite_files": MAX_LOOPS, "tests": MAX_LOOPS * len(STAGES)},
        "tests": tests,
    }


def _test_spec(definition: dict[str, Any], loop: int, stage: str) -> dict[str, Any]:
    pilot = pilot_id(definition["number"])
    return {
        "schema": "pfp.test-spec.v1",
        "authority_effect": "None",
        "campaign": CAMPAIGN,
        "pilot_id": pilot,
        "test_id": f"{pilot}_{loop:02d}_{stage}",
        "test_index": stage_index(loop, stage),
        "loop": loop,
        "stage": stage,
        "task_family": definition["family"],
        "checker_id": definition["checker"],
        "mode": MODE,
        "refusal_gate": REFUSAL_GATE,
        "observation_mode": "INDEPENDENT_MODEL_TRIAL" if stage == "provider_certificate" else "HOST_DETERMINISTIC_STAGE",
        "expected_outcome": {"status": "HOST_CHECKED_WITNESS" if stage == "provider_certificate" else "COMPLETED"},
        "actual_outcome": {"status": "PLANNED"},
        "model_id": "nvidia/nemotron-3.5-lightning:free" if stage == "provider_certificate" else None,
        "notes": "The immutable response.yaml records the actual outcome. Planned host stages are materialized only after their predecessor exists.",
    }


def _readme(definition: dict[str, Any]) -> str:
    pilot = pilot_id(definition["number"])
    return f"""# {pilot}: {definition['title']}

AuthorityEffect: None.

This pilot preserves one foundational PO-035 seed and runs it through five sequential loops. Each loop has one live provider certificate stage and four deterministic stages: requested-lift handling, exact host checking, a negative mutation control, and a prompt-container refinement. This is **25 test capsules**, of which five are provider calls.

PFP Mode 12 (`{MODE}`) carries the finite simplicial/cochain structure. `{REFUSAL_GATE}` fails closed when a response does not meet the strict JSON or exact-witness contract. The supplied carrier and the host checker confine every result to the named finite instance.

## Claim hygiene

- Supports: replayable observations about the finite carrier and a particular provider response.
- Does not support: a continuum limit, ambient geometry, physical causality, or a general model capability claim.
- Narrowest defensible claim: an exact host predicate accepted or rejected a retained candidate certificate.
- Next test: review the final tagged prompt container before dispatching a new independent round.

Run targeted preparation and replay with `py -3.12 -m omega_engine_education.pilots.po035_derivation_trials.run --replay`. Individual prompt and response custody remains inside `tests/test_XX`; aggregate findings and candidate artifacts are written under `../matrix/{CAMPAIGN}/`.
"""


def prepare() -> dict[str, Any]:
    matrix = PILOTS / "matrix" / CAMPAIGN
    manifest_path = matrix / "source_manifest.yaml"
    if not manifest_path.exists():
        write_once(manifest_path, source_manifest())
    rows = []
    for definition in PILOT_DEFINITIONS:
        pilot = pilot_id(definition["number"])
        folder = PILOTS / pilot
        write_once(folder / "prompt_template.yaml", template_bytes())
        write_once(folder / "spec.yaml", _spec(definition))
        write_once(folder / "seed.yaml", _seed(definition))
        write_once(folder / "testplan.yaml", _testplan(definition))
        write_once(folder / "README.md", _readme(definition))
        write_once(folder / "misc" / "README.md", "Aggregate campaign material belongs in ../matrix; individual prompts and replies belong only in tests/test_XX.\n")
        for loop in range(1, MAX_LOOPS + 1):
            for stage in STAGES:
                relative = capsule(pilot, loop, stage)
                folder_stage = PILOTS / relative
                write_once(folder_stage / "test_spec.yaml", _test_spec(definition, loop, stage))
                rows.append({
                    "pilot_id": pilot,
                    "loop": loop,
                    "stage": stage,
                    "capsule": relative,
                    "observation_mode": "INDEPENDENT_MODEL_TRIAL" if stage == "provider_certificate" else "HOST_DETERMINISTIC_STAGE",
                })
        # Only the first dispatch has no predecessor. Later prompt inputs are
        # generated after the prior loop's lift decision so they retain it exactly.
        initial = PILOTS / capsule(pilot, 1, "provider_certificate") / "input.yaml"
        write_once(initial, prompt_container(pilot, 1, []))
    plan = {
        "schema": "pfp.po035-derivation-campaign.v1",
        "authority_effect": "None",
        "campaign": CAMPAIGN,
        "source": SOURCE,
        "mode": MODE,
        "refusal_gate": REFUSAL_GATE,
        "max_loops": MAX_LOOPS,
        "tests": len(rows),
        "provider_calls": len(PILOT_DEFINITIONS) * MAX_LOOPS,
        "per_pilot_tests": MAX_LOOPS * len(STAGES),
        "budget_cap_usd": "0.05",
        "token_cap": 120000,
        "time_cap_seconds": 180,
        "status": "PLANNED",
        "cases": rows,
    }
    write_once(PILOTS / "matrix" / f"{CAMPAIGN}.yaml", plan)
    return plan


if __name__ == "__main__":
    prepared = prepare()
    print(json.dumps({key: value for key, value in prepared.items() if key != "cases"}, indent=2))
