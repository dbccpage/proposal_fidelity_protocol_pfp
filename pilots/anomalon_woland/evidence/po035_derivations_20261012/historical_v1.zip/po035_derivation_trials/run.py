"""Bounded live PO-035 derivation loops through the canonical provider port.

Usage:
  py -3.12 -m omega_engine_education.pilots.po035_derivation_trials.run --live \
      --model nvidia/nemotron-3.5-lightning:free --budget-usd 0.05
  py -3.12 -m omega_engine_education.pilots.po035_derivation_trials.run --replay

Live dispatch has no retries, cached completions, provider fallback, or silent
cost assumptions.  Every completed provider call retains its exact wire body
and raw response bytes in its own capsule.
"""
from __future__ import annotations

import argparse
import importlib.metadata
import json
import platform
import time
import urllib.request
from collections import Counter
from datetime import datetime, timezone
from decimal import ROUND_CEILING, Decimal
from typing import Any

import yaml

from omega_engine_providers.domain.types import CandidateRequest, DecodingParamsV1
from omega_engine_providers.infrastructure.budget_ledger import SqliteBudgetLedger
from omega_engine_providers.infrastructure.openai_compat import build_openai_compat_body
from omega_engine_providers.infrastructure.openrouter_transport import openrouter_transport
from omega_engine_providers.infrastructure.wire import decode_reply

from .cases import (
    ALLOWED_LIFTS,
    BY_PILOT,
    CAMPAIGN,
    MAX_LOOPS,
    PILOTS,
    ROOT,
    canonical,
    capsule,
    prompt_container,
    sha,
    task_for,
)
from .checking import evaluate, mutation_is_rejected
from .prepare import prepare, write_once

MAX_OUTPUT = 400
TOKEN_CAP = 120_000
TIME_CAP_SECONDS = 180
DEFAULT_BUDGET_MICROUSD = 50_000
DEPENDENCIES = (
    "omega_engine_education/pilots/po035_derivation_trials/cases.py",
    "omega_engine_education/pilots/po035_derivation_trials/checking.py",
    "omega_engine_education/pilots/po035_derivation_trials/learn.py",
    "omega_engine_education/pilots/po035_derivation_trials/prepare.py",
    "omega_engine_education/pilots/po035_derivation_trials/run.py",
    "omega_engine_education/pfp/domain/pilots/checker_registry.py",
    "omega_engine_providers/infrastructure/wire.py",
    "omega_engine_providers/infrastructure/openai_compat.py",
    "omega_engine_providers/infrastructure/openrouter_transport.py",
    "omega_engine_providers/domain/types.py",
)


class CampaignStop(RuntimeError):
    """A bounded campaign stopped before another provider dispatch."""


def matrix_root():
    return PILOTS / "matrix" / CAMPAIGN


def environment() -> dict[str, Any]:
    return {
        "python": platform.python_version(),
        "packages": {name: importlib.metadata.version(name) for name in ("jsonschema", "PyYAML")},
        "sources": {path: sha((ROOT / path).read_bytes()) for path in DEPENDENCIES},
    }


def microusd(value: Any) -> int:
    if type(value) not in (str, int, float, Decimal):
        raise ValueError("UNRECONCILED_COST")
    amount = Decimal(str(value))
    if not amount.is_finite() or amount < 0:
        raise ValueError("UNRECONCILED_COST")
    return int((amount * 1_000_000).to_integral_value(rounding=ROUND_CEILING))


def load_yaml(path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))


def load_input(pilot: str, loop: int) -> tuple[Any, dict[str, Any], bytes]:
    path = PILOTS / capsule(pilot, loop, "provider_certificate") / "input.yaml"
    raw = path.read_bytes()
    document = yaml.safe_load(raw)
    if not isinstance(document, dict):
        raise ValueError("INPUT_NOT_MAPPING")
    return path.parent, document, raw


def request_for(document: dict[str, Any]) -> CandidateRequest:
    prompt = document["prompt"]
    pilot_number = int(str(document["pilot_id"]).rsplit("_", maxsplit=1)[1])
    return CandidateRequest(
        prompt["system_prompt"],
        prompt["user_prompt"],
        decoding=DecodingParamsV1(
            seed=10_000 + pilot_number * 10 + int(document["loop"]),
            temperature=0.0,
            allow_fallbacks=False,
            require_parameters=True,
            thinking="disabled",
        ),
    )


def request_wire(document: dict[str, Any], model: str) -> dict[str, Any]:
    body = build_openai_compat_body(request_for(document), model=model, max_tokens=MAX_OUTPUT)
    body["usage"] = {"include": True}
    return body


def pricing(model: str) -> tuple[dict[str, Any], bytes]:
    with urllib.request.urlopen("https://openrouter.ai/api/v1/models", timeout=20) as reply:
        raw = reply.read()
    catalog = decode_reply(raw)
    if not isinstance(catalog.get("data"), list):
        raise ValueError("MODEL_CATALOG_INVALID")
    row = next((item for item in catalog["data"] if type(item) is dict and item.get("id") == model), None)
    if row is None:
        raise ValueError("MODEL_NOT_LISTED")
    rates = row.get("pricing")
    supported = row.get("supported_parameters")
    if not isinstance(rates, dict) or not isinstance(supported, list):
        raise ValueError("MODEL_CATALOG_INVALID")
    required = {"max_tokens", "temperature", "reasoning", "seed"}
    if not required.issubset(set(supported)):
        raise ValueError("REQUIRED_DECODING_UNSUPPORTED")
    billable = {"prompt", "completion"}
    optional_cache = {"input_cache_read", "input_cache_write"}
    for key, value in rates.items():
        try:
            amount = Decimal(str(value))
        except (ArithmeticError, ValueError) as exc:
            raise ValueError("INVALID_PRICING") from exc
        if not amount.is_finite() or amount < 0:
            raise ValueError("INVALID_PRICING")
        if key not in billable | optional_cache and amount != 0:
            raise ValueError("UNSUPPORTED_SURCHARGE")
    if any(key not in rates for key in billable):
        raise ValueError("MODEL_CATALOG_INVALID")
    # OpenRouter omits cache rate fields for routes that do not offer caching.
    # Omission cannot create a charge; an advertised nonzero cache rate cannot pass.
    if any(Decimal(str(rates.get(key, "0"))) != 0 for key in billable | optional_cache):
        raise ValueError("NONZERO_PRICING_REQUIRES_NEW_AUTHORIZATION")
    return {
        "observed_at": datetime.now(timezone.utc).isoformat(),
        "catalog_sha256": sha(raw),
        "model": model,
        "row": row,
    }, raw


def reservation(document: dict[str, Any], price: dict[str, Any]) -> int:
    request = request_for(document)
    upper_input_tokens = request.estimated_payload_bytes() + 256
    rates = price["row"]["pricing"]
    return microusd(Decimal(str(rates["prompt"])) * upper_input_tokens + Decimal(str(rates["completion"])) * MAX_OUTPUT)


def grade(document: dict[str, Any], raw: bytes, model: str) -> tuple[dict[str, Any], dict[str, Any] | None]:
    reply = decode_reply(raw)
    if reply.get("model") != model:
        raise ValueError("REPLY_MODEL_MISMATCH")
    if type(reply.get("id")) is not str or not reply["id"]:
        raise ValueError("MISSING_GENERATION_ID")
    usage = reply.get("usage")
    if not isinstance(usage, dict):
        raise ValueError("MISSING_USAGE")
    for field in ("prompt_tokens", "completion_tokens", "total_tokens"):
        if type(usage.get(field)) is not int or usage[field] < 0:
            raise ValueError("MISSING_USAGE")
    cost = microusd(usage.get("cost"))
    choices = reply.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        raise ValueError("MISSING_COMPLETION")
    message = choices[0].get("message")
    if not isinstance(message, dict) or type(message.get("content")) is not str:
        raise ValueError("MISSING_COMPLETION")
    outcome = evaluate(document["task"], message["content"])
    return ({
        "status": outcome["status"],
        "code": outcome["code"],
        "model_id": model,
        "generation_id": reply["id"],
        "usage": usage,
        "cost_microusd": cost,
        "finish_reason": choices[0].get("finish_reason"),
        "content_sha256": sha(message["content"].encode("utf-8")),
    }, outcome["payload"])


def _write_provider_receipt(folder, document: dict[str, Any], input_raw: bytes, wire: bytes, raw: bytes, result: dict[str, Any], elapsed: float, env: dict[str, Any]) -> dict[str, Any]:
    receipt = {
        "schema": "pfp.po035-provider-response.v1",
        "authority_effect": "None",
        **result,
        "latency_seconds": elapsed,
        "input_sha256": sha(input_raw),
        "request_sha256": sha(wire),
        "provider_response_sha256": sha(raw),
        "environment": env,
    }
    write_once(folder / "response.yaml", receipt)
    return receipt


def _provider_receipt(folder) -> dict[str, Any]:
    path = folder / "response.yaml"
    if not path.exists():
        raise ValueError("PROVIDER_RESPONSE_MISSING")
    document = load_yaml(path)
    if not isinstance(document, dict):
        raise ValueError("PROVIDER_RECEIPT_INVALID")
    return document


def _verify_provider(folder, document: dict[str, Any], input_raw: bytes, model: str, env: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any] | None]:
    receipt = _provider_receipt(folder)
    raw = (folder / "provider_response.json").read_bytes()
    wire = (folder / "request.json").read_bytes()
    expected = canonical(request_wire(document, model))
    if (receipt.get("environment") != env or receipt.get("input_sha256") != sha(input_raw)
            or receipt.get("request_sha256") != sha(wire) or receipt.get("provider_response_sha256") != sha(raw)
            or wire != expected):
        raise ValueError("REPLAY_BINDING_MISMATCH")
    result, payload = grade(document, raw, model)
    for key, value in result.items():
        if receipt.get(key) != value:
            raise ValueError("REPLAY_RESULT_MISMATCH")
    return receipt, payload


def _host_input(pilot: str, loop: int, stage: str, body: dict[str, Any]) -> Any:
    folder = PILOTS / capsule(pilot, loop, stage)
    document = {
        "schema": "pfp.po035-stage-input.v1",
        "authority_effect": "None",
        "campaign": CAMPAIGN,
        "pilot_id": pilot,
        "loop": loop,
        "stage": stage,
        **body,
    }
    write_once(folder / "input.yaml", document)
    return folder


def _host_response(folder, stage: str, body: dict[str, Any]) -> dict[str, Any]:
    response = {
        "schema": "pfp.po035-host-stage-response.v1",
        "authority_effect": "None",
        "stage": stage,
        "status": "COMPLETED",
        **body,
    }
    write_once(folder / "response.yaml", response)
    return response


def _requested_lifts(payload: dict[str, Any] | None) -> list[str]:
    if payload is None:
        return []
    values = payload.get("requested_lifts")
    if not isinstance(values, list) or any(type(value) is not str for value in values):
        return []
    return values


def _grant_stage(pilot: str, loop: int, provider_receipt: dict[str, Any], payload: dict[str, Any] | None, accumulated: list[str]) -> tuple[dict[str, Any], list[str]]:
    requested = _requested_lifts(payload)
    granted = [item for item in requested if item in ALLOWED_LIFTS and item not in accumulated]
    already = [item for item in requested if item in accumulated]
    denied = [item for item in requested if item not in ALLOWED_LIFTS]
    next_lifts = accumulated + granted
    folder = _host_input(pilot, loop, "grant_requested_lifts", {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        "requested_lifts": requested,
        "allowlist": list(ALLOWED_LIFTS),
        "previous_granted_lifts": accumulated,
    })
    response = _host_response(folder, "grant_requested_lifts", {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        "requested_lifts": requested,
        "granted_lifts": granted,
        "already_granted": already,
        "denied_lifts": denied,
        "cumulative_granted_lifts": next_lifts,
    })
    return response, next_lifts


def _host_check_stage(pilot: str, loop: int, provider_receipt: dict[str, Any]) -> dict[str, Any]:
    folder = _host_input(pilot, loop, "host_witness_check", {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        "provider_status": provider_receipt["status"],
        "provider_code": provider_receipt["code"],
    })
    return _host_response(folder, "host_witness_check", {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        "gate_status": provider_receipt["status"],
        "gate_code": provider_receipt["code"],
    })


def _mutation_stage(pilot: str, loop: int, provider_receipt: dict[str, Any], task: dict[str, Any], payload: dict[str, Any] | None) -> dict[str, Any]:
    mutation = mutation_is_rejected(task, payload)
    folder = _host_input(pilot, loop, "negative_mutation_control", {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        "task_sha256": sha(canonical(task)),
        "mutation_policy": "deterministic_wrong_or_malformed_certificate",
    })
    return _host_response(folder, "negative_mutation_control", {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        **mutation,
    })


def _refinement_stage(pilot: str, loop: int, provider_receipt: dict[str, Any], grants: dict[str, Any], check: dict[str, Any], mutation: dict[str, Any], next_lifts: list[str]) -> dict[str, Any]:
    tags = [
        f"candidate:host-status:{check['gate_status']}",
        f"candidate:negative-control:{mutation['mutation_code']}",
        *[f"candidate:lift:{item}" for item in grants["granted_lifts"]],
    ]
    body: dict[str, Any] = {
        "provider_response_sha256": provider_receipt["provider_response_sha256"],
        "cumulative_granted_lifts": next_lifts,
        "candidate_tags": tags,
    }
    if loop < MAX_LOOPS:
        next_document = prompt_container(pilot, loop + 1, next_lifts)
        target = PILOTS / capsule(pilot, loop + 1, "provider_certificate") / "input.yaml"
        write_once(target, next_document)
        body.update({"next_prompt_id": next_document["prompt_id"], "next_input_sha256": sha(target.read_bytes())})
    else:
        terminal = prompt_container(pilot, loop, next_lifts)
        body.update({"next_prompt_id": terminal["prompt_id"], "terminal_prompt_container_sha256": sha(canonical(terminal))})
    folder = _host_input(pilot, loop, "prompt_refinement", body)
    return _host_response(folder, "prompt_refinement", body)


def _ledger_state(ledger: SqliteBudgetLedger, budget: int) -> dict[str, Any]:
    with ledger.transaction(budget) as state:
        return json.loads(json.dumps(state))


def _reserve(ledger: SqliteBudgetLedger, budget: int, attempt: str, reserved: int, input_sha: str) -> None:
    with ledger.transaction(budget) as state:
        if any(row["state"] != "settled" for row in state["attempts"].values()):
            raise CampaignStop("UNRECONCILED_ATTEMPT")
        if attempt in state["attempts"]:
            raise CampaignStop("ATTEMPT_ALREADY_RECORDED")
        if state["spent"] + reserved > budget:
            raise CampaignStop("CAMPAIGN_BUDGET_EXCEEDED")
        state["spent"] += reserved
        state["attempts"][attempt] = {"state": "reserved", "reserved": reserved, "input_sha256": input_sha}


def _settle(ledger: SqliteBudgetLedger, budget: int, attempt: str, result: dict[str, Any]) -> int:
    with ledger.transaction(budget) as state:
        row = state["attempts"].get(attempt)
        if not row or row["state"] != "reserved":
            raise CampaignStop("ATTEMPT_SETTLEMENT_INVALID")
        if any(item.get("generation_id") == result["generation_id"] for item in state["attempts"].values()):
            raise CampaignStop("DUPLICATE_PROVIDER_GENERATION")
        actual = result["cost_microusd"]
        state["spent"] += actual - row["reserved"]
        row.update({"state": "settled", "actual": actual, "generation_id": result["generation_id"]})
        return state["spent"]


def _record_stop(code: str, **details: Any) -> None:
    path = matrix_root() / "stop.yaml"
    if path.exists():
        return
    write_once(path, {"schema": "pfp.po035-stop.v1", "authority_effect": "None", "code": code, **details})


def _dispatch_one(pilot: str, loop: int, model: str, budget: int, price: dict[str, Any], ledger: SqliteBudgetLedger, env: dict[str, Any], start: float) -> tuple[dict[str, Any], dict[str, Any] | None]:
    folder, document, input_raw = load_input(pilot, loop)
    if folder.joinpath("response.yaml").exists():
        return _verify_provider(folder, document, input_raw, model, env)
    elapsed_before = time.monotonic() - start
    if elapsed_before >= TIME_CAP_SECONDS:
        raise CampaignStop("TIME_CAP_EXCEEDED")
    reserve = reservation(document, price)
    if reserve > DEFAULT_BUDGET_MICROUSD:
        raise CampaignStop("PER_CALL_BUDGET_EXCEEDED")
    attempt = capsule(pilot, loop, "provider_certificate")
    timeout = min(25.0, max(1.0, TIME_CAP_SECONDS - elapsed_before))
    transport = openrouter_transport(timeout=timeout)
    if not transport.is_ok:
        raise CampaignStop("PROVIDER_CREDENTIAL_UNAVAILABLE")
    _reserve(ledger, budget, attempt, reserve, sha(input_raw))
    body = canonical(request_wire(document, model))
    write_once(folder / "request.json", body)
    write_once(folder / "reservation.yaml", {
        "schema": "pfp.po035-reservation.v1",
        "model_id": model,
        "reserved_microusd": reserve,
        "input_sha256": sha(input_raw),
        "request_sha256": sha(body),
        "pricing_catalog_sha256": price["catalog_sha256"],
        "automatic_retry": False,
    })
    sent_at = time.monotonic()
    try:
        raw = transport.unwrap()(model, request_for(document), MAX_OUTPUT)
    except BaseException as exc:
        _record_stop("PROVIDER_TRANSPORT_FAILURE", exception=type(exc).__name__, capsule=attempt)
        raise CampaignStop("PROVIDER_TRANSPORT_FAILURE") from exc
    elapsed = time.monotonic() - sent_at
    write_once(folder / "provider_response.json", raw)
    try:
        result, payload = grade(document, raw, model)
    except (TypeError, ValueError, KeyError) as exc:
        write_once(folder / "response.yaml", {
            "schema": "pfp.po035-provider-response.v1",
            "authority_effect": "None",
            "status": "INFRASTRUCTURE_ERROR",
            "code": f"UNRECONCILED_{type(exc).__name__}",
            "input_sha256": sha(input_raw),
            "request_sha256": sha(body),
            "provider_response_sha256": sha(raw),
            "environment": env,
            "automatic_retry": False,
        })
        _record_stop("UNRECONCILED_PROVIDER_RESPONSE", capsule=attempt, exception=type(exc).__name__)
        raise CampaignStop("UNRECONCILED_PROVIDER_RESPONSE") from exc
    receipt = _write_provider_receipt(folder, document, input_raw, body, raw, result, elapsed, env)
    spent = _settle(ledger, budget, attempt, result)
    total_tokens = _ledger_token_total()
    if result["cost_microusd"] > reserve:
        _record_stop("BILL_EXCEEDS_RESERVATION", capsule=attempt, reported_cost_microusd=result["cost_microusd"], reserved_microusd=reserve)
        raise CampaignStop("BILL_EXCEEDS_RESERVATION")
    if spent > budget:
        _record_stop("CAMPAIGN_BUDGET_EXCEEDED", spent_microusd=spent, budget_microusd=budget)
        raise CampaignStop("CAMPAIGN_BUDGET_EXCEEDED")
    if total_tokens > TOKEN_CAP:
        _record_stop("TOKEN_CAP_EXCEEDED", total_tokens=total_tokens, token_cap=TOKEN_CAP)
        raise CampaignStop("TOKEN_CAP_EXCEEDED")
    if time.monotonic() - start > TIME_CAP_SECONDS:
        _record_stop("TIME_CAP_EXCEEDED", elapsed_seconds=time.monotonic() - start)
        raise CampaignStop("TIME_CAP_EXCEEDED")
    return receipt, payload


def _ledger_token_total() -> int:
    total = 0
    for definition in BY_PILOT.values():
        pilot = f"pilot_{definition['number']:07d}"
        for loop in range(1, MAX_LOOPS + 1):
            path = PILOTS / capsule(pilot, loop, "provider_certificate") / "response.yaml"
            if path.exists():
                receipt = load_yaml(path)
                if isinstance(receipt, dict) and isinstance(receipt.get("usage"), dict):
                    value = receipt["usage"].get("total_tokens")
                    if type(value) is int:
                        total += value
    return total


def _complete_loop(pilot: str, loop: int, receipt: dict[str, Any], payload: dict[str, Any] | None, cumulative: list[str]) -> list[str]:
    grants, cumulative = _grant_stage(pilot, loop, receipt, payload, cumulative)
    check = _host_check_stage(pilot, loop, receipt)
    mutation = _mutation_stage(pilot, loop, receipt, task_for(pilot, loop), payload)
    _refinement_stage(pilot, loop, receipt, grants, check, mutation, cumulative)
    return cumulative


def live(model: str, budget: int) -> dict[str, Any]:
    if budget != DEFAULT_BUDGET_MICROUSD:
        raise ValueError("EXPLICIT_CAMPAIGN_CAP_MUST_BE_0_05_USD")
    prepare()
    root = matrix_root()
    root.mkdir(parents=True, exist_ok=True)
    env = environment()
    start = time.monotonic()
    price, catalog_raw = pricing(model)
    config = {
        "schema": "pfp.po035-authorization.v1",
        "authority_effect": "None",
        "model": model,
        "budget_microusd": budget,
        "per_call_budget_microusd": DEFAULT_BUDGET_MICROUSD,
        "token_cap": TOKEN_CAP,
        "time_cap_seconds": TIME_CAP_SECONDS,
        "max_output_tokens": MAX_OUTPUT,
        "provider_calls_planned": len(BY_PILOT) * MAX_LOOPS,
        "environment": env,
        "automatic_retries": False,
        "provider_fallback": False,
    }
    write_once(root / "authorization.yaml", config)
    write_once(root / "catalog.json", catalog_raw)
    write_once(root / "pricing.yaml", price)
    ledger = SqliteBudgetLedger(root / "budget.sqlite3", budget_id=CAMPAIGN)
    completed = []
    try:
        for definition in BY_PILOT.values():
            pilot = f"pilot_{definition['number']:07d}"
            cumulative: list[str] = []
            for loop in range(1, MAX_LOOPS + 1):
                receipt, payload = _dispatch_one(pilot, loop, model, budget, price, ledger, env, start)
                cumulative = _complete_loop(pilot, loop, receipt, payload, cumulative)
                completed.append({"pilot_id": pilot, "loop": loop, "status": receipt["status"], "cost_microusd": receipt["cost_microusd"]})
    except CampaignStop as exc:
        _record_stop(str(exc), completed_loops=len(completed), total_tokens=_ledger_token_total())
        return {"status": "STOPPED", "code": str(exc), "completed_loops": completed, "total_tokens": _ledger_token_total()}
    snapshot = _ledger_state(ledger, budget)
    write_once(root / "budget_snapshot.json", canonical(snapshot) + b"\n")
    return {"status": "COMPLETED", "completed_loops": completed, "total_tokens": _ledger_token_total(), "spent_microusd": snapshot["spent"]}


def _read_host_response(pilot: str, loop: int, stage: str) -> dict[str, Any]:
    value = load_yaml(PILOTS / capsule(pilot, loop, stage) / "response.yaml")
    if not isinstance(value, dict):
        raise ValueError("HOST_STAGE_RESPONSE_INVALID")
    return value


def _replay_loop(pilot: str, loop: int, model: str, env: dict[str, Any], cumulative: list[str]) -> tuple[dict[str, Any], list[str]]:
    folder, document, input_raw = load_input(pilot, loop)
    expected_input = prompt_container(pilot, loop, cumulative)
    if document != expected_input:
        raise ValueError("PROMPT_CONTAINER_BINDING_MISMATCH")
    receipt, payload = _verify_provider(folder, document, input_raw, model, env)
    requested = _requested_lifts(payload)
    granted = [item for item in requested if item in ALLOWED_LIFTS and item not in cumulative]
    already = [item for item in requested if item in cumulative]
    denied = [item for item in requested if item not in ALLOWED_LIFTS]
    next_lifts = cumulative + granted
    grant = _read_host_response(pilot, loop, "grant_requested_lifts")
    if any(grant.get(key) != value for key, value in {
        "provider_response_sha256": receipt["provider_response_sha256"],
        "requested_lifts": requested,
        "granted_lifts": granted,
        "already_granted": already,
        "denied_lifts": denied,
        "cumulative_granted_lifts": next_lifts,
    }.items()):
        raise ValueError("LIFT_GRANT_REPLAY_MISMATCH")
    check = _read_host_response(pilot, loop, "host_witness_check")
    if check.get("gate_status") != receipt["status"] or check.get("gate_code") != receipt["code"]:
        raise ValueError("HOST_CHECK_REPLAY_MISMATCH")
    expected_mutation = mutation_is_rejected(document["task"], payload)
    mutation = _read_host_response(pilot, loop, "negative_mutation_control")
    if any(mutation.get(key) != value for key, value in expected_mutation.items()):
        raise ValueError("MUTATION_REPLAY_MISMATCH")
    refinement = _read_host_response(pilot, loop, "prompt_refinement")
    if refinement.get("cumulative_granted_lifts") != next_lifts:
        raise ValueError("REFINEMENT_REPLAY_MISMATCH")
    if loop < MAX_LOOPS:
        target = PILOTS / capsule(pilot, loop + 1, "provider_certificate") / "input.yaml"
        if refinement.get("next_input_sha256") != sha(target.read_bytes()):
            raise ValueError("NEXT_PROMPT_DIGEST_MISMATCH")
    return receipt, next_lifts


def replay() -> dict[str, Any]:
    prepare()
    root = matrix_root()
    config_path = root / "authorization.yaml"
    if not config_path.exists():
        return {"campaign": CAMPAIGN, "status": "PLANNED", "provider_completed": 0, "rows": []}
    config = load_yaml(config_path)
    model = config["model"]
    env = environment()
    if config.get("environment") != env:
        raise ValueError("ENVIRONMENT_BINDING_MISMATCH")
    rows = []
    for definition in BY_PILOT.values():
        pilot = f"pilot_{definition['number']:07d}"
        cumulative: list[str] = []
        for loop in range(1, MAX_LOOPS + 1):
            path = PILOTS / capsule(pilot, loop, "provider_certificate") / "response.yaml"
            if not path.exists():
                rows.append({"pilot_id": pilot, "loop": loop, "status": "PLANNED"})
                continue
            receipt, cumulative = _replay_loop(pilot, loop, model, env, cumulative)
            rows.append({"pilot_id": pilot, "loop": loop, "status": receipt["status"], "generation_id": receipt["generation_id"],
                         "cost_microusd": receipt["cost_microusd"], "total_tokens": receipt["usage"]["total_tokens"],
                         "response_sha256": receipt["provider_response_sha256"]})
    result = {
        "schema": "pfp.po035-replay.v1",
        "authority_effect": "None",
        "campaign": CAMPAIGN,
        "provider_completed": sum("generation_id" in row for row in rows),
        "statuses": dict(Counter(row["status"] for row in rows)),
        "cost_microusd": sum(row.get("cost_microusd", 0) for row in rows),
        "total_tokens": sum(row.get("total_tokens", 0) for row in rows),
        "rows": rows,
    }
    if result["provider_completed"] == len(BY_PILOT) * MAX_LOOPS:
        if len({row["generation_id"] for row in rows}) != result["provider_completed"]:
            raise ValueError("DUPLICATE_PROVIDER_GENERATION")
        write_once(root / "replay.json", canonical(result) + b"\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--live", action="store_true")
    parser.add_argument("--replay", action="store_true")
    parser.add_argument("--model")
    parser.add_argument("--budget-usd")
    args = parser.parse_args()
    if args.live:
        if not args.model or args.budget_usd is None:
            parser.error("--live requires --model and --budget-usd")
        result = live(args.model, microusd(args.budget_usd))
    else:
        result = replay()
    print(json.dumps({key: value for key, value in result.items() if key != "rows"}, indent=2))


if __name__ == "__main__":
    main()
