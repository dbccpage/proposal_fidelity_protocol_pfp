"""Atomic budget ledger with pre-dispatch reservation and exposure accounting.

AuthorityEffect: None.
"""

from __future__ import annotations

import hashlib
import json
import os
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any, Dict, FrozenSet, Optional, Sequence


def _canonical(value: Any) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")


def _sha(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _money(value: Any) -> Optional[Decimal]:
    if value is None or isinstance(value, bool):
        return None
    try:
        result = Decimal(str(value))
    except (InvalidOperation, ValueError):
        return None
    return result if result.is_finite() and result >= 0 else None


def _atomic(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + "." + uuid.uuid4().hex + ".tmp")
    with temporary.open("wb") as handle:
        handle.write(_canonical(value))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


@contextmanager
def _locked(path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+b") as handle:
        handle.seek(0, 2)
        if handle.tell() == 0:
            handle.write(b"0")
            handle.flush()
        deadline = time.monotonic() + 10
        while True:
            try:
                handle.seek(0)
                if os.name == "nt":
                    import msvcrt

                    msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
                else:
                    import fcntl

                    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    raise RuntimeError("LEDGER_LOCK_TIMEOUT")
                time.sleep(0.05)
        try:
            yield
        finally:
            handle.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


class BudgetLedger:
    """The same atomic ledger used by live dispatch and offline boundary probes."""

    def __init__(
        self,
        path: Path | str,
        pilot_cap_usd: str | float | Decimal = "0.20",
        campaign_cap_usd: str | float | Decimal = "20",
        *,
        authorized_prior_unknown_ids: Sequence[str] = (),
        balance_ceiling_usd: str | float | Decimal = "17.48",
    ):
        self.path = Path(path)
        self.pilot_cap = _money(pilot_cap_usd)
        self.campaign_cap = _money(campaign_cap_usd)
        self.balance_ceiling = _money(balance_ceiling_usd)
        self.authorized_prior_unknown_ids: FrozenSet[str] = frozenset(authorized_prior_unknown_ids)
        if self.balance_ceiling is None or self.balance_ceiling > Decimal("17.48"):
            raise ValueError("ACCOUNT_CEILING_NOT_AUTHORIZED")
        if (
            self.pilot_cap is None
            or self.campaign_cap is None
            or self.pilot_cap > Decimal("3.00")
            or self.campaign_cap > 20
        ):
            raise ValueError("BUDGET_CAP_NOT_AUTHORIZED")

    def _read(self) -> Dict[str, Any]:
        if self.path.exists():
            data = json.loads(self.path.read_text(encoding="utf-8"))
            if data.get("schema") != "pfp.provider-ledger.v1":
                raise ValueError("LEDGER_SCHEMA_MISMATCH")
            if (
                _money(data.get("pilot_cap_usd")) != self.pilot_cap
                or _money(data.get("campaign_cap_usd")) != self.campaign_cap
            ):
                raise ValueError("LEDGER_CAP_MISMATCH")
            return data
        return {
            "schema": "pfp.provider-ledger.v1",
            "pilot_cap_usd": str(self.pilot_cap),
            "campaign_cap_usd": str(self.campaign_cap),
            "requests": {},
        }

    def snapshot(self) -> Dict[str, Any]:
        with _locked(self.path.with_suffix(".lock")):
            return self._read()

    def reserve(
        self,
        request_id: str,
        amount_usd: Any,
        *,
        request_sha256: str = "",
        model: str = "",
        pricing_sha256: str = "",
    ) -> Optional[Dict[str, Any]]:
        amount = _money(amount_usd)
        if amount is None:
            raise ValueError("INVALID_RESERVATION")
        fingerprint = request_sha256 or _sha(_canonical([request_id, str(amount), model]))
        with _locked(self.path.with_suffix(".lock")):
            ledger = self._read()
            prior = ledger["requests"].get(request_id)
            if prior:
                if prior["request_sha256"] != fingerprint:
                    raise ValueError("REQUEST_ID_REUSED_WITH_DIFFERENT_INPUT")
                return prior.get("result") or {
                    "status": "UNRESOLVED",
                    "error_code": "REQUEST_ALREADY_RESERVED",
                    "request_id": request_id,
                    "cost_usd": None,
                }
            if any(
                row["state"] == "BREACH"
                or (row["state"] == "UNKNOWN" and key not in self.authorized_prior_unknown_ids)
                for key, row in ledger["requests"].items()
            ):
                raise ValueError("UNRESOLVED_CHARGE_HOLDS_DISPATCH")
            exposure = sum(
                (
                    Decimal(row["cost_usd"])
                    if row["state"] == "SETTLED"
                    else Decimal(row["reserved_usd"])
                    if row["state"] != "CANCELLED"
                    else Decimal(0)
                    for row in ledger["requests"].values()
                ),
                Decimal(0),
            )
            if exposure + amount > min(self.pilot_cap, self.campaign_cap, self.balance_ceiling):
                raise ValueError("BUDGET_RESERVATION_REFUSED")
            ledger["requests"][request_id] = {
                "request_sha256": fingerprint,
                "model": model,
                "state": "RESERVED",
                "reserved_usd": str(amount),
                "cost_usd": None,
                "pricing_sha256": pricing_sha256,
                "reserved_at": _now(),
                "dispatched": False,
            }
            _atomic(self.path, ledger)
        return None

    def mark_dispatched(self, request_id: str) -> None:
        with _locked(self.path.with_suffix(".lock")):
            ledger = self._read()
            row = ledger["requests"][request_id]
            if row["state"] != "RESERVED" or row["dispatched"]:
                raise ValueError("REQUEST_NOT_DISPATCHABLE")
            row.update(dispatched=True, dispatched_at=_now())
            _atomic(self.path, ledger)

    def settle(
        self, request_id: str, cost_usd: Any, *, result: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        cost = _money(cost_usd)
        if cost is None:
            raise ValueError("UNKNOWN_IS_NOT_ZERO")
        result = dict(
            result or {"request_id": request_id, "cost_usd": str(cost), "status": "COMPLETE"}
        )
        with _locked(self.path.with_suffix(".lock")):
            ledger = self._read()
            row = ledger["requests"][request_id]
            if row["state"] == "CANCELLED":
                raise ValueError("CANCELLED_REQUEST_CANNOT_SETTLE")
            if row["state"] in {"SETTLED", "BREACH"}:
                if Decimal(row["cost_usd"]) != cost:
                    raise ValueError("CONFLICTING_RECONCILIATION")
                return row["result"]
            state = "SETTLED"
            if cost > Decimal(row["reserved_usd"]):
                state = "BREACH"
                result.update(status="UNRESOLVED", error_code="BILLED_COST_EXCEEDS_RESERVATION")
            row.update(state=state, cost_usd=str(cost), result=result, updated_at=_now())
            _atomic(self.path, ledger)
        return result

    def unresolved(
        self,
        request_id: str,
        reason: str = "BILLING_UNKNOWN",
        *,
        result: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        result = dict(
            result
            or {
                "request_id": request_id,
                "cost_usd": None,
                "status": "UNRESOLVED",
                "error_code": reason,
            }
        )
        with _locked(self.path.with_suffix(".lock")):
            ledger = self._read()
            row = ledger["requests"][request_id]
            if row["state"] not in {"RESERVED", "UNKNOWN"}:
                raise ValueError("REQUEST_ALREADY_TERMINAL")
            row.update(state="UNKNOWN", cost_usd=None, result=result, updated_at=_now())
            _atomic(self.path, ledger)
        return result

    def cancel(self, request_id: str) -> Dict[str, Any]:
        with _locked(self.path.with_suffix(".lock")):
            ledger = self._read()
            row = ledger["requests"][request_id]
            if row["state"] == "CANCELLED":
                return row
            if row["state"] != "RESERVED" or row["dispatched"]:
                raise ValueError("DISPATCHED_OR_TERMINAL_RESERVATION_CANNOT_CANCEL")
            row.update(
                state="CANCELLED",
                cancelled_at=_now(),
                result={
                    "request_id": request_id,
                    "status": "REFUSED",
                    "error_code": "CANCELLED_BEFORE_DISPATCH",
                    "cost_usd": None,
                    "cost_status": "NOT_DISPATCHED",
                },
            )
            _atomic(self.path, ledger)
        return row

    def summary(self) -> Dict[str, Any]:
        rows = list(self.snapshot()["requests"].values())
        spent = sum(
            (Decimal(row["cost_usd"]) for row in rows if row["state"] in {"SETTLED", "BREACH"}),
            Decimal(0),
        )
        held = sum(
            (
                Decimal(row["reserved_usd"])
                for row in rows
                if row["state"] in {"RESERVED", "UNKNOWN"}
            ),
            Decimal(0),
        )
        return {
            "settled_usd": str(spent),
            "held_usd": str(held),
            "exposure_usd": str(spent + held),
            "unknown_request_ids": [
                key for key, row in self.snapshot()["requests"].items() if row["state"] == "UNKNOWN"
            ],
            "request_count": len(rows),
        }
