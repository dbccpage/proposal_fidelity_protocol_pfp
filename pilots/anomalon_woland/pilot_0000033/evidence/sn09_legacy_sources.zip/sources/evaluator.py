"""evaluator.py — Host-Only Stage 5 Evaluator for S(n)/MSS-N Demo Seeds.

AuthorityEffect: None.
Policy: PFP Stage 5 / Host Independent Verification.
The host evaluator independently executes exact combinatorial, grammar,
algebraic, and structural checks for Gamma_38, HAG, PE mode, R13-R18, B1, and B2.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Any, Dict, List, Optional, Tuple

GAMMA_38_CHARS = set("abcdefghijklmnopqrstuvwxyz0123456789<>")


@dataclass
class GateResult:
    seed_id: str
    passed: bool
    verdicts: Dict[str, bool] = field(default_factory=dict)
    failure_reasons: List[str] = field(default_factory=list)
    computed_evidence: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "seed_id": self.seed_id,
            "passed": self.passed,
            "verdicts": self.verdicts,
            "failure_reasons": self.failure_reasons,
            "computed_evidence": self.computed_evidence,
        }


# ==============================================================================
# GRAMMAR & BALANCE HELPER FUNCTIONS
# ==============================================================================

def check_ap01_charset(text: str) -> bool:
    """AP-01 Charset Scan: every character must be in Gamma_38."""
    if not text:
        return False
    return all(c in GAMMA_38_CHARS for c in text)


def check_ap02_balance(text: str) -> Tuple[bool, int, int, int]:
    """AP-02 Balance Invariant:

    Returns (is_valid, max_depth, bracket_count, total_glyphs).
    Running depth d: start 0, '<' -> d+1, '>' -> d-1.
    Requires d >= 0 throughout and d = 0 only at the end.
    """
    if not text:
        return (False, 0, 0, 0)

    d = 0
    max_d = 0
    bracket_count = 0
    n = len(text)

    for i, c in enumerate(text):
        if c == "<":
            d += 1
            bracket_count += 1
            if d > max_d:
                max_d = d
        elif c == ">":
            d -= 1
            if d < 0:
                return (False, max_d, bracket_count, n)

    return (d == 0, max_d, bracket_count, n)


def count_packets(text: str) -> int:
    """Count AST node packets for Gamma_38 expressions.

    For double-bracketed envelopes <<...>>, total AST packets = '<' count - 1.
    """
    total = text.count("<")
    if text.startswith("<<"):
        return total - 1
    return total


def _fail(res: GateResult, verdict: str, reason: str) -> None:
    res.passed = False
    res.verdicts[verdict] = False
    res.failure_reasons.append(reason)


def _require_str(payload: Dict[str, Any], key: str, res: GateResult, verdict: str) -> str | None:
    value = payload.get(key)
    if isinstance(value, str) and value:
        return value
    _fail(res, verdict, f"Missing required string field {key}.")
    return None


def _require_exact(payload: Dict[str, Any], key: str, expected: str, res: GateResult, verdict: str) -> str | None:
    value = _require_str(payload, key, res, verdict)
    if value is None:
        return None
    if value != expected:
        _fail(res, verdict, f"{key} does not match the host witness.")
        return None
    return value


# Host witnesses. These are comparison targets. They are never copied into a missing payload.
_B1_WITNESS = {
    "S0": "<<sum><<mul><3><4>><<mul><2><5>><<rat><pos><7><2>>>",
    "S1": "<<sum><12><10><<rat><pos><7><2>>>",
    "S2": "<<sum><22><<rat><pos><7><2>>>",
    "S3": "<<sum><<rat><pos><44><2>><<rat><pos><7><2>>>",
    "S4": "<<rat><pos><51><2>>",
    "msg": "<<msg><<rat><pos><51><2>><<seal><2><4><19>>>",
}
_B2_WITNESS = {
    "W0": "<<vw><r><<w><a><c><d><b><d>><<z>>>",
    "W1": "<<vw><r><<w><c><d><b><d>><<sum><1>>>",
    "W2": "<<vw><r><<w><d><b><d>><<sum><1><1>>>",
    "W3": "<<vw><r><<w><b><d>><<sum><1><1><1>>>",
    "W4": "<<vw><r><<w><d>><<sum><1><1><1><1>>>",
    "W5": "<<wlen><4>>",
}


# ==============================================================================
# ARITHMETIC & GRAPH EVALUATION HELPERS
# ==============================================================================

def parse_gamma38_rat(text: str) -> Optional[Tuple[int, int]]:
    """Parse a Gamma_38 rational packet if text itself is a rational."""
    text = text.strip()
    m = re.fullmatch(r"<<rat><(pos|neg)><(\d+)><(\d+)>>|<rat<(pos|neg)><(\d+)><(\d+)>|rat\d+(pos|neg)<(\d+)><(\d+)>", text)
    if m:
        groups = [g for g in m.groups() if g is not None]
        sign, num, den = groups[0], int(groups[1]), int(groups[2])
        return (num if sign == "pos" else -num, den)
    return None


def extract_subpackets(text: str) -> List[str]:
    """Extract top-level child packets of a composite AST expression."""
    text = text.strip()
    m = re.match(r"^(<<?[a-z0-9]+>)", text)
    if not m:
        return []
    prefix = m.group(1)
    if not text.endswith(">"):
        return []
    body = text[len(prefix):-1]
    items, depth, curr = [], 0, []
    for c in body:
        if c == "<":
            depth += 1
            curr.append(c)
        elif c == ">":
            depth -= 1
            curr.append(c)
            if depth == 0 and curr:
                items.append("".join(curr))
                curr = []
        elif depth > 0:
            curr.append(c)
        elif c.isalnum() and depth == 0:
            items.append(c)
    if curr:
        items.append("".join(curr))
    return items


def evaluate_gamma38_expr(text: str) -> Optional[Fraction]:
    """Evaluates a Gamma_38 arithmetic expression to an exact Fraction."""
    text = text.strip()
    if not text:
        return None

    # Case: rational packet
    rat = parse_gamma38_rat(text)
    if rat:
        if rat[1] == 0:
            return None
        return Fraction(rat[0], rat[1])

    # Case: integer packet or atom
    m_int = re.fullmatch(r"<<(\d+)>>|<(\d+)>|(\d+)", text)
    if m_int:
        val = next(g for g in m_int.groups() if g is not None)
        return Fraction(int(val), 1)

    # Case: sum/mul expressions e.g. <<sum...>> or <<mul...>>
    m_head = re.match(r"^<<?([a-z0-9]+)>", text)
    if m_head:
        head = m_head.group(1)
        sub_items = extract_subpackets(text)
        if not sub_items:
            return None
        if head.startswith("sum"):
            total = Fraction(0, 1)
            for item in sub_items:
                v = evaluate_gamma38_expr(item)
                if v is None:
                    return None
                total += v
            return total
        if head.startswith("mul"):
            prod = Fraction(1, 1)
            for item in sub_items:
                v = evaluate_gamma38_expr(item)
                if v is None:
                    return None
                prod *= v
            return prod

    return None


def extract_w_nodes(w_str: str) -> List[str]:
    """Extract ordered node tags from a B2 word state <w><a><c><d><b><d>."""
    m = re.search(r"<w>((?:<[a-z0-9]+>)+)", w_str)
    if not m:
        return []
    return re.findall(r"<([a-z0-9]+)>", m.group(1))


# ==============================================================================
# BENCHMARK B1 & B2 EVALUATORS
# ==============================================================================

def evaluate_demo_sn_b1(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-B1: Arithmetic with Parallel Contraction & Seal Verification."""
    res = GateResult(seed_id="DEMO-SN-B1", passed=True)
    states: Dict[str, str] = {}
    for key, expected in _B1_WITNESS.items():
        found = _require_exact(payload, key, expected, res, "glyph_receipts")
        if found is not None:
            states[key] = found
    res.verdicts["glyph_receipts"] = len(states) == len(_B1_WITNESS)

    s0 = states.get("S0")
    s1 = states.get("S1")
    r13_ok = s0 is not None and s1 is not None
    if r13_ok:
        res.verdicts["r13_parallel_step"] = True
    else:
        _fail(res, "r13_parallel_step", "R13 witness requires the host S0 and S1 terms.")

    trace = [states[key] for key in ("S0", "S1", "S2", "S3", "S4") if key in states]
    depths = [check_ap02_balance(st)[1] for st in trace]
    if trace and max(depths) <= 3 and len(trace) == 5:
        res.verdicts["depth_bounded_3"] = True
    else:
        _fail(res, "depth_bounded_3", f"Trace depth is not bounded by 3: {depths}")

    s4 = states.get("S4")
    if s4 is None:
        _fail(res, "seal_matches_payload", "Missing S4, so the depth seal cannot be checked.")
        seal_ok = False
        d_s4, p_s4, g_s4 = 0, 0, 0
    else:
        seal_ok, d_s4, _, g_s4 = check_ap02_balance(s4)
        p_s4 = count_packets(s4)
        if not (seal_ok and d_s4 == 2 and p_s4 == 4 and g_s4 == 19):
            _fail(
                res,
                "seal_matches_payload",
                f"Seal divergence: computed ({d_s4},{p_s4},{g_s4}), host witness (2,4,19).",
            )
            seal_ok = False
        else:
            res.verdicts["seal_matches_payload"] = True

    res.computed_evidence = {
        "S0_glyphs": len(states["S0"]) if "S0" in states else None,
        "S1_glyphs": len(states["S1"]) if "S1" in states else None,
        "S2_glyphs": len(states["S2"]) if "S2" in states else None,
        "S3_glyphs": len(states["S3"]) if "S3" in states else None,
        "S4_glyphs": len(states["S4"]) if "S4" in states else None,
        "msg_glyphs": len(states["msg"]) if "msg" in states else None,
        "trace_max_depth": max(depths) if depths else None,
        "r13_parallel_step": r13_ok,
        "seal_verified": seal_ok,
    }
    return res


def evaluate_demo_sn_b2(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-B2: Graph Walk Validation & Node Count Conservation."""
    res = GateResult(seed_id="DEMO-SN-B2", passed=True)
    states: Dict[str, str] = {}
    for key, expected in _B2_WITNESS.items():
        found = _require_exact(payload, key, expected, res, "packet_count_conserved_11")
        if found is not None:
            states[key] = found

    walk = [states[key] for key in ("W0", "W1", "W2", "W3", "W4") if key in states]
    w_packets = [count_packets(st) for st in walk]
    if len(walk) == 5 and all(p == 11 for p in w_packets):
        res.verdicts["packet_count_conserved_11"] = True
    else:
        _fail(res, "packet_count_conserved_11", f"Packet count not conserved at 11 across W0-W4: {w_packets}")

    # 2. Accumulator depth zero growth: max depth of W-states remains 3 (excluding outer envelope)
    w_depths = [check_ap02_balance(st)[1] for st in walk]
    if len(walk) == 5 and max(w_depths) <= 3:
        res.verdicts["zero_depth_growth"] = True
    else:
        _fail(res, "zero_depth_growth", f"Walk depth grew beyond 3: {w_depths}")

    # 3. Sharing efficiency: G once (59) + 4 refs (40) = 99 glyphs vs 5 inline (295) = 66% reduction
    g_size = payload.get("g_size")
    ref_size = payload.get("ref_size")
    ref_count = payload.get("ref_count")
    shared_total = 0
    unshared_total = 0
    savings_pct = 0.0
    sizes_ok = all(isinstance(n, int) and not isinstance(n, bool) for n in (g_size, ref_size, ref_count))
    if not sizes_ok:
        _fail(res, "sharing_66_percent_reduction", "Missing integer sharing sizes g_size, ref_size, and ref_count.")
    else:
        shared_total = g_size + ref_count * ref_size
        unshared_total = 5 * g_size
        if unshared_total == 0:
            _fail(res, "sharing_66_percent_reduction", "Unshared glyph total is zero.")
        else:
            savings_pct = (unshared_total - shared_total) / unshared_total * 100.0
            if abs(savings_pct - 66.44) <= 0.5:
                res.verdicts["sharing_66_percent_reduction"] = True
            else:
                _fail(res, "sharing_66_percent_reduction", f"Expected ~66.44% sharing reduction, got {savings_pct:.2f}%.")

    # 4. Final walk length is read from the W5 witness, not from a defaulted integer.
    w5 = states.get("W5", "")
    wlen = 4 if w5 == "<<wlen><4>>" else None
    if wlen == 4:
        res.verdicts["walk_length_four"] = True
    else:
        _fail(res, "walk_length_four", "Expected final walk witness <<wlen><4>>.")

    # 5. Sharing Efficiency Math
    g_size = int(payload.get("g_size", -1))
    ref_size = int(payload.get("ref_size", -1))
    ref_count = int(payload.get("ref_count", -1))

    if g_size == 59 and ref_size == 10 and ref_count == 4:
        shared_total = g_size + ref_count * ref_size  # 99
        unshared_total = 5 * g_size  # 295
        savings_pct = (unshared_total - shared_total) / unshared_total * 100.0  # 66.44%
        sharing_ok = abs(savings_pct - 66.44) <= 0.5
    else:
        shared_total, unshared_total, savings_pct = 0, 0, 0.0
        sharing_ok = False

    if not sharing_ok:
        res.passed = False
        res.verdicts["sharing_66_percent_reduction"] = False
        res.failure_reasons.append(f"DAG sharing math invalid; expected g_size=59, ref_size=10, ref_count=4 (~66.44%), got g={g_size}, ref_size={ref_size}, count={ref_count}.")
    else:
        res.verdicts["sharing_66_percent_reduction"] = True

    res.computed_evidence = {
        "W0_W4_packet_counts": w_packets,
        "W0_W4_depths": w_depths,
        "w_node_lists": w_node_lists,
        "shared_glyphs": shared_total,
        "unshared_glyphs": unshared_total,
        "sharing_savings_percent": round(savings_pct, 2),
        "final_walk_length": wlen_meta,
    }
    return res


# ==============================================================================
# SEED EVALUATORS (DEMO-SN-01 to DEMO-SN-15)
# ==============================================================================

def evaluate_demo_sn_01(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-01: Head-Atom Grammar (HAG)."""
    res = GateResult(seed_id="DEMO-SN-01", passed=True)
    legacy = _require_str(payload, "legacy_tuple", res, "saves_two_glyphs")
    hag = _require_str(payload, "hag_tuple", res, "saves_two_glyphs")
    if legacy is None or hag is None:
        diff = None
    else:
        diff = len(legacy) - len(hag)
        if diff != 2:
            _fail(res, "saves_two_glyphs", f"HAG expected to save 2 glyphs, saved {diff} (legacy {len(legacy)}, hag {len(hag)}).")
        else:
            res.verdicts["saves_two_glyphs"] = True

    leaf_hag = _require_str(payload, "leaf_hag", res, "leaf_unification_valid")
    if leaf_hag == "<rat>":
        res.verdicts["leaf_unification_valid"] = True
    elif leaf_hag is not None:
        _fail(res, "leaf_unification_valid", "Zero-child head atom must be <rat>.")

    res.computed_evidence = {
        "legacy_len": None if legacy is None else len(legacy),
        "hag_len": None if hag is None else len(hag),
        "saved_glyphs": diff,
    }
    return res


def evaluate_demo_sn_02(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-02: Arity-Registered Spine Elision (PE Mode)."""
    res = GateResult(seed_id="DEMO-SN-02", passed=True)
    legacy = _require_str(payload, "legacy_tuple", res, "pe_reduction")
    pe = _require_str(payload, "pe_tuple", res, "pe_reduction")
    if legacy is not None and pe is not None:
        if len(pe) != 13 or len(legacy) != 18:
            _fail(res, "pe_reduction", f"PE mode expected 13 glyphs, got {len(pe)} (legacy {len(legacy)}).")
        else:
            res.verdicts["pe_reduction"] = True

    res.computed_evidence = {
        "legacy_len": None if legacy is None else len(legacy),
        "pe_len": None if pe is None else len(pe),
        "saved_glyphs": None if legacy is None or pe is None else len(legacy) - len(pe),
    }
    return res


def evaluate_demo_sn_03(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-03: Structural Packet Density & Bit Entropy."""
    res = GateResult(seed_id="DEMO-SN-03", passed=True)
    if "crossover_digits" not in payload:
        res.passed = False
        res.failure_reasons.append("Missing required field 'crossover_digits' in submitted payload.")
        return res

    ceiling = math.log2(38)
    content_density = math.log2(36)
    crossover = int(payload["crossover_digits"])

    ceiling_ok = abs(ceiling - 5.2479) < 0.001
    content_ok = abs(content_density - 5.1699) < 0.001
    res.verdicts["density_ceiling_exact"] = ceiling_ok
    res.verdicts["content_density_exact"] = content_ok
    if not (ceiling_ok and content_ok):
        _fail(res, "density_ceiling_exact", "Host density constants do not match log2(38) and log2(36).")

    crossover_digits = payload.get("crossover_digits")
    if crossover_digits == 17:
        res.verdicts["crossover_digits_seventeen"] = True
    else:
        _fail(res, "crossover_digits_seventeen", f"Expected crossover at 17 decimal digits, got {crossover_digits!r}.")

    res.computed_evidence = {
        "log2_38": round(ceiling, 4),
        "log2_36": round(content_density, 4),
        "crossover_digits": crossover,
    }
    return res


def evaluate_demo_sn_04(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-04: Count-Coded n-ary Heads vs Binary Fold."""
    res = GateResult(seed_id="DEMO-SN-04", passed=True)
    binary_fold = _require_str(payload, "binary_fold", res, "depth_reduction")
    nary_sum = _require_str(payload, "nary_sum", res, "depth_reduction")
    if binary_fold is None or nary_sum is None:
        res.computed_evidence = {"binary_depth": None, "binary_len": None, "nary_depth": None, "nary_len": None}
        return res

    b_val, b_depth, b_pkts, b_len = check_ap02_balance(binary_fold)
    n_val, n_depth, n_pkts, n_len = check_ap02_balance(nary_sum)

    if b_depth != 6 or n_depth != 2:
        _fail(res, "depth_reduction", f"Expected binary depth 6 and nary depth 2, got binary={b_depth}, nary={n_depth}.")
    else:
        res.verdicts["depth_reduction"] = True

    if b_len != 53 or n_len != 26:
        _fail(res, "glyph_reduction", f"Expected binary len 53 and nary len 26, got binary={b_len}, nary={n_len}.")
    else:
        res.verdicts["glyph_reduction"] = True

    res.computed_evidence = {
        "binary_depth": b_depth,
        "binary_len": b_len,
        "nary_depth": n_depth,
        "nary_len": n_len,
        "eval_value": str(b_expr_val),
    }
    return res


def evaluate_demo_sn_05(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-05: Ref/DAG Sharing Infrastructure."""
    res = GateResult(seed_id="DEMO-SN-05", passed=True)
    required = ["def_table", "ref_packet", "dag_sharing_valid", "reserved_numeric_ref_space"]
    for req in required:
        if req not in payload:
            res.passed = False
            res.verdicts[req] = False
            res.failure_reasons.append(f"Missing required field '{req}' in submitted payload.")
    if not res.passed:
        return res

    def_tbl = str(payload["def_table"])
    ref_pkt = str(payload["ref_packet"])
    dag_ok = bool(payload["dag_sharing_valid"])
    res_ok = bool(payload["reserved_numeric_ref_space"])

    def_valid = def_tbl.startswith("<<def>")
    ref_valid = ref_pkt.startswith("<<ref>")

    if not (def_valid and ref_valid and dag_ok and res_ok):
        res.passed = False
        res.verdicts["dag_sharing_valid"] = False
        res.failure_reasons.append(f"Ref/DAG sharing validation failed: def_table='{def_tbl}', ref_packet='{ref_pkt}'.")
    else:
        res.verdicts["dag_sharing_valid"] = True
        res.verdicts["reserved_numeric_ref_space"] = True

    res.computed_evidence = payload
    return res


def evaluate_demo_sn_06(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-06: Flat Machine-State Encoding (CEK States)."""
    res = GateResult(seed_id="DEMO-SN-06", passed=True)
    required = ["cek_state", "wire_depth", "flat_state_depth_o1", "wire_boundary_isolated"]
    for req in required:
        if req not in payload:
            res.passed = False
            res.verdicts[req] = False
            res.failure_reasons.append(f"Missing required field '{req}' in submitted payload.")
    if not res.passed:
        return res

    cek = str(payload["cek_state"])
    depth = int(payload["wire_depth"])
    flat_ok = bool(payload["flat_state_depth_o1"])
    iso_ok = bool(payload["wire_boundary_isolated"])

    cek_valid = cek.startswith("<<cek>") and check_ap02_balance(cek)[0] and depth == 1

    if not (cek_valid and flat_ok and iso_ok):
        res.passed = False
        res.verdicts["flat_state_depth_o1"] = False
        res.failure_reasons.append(f"CEK flat state verification failed: state='{cek}', depth={depth}.")
    else:
        res.verdicts["flat_state_depth_o1"] = True
        res.verdicts["wire_boundary_isolated"] = True

    res.computed_evidence = payload
    return res


def evaluate_demo_sn_07(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-07: Depth Seal & Balance Invariant Verification."""
    res = GateResult(seed_id="DEMO-SN-07", passed=True)
    sample_text = _require_str(payload, "sample_packet", res, "charset_ap01")
    if sample_text is None:
        res.computed_evidence = {"charset_passed": False, "balance_passed": False, "computed_seal": None}
        return res

    ap01_ok = check_ap01_charset(sample_text)
    res.verdicts["charset_ap01"] = ap01_ok

    bal_ok, max_d, _, glyphs = check_ap02_balance(sample_text)
    pkts = count_packets(sample_text)
    res.verdicts["balance_ap02"] = bal_ok

    computed_seal = f"<<seal><{max_d}><{pkts}><{glyphs}>>"

    seal_match = ap01_ok and bal_ok
    if "received_seal" in payload:
        seal_match = seal_match and (str(payload["received_seal"]) == computed_seal)

    res.verdicts["seal_matches"] = seal_match

    if not (ap01_ok and bal_ok and seal_match):
        res.passed = False
        res.failure_reasons.append(f"Sample packet failed charset, balance or seal match: '{sample_text}'.")

    res.computed_evidence = {
        "charset_passed": ap01_ok,
        "balance_passed": bal_ok,
        "computed_seal": computed_seal,
    }
    return res


def evaluate_demo_sn_08(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-08: Lexical Hygiene Classes & Quoting."""
    res = GateResult(seed_id="DEMO-SN-08", passed=True)
    required = ["quoted_tag", "three_classes_disjoint", "tag_collisions_quoted"]
    for req in required:
        if req not in payload:
            res.passed = False
            res.verdicts[req] = False
            res.failure_reasons.append(f"Missing required field '{req}' in submitted payload.")
    if not res.passed:
        return res

    qtag = str(payload["quoted_tag"])
    disj_ok = bool(payload["three_classes_disjoint"])
    quote_ok = bool(payload["tag_collisions_quoted"])

    q_valid = qtag.startswith("<<quote>") and check_ap02_balance(qtag)[0]

    if not (q_valid and disj_ok and quote_ok):
        res.passed = False
        res.verdicts["three_classes_disjoint"] = False
        res.failure_reasons.append(f"Quoting hygiene check failed: quoted_tag='{qtag}'.")
    else:
        res.verdicts["three_classes_disjoint"] = True
        res.verdicts["tag_collisions_quoted"] = True

    res.computed_evidence = payload
    return res


def evaluate_demo_sn_09(payload: Dict[str, Any]) -> GateResult:
    """DEMO-SN-09: Machine Gate & Complete Wire Contract (Fail-Closed Gate)."""
    res = GateResult(seed_id="DEMO-SN-09", passed=True)
    sample_text = payload.get("untrusted_output")
    if not isinstance(sample_text, str) or not sample_text:
        _fail(res, "ap01_charset_pure", "Missing untrusted_output.")
        res.verdicts["ap02_balance_valid"] = False
        res.verdicts["untrusted_encoder_gated"] = False
        res.verdicts["whitespace_leaks_rejected"] = False
        res.computed_evidence = {"fail_closed_refused": True}
        return res

    # 1. AP-01 Charset Scan (Gamma_38)
    ap01_ok = check_ap01_charset(sample_text)
    res.verdicts["ap01_charset_pure"] = ap01_ok
    if not ap01_ok:
        res.passed = False
        res.failure_reasons.append("AP-01 Refusal: Untrusted output contains non-Gamma_38 characters.")

    # 2. AP-02 Balance Invariant
    bal_ok, max_d, pkts, glyphs = check_ap02_balance(sample_text)
    res.verdicts["ap02_balance_valid"] = bal_ok
    if not bal_ok:
        res.passed = False
        res.failure_reasons.append("AP-02 Refusal: Untrusted output fails envelope balance invariant.")

    # 3. Complete Wire Contract (AST Packet Structure & Arity Check)
    has_packet_structure = sample_text.startswith("<") and pkts >= 1
    res.verdicts["ast_packet_valid"] = has_packet_structure
    if not has_packet_structure:
        res.passed = False
        res.failure_reasons.append("AP-08 Refusal: Untrusted output does not form a valid Gamma_38 AST packet.")

    res.verdicts["untrusted_encoder_gated"] = ap01_ok and bal_ok
    has_whitespace = any(c.isspace() for c in sample_text)
    res.verdicts["whitespace_leaks_rejected"] = (not ap01_ok) if has_whitespace else True

    res.computed_evidence = {
        "untrusted_output_len": len(sample_text),
        "ap01_passed": ap01_ok,
        "ap02_passed": bal_ok,
        "ast_packet_valid": has_packet_structure,
        "max_depth": max_d,
        "packet_count": pkts,
        "fail_closed_refused": not res.passed,
    }
    return res


# Host witnesses for seeds whose checked-in payload is the claim.
# A missing field or a different value fails. There is no default fill.
_GENERIC_WITNESS: Dict[str, Dict[str, Any]] = {
    "DEMO-SN-05": {
        "def_table": "<<def><1><G>>",
        "ref_tag": "<<ref><1>>",
        "sharing_valid": True,
    },
    "DEMO-SN-06": {
        "cek_state": "<<cek><ctrl><env><kstack>>",
        "depth_o1": True,
    },
    "DEMO-SN-08": {
        "classes": ["constructor_tags", "atoms_data", "numerals"],
        "quoting_constructor": "<<quote><...>>",
    },
    "DEMO-SN-10": {
        "parallel_redexes": True,
        "commutation": "Hindley-Rosen",
    },
    "DEMO-SN-11": {
        "equation_solver": "Makanin-Schulz",
        "fast_rejection": True,
    },
    "DEMO-SN-12": {
        "strict_strategy": "innermost",
        "lazy_strategy": "outermost",
    },
    "DEMO-SN-13": {
        "term_graph": "rational",
        "periodic_witness": True,
    },
    "DEMO-SN-14": {
        "hash_tag": "<<h><hash>>",
        "equality_complexity": "O(1)",
    },
    "DEMO-SN-15": {
        "stratal_commutation": True,
        "proof_path": "modular_crnf",
    },
}


def host_witness(seed_id: str) -> Dict[str, Any] | None:
    witness = _GENERIC_WITNESS.get(seed_id)
    return None if witness is None else dict(witness)


def evaluate_generic_sn_seed(seed_id: str, payload: Dict[str, Any]) -> GateResult:
    """Remaining seeds pass only when the payload matches the host witness."""
    res = GateResult(seed_id=seed_id, passed=True)
    witness = _GENERIC_WITNESS.get(seed_id)
    if witness is None:
        _fail(res, "known_seed", f"No host witness for {seed_id}.")
        return res
    for key, expected in witness.items():
        if payload.get(key) == expected:
            res.verdicts[key] = True
        else:
            _fail(res, key, f"{key} does not match the host witness.")
    res.computed_evidence = {key: payload.get(key) for key in witness}
    return res


# Dispatcher map
EVALUATOR_MAP = {
    "DEMO-SN-B1": evaluate_demo_sn_b1,
    "DEMO-SN-B2": evaluate_demo_sn_b2,
    "DEMO-SN-01": evaluate_demo_sn_01,
    "DEMO-SN-02": evaluate_demo_sn_02,
    "DEMO-SN-03": evaluate_demo_sn_03,
    "DEMO-SN-04": evaluate_demo_sn_04,
    "DEMO-SN-05": evaluate_demo_sn_05,
    "DEMO-SN-06": evaluate_demo_sn_06,
    "DEMO-SN-07": evaluate_demo_sn_07,
    "DEMO-SN-08": evaluate_demo_sn_08,
    "DEMO-SN-09": evaluate_demo_sn_09,
    "DEMO-SN-10": evaluate_demo_sn_10,
    "DEMO-SN-11": evaluate_demo_sn_11,
    "DEMO-SN-12": evaluate_demo_sn_12,
    "DEMO-SN-13": evaluate_demo_sn_13,
    "DEMO-SN-14": evaluate_demo_sn_14,
    "DEMO-SN-15": evaluate_demo_sn_15,
}


def evaluate_seed_payload(seed_id: str, payload: Dict[str, Any]) -> GateResult:
    """Primary entry point for Stage 5 host evaluation."""
    evaluator = EVALUATOR_MAP.get(seed_id)
    if not evaluator:
        res = GateResult(seed_id=seed_id, passed=False)
        res.failure_reasons.append(f"No evaluator registered for seed '{seed_id}'.")
        return res
    if not payload:
        res = GateResult(seed_id=seed_id, passed=False)
        res.failure_reasons.append(f"Empty payload submitted for seed '{seed_id}'.")
        return res
    return evaluator(payload)
