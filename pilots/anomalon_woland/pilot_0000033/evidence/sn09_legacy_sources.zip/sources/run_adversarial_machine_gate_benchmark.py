"""run_adversarial_machine_gate_benchmark.py — Systematic Adversarial Noisy Input Benchmark.

AuthorityEffect: None.
Evaluates 20 distinct adversarial noisy inputs (whitespace injection, character corruption,
envelope imbalance, negative running depth, truncated payloads) through Stage 5 Machine Gate
(DEMO-SN-09) to verify AP-01/AP-02 fail-closed refusal routing.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

_HERE = Path(__file__).resolve().parent
_PYTHON_DIR = _HERE.parents[1] / "python"

for p in (_HERE, _PYTHON_DIR):
    if str(p) not in sys.path:
        sys.path.insert(0, str(p))

from evaluator import evaluate_seed_payload, GateResult


NOISY_INPUT_BENCHMARK_MATRIX: List[Dict[str, str]] = [
    # Category 1: Whitespace Leaks (AP-01 Refusal)
    {"id": "NOISE-01", "category": "whitespace_leak", "input": " <<rat><pos><51><2>>", "description": "Leading space before outer bracket"},
    {"id": "NOISE-02", "category": "whitespace_leak", "input": "<<rat><pos><51><2>> ", "description": "Trailing space after closing bracket"},
    {"id": "NOISE-03", "category": "whitespace_leak", "input": "<<rat> <pos> <51> <2>>", "description": "Inter-packet space separator"},
    {"id": "NOISE-04", "category": "whitespace_leak", "input": "<<rat>\t<pos>\n<51><2>>", "description": "Tab and newline injection"},
    {"id": "NOISE-05", "category": "whitespace_leak", "input": "<<sum> <1><2>>", "description": "Space inside n-ary envelope"},

    # Category 2: Character Corruptions (AP-01 Refusal)
    {"id": "NOISE-06", "category": "character_corruption", "input": "<<RAT><POS><51><2>>", "description": "Uppercase ASCII tag names"},
    {"id": "NOISE-07", "category": "character_corruption", "input": "<<rat><pos><51><-2>>", "description": "Hyphen / minus sign in numeral"},
    {"id": "NOISE-08", "category": "character_corruption", "input": "<<rat><pos!><51><2>>", "description": "Exclamation mark in tag"},
    {"id": "NOISE-09", "category": "character_corruption", "input": "<<rat_pos_51_2>>", "description": "Underscore delimiters"},
    {"id": "NOISE-10", "category": "character_corruption", "input": "<<rat><pos><51><2>>#comment", "description": "Inline comment hash"},
    {"id": "NOISE-11", "category": "character_corruption", "input": "<<rat><pos><51.5><2>>", "description": "Floating point decimal dot"},

    # Category 3: Envelope Balance Corruptions (AP-02 Refusal)
    {"id": "NOISE-12", "category": "envelope_corruption", "input": "<<rat><pos><51><2>", "description": "Missing outer closing bracket"},
    {"id": "NOISE-13", "category": "envelope_corruption", "input": "<<rat><pos><51><2>>>", "description": "Extra closing bracket"},
    {"id": "NOISE-14", "category": "envelope_corruption", "input": "><rat><pos><51><2><", "description": "Negative running depth at position 0"},
    {"id": "NOISE-15", "category": "envelope_corruption", "input": "<rat><pos><51><2>>", "description": "Single outer bracket envelope"},
    {"id": "NOISE-16", "category": "envelope_corruption", "input": "<<rat><pos><", "description": "Truncated mid-packet envelope"},
    {"id": "NOISE-17", "category": "envelope_corruption", "input": "<<rat>>><pos><51><2>>", "description": "Premature depth drop to zero"},

    # Category 4: Baseline Clean Controls (Should Pass)
    {"id": "CLEAN-01", "category": "clean_baseline", "input": "<<rat><pos><51><2>>", "description": "Canonical 4-packet rational tuple"},
    {"id": "CLEAN-02", "category": "clean_baseline", "input": "<rat<pos><3><4>>", "description": "HAG single-envelope rational tuple"},
    {"id": "CLEAN-03", "category": "clean_baseline", "input": "<<sum6><1><1><1><1><1><1>>", "description": "Count-coded 6-ary sum"},
]


def run_adversarial_machine_gate_benchmark() -> Dict[str, Any]:
    """Execute all 20 noisy input cases against Stage 5 Machine Gate (DEMO-SN-09)."""
    results = []
    total_noisy = 0
    refused_noisy = 0
    total_clean = 0
    passed_clean = 0

    print("=" * 80)
    print("STAGE 5 MACHINE GATE ADVERSARIAL NOISY INPUT BENCHMARK (DEMO-SN-09)")
    print("=" * 80)

    for item in NOISY_INPUT_BENCHMARK_MATRIX:
        case_id = item["id"]
        category = item["category"]
        raw_input = item["input"]
        desc = item["description"]

        payload = {"untrusted_output": raw_input}
        res: GateResult = evaluate_seed_payload("DEMO-SN-09", payload)

        is_clean = category == "clean_baseline"
        if is_clean:
            total_clean += 1
            if res.passed:
                passed_clean += 1
        else:
            total_noisy += 1
            if not res.passed:
                refused_noisy += 1

        expected_verdict = "PASS" if is_clean else "REFUSE"
        actual_verdict = "PASS" if res.passed else "REFUSE"
        correct = (expected_verdict == actual_verdict)

        results.append({
            "id": case_id,
            "category": category,
            "description": desc,
            "input": repr(raw_input),
            "ap01_pure": res.verdicts.get("ap01_charset_pure", False),
            "ap02_valid": res.verdicts.get("ap02_balance_valid", False),
            "passed": res.passed,
            "expected_verdict": expected_verdict,
            "actual_verdict": actual_verdict,
            "correct_routing": correct,
            "failure_reasons": res.failure_reasons,
        })

        status_flag = "[OK]" if correct else "[FAIL]"
        print(f" {status_flag} {case_id} ({category}): {actual_verdict} (Expected: {expected_verdict}) — {desc}")

    noisy_pass_rate = (refused_noisy / total_noisy) * 100.0 if total_noisy > 0 else 0.0
    clean_pass_rate = (passed_clean / total_clean) * 100.0 if total_clean > 0 else 0.0

    print("-" * 80)
    print(f"Noisy Input Refusal Accuracy: {refused_noisy}/{total_noisy} ({noisy_pass_rate:.1f}%)")
    print(f"Clean Input Pass Accuracy:    {passed_clean}/{total_clean} ({clean_pass_rate:.1f}%)")
    print("=" * 80)

    report = {
        "suite": "DEMO-SN-09 Machine Gate Adversarial Benchmark",
        "total_cases": len(NOISY_INPUT_BENCHMARK_MATRIX),
        "noisy_refusal_accuracy_pct": noisy_pass_rate,
        "clean_pass_accuracy_pct": clean_pass_rate,
        "all_cases_correct": (refused_noisy == total_noisy and passed_clean == total_clean),
        "case_details": results,
    }

    report_file = _HERE / "seeds" / "adversarial_machine_gate_benchmark_receipt.json"
    report_file.parent.mkdir(parents=True, exist_ok=True)
    report_file.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    return report


if __name__ == "__main__":
    run_adversarial_machine_gate_benchmark()
