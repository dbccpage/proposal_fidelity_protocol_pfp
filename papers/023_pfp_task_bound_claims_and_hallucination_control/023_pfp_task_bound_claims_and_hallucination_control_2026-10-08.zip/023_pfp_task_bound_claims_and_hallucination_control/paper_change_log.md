# Change log

## 0.1.0 — 2026-10-05

Initial author-review draft with a finite proof, exact example, and rejection
controls. No new provider experiment or general reasoning guarantee.
