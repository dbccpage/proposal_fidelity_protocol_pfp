# Task-bound claims and the scope of hallucination control

[Read the manuscript](paper.md). Version 0.1.0, unpublished author-review draft.

Run `python code/replay.py` from this directory. The example uses only the
standard library. Written proofs and finite replay are distinct evidence.
No new Lean proof, model trial, PDF, DOI, or publication is claimed.

Text: CC BY 4.0. Code: PolyForm Noncommercial 1.0.0. AuthorityEffect: None.

[Inspect the two-level teaching packet](prompts/example.yaml). It is an
unexecuted example with a typed response schema, not a provider run.
