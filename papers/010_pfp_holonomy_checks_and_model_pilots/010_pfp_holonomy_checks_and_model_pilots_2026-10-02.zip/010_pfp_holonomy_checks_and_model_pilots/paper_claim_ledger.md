# Claim ledger: PFP X (Paper 010)

Version 0.1.0, 2026-10-02. Code baseline `a623568eb0f853b968bc419bf06dfc6af256ab02`.

Each row is a claim made in the manuscript, with the section that makes it, its
kind, and the evidence that supports it. Kinds are: *executable check* (a named
test in `code/tests/`), *formal proof* (a Lean declaration in `lean4/`), *standard
fact* (a cited reference), *retained record* (a repository file, cited by path and
commit), and *source inspection* (reading a retained script), and *historical replay* (the collection's
`tools/replay_formal_math_baselines.py`, which runs the challenge checkers from the
cited commits on answers that need no mathematics; its output is recorded in the
collection's `verification/formal_math_baselines.json`). Paths under
`omega_engine_projects/` are relative to the repository root; the C017 folder is
`omega_engine_projects/mssn_sn_symgam/challenges/b_cohomology/c017_nonabelian_lattice_holonomy/`
and the formal-mathematics folder is
`omega_engine_projects/mssn_sn_symgam/challenges/e_formal_math/`. Claims withdrawn
from the initial internal draft are listed in `paper_change_log.md`, not here.

## The initial internal draft (Section 1)

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-00 | In the initial internal draft's package, the five prompt-filter stages were simple functions (a radius-one neighbourhood split, a list-membership test, two threshold comparisons, an ordered four-label line check, and a count of five listed symbols compared with three); no run, runner or receipt for the initial internal draft's filter benchmark or effect sizes is retained, and no effect was measured. | 1 | Source inspection | `paper.md` and `code/tests/test_010_adversarial_refusals_and_decimation.py` in this package folder at commit `35e3d7ba2e0e20904d17a79cc395980f50a1a0f1`; a search of the repository finds the benchmark and effect statements only in copies of the initial-draft paper. Engine components with similar names (an allosteric gate and a kinetic proofreader under `omega_engine_symbol_game/domain/`) are separate code, and no run of them against model answers is recorded |

## Checker and mathematics (Section 2)

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-01 | The package's $S_3$ (permutations of three points) and $Q_8$ (integer unit quaternions) tables satisfy the group axioms; they are nonabelian of orders 6 and 8, and $Q_8$ has one element of order 2. | 2.1 | Executable check | `test_holonomy_checker.py::test_package_groups_are_nonabelian_of_orders_6_and_8` |
| PFP10-02 | A table that is not a group (two entries of a row swapped, a wrong inverse, an entry that is not an element) is refused. | 2.1, 2.2 | Executable check | `test_holonomy_checker.py::test_constructor_rejects_tables_that_are_not_groups` |
| PFP10-03 | Lattices with too few rows or columns, or with non-integer sizes, are refused; a torus needs at least three rows and columns. | 2.1 | Executable check | `test_holonomy_checker.py::test_lattice_rejects_degenerate_shapes` |
| PFP10-04 | Link lists with an inverse mismatch, a missing direction or an edge outside the lattice are refused. | 2.2 | Executable check | `test_holonomy_checker.py::test_loader_refuses_inconsistent_or_incomplete_links` |
| PFP10-05 | Reversing a plaquette inverts its product; changing the starting vertex conjugates it; some products differ from their inverses in $S_3$ and $Q_8$. | 2.1, 2.4 | Executable check; standard fact | `test_holonomy_checker.py::test_orientation_reversal_inverts_plaquette_holonomy`; references 1 and 2 |
| PFP10-06 | A gauge transformation conjugates each plaquette product by the gauge at the plaquette's first vertex. | 2.1 | Executable check; standard fact | `test_holonomy_checker.py::test_gauge_transformation_conjugates_plaquette_holonomy`; references 1 and 2 |
| PFP10-07 | A flat connection on an open lattice is gauge-trivial; on the torus $A$ and $B$ commute, and the connection is gauge-trivial exactly when $A = B = e$. | 2.1 | Standard fact | References 2 and 3; checked on finite families by PFP10-11 and PFP10-12 |
| PFP10-08 | The trivial connection is `FLAT_TRIVIAL` on open and periodic lattices, and every plaquette can be skipped. | 2.4 | Executable check | `test_holonomy_checker.py::test_trivial_connection_is_flat_trivial` |
| PFP10-09 | A gauge transformation of the trivial connection with no plaquette of four identity links is `FLAT_TRIVIAL`; the returned tree gauge makes every link the identity. | 2.3, 2.4 | Executable check | `test_holonomy_checker.py::test_pure_gauge_connection_is_flat_trivial_with_no_identity_plaquettes` |
| PFP10-10 | A single non-identity link away from the boundary gives `NOT_FLAT` with exactly two non-flat plaquettes. | 2.4 | Executable check | `test_holonomy_checker.py::test_single_non_identity_link_is_not_flat` |
| PFP10-11 | A torus connection with a constant non-identity product around one cycle is `FLAT_NONTRIVIAL`. | 2.4 | Executable check | `test_holonomy_checker.py::test_flat_nontrivial_torus_with_constant_holonomy_around_one_cycle` |
| PFP10-12 | For every pair $(a, b)$ in $S_3 \times S_3$ and $Q_8 \times Q_8$, the $3 \times 4$ torus connection with seam links $a$ and $b$ is flat exactly when $ab = ba$; flat cases have cycle products $(a, b)$, conjugated by one element after a gauge transformation; the non-flat plaquette has product $b a b^{-1} a^{-1}$. | 2.4 | Executable check | `test_holonomy_checker.py::test_flat_cycle_holonomies_commute_on_every_seam_pair` |
| PFP10-13 | Skipping plaquettes with four identity links never changes the verdict, the non-flat count, the witness or the cycle products. | 2.3, 2.4 | Executable check | `test_holonomy_checker.py::test_identity_skipping_never_changes_the_result` |
| PFP10-14 | The certificate check accepts a correct plaquette in either orientation and rejects a wrong product, a flat plaquette, a four-cycle that is not a plaquette, a wrong gauge, an unparsed answer and a contractible loop. | 2.2, 2.4 | Executable check | `test_holonomy_checker.py::test_verify_claim_checks_certificates_not_labels` |
| PFP10-15 | Lemma: four identity links give the identity plaquette product (identity law and $e^{-1} = e$ only). | 2.3 | Formal proof | `lean4/LatticeDecimation.lean`, `SymbolGame010.identity_links_give_identity_product`; `lean4/axiom_report.txt` records no axioms |

## C017 pilot (Section 3)

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-16 | The five files in `code/data/c017/` are byte copies of the retained challenge cases; their CRLF digests equal the challenge's judge manifest. | 3.1 | Executable check; retained record | `code/data/c017/provenance.json`; `test_c017_replay.py::test_case_files_match_recorded_digests` |
| PFP10-17 | Host verdicts, lattice sizes, plaquette counts and skippable counts of Table 1; they agree with the verdicts the harness expected. | 3.1 | Executable check | `test_c017_replay.py::test_host_verdicts_for_the_five_cases`; `test_c017_replay.py::test_retained_certificates_agree_with_recorded_outcomes` |
| PFP10-18 | In `base_03`, $A$ = `r`, $B$ = `r2`, and exactly 10 of 30 plaquettes contain a non-identity link. | 3.1, 3.2 | Executable check | `test_c017_replay.py::test_torus_case_has_ten_plaquettes_with_a_non_identity_link` |
| PFP10-19 | The case $S_3$ table is isomorphic to the permutation group (six isomorphisms) and the case $Q_8$ table equals the package table. | 3.1 | Executable check | `test_c017_replay.py::test_case_groups_are_s3_and_q8` |
| PFP10-20 | Arm settings (prompt content, model, temperature, completion limit). | 3.1 | Source inspection | `eval_epistemic_immune_transfer.py` at `7e639a0be573f6affc4d84a2aacb5573da92bc79`; `eval_arm5_hybrid.py` at `9e45ee501e6a48086aaabd2381632eef6f7ed7a2` and `5327cfcb7ee3622e79f7d0cd884dfa37ef4eef56`; `eval_arm6_hierarchical_decimation.py` at `eb5fc971ae44320ff8183f09343d547f830d9d56` (all in the C017 folder) |
| PFP10-21 | Accepted certificates per run: 0, 0, 3, 3 and 4 of 5; verdict labels equal to the host: 4, 2, 3, 3 and 4 of 5 (Table 2). | 3.2 | Retained record; executable check | `results/immune_transfer_report.json` at `7e639a0be573f6affc4d84a2aacb5573da92bc79`; `results/arm5_hybrid_report.json` at `9e45ee501e6a48086aaabd2381632eef6f7ed7a2`; `results/arm5_stealth_space_bunny_alpha_report.json` at `5327cfcb7ee3622e79f7d0cd884dfa37ef4eef56`; `results/arm6_stealth_space_bunny_alpha_report.json` at `eb5fc971ae44320ff8183f09343d547f830d9d56`; `test_c017_replay.py::test_recorded_outcomes_for_arms_1_and_2`; `test_c017_replay.py::test_retained_certificates_agree_with_recorded_outcomes` |
| PFP10-22 | The package's certificate check agrees with the harness on all 15 retained solution records (10 accepted, 5 rejected). | 3.2 | Executable check | `code/data/c017/model_claims.json`; `test_c017_replay.py::test_retained_certificates_agree_with_recorded_outcomes` |
| PFP10-23 | Three Arm 1 and two Arm 2 answers were rejected because the plaquette was listed in the reverse vertex order; the Arm 1 and Arm 2 prompts did not state the accepted order. | 3.2 | Retained record; source inspection; executable check | `results/immune_transfer_report.json` and `eval_epistemic_immune_transfer.py` at `7e639a0be573f6affc4d84a2aacb5573da92bc79`; `test_c017_replay.py::test_recorded_outcomes_for_arms_1_and_2` |
| PFP10-24 | For `base_03`, the Arm 5 reply of `stealth/space-bunny-alpha` stopped at 8,000 completion tokens with unfinished JSON; the Arm 6 reply used 2,810 completion tokens and was accepted. | 3.2 | Retained record; executable check | `results/arm5_stealth_space_bunny_alpha_report.json` and `results/arm6_stealth_space_bunny_alpha_report.json`; `test_c017_replay.py::test_completion_lengths_recorded_for_the_torus_case` |
| PFP10-25 | The only retained `PURE_GAUGE` answer is the Arm 2 answer for `base_01`, whose gauge fails on the edge $(0,1) \to (0,2)$; the three Arm 5 and Arm 6 answers for `base_02` stated a flat plaquette as non-flat. | 3.2 | Retained record | `results/immune_transfer_report.json`; `code/data/c017/model_claims.json` |
| PFP10-26 | Both C017 harness checkers import the plaquette list and path product from the challenge's reference solver. | 3.2 | Source inspection | `judge_packet/checkers/algebraic_holonomy_checker.py` and `judge_packet/checkers/independent_checker.py` import `reference_solver/lattice_holonomy.py` (C017 folder) |
| PFP10-27 | Each C017 report's SHA-256 digest equals the digest in its receipt file. | 3.3 | Retained record | `results/receipt.json`, `results/receipt_arm5.json` (at `9e45ee501e6a48086aaabd2381632eef6f7ed7a2`), `results/receipt_arm5_stealth_space_bunny_alpha.json`, `results/receipt_arm6_stealth_space_bunny_alpha.json` (C017 folder) |

## Formal-mathematics pilots (Section 4)

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-28 | Counts in Table 3, n = 10 per cell, one reply per case; a pass required both checkers. The counts are made under leaked labels (PFP10-37) and do not measure unaided performance. | 4.1 | Retained record | `c045_knot_polynomials_from_pd/empirical_results/c045_space_bunny_matrix_report.json` at `ea2b55d841bdbe283f2f6ac77abe8a1677cbf0f8`; the C046, C047, C048 and C049 panel B reports (`*_space_bunny_matrix_report.json`) and the C049 panel A files (`results_*.json`) at `46bd1dec156260f073b77caa07d8a453f8efad30`; the C050 report at `46bd1dec156260f073b77caa07d8a453f8efad30` (run 1) and `5a256c6e8d088c612332362a8abc53138806ac7a` (run 2) |
| PFP10-29 | Completion limits, temperature 0 and panel definitions set by the runners; the C049 panel B runner is not retained. | 4.1 | Source inspection | `run_c045_matrix.py` to `run_c050_matrix.py` in the challenge folders at the commits of PFP10-28 |
| PFP10-30 | C050 was run twice with the same runner and cases; start times 98 seconds apart; five of ten `stealth/space-bunny-alpha` outcomes changed, two through API errors. | 4.1 | Retained record | C050 report at `46bd1dec156260f073b77caa07d8a453f8efad30` and at `5a256c6e8d088c612332362a8abc53138806ac7a` |
| PFP10-31 | In C045 all 8 and in C046 5 of 6 `stealth/space-bunny-alpha` failures returned no answer object, at 4,751 to 4,845 and 4,624 to 4,747 recorded tokens; the second checker reported acceptance for these empty answers. | 4.2 | Retained record | C045 and C046 reports (PFP10-28); the extent of the second-checker defects is PFP10-39 |
| PFP10-32 | In C047 case m06 the second checker accepted an absence certificate that the exact checker rejected; on m07, m08 and m10 no model returned a certificate both checkers accepted. | 4.2 | Retained record; source inspection | C047 report (PFP10-28); panel in `c047_sequence_law_discovery/run_c047_matrix.py`; `c047_sequence_law_discovery/judge_packet/exact_checker.py` uses a fraction-free determinant (reference 5) |
| PFP10-33 | C043 and C044 scoring receipts record the reference solver passing 64 of 64 hidden cases with no checker disagreement and 48 of 48 mutations rejected; no receipt is retained for C045 to C050; each judge packet retains 64 cases and 48 mutations. | 4.3 | Retained record | `c043_ramsey_vdw_constructions/commit_reveal/c043_l41_scoring_receipt.json` at `50197478726e5ecb791e519760cee9a79af2af27`; `c044_finite_group_identification/commit_reveal/c044_l41_scoring_receipt.json` at `999b36c1afed0f905f634f83adc1c646da7b975e`; judge packet folders |
| PFP10-34 | The C043 and C044 model run reports are not retained in the repository; the C044 runner sent each example's `note`, which names the group or the expected verdict, and the C043 prompts carried no note. | 4.3 | Source inspection | `run_c043_matrix.py` writes to `_intelligence/symbol_game/runs/` inside the repository, which the repository ignores (`.gitignore`, pattern `runs/`); `run_c044_matrix.py` (commit `999b36c1afed0f905f634f83adc1c646da7b975e`, lines 134, 153 and 204) reads ten files `participant_packet/examples/c044_pub_*.json`, sends each whole, and writes its report to `parents[6]`, outside the repository; no such report exists in the repository history; a file of that name outside the repository has SHA-256 `5fecd63f08dc1b5b2094fe6b722c236f284567b52a9a140f62d4825e63e8648b` |

## Scope statements

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-35 | `stealth/space-bunny-alpha` is a new free stealth model offered on OpenRouter as of 2026-09-28; the provider does not disclose its identity, size or training; its results are exploratory, fall outside SG-CP v1 §2, and may not be reproducible after the stealth period. | 3.1, 5 | Scope statement | Model identifier in the retained reports; no provider, size or training record exists; `omega_engine_projects/mssn_sn_symgam/challenges/01_challenge_protocol.md` §2 |
| PFP10-36 | No comparison between prompts or models is claimed; no statistical test was run; costs are not reported. | 4.1, 5 | Scope statement | Sections 4.1 and 5 |

## Erratum of version 0.1.0 (Section 4)

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-37 | Each C045 to C050 runner sent `Case ID: <id>` before the case data; for 36 of the 60 cases in the six panels whose runner is retained the identifier names the expected verdict or answer (C045 7, C046 5, C047 4, C048 10, C049 panel A 5, C050 5); the C045, C046, C049 and C050 runners sent the whole case record, including the `note` of C049 m10 and C050 m09. | 4.1 | Source inspection; replay | Prompt lines `run_c045_matrix.py:219`, `run_c046_matrix.py:270`, `run_c047_matrix.py:221`, `run_c048_matrix.py:163`, `run_c049_matrix.py:264`, `run_c050_matrix.py:236` at the run commits of PFP10-28 and at the code baseline; the panel identifiers, the notes and the author's reading of each identifier are listed in `verification/formal_math_baselines.json` (`prompt_lines`, `panel_case_ids`, `panel_cases_with_note`, `identifier_reading_ids`); the reading is a judgment, recorded so that it can be disputed case by case |
| PFP10-38 | Under the runners' pass rule, the best answer that needs no mathematics passes 10, 10, 0, 3, 2 and 1 of the ten cases of C045, C046, C047, C048, C049 panel A and C050; in C045 and C046 it is a refusal of every case with any listed reason. | 4.1 | Replay | `verification/formal_math_baselines.json`, field `best_trivial_both_accept` and the rows under `trivial_answers` |
| PFP10-39 | The C045 and C046 second checkers accept `{}`, a bare abstention and any refusal with a reason and a witness on all ten cases; the C047 second checker accepts an empty coefficient list and an empty list of minor rows on 9 of 10; the C048 second checker accepts any out-of-scope answer on all ten; the C049 second checker accepts a constant "does not exist" on 8 of 10; the C045 and C046 exact checkers accept any refusal that carries a reason. | 4.2 | Replay; source inspection | `verification/formal_math_baselines.json`; `c045_knot_polynomials_from_pd/judge_packet/checkers/exact_checker.py` lines 26 to 29 and `c046_knuth_bendix_completion/judge_packet/checkers/exact_checker.py` lines 28 to 31 at the run commits |
| PFP10-40 | In C045 and C046 the models' passes include refusals only on the cases whose identifiers name a refusal (C045 m09 and m10; C046 m08 to m10). | 4.1 | Retained record | The `parsed_ans` fields of the C045 and C046 reports (PFP10-28) |
| PFP10-41 | After the runs, the harness was corrected: the C045 and C046 second checkers recompute the answer, so a refusal of every case, `{}` and an empty answer fail them; the C047 second checker refuses empty certificates; the C048 second checker accepts an out-of-scope answer only for a non-integer coefficient; the runners use opaque per-run tokens; the C045 and C046 exact checkers still accept any refusal. | 4.2, 4.3 | Source inspection; replay | The corrected runners and checkers at commits `e6fbc15cf011121597a82a1d199626063bedf7c0` and `e2f7a3500413af960c6001832a1ab096a7a14af8`; the trivial answers of Section 4.2 replayed against them on 2026-09-29 (recorded in the collection's verification report) |

## Current v0.1 publication review

Earlier source inspections and formal-checker/Lean executions remain historical.
The current package-local execution record is `docs/v01_review_2026_10_02.json`.
This revision freshly executes the host tests and C017 replay, and audits the
bundled historical report bytes/counts; it does not repeat the C045–C050 checkers,
pinned Lean build, or model runs.

| ID | Claim | Section | Kind | Evidence |
| --- | --- | --- | --- | --- |
| PFP10-42 | Parsed edge aliases cannot overwrite links; unknown/non-string links are typed refusals. | 2.2, 2.4 | Executable check | `test_duplicate_parsed_edges_cannot_overwrite_links`; `test_unknown_link_values_are_typed_refusals` |
| PFP10-43 | Conflicting parsed gauge aliases are rejected, and malformed table shapes/empty cycles receive typed errors. | 2.2, 2.4 | Executable check | `test_duplicate_gauge_vertices_cannot_hide_conflicting_values`; `test_malformed_group_shapes_raise_group_table_error`; `test_missing_case_fields_and_empty_cycle_raise_lattice_error` |
| PFP10-44 | Fifteen original historical evidence files match source Git blob and SHA-256 hashes; 25 C017 extraction entries match their source reports. | 3.3, 6 | Executable custody/extraction check | `docs/historical_evidence/provenance.json`; `test_historical_sources_and_c017_extraction_match_original_bytes` |
| PFP10-45 | Table 3 is reproduced from original per-case acceptance/error records. | 4.1, 6 | Offline recount of retained records | `test_table3_counts_follow_per_case_acceptance_flags`; `code/recount_pilots.py` |
| PFP10-46 | Table 4's author categories partition the 60 identifiers and its prior baseline counts are internally consistent. | 4.1, 6 | Offline recount of author annotation/prior replay | `test_table4_recounts_author_categories_and_prior_baseline_record`; not a new leakage classification or checker execution |
| PFP10-47 | The 100 seam connections comprise 58 flat (2 trivial, 56 nontrivial) and 42 non-flat cases; capstone skipping changes 20 to 0 under gauge. | 2.4, companion | Finite-family execution | `tools/study_capstone.py`; this is not an exhaustive test of all connections or a learner outcome |
