import AuthorityGap

#print axioms hidden_bit_counts
#print axioms hidden_bit_half
#print axioms hidden_bit_positive
#print axioms local_green_does_not_imply_global
#print axioms unconditional_red_ratio
#print axioms backlog_example
#print axioms manuscript_backlog_step
#print axioms backlog_positive
#print axioms verified_share
#print axioms missing_descent_is_refuted
#print axioms nonzero_residual_is_refuted
#print axioms scoped_residual_is_outside_this_rule
#print axioms restricted_acceptance_zero_defect
#print axioms global_evaluation_does_not_factor
