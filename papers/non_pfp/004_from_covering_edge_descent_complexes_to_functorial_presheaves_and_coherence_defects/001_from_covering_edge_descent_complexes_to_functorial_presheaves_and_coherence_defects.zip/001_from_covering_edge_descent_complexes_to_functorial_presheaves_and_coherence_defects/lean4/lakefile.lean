import Lake

open Lake DSL

package «po001» where
  version := v!"2.0.0"

require mathlib from git
  "https://github.com/leanprover-community/mathlib4" @
    "5ed2965256430c3649e86755f9576b54eca72435"

@[default_target]
lean_lib «Po001» where
  srcDir := "."
  roots := #[
    `StrictCompletion,
    `PrimitiveDifference,
    `PrimitiveDifferenceLggr,
    `CurvatureCochain,
    `CohomologyClass,
    `CurvedDerivation,
    `AllDegreeCurvature,
    `ConcreteIncidence,
    `HeterogeneousIncidence,
    `TransportIdentities,
    `FlatLossAndCurvature,
    `CurvedDerivationStandalone,
    `CODAWitnessStandalone,
    `PrimeTriadRouterStandalone,
    `ReggeBianchiStandalone,
    `SheafContextualityStandalone,
    `Core,
    `AxiomAudit,
    `Census,
  ]
