# Licensing

What each licence covers in this repository. AuthorityEffect: None.

| Material | Licence | SPDX identifier |
| --- | --- | --- |
| Code: the Rust workspace `omega_engine/crates_rs`, the `omega_engine_*` Python packages, and every other file not listed below | PolyForm Noncommercial 1.0.0 (`LICENSE`) | `PolyForm-Noncommercial-1.0.0` |
| Paper text and figures | Creative Commons Attribution 4.0 International | `CC-BY-4.0` |
| Research paper packages under `research/` | Each package's own `LICENSE` and `LICENSE-CODE`, for its current version | as stated in the package |

## Commercial use

PolyForm Noncommercial permits personal, research, educational and other
noncommercial use without charge, including use by charitable, educational,
public research and government organisations. Any commercial use of the code
needs a separate paid licence. Contact Jeremy H. Carroll via
<https://github.com/dbccpage> for commercial licensing.

## Required notice

Anyone who passes on any part of the code must pass on the licence terms and
this line with it:

> Required Notice: Copyright 2026 Jeremy H. Carroll (https://github.com/dbccpage)

## Research paper packages

A research package's own licence files govern its current version. Its code
moves to PolyForm Noncommercial 1.0.0 at its next version; its text stays
CC BY 4.0. A version already deposited, on Zenodo or elsewhere, keeps the
licence it was deposited under. At the time of this change:

- 33 packages carry a `LICENSE-CODE` file granting Apache-2.0. Each is pinned in
  its package's `SHA256SUMS`, and 15 of those packages also commit a deposit
  archive whose bytes are fixed.
- 71 packages carry a single `LICENSE` that grants code under Apache-2.0 and
  text under CC BY 4.0.

Packages switched since then: `research/omega_engine_discrete_deformation_calculus`
at v1.0.0 (`LICENSE` CC BY 4.0, `LICENSE-CODE` PolyForm Noncommercial 1.0.0);
`research/omega_engine_prime_algos` at v1.0.0 (`LICENSE` CC BY 4.0, `LICENSE-CODE`
PolyForm Noncommercial 1.0.0).

## History

Before this change the repository root was licensed under the Apache License
2.0, and the crates under MIT, Apache-2.0 or "MIT OR Apache-2.0", or declared
no licence. Those grants remain valid for the copies that carried them.

## Licence text

`LICENSE` begins with the Required Notice, followed by the PolyForm
Noncommercial License 1.0.0 exactly as published at
<https://polyformproject.org/licenses/noncommercial/1.0.0>, taken from the
`polyformproject/polyform-licenses` repository at tag `1.0.0` (text SHA-256
`c0ea4a896d2c8c394b29f9427589996db826cd501c512279ff0ed3ef48fabbe5`).
