# Source-pin review — three `omega_functional` rows in `reviewed_source_bindings.v1.json`

**Date:** 2026-09-25  
**Manifest:** `omega_engine_governance/contracts/contracts_omega_engine_crates/omega_contracts/reviewed_source_bindings.v1.json`  
**Rows:** `lib.rs` (`functional_module_composition`), `phi1.rs` (`verified_phi1_certificate`), `contract_descriptors.rs` (`functional_registry`)  
**Pinned bytes reviewed from:** `7432d15a` (the blobs the old `source_sha256` values hash to)  
**Pin change reviewed:** `9c6a00de` on `claude/lucid-clarke-tjfsbq` (dbccpage/the_symbol_game#80). The branch head at review close was `5f9021f8`, which leaves these rows unchanged.  
**Requested by:** repository owner  
**Reviewer:** Claude (Claude Code session `session_01MkZdn6THWDRD1nwCpVcaWW`), independent of the session that wrote `9c6a00de` (`session_01QknyEXLTfqutAxHoxahWPm`)  
**Human decision:** pending. This receipt is an AI review; it is not a promotion.  
**AuthorityEffect:** `None`  
**Nonclaims:** Static source-pin review with the named tests executed. Not behavioral acceptance of `omega_functional`. Not PROVED. Not GlobalGreen. The seven math contracts added in `bcd3bdf0` were checked only for identity and dependency agreement with the registry, not re-reviewed as mathematics.

## Verdict

```text
SOURCE_PIN_REVIEW: PASS_WITH_RESIDUAL
lib.rs=PASS phi1.rs=PASS_WITH_RESIDUAL contract_descriptors.rs=PASS
Pins: the three source_sha256 values in 9c6a00de match independently recomputed digests; no other row changed
Documents: all 31 document_sha256 pins unchanged and matching
Residuals: R1 R2 R3 (below)
AuthorityEffect: None
```

## Pins

| Source | Pinned (`7432d15a`) | Refreshed (`9c6a00de`) | Changed by |
| --- | --- | --- | --- |
| `omega_functional/src/lib.rs` | `c043f13c…925f6ac0` | `f994eea5…5fd7964c` | `07e9f187`, `abbdf211`, `117d6d6f`, `23718756` |
| `omega_functional/src/phi1.rs` | `480e42df…0f72dd68` | `f4e3ac47…0ca69af1` | `07e9f187` |
| `omega_functional/src/contract_descriptors.rs` | `75f2ecc0…77d2b34b` | `104df87d…85ad6be7` | `84cc7ce3` (PR #80) |

Digests are shown as the first and last eight hex digits. The full values are in the manifest.

## Per-file review

### `lib.rs` — `functional_module_composition` — PASS

- **Diff:** seven `pub mod` lines (`phi1_arithmetic`, `phi2`, `phi3`, `phi4`, `graph_phi1`, `binary_degree`, `trace_diagnostics`) and three `pub use` lines re-exporting `ExactPhi{2,3,4}Certificate`, `Phi{2,3,4}Functional`, `VerifiedExactPhi{2,3,4}`. Nothing else.
- **required_substrings:** all three present.
- **required_tests:** none declared.
- **must_not `export_a_missing_native_module`:** holds. Every `pub mod` in the file resolves to a source file, and all nine re-exported names are `pub` items in their modules.
- **does_not_own:** holds. The file adds exports only. Whether the re-exported `phi2`–`phi4` code is mathematically correct belongs to the seven math contracts from PR #80, not to this contract. `omega_functional/Cargo.toml` gained four `[[bin]]` targets and no dependencies, so the dependency boundary is unaffected. `dependency_boundary` passes (see Execution evidence).

### `phi1.rs` — `verified_phi1_certificate` — PASS_WITH_RESIDUAL

- **Diff:** one new function, `Phi1Functional::scaled_verified_value(&VerifiedExactPhi1, i128) -> Option<BigRational>`. It returns `None` for a scale of 0 or less. Otherwise it returns `value() / scale`. The verifier path is unchanged.
- **required_substrings:** all three present.
- **required_tests:** all nine exist and pass.
- **must_not:** holds. The helper borrows a sealed `VerifiedExactPhi1` and returns a new `BigRational`. It builds no `VerifiedExactPhi1`: the only constructor is still the `Ok(VerifiedExactPhi1 { certificate })` at the end of `verify_exact_certificate`. It mutates no verified evidence and promotes nothing.
- **does_not_own:** holds. The helper runs no solver and authenticates no carrier.
- **Residuals:** R1 and R2.

### `contract_descriptors.rs` — `functional_registry` — PASS

- **Diff:** seven `FunctionalContractBinding` rows and seven URNs appended to `FUNCTIONAL_LAYER_BOUNDARY_DEPENDENCY_CONTRACT_URNS`. Nothing else.
- **required_substrings:** all three present.
- **required_tests:** all six exist and pass.
- **must_not `register_duplicate_or_empty_identities`:** holds. `FUNCTIONAL_CONTRACT_BINDINGS` has 39 rows and no repeated URN. The six URNs that appear twice elsewhere in the file were already there at `7432d15a` and are outside this table.
- **Row checks, done independently of the tests:**
  - Each new row's `canonical_file` exists under `math/` and its `contract_id` equals the row's URN.
  - Every `rust_symbols` entry is a `pub` item in the named module.
  - Every dependency URN is registered earlier in the table.
  - Each row's `dependency_contract_urns` equals its YAML's `dependencies.contracts`. Two rows depend on `phi1`, one on `phi1` and `gamma2_closure_defect`, and four have none.
- **must_not `self_assign_mathematical_or_terminal_authority`:** holds. The added lines are identity data only.
- **does_not_own:** holds. The registry claims nothing about enforcement.

## Execution evidence

Commands were run from `omega_engine/crates_rs` with `CARGO_INCREMENTAL=0` and `-j 1`, one test binary at a time, on `9c6a00de`.

| Command | Before (`84cc7ce3` manifest) | After (`9c6a00de`) |
| --- | --- | --- |
| `cargo test -p omega_contracts --test source_bindings` | 21/22. `published_binding_scope_matches_reviewed_governance_bytes` fails with exactly three `StaleSource` findings: `contract_descriptors.rs`, `lib.rs`, `phi1.rs` | 22/22, and 22/22 on `main` (`6d92b8ad`) merged with PR #80 head (`5f9021f8`) |
| `cargo test -p omega_functional --lib -- phi1::tests:: contract_descriptors::tests::` | n/a | 41/41. That is 27 `contract_descriptors`, 9 `phi1` and 5 `graph_phi1`, which the substring filter also matches. It includes all 15 required tests of the two contracts. |
| `cargo test -p omega_functional --test functional_boundary` | n/a | 14/14 |
| `cargo test -p omega_functional --test dependency_boundary` | n/a | 10/10 |

For the before run, the manifest was temporarily replaced by its `84cc7ce3` blob and then restored. The test reads the manifest at run time, so both runs used the same compiled binary.

### Operations tests that read the manifest

Sixteen files under `omega_engine_operations/tests/unit/` read `reviewed_source_bindings.v1.json`. Each file was run on its own with pytest 9.1.1, in a full-history clone (438 commits, not shallow), in three trees:

| Tree | Tests | Pass | Fail |
| --- | ---: | ---: | ---: |
| `main` (`67b1cd65`) | 73 | 31 | 42 |
| PR #80 before re-pin (`84cc7ce3`) | 73 | 31 | 42 |
| PR #80 after re-pin (`9c6a00de`) | 73 | 32 | 41 |
| `main` (`6d92b8ad`) merged with `84cc7ce3` | 73 | 31 | 42 |
| `main` (`6d92b8ad`) merged with PR #80 head (`5f9021f8`) | 73 | 32 | 41 |

`main` moved to `6d92b8ad` and PR #80 moved to `5f9021f8` during this review. The last two rows re-check the result against both. Neither move touched the three sources, the manifest or the governing contracts. `5f9021f8` only removes two rows from `v1_rust_binding_findings_baseline.txt`. On both merges the pass sets are the same as in the earlier runs.

- **Regressions:** none.
- **Fixed:** `test_functional_dependency_gate_migration.py::test_current_dependency_gate_and_reclassified_sources_have_exact_file_bindings`.
- **Still failing, for a different reason:** `test_verified_obstruction_mass_migration.py::test_native_mass_migration_binds_each_changed_native_source_and_contract` (R3).
- **Other 40 failures:** identical before and after, and on `main`. The two runs differ only in the worktree path printed in four error messages. Causes:
  - 25 `git cat-file blob` lookups of commits that are not in the repository's history;
  - 5 digest assertions on other evidence files;
  - 5 count, census or exit-code assertions;
  - 4 retired `omega_engine/crates/functional/*.py` files;
  - 1 `RUST_FUNCTIONAL_REQUIRED` runtime refusal.

## Residuals

- **R1 — `phi1.rs`, untested refusal.** No test reaches the helper's `scale <= 0` branch. `omega_mub/tests/test_target_a9_haagerup.rs` passes scales of 0 and -30000 to `certify_haagerup_cycle_circulation`. `build_haagerup_cochain(scale)?` refuses both before the helper runs, so they never reach it. The only test that calls the helper directly is `omega_solvers/tests/network_simplex_hardening.rs`, with `scale = 1`. The helper is also not named in the contract's `owns` list. It sits closest to `read_only_certificate_export`. Its result is an unsealed `BigRational`, not a `VerifiedExactPhi1`.
- **R2 — `phi1.rs` callers, outside this contract.** The `9c6a00de` note is right that only one test calls the helper, but it does not mention the four production callers in `omega_mub`. All four go through `omega_solvers::phi1_l1_boundary_solver::solve_phi1` and then `Phi1Solution::scaled_verified_value`:
  - `mub6_nerve_chaining.rs`
  - `mub6_global_cover.rs`
  - `mub6_haagerup.rs`
  - `mub6_grand_synthesis.rs`

  They bind the result to names such as `rational_phi1`. `value / scale` equals Φ₁ of the original cochain only when the caller scaled it exactly. `build_haagerup_cochain` truncates `margin · S` with `to_integer()`. That is exact at the documented `S = 30000` but not at every scale. The other three callers were not audited. This belongs to `omega_mub`, because `phi1.rs` does not own the certificate-generating solver. It does not block this pin.
- **R3 — historical record vs live pin.** `test_verified_obstruction_mass_migration` requires every row of `verified_obstruction_mass_001/migration.json` to be in the live manifest **and** to match current bytes. That record's `phi1.rs` row carries `480e42df…`. Once `phi1.rs` changed in `07e9f187`, both conditions could no longer hold at once:
  - before the re-pin, the byte check fails;
  - after it, the membership check fails.

  `test_born_native_migration` already treats its migration record as "historical custody, not a freeze on later source changes". Giving this test the same treatment is a separate change. The historical evidence record is left as it is.

**AuthorityEffect: `None`.**
