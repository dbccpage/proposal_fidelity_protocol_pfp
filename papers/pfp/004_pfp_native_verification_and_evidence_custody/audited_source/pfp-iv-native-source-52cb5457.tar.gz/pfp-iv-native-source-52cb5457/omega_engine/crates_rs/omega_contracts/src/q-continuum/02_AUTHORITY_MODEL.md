Authority Model
===============

Definition
----------

Authority is accumulated bounded reliability. It is not status, reputation, citation count, or narrative confidence.

The implemented model uses structured evidence rather than numeric scores. There is no fake decimal confidence field.

Authority Inputs
----------------

Authority can be built from:

* provenance,
* finite descent attempts,
* successful witnesses,
* failed witnesses,
* counterexamples,
* adversarial attacks survived,
* scope limits,
* reproducibility,
* terminal statuses,
* residuals.

Strength Ladder
---------------

The implemented `AuthorityStrength` values are:

* `Untrusted`
* `Speculative`
* `Probed`
* `ConditionallySupported`
* `AdversariallySurvived`
* `TerminalWithinScope`

The ladder is scoped. `TerminalWithinScope` is not global truth. It means the trace has an in-scope `Supported` descent result with a finite witness.

AuthorityTrace Questions
------------------------

1. What is this authority about?
   * `AuthorityTrace.about`

2. What scope does it apply to?
   * `AuthorityTrace.scope`

3. What finite descents support it?
   * `AuthorityTrace.successful_descents`

4. What finite descents failed?
   * `AuthorityTrace.failed_descents`

5. What residuals remain?
   * `AuthorityTrace.residuals`

6. What counterexamples exist?
   * `AuthorityTrace.counterexamples`

7. What terminal statuses were reached?
   * `AuthorityTrace.terminal_statuses`

8. What would weaken or revoke the authority?
   * `AuthorityTrace.revocation_conditions`

9. What is still speculative?
   * `AuthorityTrace.speculative_notes`

Update Rule
-----------

`AuthorityTrace::record_descent_result` updates strength only after a descent result is recorded. A support status without a witness is converted into a failed descent with a `MissingWitness` residual. A scope mismatch is recorded as `ScopeViolation`.

Revocation
----------

Authority should be weakened or revoked when:

* a replay path fails,
* a witness is withdrawn,
* a counterexample lands inside scope,
* the result is applied outside its scope,
* required definitions change,
* the finite projection is shown to be malformed.

Relation To Existing Authority Types
------------------------------------

The Q-continuum model is intentionally weaker than certified authority machinery already present in the repo. It is a staging and trace surface. It must not mint certified authority.
