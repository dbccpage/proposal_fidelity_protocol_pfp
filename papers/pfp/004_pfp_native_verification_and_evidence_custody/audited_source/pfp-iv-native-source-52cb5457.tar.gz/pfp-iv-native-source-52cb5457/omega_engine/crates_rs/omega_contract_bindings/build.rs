//! Runs the contract binding audit and prints it as cargo warnings.
//!
//! Warning-only: nothing here fails the build. Once coverage is high enough,
//! the switch to enforcement is a test that asserts on `summary::UNRESOLVED`.

#[path = "src/audit.rs"]
mod audit;

use std::path::PathBuf;

fn main() {
    let manifest = PathBuf::from(std::env::var("CARGO_MANIFEST_DIR").unwrap());
    let out_dir = PathBuf::from(std::env::var("OUT_DIR").unwrap());
    let repo_root = manifest
        .ancestors()
        .nth(3)
        .expect("crate sits at <repo>/omega_engine/crates_rs/<crate>")
        .to_path_buf();

    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-changed=src/audit.rs");

    let report = match audit::audit(&repo_root) {
        Ok(report) => report,
        Err(error) => {
            println!("cargo:warning=CONTRACT_BINDING_AUDIT_NOT_RUN: {error}");
            audit::AuditReport::default()
        }
    };
    for path in &report.watched {
        println!("cargo:rerun-if-changed={}", path.display());
    }

    let report_path = out_dir.join("contract_binding_audit.txt");
    std::fs::write(&report_path, audit::render_report(&report))
        .unwrap_or_else(|e| panic!("write {}: {e}", report_path.display()));
    std::fs::write(
        out_dir.join("binding_audit_summary.rs"),
        audit::render_summary(&report),
    )
    .unwrap_or_else(|e| panic!("write binding_audit_summary.rs: {e}"));

    for line in audit::warning_lines(&report, &report_path.display().to_string()) {
        println!("cargo:warning={line}");
    }
}
