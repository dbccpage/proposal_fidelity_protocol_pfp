use crate::kinds::{Capability, ContractEffect};
use serde::{Deserialize, Serialize};

/// Classification of witness types.
///
/// Per 02_evidence.yaml witness contract, witnesses are typed attestation records.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WitnessClass {
    /// Structural witness: proves structural properties (e.g., basis independence)
    Structural,
    /// Behavioral witness: proves behavioral properties (e.g., replay integrity)
    Behavioral,
    /// Empirical witness: statistical evidence from sampling (e.g., phi monotonicity)
    Empirical,
}

/// Witness certainty hierarchy (epistemic certainty of a witness).
///
/// From highest to lowest certainty. This is the **witness-certainty axis**,
/// distinct from `EvidenceCeiling` (host verification capability) and
/// `WitnessClass` (kind antichain). Three independent axes.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash, Serialize, Deserialize)]
#[repr(u8)]
pub enum WitnessCertainty {
    /// Human-declared evidence (lowest certainty)
    HumanDeclared = 0,
    /// Statistical witness (e.g., property-based testing)
    StatisticalWitness = 1,
    /// Exhaustive finite proof (e.g., all cases enumerated)
    ExhaustiveFiniteProof = 2,
    /// Property witness (e.g., verified behavioral property)
    PropertyWitness = 3,
    /// Full structural proof (e.g., type-level guarantee)
    StructuralProof = 4,
}

/// Witness verification status.
///
/// Per 02_evidence.yaml witness contract:
/// - Verified: witness verification succeeded
/// - Failed: witness verification failed
/// - Indeterminate: verification could not conclude
/// - Inapplicable: verification is not applicable to this witness type
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WitnessVerificationStatus {
    Verified,
    Failed,
    Indeterminate,
    Inapplicable,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LawViolation {
    pub property: &'static str,
    pub description: String,
}

/// Validation witness trait.
///
/// Per 02_evidence.yaml witness contract:
/// - Role: "Typed attestation record binding a claim to computational evidence"
/// - authority_effect: EvidenceOnly (witnesses carry no authority themselves)
/// - Witnesses are EvidenceEnvelope, not StructureArtifact as primary output
///
/// Witnesses must NOT:
/// - certify or sign certificates
/// - verify themselves (self-verification forbidden)
/// - evaluate admissibility
/// - interpret policy
/// - map terminal outcomes
/// - execute state transitions
/// - authorize transitions
/// - license actions
/// - upgrade authority
/// - mutate state
pub trait ValidationWitness:
    core::fmt::Debug + Send + Sync + erased_serde::Serialize + 'static
{
    fn property(&self) -> &'static str;
    fn class(&self) -> WitnessClass;
    fn witness_certainty(&self) -> WitnessCertainty;

    /// Returns the authority effect of this witness.
    ///
    /// Per 02_evidence.yaml: Witnesses always carry EvidenceOnly authority.
    /// A verified witness may support FactOnly claims only through a declared
    /// verifier, CertificateKernel, ReplayVerifier, or validation boundary.
    fn authority_effect(&self) -> ContractEffect {
        ContractEffect::EvidenceOnly
    }
}

erased_serde::serialize_trait_object!(ValidationWitness);

/// Witness verification result.
///
/// Per 02_evidence.yaml witness contract structural_representation.verification_result.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WitnessVerificationResult {
    pub witness_id: String,
    pub verifier_id: String,
    pub verifier_version: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub status: WitnessVerificationStatus,
    pub result_hash: String,
    pub supporting_certificate_ref: Option<String>,
    pub authority_effect: ContractEffect,
}

impl WitnessVerificationResult {
    /// Create a new verification result.
    ///
    /// Per YAML contract, verification results are EvidenceOnly by default.
    pub fn new(
        witness_id: impl Into<String>,
        verifier_id: impl Into<String>,
        status: WitnessVerificationStatus,
        result_hash: impl Into<String>,
    ) -> Self {
        Self {
            witness_id: witness_id.into(),
            verifier_id: verifier_id.into(),
            verifier_version: "unspecified".to_string(),
            schema_hash: String::new(),
            witness_hash: String::new(),
            status,
            result_hash: result_hash.into(),
            supporting_certificate_ref: None,
            authority_effect: ContractEffect::EvidenceOnly,
        }
    }

    /// Add a supporting certificate reference.
    pub fn with_supporting_certificate_ref(mut self, cert_ref: impl Into<String>) -> Self {
        self.supporting_certificate_ref = Some(cert_ref.into());
        self
    }

    /// Backward-compatible alias for adding a supporting certificate reference.
    pub fn with_certificate_ref(self, cert_ref: impl Into<String>) -> Self {
        self.with_supporting_certificate_ref(cert_ref)
    }

    pub fn with_verifier_version(mut self, verifier_version: impl Into<String>) -> Self {
        self.verifier_version = verifier_version.into();
        self
    }

    pub fn with_schema_hash(mut self, schema_hash: impl Into<String>) -> Self {
        self.schema_hash = schema_hash.into();
        self
    }

    pub fn with_witness_hash(mut self, witness_hash: impl Into<String>) -> Self {
        self.witness_hash = witness_hash.into();
        self
    }
}

/// Canonical capabilities forbidden to witness producers and witness records.
pub const WITNESS_FORBIDDEN_CAPABILITIES: &[Capability] = &[
    Capability::CertificateSigning,
    Capability::SelfCertification,
    Capability::Evaluation,
    Capability::AdmissibilityDecision,
    Capability::PolicyInterpretation,
    Capability::TerminalMapping,
    Capability::ExecuteStateTransition,
    Capability::ActionLicensing,
    Capability::AuthorityPromotion,
    Capability::RuntimeMutation,
];

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct PhiMonotonicityWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub sample_count: usize,
    pub max_phi_delta: f64,
    pub violation_count: usize,
    pub maximum_observed_phi: f64,
    pub minimum_observed_phi: f64,
    pub violations: Vec<LawViolation>,
    pub distribution_metadata: String,
}

impl ValidationWitness for PhiMonotonicityWitness {
    fn property(&self) -> &'static str {
        "phi_monotonicity"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Empirical
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::StatisticalWitness
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct IdempotenceWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub samples_verified: usize,
}

impl ValidationWitness for IdempotenceWitness {
    fn property(&self) -> &'static str {
        "idempotence"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Empirical
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::StatisticalWitness
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct DeterminismWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub samples_verified: usize,
}

impl ValidationWitness for DeterminismWitness {
    fn property(&self) -> &'static str {
        "determinism"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Empirical
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::StatisticalWitness
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct ReplayWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub trace_hash: String,
    pub steps_verified: usize,
}

impl ValidationWitness for ReplayWitness {
    fn property(&self) -> &'static str {
        "replay_integrity"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Behavioral
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::PropertyWitness
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct HashWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub computed_hash: String,
}

impl ValidationWitness for HashWitness {
    fn property(&self) -> &'static str {
        "hash_verification"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Structural
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::StructuralProof
    }
}

pub trait WitnessProducer<S> {
    type Witness: ValidationWitness;
    fn produce(subject: &S) -> Self::Witness;
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct VectorSpaceAdmissibilityWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub dimension: usize,
    pub basis_hash: String,
    pub operations_verified: bool,
}

impl ValidationWitness for VectorSpaceAdmissibilityWitness {
    fn property(&self) -> &'static str {
        "vector_space_admissibility"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Structural
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::StructuralProof
    }
}

#[derive(Debug, Clone, PartialEq, Serialize)]
pub struct BasisLinearIndependenceWitness {
    pub witness_id: String,
    pub contract_id: String,
    pub schema_hash: String,
    pub witness_hash: String,
    pub produced_by: String,
    pub dimension: usize,
    pub basis_hash: String,
    pub rank_verified: bool,
}

impl ValidationWitness for BasisLinearIndependenceWitness {
    fn property(&self) -> &'static str {
        "basis_linear_independence"
    }
    fn class(&self) -> WitnessClass {
        WitnessClass::Structural
    }
    fn witness_certainty(&self) -> WitnessCertainty {
        WitnessCertainty::StructuralProof
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn witness_forbidden_capabilities_use_canonical_capability_enum() {
        assert!(WITNESS_FORBIDDEN_CAPABILITIES.contains(&Capability::SelfCertification));
        assert!(WITNESS_FORBIDDEN_CAPABILITIES.contains(&Capability::ActionLicensing));
        assert!(WITNESS_FORBIDDEN_CAPABILITIES.contains(&Capability::ExecuteStateTransition));
        assert!(WITNESS_FORBIDDEN_CAPABILITIES.contains(&Capability::AuthorityPromotion));
    }

    #[test]
    fn witness_verification_result_is_evidence_with_reference_metadata() {
        let result = WitnessVerificationResult::new(
            "wit:1",
            "verifier:1",
            WitnessVerificationStatus::Verified,
            "result:hash",
        )
        .with_verifier_version("v1")
        .with_schema_hash("schema:hash")
        .with_witness_hash("witness:hash")
        .with_supporting_certificate_ref("cert:ref");

        assert_eq!(result.authority_effect, ContractEffect::EvidenceOnly);
        assert_eq!(result.verifier_version, "v1");
        assert_eq!(result.schema_hash, "schema:hash");
        assert_eq!(result.witness_hash, "witness:hash");
        assert_eq!(
            result.supporting_certificate_ref.as_deref(),
            Some("cert:ref")
        );
    }

    #[test]
    fn witness_structs_carry_identity_hash_and_producer_metadata() {
        let witness = PhiMonotonicityWitness {
            witness_id: "wit:phi".to_string(),
            contract_id: "contract:lambda".to_string(),
            schema_hash: "schema:hash".to_string(),
            witness_hash: "witness:hash".to_string(),
            produced_by: "producer:v1".to_string(),
            sample_count: 2,
            max_phi_delta: 0.0,
            violation_count: 0,
            maximum_observed_phi: 1.0,
            minimum_observed_phi: 0.0,
            violations: Vec::new(),
            distribution_metadata: "explicit_finite_samples".to_string(),
        };

        assert_eq!(witness.authority_effect(), ContractEffect::EvidenceOnly);
        assert_eq!(witness.property(), "phi_monotonicity");
        assert_eq!(witness.witness_id, "wit:phi");
        assert_eq!(witness.witness_hash, "witness:hash");
        assert_eq!(witness.produced_by, "producer:v1");
    }
}
