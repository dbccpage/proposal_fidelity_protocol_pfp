use std::fs;
use std::path::{Path, PathBuf};

const LOW_LEVEL_AUTHORITY_CALLS: [&str; 3] = [
    "CertifiedAuthority::certify(",
    "authority_from_outcome_f13(",
    "authority_from_outcome(",
];

const MIGRATED_SOURCE_ROOTS: [&str; 7] = [
    "crates/omega_certifiers/src",
    "crates/omega_pipelines/src",
    "crates/omega_state/src",
    "crates/omega_rip_papers_runtime/src",
    "crates/omega_safety_controller/src",
    "crates/omega_symbol_game/src",
    "omega_layer_applications/omega_sweeper/src",
];

fn workspace_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .and_then(Path::parent)
        .expect("omega_contracts must be under omega_engine/crates")
        .to_path_buf()
}

fn collect_rust_files(root: &Path, files: &mut Vec<PathBuf>) {
    if !root.exists() {
        return;
    }
    let mut entries = fs::read_dir(root)
        .unwrap_or_else(|error| panic!("cannot read {}: {error}", root.display()))
        .map(|entry| entry.expect("directory entry must be readable").path())
        .collect::<Vec<_>>();
    entries.sort();
    for path in entries {
        if path.is_dir() {
            collect_rust_files(&path, files);
        } else if path.extension().and_then(|extension| extension.to_str()) == Some("rs") {
            files.push(path);
        }
    }
}

fn production_prefix(source: &str) -> &str {
    let unix = source.find("\n#[cfg(test)]");
    let windows = source.find("\r\n#[cfg(test)]");
    let end = match (unix, windows) {
        (Some(left), Some(right)) => left.min(right),
        (Some(index), None) | (None, Some(index)) => index,
        (None, None) => source.len(),
    };
    &source[..end]
}

fn normalized_relative(root: &Path, path: &Path) -> String {
    path.strip_prefix(root)
        .expect("scanned file must be under workspace root")
        .to_string_lossy()
        .replace('\\', "/")
}

#[test]
fn low_level_authority_construction_is_confined_to_the_type_owner_and_host_promotion() {
    let root = workspace_root();
    let mut files = Vec::new();
    let crates = root.join("crates");
    for entry in fs::read_dir(&crates).expect("workspace crates directory must be readable") {
        let path = entry
            .expect("crate directory entry must be readable")
            .path();
        if path.is_dir() {
            collect_rust_files(&path.join("src"), &mut files);
        }
    }
    collect_rust_files(&root.join("omega_layer_applications"), &mut files);
    collect_rust_files(&root.join("omega_layer_presentation"), &mut files);

    let allowed = [
        "crates/omega_types/src/authority.rs",
        "crates/omega_contracts/src/certificate_promotion.rs",
    ];
    let mut violations = Vec::new();
    for path in files {
        let relative = normalized_relative(&root, &path);
        if allowed.contains(&relative.as_str()) {
            continue;
        }
        let source = fs::read_to_string(&path)
            .unwrap_or_else(|error| panic!("cannot read {}: {error}", path.display()));
        let production = production_prefix(&source);
        for call in LOW_LEVEL_AUTHORITY_CALLS {
            if production.contains(call) {
                violations.push(format!("{relative}: {call}"));
            }
        }
    }
    violations.sort();
    assert!(
        violations.is_empty(),
        "low-level authority construction escaped its owners: {violations:#?}"
    );
}

#[test]
fn migrated_certificate_and_diagnostic_sources_have_no_authority_return_path() {
    let root = workspace_root();
    let forbidden = [
        "CertifiedAuthority::certify(",
        "Result<CertifiedAuthority",
        "fn certify_authority(",
        "TerminalStatus::certify",
    ];
    let mut violations = Vec::new();
    for relative_root in MIGRATED_SOURCE_ROOTS {
        let mut files = Vec::new();
        collect_rust_files(&root.join(relative_root), &mut files);
        for path in files {
            let relative = normalized_relative(&root, &path);
            let source = fs::read_to_string(&path)
                .unwrap_or_else(|error| panic!("cannot read {}: {error}", path.display()));
            let production = production_prefix(&source);
            for symbol in forbidden {
                if production.contains(symbol) {
                    violations.push(format!("{relative}: {symbol}"));
                }
            }
        }
    }
    violations.sort();
    assert!(
        violations.is_empty(),
        "migrated evidence source still exposes authority: {violations:#?}"
    );
}

#[test]
fn checked_packet_certificate_surface_declares_none_effect() {
    let source = include_str!("../src/certificate_promotion.rs");
    assert!(source.contains("authority_effect: AuthorityEffect::None"));
    assert!(!source.contains("pub fn new_host_promotion_capability"));
    assert!(!source.contains("impl Default for HostPromotionCapabilityV1"));
}
