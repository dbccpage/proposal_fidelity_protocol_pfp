//! Contract-specific firewall test for the InvariantDefectProfile contract (the
//! Operator-Shadow signature, invariant_discovery_theory.md Thm 7.1). Mirrors
//! `v1_trichotomy_firewall.rs`: a diagnostic math object MUST confer no authority
//! and MUST declare the order-sensitivity / no-self-assign negative tests.
use omega_contracts::registry::OmegaContractV1;
use omega_contracts::ContractEffect;
use std::path::Path;

#[test]
fn invariant_defect_profile_declares_authority_free_and_order_sensitive() {
    let p = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/math/invariant_defect_profile.contract.yaml");
    let text = std::fs::read_to_string(p).expect("invariant_defect_profile contract exists");
    let c: OmegaContractV1 = serde_yaml::from_str(&text).expect("parses as v1");

    // Firewall: a diagnostic signature confers NO authority and never runs as a gate.
    assert_eq!(
        c.descriptor.authority_effect,
        ContractEffect::None,
        "InvariantDefectProfile must declare authority_effect: none (it is a diagnostic, not authority)"
    );
    assert!(
        !c.descriptor.runtime_enforcement,
        "a pure diagnostic math object must not be a runtime-enforcing gate"
    );

    // Discipline: it must declare the order-sensitivity and no-self-assign negative tests
    // (the Operator-Shadow classifier is a non-commutative word, never an operator).
    let tests = c.negative_tests.as_ref().expect("negative_tests present");
    assert!(
        tests.iter().any(|t| {
            let t = t.to_lowercase();
            t.contains("commutative") || t.contains("order")
        }),
        "must declare a negative test against order-free / commutative collapse"
    );
    assert!(
        tests
            .iter()
            .any(|t| t.to_lowercase().contains("self_assigned")
                || t.to_lowercase().contains("effect_class")),
        "must declare a negative test against self-assigning a fixed-layer effect class"
    );
}
