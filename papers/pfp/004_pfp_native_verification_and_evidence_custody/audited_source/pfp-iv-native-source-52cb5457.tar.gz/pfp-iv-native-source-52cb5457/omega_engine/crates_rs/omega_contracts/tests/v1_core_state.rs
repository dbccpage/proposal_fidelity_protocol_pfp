//! Sprint 2b — the migrated 01_state layer loads and validates cleanly.
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn state_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/01_core_state");
    let report = load_v1_dir(&dir).expect("dir readable");
    assert_eq!(report.loaded, 5, "expected 5 migrated state contracts");
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
