//! Seeded omega.contract.v1 terminal/refusal vocabulary (spec §11.1).
//!
//! NO `omega_state` dependency (layer rule: `omega_contracts` must not depend on
//! `omega_state`, the same prohibition that applies to `omega_replay`). For the walking
//! skeleton this is a small local allow-list seeded with the trichotomy classes + generic
//! error vocabulary. A later sprint replaces/extends this with a generated global
//! `TermReg`/`RefusalReg`.

/// Terminal/class names recognized in v1 (Sprint 1 seed: trichotomy classes).
pub const V1_KNOWN_TERMINALS: &[&str] = &["ExactRepair", "StabilizedSurvivor", "OpenObstruction"];

/// Refusal/meta-outcome names recognized in v1 (Sprint 1 seed: trichotomy + generic errors).
pub const V1_KNOWN_REFUSALS: &[&str] = &[
    "Invalid",
    "Incomparable",
    "TriRefused(NumericUndecidable)",
    "NumericUndecidable",
    "DetectorInadequate",
    "NoRule",
    "RequiresLift",
    "Refused",
    "BudgetExhausted",
    "Cancelled",
    "UnknownTerminal",
    "UnknownRefusal",
];

pub fn is_known_terminal(name: &str) -> bool {
    V1_KNOWN_TERMINALS.contains(&name)
}

pub fn is_known_refusal(name: &str) -> bool {
    V1_KNOWN_REFUSALS.contains(&name)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn seeded_terminals_known() {
        assert!(is_known_terminal("ExactRepair"));
        assert!(is_known_terminal("StabilizedSurvivor"));
        assert!(is_known_terminal("OpenObstruction"));
        assert!(!is_known_terminal("MadeUpTerminal"));
    }

    #[test]
    fn seeded_refusals_known() {
        assert!(is_known_refusal("Invalid"));
        assert!(is_known_refusal("TriRefused(NumericUndecidable)"));
        assert!(is_known_refusal("DetectorInadequate"));
        assert!(is_known_refusal("NoRule"));
        assert!(is_known_refusal("RequiresLift"));
        assert!(is_known_refusal("Refused"));
        assert!(is_known_refusal("BudgetExhausted"));
        assert!(is_known_refusal("Cancelled"));
        assert!(!is_known_refusal("MadeUpRefusal"));
    }
}
