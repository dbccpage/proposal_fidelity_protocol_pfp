//! Compile-time contract images generated from `omega.contract.v1` YAML contracts that
//! declare a `rust_binding`.
//!
//! The generated file is emitted by `build.rs` after running the shared v1 validator. It
//! preserves the existing public image names such as `InvariantDefectProfileContract`,
//! `CochainComplexContract`, `FiniteObstructionTrichotomyContract`, and
//! `CouncilDecisionContract`.

include!(concat!(env!("OUT_DIR"), "/generated_contract_images.rs"));
