Adversarial Review
==================

Objections
----------

| Objection | Succeeds? | Evidence | Repair | Priority |
| --- | --- | --- | --- | --- |
| 1. Q-continuum is undefined. | Partly. | The docs define the first contract, but not a mathematical theory. | Keep it as an interface layer until formal definitions exist. | High |
| 2. This is just a staging area for vague ideas. | Partly. | It intentionally stages vague ideas, but forces finite probes and residuals. | Require every accepted object to produce probes or remain explicitly speculative. | High |
| 3. Authority model is just provenance tracking. | Partly. | Provenance is included, but witnesses, failures, residuals, counterexamples, and scope also affect traces. | Add replay receipts and adversarial-survival evidence in later slices. | Medium |
| 4. Probe generation is just task decomposition. | Mostly. | The generator is heuristic and deterministic. | Treat it as first-pass scaffolding; add domain-specific adapters later. | Medium |
| 5. Descent gate is too weak. | Partly addressed. | `verify_lean_witness` now binds the gate to the Lean engine via a `LeanWitness` receipt type and forces the verdict from the `#print axioms` shape (`sorryAx`/non-standard axiom cannot reach `Supported`); `qm_holonomy_descent_witnesses()` is the first real batch. It still does not run the engine, and search/empirical engines remain unbound. | Add receipt types for the remaining finite engines (search, numerical, empirical). | Medium |
| 6. Finite system is missing or insufficient. | Partly. | This slice does not integrate a solver or proof checker. | Wire concrete finite engines one at a time. | High |
| 7. The layer may launder speculation into authority. | Addressed (structural). | `recompute_strength` derives strength from accumulated evidence, so any in-scope residual or counterexample blocks `TerminalWithinScope` and a *later* residual demotes a previously-terminal trace; tests cover witness-less support, `sorryAx`, residual-demotion, and the full holonomy-ladder claim landing `ConditionallySupported`. | Add human review gates for upgrades beyond the structural rule. | Medium |
| 8. Physics examples may overclaim. | Addressed in docs. | Physics examples are labeled as probes and analogies, not results. | Keep physics probes definition-first and source-bound. | High |
| 9. Self-improvement is not demonstrated. | Yes. | There is no self-improving loop in this slice. | Later work can feed repeated residuals into repair planning. | Medium |
| 10. The code may not justify the math. | Yes. | DTOs and tests do not prove mathematical claims. | Require theorem receipts before math authority. | High |

Net Verdict
-----------

The layer is useful as a guardrail and finite-probe boundary. It is not a theorem, not a solver, and not a scientific result.
