//! Exact packet-mapping findings for the canonical Rust workspace.
//!
//! Cargo supplies the member denominator. Current unmapped members and stale
//! registry entries are pinned as explicit findings: adding or resolving one
//! requires a deliberate baseline update. This is not packet-completeness
//! evidence. Registry existence proves neither packet ownership nor an active
//! hook: those need separate enforcement evidence. AuthorityEffect: None.

use serde::Deserialize;
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};
use std::process::Command;

const REGISTRIES: [&str; 2] = [
    "omega_engine_operations/cicd_verification_suite/domain/packet_registry.json",
    "omega_engine_operations/domain/cicd/packet_registry.json",
];

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct Mapping {
    prefix: String,
    packet: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct Registry {
    #[serde(rename = "_comment")]
    _comment: String,
    packet_home: String,
    mappings: Vec<Mapping>,
}

fn repo_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../..")
        .canonicalize()
        .expect("repository root must resolve")
}

/// Use Cargo's parser, package identities and actual workspace membership.
/// This read-only metadata request does not compile another package.
fn workspace_members(root: &Path) -> Result<BTreeSet<String>, String> {
    let workspace = root
        .join("omega_engine/crates_rs")
        .canonicalize()
        .map_err(|error| format!("WORKSPACE_PATH_INVALID: {error}"))?;
    // The e2e/integration test crate is the one member outside crates_rs.
    let engine_tests = root
        .join("omega_engine/tests")
        .canonicalize()
        .map_err(|error| format!("WORKSPACE_TESTS_PATH_INVALID: {error}"))?;
    let output = Command::new(env!("CARGO"))
        .args([
            "metadata",
            "--offline",
            "--no-deps",
            "--format-version",
            "1",
            "--manifest-path",
        ])
        .arg(workspace.join("Cargo.toml"))
        .current_dir(&workspace)
        .output()
        .map_err(|error| format!("WORKSPACE_METADATA_UNAVAILABLE: {error}"))?;
    if !output.status.success() {
        return Err(format!(
            "WORKSPACE_METADATA_FAILED: {}",
            String::from_utf8_lossy(&output.stderr)
        ));
    }
    let metadata: serde_json::Value = serde_json::from_slice(&output.stdout)
        .map_err(|error| format!("WORKSPACE_METADATA_INVALID: {error}"))?;
    let declared_root = metadata["workspace_root"]
        .as_str()
        .ok_or("WORKSPACE_METADATA_ROOT_MISSING")?;
    if Path::new(declared_root)
        .canonicalize()
        .map_err(|e| e.to_string())?
        != workspace
    {
        return Err("WORKSPACE_METADATA_ROOT_MISMATCH".into());
    }
    let ids = metadata["workspace_members"]
        .as_array()
        .ok_or("WORKSPACE_METADATA_MEMBERS_MISSING")?;
    let packages = metadata["packages"]
        .as_array()
        .ok_or("WORKSPACE_METADATA_PACKAGES_MISSING")?;
    let mut by_id = BTreeMap::new();
    for package in packages {
        let id = package["id"]
            .as_str()
            .ok_or("WORKSPACE_PACKAGE_ID_MISSING")?;
        let manifest = package["manifest_path"]
            .as_str()
            .ok_or("WORKSPACE_PACKAGE_PATH_MISSING")?;
        if by_id.insert(id, manifest).is_some() {
            return Err("WORKSPACE_PACKAGE_DUPLICATE".into());
        }
    }
    let mut seen_ids = BTreeSet::new();
    let mut members = BTreeSet::new();
    for raw_id in ids {
        let id = raw_id.as_str().ok_or("WORKSPACE_MEMBER_ID_INVALID")?;
        if !seen_ids.insert(id) {
            return Err("WORKSPACE_MEMBER_DUPLICATE".into());
        }
        let manifest = by_id.get(id).ok_or("WORKSPACE_MEMBER_PACKAGE_MISSING")?;
        let directory = Path::new(manifest)
            .parent()
            .ok_or("WORKSPACE_MEMBER_PARENT_MISSING")?
            .canonicalize()
            .map_err(|e| format!("WORKSPACE_MEMBER_PATH_INVALID: {e}"))?;
        if !directory.starts_with(&workspace) && directory != engine_tests {
            return Err("WORKSPACE_MEMBER_OUTSIDE_CANONICAL_TREE".into());
        }
        let relative = directory
            .strip_prefix(root)
            .map_err(|e| e.to_string())?
            .to_str()
            .ok_or("WORKSPACE_MEMBER_PATH_NOT_UTF8")?
            .replace('\\', "/");
        if !members.insert(relative) {
            return Err("WORKSPACE_MEMBER_PATH_DUPLICATE".into());
        }
    }
    if members.is_empty() {
        return Err("WORKSPACE_POPULATION_EMPTY".into());
    }
    Ok(members)
}

fn relative_path(value: &str, allow_directory_suffix: bool) -> bool {
    let value = if allow_directory_suffix {
        value.strip_suffix('/').unwrap_or(value)
    } else {
        value
    };
    !value.is_empty()
        && !value.contains(['\\', ':', '\0', '\n', '\r'])
        && value
            .split('/')
            .all(|part| !part.is_empty() && part != "." && part != "..")
}

fn registry_findings(root: &Path, registry: &Registry) -> Vec<String> {
    let mut findings = Vec::new();
    if !relative_path(&registry.packet_home, true) {
        findings.push("PACKET_HOME_INVALID".into());
    }
    if registry.mappings.is_empty() {
        findings.push("PACKET_MAPPING_POPULATION_EMPTY".into());
    }
    let mut prefixes = BTreeSet::new();
    for mapping in &registry.mappings {
        if !relative_path(&mapping.prefix, true) {
            findings.push(format!("PACKET_PREFIX_INVALID: {:?}", mapping.prefix));
        } else if !root.join(&mapping.prefix).exists() {
            findings.push(format!("PACKET_PREFIX_MISSING: {}", mapping.prefix));
        }
        if !prefixes.insert(&mapping.prefix) {
            findings.push(format!("PACKET_PREFIX_DUPLICATE: {}", mapping.prefix));
        }
        // A packet is a direct Markdown file under the declared home, not a
        // traversal, nested directory or arbitrary external path.
        if !relative_path(&mapping.packet, false)
            || mapping.packet.contains('/')
            || !mapping.packet.ends_with(".md")
        {
            findings.push(format!("PACKET_NAME_INVALID: {:?}", mapping.packet));
        } else if relative_path(&registry.packet_home, true)
            && !root
                .join(&registry.packet_home)
                .join(&mapping.packet)
                .is_file()
        {
            findings.push(format!("PACKET_FILE_MISSING: {}", mapping.packet));
        }
    }
    findings.sort();
    findings
}

fn coverage_findings(members: &BTreeSet<String>, mappings: &[Mapping]) -> Vec<String> {
    if members.is_empty() {
        return vec!["WORKSPACE_POPULATION_EMPTY".into()];
    }
    members
        .iter()
        .filter(|member| {
            let whole_crate = format!("{member}/");
            !mappings.iter().any(|mapping| mapping.prefix == whole_crate)
        })
        .map(|member| format!("UNMAPPED_WORKSPACE_MEMBER: {member}"))
        .collect()
}

fn registry(root: &Path) -> Registry {
    let bytes = std::fs::read(root.join(REGISTRIES[0]))
        .expect("PACKET_REGISTRY_UNREADABLE: canonical verification-suite registry");
    serde_json::from_slice(&bytes).expect("PACKET_REGISTRY_SCHEMA_INVALID")
}

fn baseline_lines(value: &str) -> Vec<String> {
    value
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(str::to_owned)
        .collect()
}

#[test]
fn workspace_mapping_findings_match_the_recorded_baseline() {
    let root = repo_root();
    let members = workspace_members(&root).expect("canonical Cargo metadata must resolve");
    let registry = registry(&root);
    let findings = coverage_findings(&members, &registry.mappings);
    let expected = baseline_lines(include_str!("packet_workspace_unmapped_baseline.txt"));
    assert!(!expected.is_empty(), "PACKET_MAPPING_BASELINE_EMPTY");
    assert_eq!(
        findings, expected,
        "workspace packet-mapping findings drifted ({} members); update mappings or the explicit baseline",
        members.len()
    );
}

#[test]
fn registry_findings_match_the_recorded_baseline() {
    let root = repo_root();
    let findings = registry_findings(&root, &registry(&root));
    let expected = baseline_lines(include_str!("packet_registry_findings_baseline.txt"));
    assert!(!expected.is_empty(), "PACKET_REGISTRY_BASELINE_EMPTY");
    assert_eq!(
        findings, expected,
        "packet registry findings drifted; repair the registry or update the explicit baseline"
    );
}

#[test]
fn both_registry_consumers_receive_identical_bytes() {
    let root = repo_root();
    assert_eq!(
        std::fs::read(root.join(REGISTRIES[0])).unwrap(),
        std::fs::read(root.join(REGISTRIES[1])).unwrap(),
        "REGISTRY_PROJECTION_DRIFT: reconcile both consumers explicitly"
    );
}

#[test]
fn whole_member_mapping_is_required_and_missing_members_remain_failures() {
    let member = "omega_engine/crates_rs/example";
    let members = BTreeSet::from([member.to_owned()]);
    let mapping = |prefix: String| Mapping {
        prefix,
        packet: "fixture.md".into(),
    };
    assert!(coverage_findings(&members, &[mapping(format!("{member}/"))]).is_empty());
    for prefix in [
        format!("{member}/src/one.rs"),
        format!("{member}_other/"),
        member.into(),
    ] {
        assert_eq!(
            coverage_findings(&members, &[mapping(prefix)]),
            vec![format!("UNMAPPED_WORKSPACE_MEMBER: {member}")]
        );
    }
    assert_eq!(
        coverage_findings(&members, &[]),
        vec![format!("UNMAPPED_WORKSPACE_MEMBER: {member}")]
    );
    assert_eq!(
        coverage_findings(&BTreeSet::new(), &[]),
        vec!["WORKSPACE_POPULATION_EMPTY"]
    );
}

#[test]
fn registry_syntax_and_empty_populations_cannot_pass_vacuously() {
    for path in [
        "",
        "/",
        "../x",
        "a/../b",
        "C:/x",
        "a\\b",
        "/absolute",
        "a//b",
        "a\0b",
    ] {
        assert!(!relative_path(path, true), "{path:?}");
    }
    assert!(relative_path("omega_engine/crates_rs/example/", true));
    let empty = Registry {
        _comment: String::new(),
        packet_home: "../outside".into(),
        mappings: vec![],
    };
    assert_eq!(
        registry_findings(&repo_root(), &empty),
        vec!["PACKET_HOME_INVALID", "PACKET_MAPPING_POPULATION_EMPTY"]
    );
    assert!(serde_json::from_str::<Registry>(
        r#"{"_comment":"","packet_home":"packets","mappings":[],"unexpected":true}"#
    )
    .is_err());
}

#[test]
fn canonical_cargo_metadata_has_a_real_member_and_no_legacy_tree_entries() {
    let members = workspace_members(&repo_root()).unwrap();
    assert!(members.contains("omega_engine/crates_rs/omega_contracts"));
    assert!(members
        .iter()
        .all(|path| path.starts_with("omega_engine/crates_rs/") || path == "omega_engine/tests"));
}
