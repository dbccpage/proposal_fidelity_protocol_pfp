use num_bigint::BigInt;
use num_rational::BigRational;
use omega_certifiers::{CertificateError, Phi1Verifier};
use omega_contracts::ContractEffect;
use omega_types::{
    AuthorityEffect, EvidenceStatus, ImplementationState, NormativeEffect, OperationalEffect,
    ReleaseAuthority,
};
use std::any::TypeId;
use std::fs;
use std::path::{Path, PathBuf};
use syn::visit::Visit;

fn r(value: i64) -> BigRational {
    BigRational::from_integer(BigInt::from(value))
}

#[test]
fn test_valid_phi1_certificate_passes() {
    // max x subject to x <= 1, x >= 0; dual min y subject to y >= 1, y >= 0.
    let certificate = Phi1Verifier::verify(
        vec![r(1)],
        vec![r(1)],
        vec![vec![r(1)]],
        vec![r(1)],
        vec![r(1)],
    )
    .expect("matching feasible rational witnesses must certify");

    assert_eq!(certificate.primal_objective(), &r(1));
    assert_eq!(certificate.dual_objective(), &r(1));
    assert_eq!(
        certificate.metadata().lean_phi1_specification(),
        "OmegaCore.FiniteCochainComplex.IsPhi1"
    );
    assert_eq!(
        certificate.metadata().lean_duality_theorem(),
        "PaperER007.lp_max_form_weak_duality"
    );
    assert_eq!(
        certificate.metadata().allowed_axioms(),
        &["propext", "Classical.choice", "Quot.sound"]
    );
    assert_eq!(
        certificate.metadata().evidence_status(),
        EvidenceStatus::AlgebraicallyWitnessed
    );
    assert_eq!(
        certificate.metadata().normative_effect(),
        NormativeEffect::Proposal
    );
    assert_eq!(
        certificate.metadata().operational_effect(),
        OperationalEffect::Read
    );
    assert_eq!(
        certificate.metadata().implementation_state(),
        ImplementationState::Verified
    );
    assert_eq!(
        certificate.metadata().release_authority(),
        ReleaseAuthority::NotGranted
    );
}

#[test]
fn test_duality_gap_refused() {
    // Both candidates are feasible, but 0 = c^T x != b^T y = 1.
    let result = Phi1Verifier::verify(
        vec![r(0)],
        vec![r(1)],
        vec![vec![r(1)]],
        vec![r(1)],
        vec![r(1)],
    );

    assert_eq!(result, Err(CertificateError::DualityGapDetected));
}

#[test]
fn test_infeasible_pair_refused() {
    // x = 2 violates the exact primal constraint x <= 1.
    let result = Phi1Verifier::verify(
        vec![r(2)],
        vec![r(1)],
        vec![vec![r(1)]],
        vec![r(1)],
        vec![r(1)],
    );

    assert_eq!(result, Err(CertificateError::Infeasible));
}

#[test]
fn test_authority_effect_no_implicit_promotion() {
    assert_ne!(
        TypeId::of::<ContractEffect>(),
        TypeId::of::<AuthorityEffect>(),
        "contract policy and runtime authority must remain distinct Rust types"
    );

    let workspace = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../..")
        .canonicalize()
        .expect("workspace root must resolve");
    let mut rust_files = Vec::new();
    collect_rust_files(&workspace, &mut rust_files);

    let expected = [
        ("crates_rs/omega_types/src/authority.rs", "omega_types::authority::AuthorityEffect"),
        ("crates_rs/omega_operad_theory/src/kernel/model.rs", "omega_operad_theory::kernel::model::AuthorityEffect"),
    ];
    let mut definitions = Vec::new();
    for path in &rust_files {
        let source = fs::read_to_string(path).expect("Rust source must be readable");
        let syntax = syn::parse_file(&source)
            .unwrap_or_else(|error| panic!("Rust source {} must parse: {error}", path.display()));
        let mut audit = AuthoritySyntaxAudit::default();
        audit.visit_file(&syntax);
        assert!(audit.forbidden_lifts.is_empty(),
            "unverified contract/authority conversion in {}: {:?}", path.display(), audit.forbidden_lifts);
        for _ in 0..audit.authority_definitions {
            definitions.push(path.clone());
        }
    }
    let mut expected_paths: Vec<PathBuf> = expected.iter().map(|(path, _)| workspace.join(path)).collect();
    definitions.sort();
    expected_paths.sort();
    assert_eq!(definitions, expected_paths, "qualified AuthorityEffect census: {expected:?}");

    let contract_source = fs::read_to_string(workspace.join("crates_rs/omega_contract_core/src/kinds.rs"))
        .expect("contract kind source must be readable");
    assert!(contract_source.contains("pub enum ContractEffect"));
    assert!(!contract_source.contains("pub enum AuthorityEffect"));
}

/// A source-syntax guard for direct conversion implementations. It handles
/// qualified type paths, but does not claim compiler alias or macro resolution.
#[derive(Default)]
struct AuthoritySyntaxAudit {
    authority_definitions: usize,
    forbidden_lifts: Vec<String>,
}

fn terminal_type_name(ty: &syn::Type) -> Option<String> {
    match ty {
        syn::Type::Path(path) => path.path.segments.last().map(|segment| segment.ident.to_string()),
        syn::Type::Reference(reference) => terminal_type_name(&reference.elem),
        syn::Type::Paren(paren) => terminal_type_name(&paren.elem),
        syn::Type::Group(group) => terminal_type_name(&group.elem),
        _ => None,
    }
}

impl<'ast> Visit<'ast> for AuthoritySyntaxAudit {
    fn visit_item_enum(&mut self, item: &'ast syn::ItemEnum) {
        if item.ident == "AuthorityEffect" {
            self.authority_definitions += 1;
        }
        syn::visit::visit_item_enum(self, item);
    }

    fn visit_item_impl(&mut self, item: &'ast syn::ItemImpl) {
        if let Some((_, trait_path, _)) = &item.trait_ {
            if let Some(segment) = trait_path.segments.last() {
                if segment.ident == "From" || segment.ident == "TryFrom" {
                    if let syn::PathArguments::AngleBracketed(arguments) = &segment.arguments {
                        for argument in &arguments.args {
                            if let syn::GenericArgument::Type(input) = argument {
                                let source = terminal_type_name(input);
                                let target = terminal_type_name(&item.self_ty);
                                if matches!((source.as_deref(), target.as_deref()),
                                    (Some("ContractEffect"), Some("AuthorityEffect")) |
                                    (Some("AuthorityEffect"), Some("ContractEffect"))) {
                                    self.forbidden_lifts.push(format!("{}<{:?}> for {:?}", segment.ident, source, target));
                                }
                            }
                        }
                    }
                }
            }
        }
        syn::visit::visit_item_impl(self, item);
    }
}

#[test]
fn authority_guard_catches_qualified_lifts_in_both_scoped_types() {
    for authority in ["omega_types::authority::AuthorityEffect", "omega_operad_theory::kernel::model::AuthorityEffect"] {
        for conversion in ["From", "TryFrom"] {
            for (source, target) in [("omega_contracts::ContractEffect", authority), (authority, "omega_contracts::ContractEffect")] {
                let syntax = syn::parse_file(&format!("impl std::convert::{conversion}<{source}> for {target} {{}}"))
                    .expect("mutation fixture must parse");
                let mut audit = AuthoritySyntaxAudit::default();
                audit.visit_file(&syntax);
                assert_eq!(audit.forbidden_lifts.len(), 1, "{conversion}<{source}> for {target}");
            }
        }
    }
    let benign = syn::parse_file("// impl From<ContractEffect> for AuthorityEffect {}\nconst DOCUMENTATION: &str = \"impl From<ContractEffect> for AuthorityEffect {}\";")
        .expect("comment/string fixture must parse");
    let mut audit = AuthoritySyntaxAudit::default();
    audit.visit_file(&benign);
    assert!(audit.forbidden_lifts.is_empty());
}

fn collect_rust_files(directory: &Path, files: &mut Vec<PathBuf>) {
    for entry in fs::read_dir(directory).expect("source directory must be readable") {
        let path = entry.expect("directory entry must be readable").path();
        if path.is_dir() {
            let name = path.file_name().and_then(|name| name.to_str());
            if !matches!(name, Some("target" | ".git" | ".lake" | ".claude")) {
                collect_rust_files(&path, files);
            }
        } else if path.extension().and_then(|extension| extension.to_str()) == Some("rs") {
            files.push(path);
        }
    }
}
