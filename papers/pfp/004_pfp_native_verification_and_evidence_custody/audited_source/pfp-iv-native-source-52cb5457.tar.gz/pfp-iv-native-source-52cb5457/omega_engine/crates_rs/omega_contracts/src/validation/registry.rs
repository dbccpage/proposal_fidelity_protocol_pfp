use crate::kinds::{ContractEffect, SchemaHash};
use std::any::Any;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct ValidatorDescriptor {
    pub validator_id: &'static str,
    pub subject_type_name: &'static str,
    pub property: &'static str,
    pub schema_hash: SchemaHash,
    pub authority_effect: ContractEffect,
}

#[derive(Debug, thiserror::Error)]
pub enum ValidationRegistryError {
    #[error("validator not found")]
    ValidatorNotFound,
    #[error("subject type mismatch; expected {expected}")]
    SubjectTypeMismatch { expected: &'static str },
    #[error("validator authority mismatch; expected EvidenceOnly, got {actual:?}")]
    ValidatorAuthorityMismatch { actual: ContractEffect },
}

pub trait ErasedValidator: Send + Sync {
    fn descriptor(&self) -> ValidatorDescriptor;
    fn validate_erased(&self, subject: &dyn Any) -> Result<Box<dyn Any>, ValidationRegistryError>;
}

pub fn validate_descriptor_authority(
    descriptor: ValidatorDescriptor,
) -> Result<(), ValidationRegistryError> {
    if descriptor.authority_effect != ContractEffect::EvidenceOnly {
        return Err(ValidationRegistryError::ValidatorAuthorityMismatch {
            actual: descriptor.authority_effect,
        });
    }
    Ok(())
}
