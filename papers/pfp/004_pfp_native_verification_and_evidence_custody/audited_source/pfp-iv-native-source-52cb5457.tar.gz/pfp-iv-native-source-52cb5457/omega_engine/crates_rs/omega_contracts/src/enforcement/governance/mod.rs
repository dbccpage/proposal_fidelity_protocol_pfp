//! Governance enforcement and diagnostic functors.
//!
//! This module defines the categorical structure of governance enforcement:
//!
//! - **Blackrod**: An orthogonal enforcement functor (NOT a council, NOT a voting participant).
//!   Maps governance findings to defensive enforcement actions.
//!
//! - **Woland**: An adversarial diagnostic functor. Inspects artifacts for obstruction findings
//!   and recommends (but CANNOT enforce) actions. Woland refers to Blackrod.
//!
//! # Safety Invariant
//!
//! No offensive, retaliatory, or real-world coercive actions are representable in this type
//! system by design. Blackrod's model is lawful defensive governance enforcement only.

pub mod blackrod;
pub mod errors;
pub mod woland;

pub use blackrod::*;
pub use errors::*;
pub use woland::*;
