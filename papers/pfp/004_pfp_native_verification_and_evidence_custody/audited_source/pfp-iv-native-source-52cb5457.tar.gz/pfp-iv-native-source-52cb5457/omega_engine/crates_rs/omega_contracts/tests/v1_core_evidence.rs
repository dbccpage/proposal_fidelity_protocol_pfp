//! The migrated evidence contracts load and pass `validate_registry`
//! (CheckedPacket/Diagnostic/Measurement/Observable/Replay/Trace/Witness validators +
//! validator-free AnalysisUnit/CertificateKernel/Boundary/RepresentationBoundary roles).
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn evidence_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/02_core_evidence");
    let report = load_v1_dir(&dir).expect("dir readable");
    // 22 after `dual_trace_memory` was mapped (omega_replay::dual_trace_memory had
    // no contract, so Rule 1 of the governance validator was red at main).
    // 24 after `published_series_coordinates` and `published_paper_carrier` moved
    // the published-corpus paths, filename grammar and claim-row counts out of
    // Rust literals and into the corpus, where build.rs lowers them into
    // generated constants.
    // 26 after `measurement_observable_redirect` and `append_log` received
    // their canonical evidence contracts.
    // 27 after Epoch 4 bound `phi1_certifier` to `Phi1Certificate`.
    // 29 after Epoch 15 added `secret_scrubber` and `retention`: omega_replay is
    // a Rule-1 crate, so the two new modules needed contracts before the
    // governance validator would admit them.
    // Keep the count explicit so corpus drift requires review.
    assert_eq!(report.loaded, 29, "expected 29 migrated evidence contracts");
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
