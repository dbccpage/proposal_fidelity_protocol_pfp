//! 06_execution — the 8 migrated execution contracts load and pass validate_registry
//! (Engine / HealthModel / Kernel / Pipeline validators + validator-free kernels).
//!
//! Census log (bump the count, never relax the assertion):
//!   7 -> 8  2026-07-28  fsr_retrieval.contract.yaml (role Search, evidence_only).
//!           Declares the Python frontier retriever in omega_engine_py/omega_retrieval.
//!           `Search` was chosen over `SearchKernel` deliberately: SearchKernel falls
//!           into validate.rs's `_ => {}` catch-all and receives NO role validation,
//!           while `Search` enforces authority_effect = EvidenceOnly and forbids
//!           Terminalization / CertificateSigning / Evaluation -- all of which the
//!           implementation satisfies.
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn execution_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/06_core_execution");
    let report = load_v1_dir(&dir).expect("dir readable");
    assert_eq!(report.loaded, 8, "expected 8 migrated execution contracts");
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
