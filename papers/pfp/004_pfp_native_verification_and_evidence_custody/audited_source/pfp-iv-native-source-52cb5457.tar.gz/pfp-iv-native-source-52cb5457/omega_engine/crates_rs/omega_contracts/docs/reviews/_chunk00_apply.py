# removed: one-shot applicator for rip_math_chunk_00 (superseded; edits applied)
