use omega_atlas_reconciliation::governance::*;
#[test]
fn authority_expansion_without_licensed_lift_is_refused() {
    let f = check_governance_strict(&GovChange::authority_expansion_no_record());
    assert!(f.iter().any(|x| x.contains("licensed lift")));
}
#[test]
fn complete_licensed_lift_passes() {
    assert!(check_governance_strict(&GovChange::licensed_lift_full_10_fields()).is_empty());
}
#[test]
fn blackrod_cannot_vote_or_waive() {
    assert!(!role_may(Role::Blackrod, Power::Vote));
    assert!(!role_may(Role::Blackrod, Power::WaiveEvidence));
    assert!(role_may(Role::Blackrod, Power::Enforce));
}
#[test]
fn woland_cannot_enforce() {
    assert!(!role_may(Role::Woland, Power::Enforce));
    assert!(role_may(Role::Woland, Power::Diagnose));
}
#[test]
fn self_certification_refused() {
    assert!(check_governance_strict(&GovChange::council_self_certify())
        .iter()
        .any(|x| x.contains("self-cert")));
}
