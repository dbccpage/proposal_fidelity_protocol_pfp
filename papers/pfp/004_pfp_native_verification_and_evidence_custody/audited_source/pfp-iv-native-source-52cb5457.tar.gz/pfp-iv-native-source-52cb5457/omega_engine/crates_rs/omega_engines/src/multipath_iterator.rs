//! Finite, typed, obstruction-directed iteration for Paper 070.
//!
//! The iterator is a bounded orchestration shell. Domain adapters own the
//! meaning of packets, projections, preservation checks, and candidate states.
//! Exact admitted F2 `C0 -> C1 -> C2` probes reuse the DDA degree tower. A zero
//! probe never implies global coherence: every protected distinction must also
//! be classified as visible, projection loss, or detector inadequate.
//!
//! Every receipt produced here has [`AuthorityEffect::None`]. This module can
//! propose, evaluate, and replay candidates; it cannot certify or promote them.

use std::collections::{BTreeMap, BTreeSet};
use std::sync::{
    atomic::{AtomicBool, Ordering},
    Arc,
};
use std::time::Instant;

use omega_discrete_deformation_calculus::agent_contract::sha256_bytes;
use omega_discrete_deformation_calculus::degree_tower::{
    BinaryCochainSegment, DegreeDiagnostic, DegreeTrichotomy,
};
use omega_types::{authority::AuthorityEffect, Hash256};
use serde::{Deserialize, Serialize};
use thiserror::Error;

use crate::obstruction_runtime::{OperatorId, Provenance};

pub const MULTIPATH_RECEIPT_SCHEMA: &str = "omega.multipath.run_receipt.v3";
pub const MULTIPATH_RECEIPT_ANCHOR_SCHEMA: &str = "omega.multipath.run_receipt_anchor.v1";
const INSPECTION_TRACE_HASH_DOMAIN: &str = "omega.paper070.inspection_trace.v1";
const OPERATOR_PATTERN_HASH_DOMAIN: &str = "omega.paper070.operator_pattern.v3";
const OPERATOR_EVIDENCE_HASH_DOMAIN: &str = "omega.paper070.operator_evidence.v3";
const OPERATOR_PROPOSAL_HASH_DOMAIN: &str = "omega.paper070.operator_proposal.v3";
const SOURCE_OPERATOR_HASH_DOMAIN: &str = "omega.paper070.source_operator.v3";
const SOURCE_ASSESSMENT_HASH_DOMAIN: &str = "omega.paper070.source_assessment.v3";

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CarrierKind {
    DirectedGraph,
    Hypergraph,
    SimplicialComplex,
    CellularComplex,
    DependencyGraph,
    ProofGraph,
    CodeChangeGraph,
    WorkflowGraph,
    OpaqueFinite,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CarrierCell {
    pub cell_id: String,
    pub degree: usize,
    pub boundary: Vec<String>,
    pub payload_sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FiniteCarrier {
    pub carrier_id: String,
    pub kind: CarrierKind,
    pub cells: Vec<CarrierCell>,
}

impl FiniteCarrier {
    pub fn canonicalized(mut self) -> Result<Self, IteratorError> {
        nonempty(&self.carrier_id, "carrier_id")?;
        for cell in &mut self.cells {
            cell.boundary.sort();
            ensure_unique(&cell.boundary, "cell boundary")?;
        }
        self.cells.sort_by(|left, right| {
            (left.degree, &left.cell_id).cmp(&(right.degree, &right.cell_id))
        });
        self.validate()?;
        Ok(self)
    }

    pub fn validate(&self) -> Result<(), IteratorError> {
        nonempty(&self.carrier_id, "carrier_id")?;
        let mut degree_by_id = BTreeMap::new();
        for cell in &self.cells {
            nonempty(&cell.cell_id, "carrier cell id")?;
            if !is_sha256(&cell.payload_sha256) {
                return Err(IteratorError::InvalidCarrier(format!(
                    "carrier cell `{}` payload_sha256 must be lowercase SHA-256",
                    cell.cell_id
                )));
            }
            if degree_by_id
                .insert(cell.cell_id.clone(), cell.degree)
                .is_some()
            {
                return Err(IteratorError::InvalidCarrier(format!(
                    "duplicate carrier cell `{}`",
                    cell.cell_id
                )));
            }
            if cell.degree == 0 && !cell.boundary.is_empty() {
                return Err(IteratorError::InvalidCarrier(format!(
                    "degree-zero cell `{}` has a boundary",
                    cell.cell_id
                )));
            }
            if cell.degree > 0 && cell.boundary.is_empty() {
                return Err(IteratorError::InvalidCarrier(format!(
                    "positive-degree cell `{}` has an empty boundary",
                    cell.cell_id
                )));
            }
        }
        for cell in &self.cells {
            for boundary_id in &cell.boundary {
                let Some(boundary_degree) = degree_by_id.get(boundary_id) else {
                    return Err(IteratorError::InvalidCarrier(format!(
                        "cell `{}` references missing boundary cell `{boundary_id}`",
                        cell.cell_id
                    )));
                };
                if *boundary_degree >= cell.degree {
                    return Err(IteratorError::InvalidCarrier(format!(
                        "cell `{}` degree {} references non-lower boundary cell `{boundary_id}` degree {}",
                        cell.cell_id, cell.degree, boundary_degree
                    )));
                }
            }
        }
        Ok(())
    }

    fn extend(&mut self, extension: &CarrierExtension) -> Result<(), IteratorError> {
        let mut candidate = self.clone();
        candidate.cells.extend(extension.new_cells.clone());
        *self = candidate.canonicalized()?;
        Ok(())
    }
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DetectorRequirement {
    pub claim_id: String,
    pub distinction_id: String,
}

impl DetectorRequirement {
    fn key(&self) -> String {
        format!(
            "{}:{}|{}:{}",
            self.claim_id.len(),
            self.claim_id,
            self.distinction_id.len(),
            self.distinction_id
        )
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProblemPacket {
    pub packet_id: String,
    pub domain: String,
    pub payload: serde_json::Value,
    pub protected_distinctions: Vec<DetectorRequirement>,
    pub packet_refs: Vec<String>,
    pub evidence_ceiling: String,
}

impl ProblemPacket {
    pub fn canonicalized(mut self) -> Result<Self, IteratorError> {
        nonempty(&self.packet_id, "packet_id")?;
        nonempty(&self.domain, "domain")?;
        nonempty(&self.evidence_ceiling, "evidence_ceiling")?;
        self.protected_distinctions.sort();
        if self.packet_refs.is_empty() {
            return Err(IteratorError::InvalidDeclaration(
                "packet_refs must contain at least one immutable packet reference".into(),
            ));
        }
        self.packet_refs.sort();
        ensure_unique(&self.packet_refs, "packet_refs")?;
        for packet_ref in &self.packet_refs {
            nonempty(packet_ref, "packet_ref")?;
        }
        for requirement in &self.protected_distinctions {
            nonempty(&requirement.claim_id, "claim_id")?;
            nonempty(&requirement.distinction_id, "distinction_id")?;
        }
        ensure_unique(&self.protected_distinctions, "protected distinctions")?;
        Ok(self)
    }

    pub fn sha256(&self) -> Result<String, IteratorError> {
        sha256_json(&self.clone().canonicalized()?)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ObserverDeclaration {
    pub observer_id: String,
    pub observer_family: String,
    pub scope: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ComparisonDeclaration {
    pub comparison_id: String,
    pub zero_rel: String,
    pub gauge_family: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectedDatum {
    pub datum_id: String,
    pub degree: usize,
    pub source_refs: Vec<String>,
    pub value_sha256: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CoverageDisposition {
    PreservedVisible,
    ProjectionLoss,
    DetectorInadequate,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectionLossReceipt {
    pub loss_id: String,
    pub source_refs: Vec<String>,
    pub collided_projection_refs: Vec<String>,
    pub discarded_sha256: String,
    pub recovery_requirement: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CoverageAssessment {
    pub requirement: DetectorRequirement,
    pub disposition: CoverageDisposition,
    pub evidence_ref: String,
    pub projection_loss: Option<ProjectionLossReceipt>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(deny_unknown_fields)]
pub struct ExactBinaryCochainProbe {
    pub segment: BinaryCochainSegment,
    pub residual: Vec<bool>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(deny_unknown_fields)]
pub struct VisibleDefect {
    pub defect_id: String,
    pub claim_id: String,
    pub kind: String,
    pub cell_refs: Vec<String>,
    pub evidence_ref: String,
    pub exact_binary_cochain: Option<ExactBinaryCochainProbe>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HigherDegreeNeed {
    pub current_max_degree: usize,
    pub required_degree: usize,
    pub witness_ref: String,
    pub licensed_lift_ref: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Inspection {
    pub observer: ObserverDeclaration,
    pub comparison: ComparisonDeclaration,
    pub projected_data: Vec<ProjectedDatum>,
    pub coverage: Vec<CoverageAssessment>,
    pub visible_defects: Vec<VisibleDefect>,
    pub higher_degree_need: Option<HigherDegreeNeed>,
    pub discarded_information_refs: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CochainDiagnosticReceipt {
    pub degree: usize,
    pub phi: usize,
    pub gamma: usize,
    pub classification: String,
}

impl From<DegreeDiagnostic> for CochainDiagnosticReceipt {
    fn from(value: DegreeDiagnostic) -> Self {
        Self {
            degree: value.degree,
            phi: value.phi,
            gamma: value.gamma,
            classification: match value.classification {
                DegreeTrichotomy::Exact => "exact",
                DegreeTrichotomy::StabilizedSurvivor => "stabilized_survivor",
                DegreeTrichotomy::Open => "open",
            }
            .into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct DefectReceipt {
    pub defect_id: String,
    pub claim_id: String,
    pub kind: String,
    pub cell_refs: Vec<String>,
    pub evidence_ref: String,
    pub signature_sha256: String,
    pub cochain: Option<CochainDiagnosticReceipt>,
}

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ObstructionMeasure {
    pub projection_loss_count: usize,
    pub open_defect_count: usize,
    pub gamma_total: usize,
    pub phi_total: usize,
    pub stabilized_survivor_count: usize,
}

impl ObstructionMeasure {
    fn rank(self) -> (usize, usize, usize, usize, usize) {
        (
            self.projection_loss_count,
            self.open_defect_count,
            self.gamma_total,
            self.phi_total,
            self.stabilized_survivor_count,
        )
    }

    fn strictly_descends_to(self, after: Self) -> bool {
        after.rank() < self.rank()
    }

    fn is_resolved(self) -> bool {
        self.projection_loss_count == 0 && self.open_defect_count == 0
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ObstructionSignature {
    pub defect_id: String,
    pub kind: String,
    pub signature_sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct InspectionReceipt {
    pub observer: ObserverDeclaration,
    pub comparison: ComparisonDeclaration,
    pub projected_data: Vec<ProjectedDatum>,
    pub coverage: Vec<CoverageAssessment>,
    pub defects: Vec<DefectReceipt>,
    pub signatures: Vec<ObstructionSignature>,
    pub measure: ObstructionMeasure,
    pub detector_inadequate_count: usize,
    pub higher_degree_need: Option<HigherDegreeNeed>,
    pub discarded_information_refs: Vec<String>,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TerminalKind {
    ExactRepair,
    StabilizedSurvivor,
    OpenObstruction,
    DetectorInadequate,
    NoRule,
    RequiresLift,
    Refused,
    BudgetExhausted,
    Cancelled,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct TerminalReceipt {
    pub kind: TerminalKind,
    pub reason: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RegisteredOperator {
    pub operator_id: OperatorId,
    pub signature_kinds: Vec<String>,
    pub carrier_kinds: Vec<CarrierKind>,
    pub preconditions: Vec<String>,
    /// Adapter-owned implementation or declarative transformation reference.
    pub deformation_ref: String,
    /// Hash of the canonical transformation descriptor, not a semantic proof.
    pub deformation_descriptor_sha256: String,
    pub preservation_obligations: Vec<String>,
    pub witness_procedure: String,
    /// Declares congruence of every admission predicate and the post-inspection measure.
    pub equivalence_contract: Option<String>,
    pub requires_lift: bool,
    pub possible_terminals: Vec<TerminalKind>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OperatorRegistry {
    operators: Vec<RegisteredOperator>,
}

impl OperatorRegistry {
    pub fn new(mut operators: Vec<RegisteredOperator>) -> Result<Self, IteratorError> {
        for operator in &mut operators {
            nonempty(&operator.operator_id.0, "operator_id")?;
            nonempty(&operator.deformation_ref, "operator deformation_ref")?;
            if !is_sha256(&operator.deformation_descriptor_sha256) {
                return Err(IteratorError::InvalidRegistry(format!(
                    "operator `{}` has an invalid deformation descriptor SHA-256",
                    operator.operator_id
                )));
            }
            nonempty(&operator.witness_procedure, "operator witness_procedure")?;
            if let Some(contract) = &operator.equivalence_contract {
                nonempty(contract, "operator equivalence_contract")?;
            }
            for (values, label) in [
                (&operator.signature_kinds, "operator signature kind"),
                (&operator.preconditions, "operator precondition"),
                (
                    &operator.preservation_obligations,
                    "operator preservation obligation",
                ),
            ] {
                for value in values {
                    nonempty(value, label)?;
                }
            }
            if operator.signature_kinds.is_empty()
                || operator.carrier_kinds.is_empty()
                || operator.preservation_obligations.is_empty()
                || operator.possible_terminals.is_empty()
            {
                return Err(IteratorError::InvalidRegistry(format!(
                    "operator {} must declare signatures, carriers, preservation obligations, and possible terminals",
                    operator.operator_id
                )));
            }
            operator.signature_kinds.sort();
            operator.carrier_kinds.sort();
            operator.preconditions.sort();
            operator.preservation_obligations.sort();
            operator
                .possible_terminals
                .sort_by_key(|terminal| *terminal as u8);
            ensure_unique(&operator.signature_kinds, "operator signature kinds")?;
            ensure_unique(&operator.carrier_kinds, "operator carrier kinds")?;
            ensure_unique(&operator.preconditions, "operator preconditions")?;
            ensure_unique(
                &operator.preservation_obligations,
                "operator preservation obligations",
            )?;
            ensure_unique(&operator.possible_terminals, "operator possible terminals")?;
        }
        operators.sort_by(|left, right| left.operator_id.0.cmp(&right.operator_id.0));
        let ids: Vec<_> = operators
            .iter()
            .map(|operator| operator.operator_id.0.clone())
            .collect();
        ensure_unique(&ids, "operator ids")?;
        Ok(Self { operators })
    }

    pub fn operators(&self) -> &[RegisteredOperator] {
        &self.operators
    }

    pub fn get(&self, operator_id: &OperatorId) -> Option<&RegisteredOperator> {
        self.operators
            .binary_search_by(|candidate| candidate.operator_id.0.cmp(&operator_id.0))
            .ok()
            .map(|index| &self.operators[index])
    }

    fn validate_canonical(&self) -> Result<(), IteratorError> {
        let canonical = Self::new(self.operators.clone())?;
        if &canonical != self {
            return Err(IteratorError::InvalidRegistry(
                "operator registry must already be in canonical form".into(),
            ));
        }
        Ok(())
    }

    pub fn sha256(&self) -> Result<String, IteratorError> {
        self.validate_canonical()?;
        sha256_json(self)
    }
}

#[derive(Debug, Clone)]
pub struct DeformationProposal<S> {
    pub proposal_id: String,
    pub operator_id: OperatorId,
    pub provenance: Provenance,
    pub matched_signature_sha256: String,
    pub equivalence_key: Option<String>,
    pub predicted_candidates_avoided: usize,
    pub state: S,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CheckVerdict {
    Pass,
    Fail,
    Inconclusive,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PreservationCheck {
    pub obligation_id: String,
    pub verdict: CheckVerdict,
    pub evidence_ref: String,
    pub evidence_sha256: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum WitnessRelation {
    SeparateImplementation,
    HumanReview,
    CommonSource,
    SharedModelFamily,
    Unestablished,
}

impl WitnessRelation {
    fn supports_independence(self) -> bool {
        matches!(self, Self::SeparateImplementation | Self::HumanReview)
    }
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct WitnessResult {
    pub witness_id: String,
    pub procedure: String,
    pub relation: WitnessRelation,
    pub verdict: CheckVerdict,
    pub evidence_ref: String,
    pub evidence_sha256: String,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CandidateAssessment {
    pub preservation: Vec<PreservationCheck>,
    pub witnesses: Vec<WitnessResult>,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CarrierExtension {
    pub extension_id: String,
    pub trigger_signature_sha256: String,
    pub justification_ref: String,
    pub new_cells: Vec<CarrierCell>,
}

#[derive(Debug, Clone)]
pub struct AdapterSeed<S> {
    pub state: S,
    pub carrier: FiniteCarrier,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AdapterFailureKind {
    DetectorInadequate,
    NoRule,
    RequiresLift,
    Refused,
}

#[derive(Debug, Clone, Error, PartialEq, Eq, Serialize, Deserialize)]
#[error("{kind:?}: {detail}")]
#[serde(deny_unknown_fields)]
pub struct AdapterFailure {
    pub kind: AdapterFailureKind,
    pub detail: String,
}

pub trait MultipathAdapter {
    type State: Clone + Serialize;

    fn adapter_id(&self) -> &str;

    fn seed(&self, packet: &ProblemPacket) -> Result<AdapterSeed<Self::State>, AdapterFailure>;

    fn inspect(
        &self,
        packet: &ProblemPacket,
        carrier: &FiniteCarrier,
        state: &Self::State,
    ) -> Result<Inspection, AdapterFailure>;

    fn propose(
        &self,
        packet: &ProblemPacket,
        carrier: &FiniteCarrier,
        state: &Self::State,
        signatures: &[ObstructionSignature],
    ) -> Result<Vec<DeformationProposal<Self::State>>, AdapterFailure>;

    fn assess_candidate(
        &self,
        packet: &ProblemPacket,
        carrier: &FiniteCarrier,
        before: &Self::State,
        proposal: &DeformationProposal<Self::State>,
        operator: &RegisteredOperator,
    ) -> Result<CandidateAssessment, AdapterFailure>;

    fn extend_carrier(
        &self,
        _packet: &ProblemPacket,
        _carrier: &FiniteCarrier,
        _state: &Self::State,
        _inspection: &InspectionReceipt,
    ) -> Result<Option<CarrierExtension>, AdapterFailure> {
        Ok(None)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RunBudget {
    pub max_steps: usize,
    pub max_candidates: usize,
    pub max_carrier_cells: usize,
    pub max_receipt_bytes: usize,
    pub max_wall_millis: u64,
    pub require_independent_witness: bool,
}

impl RunBudget {
    pub fn validate(self) -> Result<Self, IteratorError> {
        if self.max_steps == 0
            || self.max_candidates == 0
            || self.max_carrier_cells == 0
            || self.max_receipt_bytes == 0
            || self.max_wall_millis == 0
        {
            return Err(IteratorError::InvalidBudget(
                "all numeric budgets must be positive".into(),
            ));
        }
        Ok(self)
    }
}

#[derive(Debug, Clone, Default)]
pub struct CancellationToken(Arc<AtomicBool>);

impl CancellationToken {
    pub fn cancel(&self) {
        self.0.store(true, Ordering::SeqCst);
    }

    pub fn is_cancelled(&self) -> bool {
        self.0.load(Ordering::SeqCst)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum CandidateVerdict {
    EligibleDescent,
    RejectedNoDescent,
    RejectedPreservation,
    RejectedWitness,
    RejectedAdapter,
    InvalidProposal,
    RequiresLift,
    DuplicatePruned,
    BudgetPruned,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CandidateReceipt {
    pub proposal_id: String,
    pub operator_id: OperatorId,
    pub provenance: Provenance,
    pub state_sha256: String,
    pub matched_signature_sha256: String,
    pub equivalence_key: Option<String>,
    pub predicted_candidates_avoided: usize,
    pub verdict: CandidateVerdict,
    pub reason: String,
    pub before: ObstructionMeasure,
    pub after: Option<ObstructionMeasure>,
    pub preservation: Vec<PreservationCheck>,
    pub witnesses: Vec<WitnessResult>,
    pub post_inspection: Option<InspectionReceipt>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CompiledOperatorCandidate {
    pub candidate_operator_id: OperatorId,
    pub source_operator_id: OperatorId,
    pub source_operator_sha256: String,
    pub source_operator_signature_kinds: Vec<String>,
    pub source_operator_carrier_kinds: Vec<CarrierKind>,
    pub source_registry_sha256: String,
    pub source_proposal_id: String,
    pub source_proposal_sha256: String,
    pub source_assessment_sha256: String,
    pub source_candidate_sha256: String,
    pub source_step_index: usize,
    pub source_packet_sha256: String,
    pub source_carrier_sha256: String,
    pub source_state_sha256: String,
    pub result_state_sha256: String,
    pub source_provenance: Provenance,
    pub source_equivalence_key: Option<String>,
    pub source_predicted_candidates_avoided: usize,
    pub signature_kind: String,
    pub observed_signature_sha256: String,
    pub carrier_kind: CarrierKind,
    pub preconditions: Vec<String>,
    pub deformation_ref: String,
    pub deformation_descriptor_sha256: String,
    pub preservation_obligations: Vec<String>,
    pub preservation_checks: Vec<PreservationCheck>,
    pub witness_procedure: String,
    pub witness_results: Vec<WitnessResult>,
    pub equivalence_contract: Option<String>,
    pub requires_lift: bool,
    pub possible_terminals: Vec<TerminalKind>,
    pub before: ObstructionMeasure,
    pub after: ObstructionMeasure,
    pub post_inspection_sha256: String,
    pub pattern_sha256: String,
    pub evidence_sha256: String,
    pub authority_effect: AuthorityEffect,
}

impl CompiledOperatorCandidate {
    pub fn verify_hashes(&self) -> Result<bool, IteratorError> {
        let bound_hashes = [
            self.source_operator_sha256.as_str(),
            self.source_registry_sha256.as_str(),
            self.source_proposal_sha256.as_str(),
            self.source_assessment_sha256.as_str(),
            self.source_candidate_sha256.as_str(),
            self.source_packet_sha256.as_str(),
            self.source_carrier_sha256.as_str(),
            self.source_state_sha256.as_str(),
            self.result_state_sha256.as_str(),
            self.observed_signature_sha256.as_str(),
            self.deformation_descriptor_sha256.as_str(),
            self.post_inspection_sha256.as_str(),
            self.pattern_sha256.as_str(),
            self.evidence_sha256.as_str(),
        ];
        if !self.authority_effect.is_none()
            || bound_hashes.iter().any(|value| !is_sha256(value))
            || !compiled_candidate_fields_are_canonical(self)
            || self.candidate_operator_id.0 != format!("candidate.sha256.{}", self.pattern_sha256)
        {
            return Ok(false);
        }
        Ok(self.source_operator_sha256 == source_operator_hash(self)?
            && self.source_proposal_sha256 == source_proposal_hash(self)?
            && self.source_assessment_sha256 == source_assessment_hash(self)?
            && self.pattern_sha256 == operator_pattern_hash(self)?
            && self.evidence_sha256 == operator_evidence_hash(self)?)
    }

    pub fn authority_effect(&self) -> &AuthorityEffect {
        &self.authority_effect
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CarrierExtensionReceipt {
    pub extension_id: String,
    pub trigger_signature_sha256: String,
    pub justification_ref: String,
    pub parent_carrier_sha256: String,
    pub extended_carrier_sha256: String,
    pub added_cell_ids: Vec<String>,
    pub added_cells: Vec<CarrierCell>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct StepReceipt {
    pub step_index: usize,
    pub state_sha256: String,
    pub carrier_sha256: String,
    pub inspection: InspectionReceipt,
    pub candidates: Vec<CandidateReceipt>,
    pub selected_proposal_id: Option<String>,
    pub selected_candidate_sha256: Option<String>,
    pub compiled_operator_candidate: Option<CompiledOperatorCandidate>,
    pub carrier_extension: Option<CarrierExtensionReceipt>,
}

#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct CandidateAccounting {
    pub proposed: usize,
    pub evaluated: usize,
    pub duplicate_pruned: usize,
    pub budget_pruned: usize,
    pub predicted_avoided_by_quotient: usize,
    pub accepted_transitions: usize,
    pub compiled_operator_candidates: usize,
    pub carrier_extensions: usize,
}

impl CandidateAccounting {
    pub fn is_balanced(&self) -> bool {
        self.evaluated
            .checked_add(self.duplicate_pruned)
            .and_then(|subtotal| subtotal.checked_add(self.budget_pruned))
            == Some(self.proposed)
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RunReceipt {
    pub schema_version: String,
    pub adapter_id: String,
    pub packet: ProblemPacket,
    pub packet_sha256: String,
    pub operator_registry: OperatorRegistry,
    pub operator_registry_sha256: String,
    pub initial_carrier: FiniteCarrier,
    pub final_carrier: FiniteCarrier,
    pub initial_state_sha256: String,
    pub final_state_sha256: String,
    pub budget: RunBudget,
    pub accounting: CandidateAccounting,
    pub steps: Vec<StepReceipt>,
    pub terminal: TerminalReceipt,
    pub replay_sha256: String,
    pub runtime_micros: u128,
    pub authority_effect: AuthorityEffect,
}

#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct RunReceiptAnchor {
    pub schema_version: String,
    pub receipt_schema_version: String,
    pub packet_sha256: Hash256,
    pub operator_registry_sha256: Hash256,
    pub replay_sha256: Hash256,
    pub inspection_trace_sha256: Hash256,
    pub canonical_receipt_sha256: Hash256,
    pub authority_effect: AuthorityEffect,
}

impl RunReceiptAnchor {
    pub fn canonical_json_bytes(&self) -> Result<Vec<u8>, IteratorError> {
        serde_json::to_vec(self).map_err(|error| IteratorError::Serialization(error.to_string()))
    }

    pub fn sha256(&self) -> Result<String, IteratorError> {
        self.canonical_json_bytes()
            .map(|bytes| sha256_bytes(&bytes))
    }

    fn is_valid(&self) -> bool {
        self.schema_version == MULTIPATH_RECEIPT_ANCHOR_SCHEMA
            && self.receipt_schema_version == MULTIPATH_RECEIPT_SCHEMA
            && self.authority_effect.is_none()
            && [
                self.packet_sha256.as_str(),
                self.operator_registry_sha256.as_str(),
                self.replay_sha256.as_str(),
                self.inspection_trace_sha256.as_str(),
                self.canonical_receipt_sha256.as_str(),
            ]
            .iter()
            .all(|value| is_sha256(value))
    }
}

impl RunReceipt {
    /// Creates a content anchor that must be pinned separately from this receipt.
    ///
    /// The anchor makes later re-sealing detectable. It does not establish
    /// adapter semantics, detector completeness, witness truth, or authority.
    pub fn external_anchor(&self) -> Result<RunReceiptAnchor, IteratorError> {
        if !self.verify_replay_hash()? {
            return Err(IteratorError::InvalidDeclaration(
                "cannot anchor a structurally invalid run receipt".into(),
            ));
        }
        Ok(RunReceiptAnchor {
            schema_version: MULTIPATH_RECEIPT_ANCHOR_SCHEMA.into(),
            receipt_schema_version: MULTIPATH_RECEIPT_SCHEMA.into(),
            packet_sha256: Hash256::from_hex_unchecked(self.packet_sha256.clone()),
            operator_registry_sha256: Hash256::from_hex_unchecked(
                self.operator_registry_sha256.clone(),
            ),
            replay_sha256: Hash256::from_hex_unchecked(self.replay_sha256.clone()),
            inspection_trace_sha256: Hash256::from_hex_unchecked(inspection_trace_hash_for(self)?),
            canonical_receipt_sha256: Hash256::from_hex_unchecked(sha256_bytes(
                &self.canonical_json_bytes()?,
            )),
            authority_effect: self.authority_effect.clone(),
        })
    }

    /// Verifies internal replay consistency against a caller-pinned external anchor.
    ///
    /// Constructing an anchor from an untrusted receipt after receipt transport
    /// provides no authenticity. The trusted host must freeze the expected anchor
    /// independently before this verifier is called.
    pub fn verify_against_anchor(
        &self,
        expected: &RunReceiptAnchor,
    ) -> Result<bool, IteratorError> {
        if !expected.is_valid() || !self.verify_replay_hash()? {
            return Ok(false);
        }
        Ok(self.external_anchor()? == *expected)
    }

    pub fn verify_replay_hash(&self) -> Result<bool, IteratorError> {
        let Ok(canonical_registry) =
            OperatorRegistry::new(self.operator_registry.operators.clone())
        else {
            return Ok(false);
        };
        if canonical_registry != self.operator_registry
            || self.schema_version != MULTIPATH_RECEIPT_SCHEMA
            || !self.authority_effect.is_none()
            || !is_sha256(&self.packet_sha256)
            || !is_sha256(&self.operator_registry_sha256)
            || !is_sha256(&self.replay_sha256)
            || self.packet.sha256()? != self.packet_sha256
            || self.operator_registry.sha256()? != self.operator_registry_sha256
            || !self.receipt_contract_is_valid()?
            || !self.verify_compiled_operator_candidates()?
        {
            return Ok(false);
        }
        Ok(self.replay_sha256 == replay_hash_for(self)?)
    }

    pub fn recompute_replay_sha256(&self) -> Result<String, IteratorError> {
        replay_hash_for(self)
    }

    pub fn canonical_json_bytes(&self) -> Result<Vec<u8>, IteratorError> {
        serde_json::to_vec(self).map_err(|error| IteratorError::Serialization(error.to_string()))
    }

    fn receipt_contract_is_valid(&self) -> Result<bool, IteratorError> {
        if nonempty(&self.adapter_id, "adapter_id").is_err()
            || nonempty(&self.terminal.reason, "terminal reason").is_err()
            || self.budget.validate().is_err()
            || !self.accounting.is_balanced()
            || self.steps.len() > self.budget.max_steps
            || !is_sha256(&self.initial_state_sha256)
            || !is_sha256(&self.final_state_sha256)
            || serialized_len(&self.packet)? >= self.budget.max_receipt_bytes
            || self.canonical_json_bytes()?.len() > self.budget.max_receipt_bytes
        {
            return Ok(false);
        }

        let Ok(canonical_packet) = self.packet.clone().canonicalized() else {
            return Ok(false);
        };
        let Ok(canonical_initial_carrier) = self.initial_carrier.clone().canonicalized() else {
            return Ok(false);
        };
        let Ok(canonical_final_carrier) = self.final_carrier.clone().canonicalized() else {
            return Ok(false);
        };
        if canonical_packet != self.packet
            || canonical_initial_carrier != self.initial_carrier
            || canonical_final_carrier != self.final_carrier
            || self.initial_carrier.cells.len() > self.budget.max_carrier_cells
            || self.final_carrier.cells.len() > self.budget.max_carrier_cells
        {
            return Ok(false);
        }

        let mut expected_state_sha256 = self.initial_state_sha256.clone();
        let mut expected_carrier = canonical_initial_carrier.clone();
        let mut expected_carrier_sha256 = sha256_json(&expected_carrier)?;
        let final_carrier_sha256 = sha256_json(&canonical_final_carrier)?;
        let mut evaluated_rows = 0usize;
        let mut duplicate_rows = 0usize;
        let mut materialized_budget_rows = 0usize;
        let mut predicted_avoided = 0usize;
        let mut selected_count = 0usize;
        let mut extension_count = 0usize;

        for (position, step) in self.steps.iter().enumerate() {
            if step.step_index != position
                || !is_sha256(&step.state_sha256)
                || !is_sha256(&step.carrier_sha256)
                || step.state_sha256 != expected_state_sha256
                || step.carrier_sha256 != expected_carrier_sha256
            {
                return Ok(false);
            }
            let Ok(canonical_inspection) =
                canonicalize_inspection_receipt(&self.packet, step.inspection.clone())
            else {
                return Ok(false);
            };
            if canonical_inspection != step.inspection {
                return Ok(false);
            }

            for candidate in &step.candidates {
                if nonempty(&candidate.proposal_id, "candidate proposal_id").is_err()
                    || nonempty(&candidate.operator_id.0, "candidate operator_id").is_err()
                    || nonempty(&candidate.provenance.0, "candidate provenance").is_err()
                    || nonempty(&candidate.reason, "candidate reason").is_err()
                    || !is_sha256(&candidate.state_sha256)
                    || !is_sha256(&candidate.matched_signature_sha256)
                    || candidate
                        .equivalence_key
                        .as_ref()
                        .is_some_and(|key| key.trim().is_empty())
                    || candidate.after.is_some() != candidate.post_inspection.is_some()
                    || candidate
                        .post_inspection
                        .as_ref()
                        .zip(candidate.after)
                        .is_some_and(|(inspection, after)| inspection.measure != after)
                {
                    return Ok(false);
                }
                if let Some(post_inspection) = &candidate.post_inspection {
                    let Ok(canonical_post_inspection) =
                        canonicalize_inspection_receipt(&self.packet, post_inspection.clone())
                    else {
                        return Ok(false);
                    };
                    if canonical_post_inspection != *post_inspection {
                        return Ok(false);
                    }
                }
                let mut assessment = CandidateAssessment {
                    preservation: candidate.preservation.clone(),
                    witnesses: candidate.witnesses.clone(),
                };
                if canonicalize_assessment(&mut assessment).is_err()
                    || assessment.preservation != candidate.preservation
                    || assessment.witnesses != candidate.witnesses
                {
                    return Ok(false);
                }

                match candidate.verdict {
                    CandidateVerdict::DuplicatePruned => {
                        let Some(next) = duplicate_rows.checked_add(1) else {
                            return Ok(false);
                        };
                        duplicate_rows = next;
                        let Some(next) =
                            predicted_avoided.checked_add(candidate.predicted_candidates_avoided)
                        else {
                            return Ok(false);
                        };
                        predicted_avoided = next;
                    }
                    CandidateVerdict::BudgetPruned => {
                        let Some(next) = materialized_budget_rows.checked_add(1) else {
                            return Ok(false);
                        };
                        materialized_budget_rows = next;
                    }
                    _ => {
                        let Some(next) = evaluated_rows.checked_add(1) else {
                            return Ok(false);
                        };
                        evaluated_rows = next;
                    }
                }
            }

            let has_selection = step.compiled_operator_candidate.is_some();
            let has_extension = step.carrier_extension.is_some();
            if has_selection && has_extension {
                return Ok(false);
            }
            if position + 1 < self.steps.len() && !has_selection && !has_extension {
                return Ok(false);
            }

            if let Some(compiled) = &step.compiled_operator_candidate {
                if !compiled.before.strictly_descends_to(compiled.after) {
                    return Ok(false);
                }
                expected_state_sha256 = compiled.result_state_sha256.clone();
                let Some(next) = selected_count.checked_add(1) else {
                    return Ok(false);
                };
                selected_count = next;
            } else if let Some(extension) = &step.carrier_extension {
                if nonempty(&extension.extension_id, "extension_id").is_err()
                    || nonempty(&extension.justification_ref, "extension justification").is_err()
                    || !is_sha256(&extension.trigger_signature_sha256)
                    || !is_sha256(&extension.parent_carrier_sha256)
                    || !is_sha256(&extension.extended_carrier_sha256)
                    || extension.parent_carrier_sha256 != expected_carrier_sha256
                    || extension.parent_carrier_sha256 == extension.extended_carrier_sha256
                    || extension.added_cell_ids.is_empty()
                    || extension.added_cells.is_empty()
                    || !strictly_sorted(&extension.added_cell_ids)
                    || !step.inspection.signatures.iter().any(|signature| {
                        signature.signature_sha256 == extension.trigger_signature_sha256
                    })
                {
                    return Ok(false);
                }

                let mut receipt_added_cell_ids: Vec<_> = extension
                    .added_cells
                    .iter()
                    .map(|cell| cell.cell_id.clone())
                    .collect();
                receipt_added_cell_ids.sort();
                if receipt_added_cell_ids != extension.added_cell_ids {
                    return Ok(false);
                }
                let mut reconstructed_carrier = expected_carrier.clone();
                let reconstructed_extension = CarrierExtension {
                    extension_id: extension.extension_id.clone(),
                    trigger_signature_sha256: extension.trigger_signature_sha256.clone(),
                    justification_ref: extension.justification_ref.clone(),
                    new_cells: extension.added_cells.clone(),
                };
                if reconstructed_carrier
                    .extend(&reconstructed_extension)
                    .is_err()
                {
                    return Ok(false);
                }
                let reconstructed_added_cells: Vec<_> = reconstructed_carrier
                    .cells
                    .iter()
                    .filter(|cell| {
                        extension
                            .added_cell_ids
                            .binary_search(&cell.cell_id)
                            .is_ok()
                    })
                    .cloned()
                    .collect();
                let reconstructed_carrier_sha256 = sha256_json(&reconstructed_carrier)?;
                if reconstructed_added_cells != extension.added_cells
                    || reconstructed_carrier_sha256 != extension.extended_carrier_sha256
                {
                    return Ok(false);
                }
                expected_carrier = reconstructed_carrier;
                expected_carrier_sha256 = reconstructed_carrier_sha256;
                let Some(next) = extension_count.checked_add(1) else {
                    return Ok(false);
                };
                extension_count = next;
            }
        }

        if expected_state_sha256 != self.final_state_sha256
            || expected_carrier != canonical_final_carrier
            || expected_carrier_sha256 != final_carrier_sha256
            || self.accounting.evaluated != evaluated_rows
            || self.accounting.duplicate_pruned != duplicate_rows
            || self.accounting.predicted_avoided_by_quotient != predicted_avoided
            || self.accounting.accepted_transitions != selected_count
            || self.accounting.compiled_operator_candidates != selected_count
            || self.accounting.carrier_extensions != extension_count
            || self.accounting.budget_pruned < materialized_budget_rows
        {
            return Ok(false);
        }

        let omitted_budget_rows = self.accounting.budget_pruned - materialized_budget_rows;
        let Some(materialized_rows) = evaluated_rows
            .checked_add(duplicate_rows)
            .and_then(|count| count.checked_add(materialized_budget_rows))
        else {
            return Ok(false);
        };
        let Some(reconstructed_proposed) = materialized_rows.checked_add(omitted_budget_rows)
        else {
            return Ok(false);
        };
        let Some(processed_candidates) = evaluated_rows.checked_add(duplicate_rows) else {
            return Ok(false);
        };
        if reconstructed_proposed != self.accounting.proposed
            || processed_candidates > self.budget.max_candidates
            || (self.accounting.budget_pruned > 0
                && self.terminal.kind != TerminalKind::BudgetExhausted)
        {
            return Ok(false);
        }

        let terminal_step_is_inert = |step: &StepReceipt| {
            step.compiled_operator_candidate.is_none() && step.carrier_extension.is_none()
        };
        match self.terminal.kind {
            TerminalKind::ExactRepair => {
                let Some(last) = self.steps.last() else {
                    return Ok(false);
                };
                if !terminal_step_is_inert(last)
                    || !last.inspection.measure.is_resolved()
                    || last.inspection.detector_inadequate_count != 0
                    || last.inspection.higher_degree_need.is_some()
                    || self.accounting.accepted_transitions == 0
                    || last.inspection.measure.stabilized_survivor_count != 0
                {
                    return Ok(false);
                }
            }
            TerminalKind::StabilizedSurvivor => {
                let Some(last) = self.steps.last() else {
                    return Ok(false);
                };
                if !terminal_step_is_inert(last)
                    || !last.inspection.measure.is_resolved()
                    || last.inspection.detector_inadequate_count != 0
                    || last.inspection.higher_degree_need.is_some()
                    || (self.accounting.accepted_transitions > 0
                        && last.inspection.measure.stabilized_survivor_count == 0)
                {
                    return Ok(false);
                }
            }
            TerminalKind::OpenObstruction => {
                let Some(last) = self.steps.last() else {
                    return Ok(false);
                };
                if !terminal_step_is_inert(last)
                    || last.inspection.measure.is_resolved()
                    || last.inspection.detector_inadequate_count != 0
                    || last.inspection.higher_degree_need.is_some()
                    || last.candidates.is_empty()
                {
                    return Ok(false);
                }
            }
            TerminalKind::DetectorInadequate => {
                let Some(last) = self.steps.last() else {
                    return Ok(false);
                };
                if !terminal_step_is_inert(last) || last.inspection.detector_inadequate_count == 0 {
                    return Ok(false);
                }
            }
            TerminalKind::NoRule => {
                let Some(last) = self.steps.last() else {
                    return Ok(false);
                };
                if !terminal_step_is_inert(last)
                    || last.inspection.measure.is_resolved()
                    || last.inspection.detector_inadequate_count != 0
                    || last.inspection.higher_degree_need.is_some()
                    || !last.candidates.is_empty()
                {
                    return Ok(false);
                }
            }
            TerminalKind::RequiresLift => {
                let Some(last) = self.steps.last() else {
                    return Ok(false);
                };
                let candidate_requires_lift = last
                    .candidates
                    .iter()
                    .any(|candidate| candidate.verdict == CandidateVerdict::RequiresLift);
                if !terminal_step_is_inert(last)
                    || (last.inspection.higher_degree_need.is_none() && !candidate_requires_lift)
                {
                    return Ok(false);
                }
            }
            TerminalKind::Refused | TerminalKind::BudgetExhausted | TerminalKind::Cancelled => {}
        }
        Ok(true)
    }

    pub fn verify_compiled_operator_candidates(&self) -> Result<bool, IteratorError> {
        let mut compiled_count = 0;
        for (position, step) in self.steps.iter().enumerate() {
            let mut proposal_ids: Vec<_> = step
                .candidates
                .iter()
                .map(|candidate| candidate.proposal_id.as_str())
                .collect();
            proposal_ids.sort_unstable();
            if step.step_index != position
                || proposal_ids
                    .iter()
                    .any(|proposal_id| proposal_id.trim().is_empty())
                || proposal_ids.windows(2).any(|window| window[0] == window[1])
            {
                return Ok(false);
            }
            let Some(compiled) = &step.compiled_operator_candidate else {
                if step.selected_proposal_id.is_some()
                    || step.selected_candidate_sha256.is_some()
                    || step
                        .candidates
                        .iter()
                        .any(|candidate| candidate.verdict == CandidateVerdict::EligibleDescent)
                {
                    return Ok(false);
                }
                continue;
            };
            compiled_count += 1;
            let (Some(selected_id), Some(selected_sha256)) =
                (&step.selected_proposal_id, &step.selected_candidate_sha256)
            else {
                return Ok(false);
            };
            if !is_sha256(selected_sha256) {
                return Ok(false);
            }
            let mut matches = step.candidates.iter().filter(|candidate| {
                candidate.proposal_id == *selected_id
                    && candidate.verdict == CandidateVerdict::EligibleDescent
            });
            let Some(source) = matches.next() else {
                return Ok(false);
            };
            if matches.next().is_some() {
                return Ok(false);
            }
            let Some(post_inspection) = &source.post_inspection else {
                return Ok(false);
            };
            let source_candidate_sha256 = sha256_json(source)?;
            let post_inspection_sha256 = sha256_json(post_inspection)?;
            let signature_is_bound = step.inspection.signatures.iter().any(|signature| {
                signature.signature_sha256 == compiled.observed_signature_sha256
                    && signature.kind == compiled.signature_kind
            });
            let expected_result_state = self
                .steps
                .get(position + 1)
                .map(|next| next.state_sha256.as_str())
                .unwrap_or(self.final_state_sha256.as_str());
            let next_carrier_is_unchanged = self
                .steps
                .get(position + 1)
                .map(|next| next.carrier_sha256 == step.carrier_sha256)
                .unwrap_or(true);
            let source_operator = source_operator_record(compiled);
            let registered_operator_is_bound = self
                .operator_registry
                .get(&compiled.source_operator_id)
                .is_some_and(|registered| registered == &source_operator);
            let admission_evidence_is_valid =
                preservation_passes(&source_operator, &compiled.preservation_checks).is_ok()
                    && witnesses_pass(&source_operator, &compiled.witness_results, self.budget)
                        .is_ok();
            if compiled.source_proposal_id != *selected_id
                || compiled.source_candidate_sha256 != *selected_sha256
                || source_candidate_sha256 != *selected_sha256
                || compiled.source_registry_sha256 != self.operator_registry_sha256
                || compiled.source_step_index != step.step_index
                || compiled.source_packet_sha256 != self.packet_sha256
                || compiled.source_carrier_sha256 != step.carrier_sha256
                || compiled.source_state_sha256 != step.state_sha256
                || compiled.result_state_sha256 != source.state_sha256
                || compiled.result_state_sha256 != expected_result_state
                || !next_carrier_is_unchanged
                || compiled.source_operator_id != source.operator_id
                || compiled.source_provenance != source.provenance
                || compiled.source_equivalence_key != source.equivalence_key
                || compiled.source_predicted_candidates_avoided
                    != source.predicted_candidates_avoided
                || compiled.observed_signature_sha256 != source.matched_signature_sha256
                || !signature_is_bound
                || compiled.before != step.inspection.measure
                || compiled.before != source.before
                || source.after != Some(compiled.after)
                || !compiled.before.strictly_descends_to(compiled.after)
                || post_inspection.measure != compiled.after
                || compiled.post_inspection_sha256 != post_inspection_sha256
                || compiled.preservation_checks != source.preservation
                || compiled.witness_results != source.witnesses
                || !registered_operator_is_bound
                || !admission_evidence_is_valid
                || !compiled.verify_hashes()?
            {
                return Ok(false);
            }
        }
        Ok(
            compiled_count == self.accounting.compiled_operator_candidates
                && compiled_count == self.accounting.accepted_transitions,
        )
    }

    pub fn authority_effect(&self) -> &AuthorityEffect {
        &self.authority_effect
    }
}

#[derive(Debug, Error)]
pub enum IteratorError {
    #[error("invalid packet or declaration: {0}")]
    InvalidDeclaration(String),
    #[error("invalid finite carrier: {0}")]
    InvalidCarrier(String),
    #[error("invalid budget: {0}")]
    InvalidBudget(String),
    #[error("invalid operator registry: {0}")]
    InvalidRegistry(String),
    #[error("adapter seed refused: {0}")]
    AdapterSeed(String),
    #[error("DDA probe failed: {0}")]
    Dda(String),
    #[error("receipt serialization failed: {0}")]
    Serialization(String),
}

struct EligibleCandidate<S> {
    proposal_id: String,
    candidate_sha256: String,
    state: S,
    measure: ObstructionMeasure,
    compiled_operator: CompiledOperatorCandidate,
}

trait RunClock {
    fn elapsed_micros(&self) -> u128;
}

struct SystemRunClock {
    started: Instant,
}

impl RunClock for SystemRunClock {
    fn elapsed_micros(&self) -> u128 {
        self.started.elapsed().as_micros()
    }
}

/// Deterministic elapsed-time source exposed only for PaperER008 regression tests.
#[cfg(feature = "paper070-test-clock")]
pub trait DeterministicRunClock {
    fn elapsed_micros(&self) -> u128;
}

#[cfg(feature = "paper070-test-clock")]
struct DeterministicRunClockAdapter<'a, C: ?Sized>(&'a C);

#[cfg(feature = "paper070-test-clock")]
impl<C: DeterministicRunClock + ?Sized> RunClock for DeterministicRunClockAdapter<'_, C> {
    fn elapsed_micros(&self) -> u128 {
        self.0.elapsed_micros()
    }
}

pub fn run_multipath<A: MultipathAdapter>(
    adapter: &A,
    packet: ProblemPacket,
    registry: &OperatorRegistry,
    budget: RunBudget,
    cancellation: &CancellationToken,
) -> Result<RunReceipt, IteratorError> {
    let clock = SystemRunClock {
        started: Instant::now(),
    };
    run_multipath_with_clock(adapter, packet, registry, budget, cancellation, &clock)
}

/// Feature-gated deterministic-clock entrypoint for PaperER008 regression tests.
#[cfg(feature = "paper070-test-clock")]
pub fn run_multipath_with_test_clock<A: MultipathAdapter, C: DeterministicRunClock + ?Sized>(
    adapter: &A,
    packet: ProblemPacket,
    registry: &OperatorRegistry,
    budget: RunBudget,
    cancellation: &CancellationToken,
    clock: &C,
) -> Result<RunReceipt, IteratorError> {
    let clock = DeterministicRunClockAdapter(clock);
    run_multipath_with_clock(adapter, packet, registry, budget, cancellation, &clock)
}

fn run_multipath_with_clock<A: MultipathAdapter, C: RunClock + ?Sized>(
    adapter: &A,
    packet: ProblemPacket,
    registry: &OperatorRegistry,
    budget: RunBudget,
    cancellation: &CancellationToken,
    clock: &C,
) -> Result<RunReceipt, IteratorError> {
    nonempty(adapter.adapter_id(), "adapter_id")?;
    let packet = packet.canonicalized()?;
    let budget = budget.validate()?;
    let packet_bytes = serialized_len(&packet)?;
    if packet_bytes >= budget.max_receipt_bytes {
        return Err(IteratorError::InvalidBudget(format!(
            "packet alone requires {packet_bytes} bytes, leaving no room in max_receipt_bytes {}",
            budget.max_receipt_bytes
        )));
    }
    let packet_sha256 = packet.sha256()?;
    let operator_registry_sha256 = registry.sha256()?;
    let seed = adapter
        .seed(&packet)
        .map_err(|failure| IteratorError::AdapterSeed(failure.to_string()))?;
    let mut carrier = seed.carrier.canonicalized()?;
    if carrier.cells.len() > budget.max_carrier_cells {
        return Err(IteratorError::InvalidBudget(format!(
            "seed carrier has {} cells, above max_carrier_cells {}",
            carrier.cells.len(),
            budget.max_carrier_cells
        )));
    }
    let initial_carrier = carrier.clone();
    let mut state = seed.state;
    let initial_state_sha256 = sha256_json(&state)?;
    let mut steps = Vec::new();
    let mut accounting = CandidateAccounting::default();
    let mut terminal = None;

    for step_index in 0..budget.max_steps {
        if cancellation.is_cancelled() {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::Cancelled,
                reason: "explicit cancellation token observed".into(),
            });
            break;
        }
        if wall_budget_exhausted(clock, budget) {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted".into(),
            });
            break;
        }

        let state_sha256 = sha256_json(&state)?;
        let carrier_sha256 = sha256_json(&carrier)?;
        let raw_inspection_result = adapter.inspect(&packet, &carrier, &state);
        if wall_budget_exhausted(clock, budget) {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted after inspect".into(),
            });
            break;
        }
        let raw_inspection = match raw_inspection_result {
            Ok(inspection) => inspection,
            Err(failure) => {
                terminal = Some(terminal_from_failure(failure)?);
                break;
            }
        };
        let inspection = inspect_packet(&packet, raw_inspection)?;
        if wall_budget_exhausted(clock, budget) {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted while validating inspection".into(),
            });
            break;
        }
        let before = inspection.measure;
        let mut step = StepReceipt {
            step_index,
            state_sha256: state_sha256.clone(),
            carrier_sha256,
            inspection: inspection.clone(),
            candidates: Vec::new(),
            selected_proposal_id: None,
            selected_candidate_sha256: None,
            compiled_operator_candidate: None,
            carrier_extension: None,
        };

        if inspection.detector_inadequate_count > 0 {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::DetectorInadequate,
                reason: format!(
                    "{} protected distinction(s) lack an adequate detector",
                    inspection.detector_inadequate_count
                ),
            });
            steps.push(step);
            break;
        }
        if let Some(need) = &inspection.higher_degree_need {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::RequiresLift,
                reason: format!(
                    "degree {} witness exceeds admitted degree {}; lift={}",
                    need.required_degree,
                    need.current_max_degree,
                    need.licensed_lift_ref.as_deref().unwrap_or("unlicensed")
                ),
            });
            steps.push(step);
            break;
        }
        if before.is_resolved() {
            let kind =
                if accounting.accepted_transitions > 0 && before.stabilized_survivor_count == 0 {
                    TerminalKind::ExactRepair
                } else {
                    TerminalKind::StabilizedSurvivor
                };
            terminal = Some(TerminalReceipt {
                kind,
                reason:
                    "all declared protected distinctions are covered and no open defect remains"
                        .into(),
            });
            steps.push(step);
            break;
        }

        let proposal_result = adapter.propose(&packet, &carrier, &state, &inspection.signatures);
        if wall_budget_exhausted(clock, budget) {
            if let Ok(proposals) = &proposal_result {
                checked_add_counter(
                    &mut accounting.proposed,
                    proposals.len(),
                    "proposed candidates",
                )?;
                checked_add_counter(
                    &mut accounting.budget_pruned,
                    proposals.len(),
                    "budget-pruned candidates",
                )?;
            }
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted after propose".into(),
            });
            steps.push(step);
            break;
        }
        let mut proposals = match proposal_result {
            Ok(proposals) => proposals,
            Err(failure) => {
                terminal = Some(terminal_from_failure(failure)?);
                steps.push(step);
                break;
            }
        };
        let proposal_count = proposals.len();
        let processed_candidates = accounting
            .evaluated
            .checked_add(accounting.duplicate_pruned)
            .ok_or_else(|| {
                IteratorError::InvalidDeclaration("candidate accounting overflow".into())
            })?;
        let remaining_candidate_capacity =
            budget.max_candidates.saturating_sub(processed_candidates);
        checked_add_counter(
            &mut accounting.proposed,
            proposal_count,
            "proposed candidates",
        )?;
        if proposal_count > remaining_candidate_capacity {
            checked_add_counter(
                &mut accounting.budget_pruned,
                proposal_count,
                "budget-pruned candidates",
            )?;
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: format!(
                    "proposal batch of {proposal_count} exceeds remaining max_candidates capacity {remaining_candidate_capacity}"
                ),
            });
            steps.push(step);
            break;
        }
        validate_proposals(&proposals)?;
        proposals.sort_by(|left, right| {
            (&left.operator_id.0, &left.proposal_id)
                .cmp(&(&right.operator_id.0, &right.proposal_id))
        });
        if wall_budget_exhausted(clock, budget) {
            checked_add_counter(
                &mut accounting.budget_pruned,
                proposal_count,
                "budget-pruned candidates",
            )?;
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted while validating proposals".into(),
            });
            steps.push(step);
            break;
        }
        // A class is prunable only after one member has passed every admission
        // predicate. The registered contract additionally promises equal
        // post-measures, so pruning cannot change the selected minimum.
        let mut established_equivalence = BTreeSet::new();
        let mut eligible = Vec::new();
        let mut saw_lift = false;
        let mut wall_exhausted = false;

        for (proposal_index, proposal) in proposals.into_iter().enumerate() {
            if wall_budget_exhausted(clock, budget) {
                checked_add_counter(
                    &mut accounting.budget_pruned,
                    proposal_count - proposal_index,
                    "budget-pruned candidates",
                )?;
                wall_exhausted = true;
                break;
            }
            let proposal_state_sha256 = sha256_json(&proposal.state)?;
            let Some(operator) = registry.get(&proposal.operator_id) else {
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                step.candidates.push(candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::InvalidProposal,
                    "operator is not registered".into(),
                ));
                continue;
            };
            if !operator.carrier_kinds.contains(&carrier.kind) {
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                step.candidates.push(candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::InvalidProposal,
                    "operator does not admit this carrier kind".into(),
                ));
                continue;
            }
            let signature = inspection
                .signatures
                .iter()
                .find(|signature| signature.signature_sha256 == proposal.matched_signature_sha256);
            let Some(signature) = signature else {
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                step.candidates.push(candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::InvalidProposal,
                    "matched obstruction signature is absent".into(),
                ));
                continue;
            };
            if !operator.signature_kinds.contains(&signature.kind) {
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                step.candidates.push(candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::InvalidProposal,
                    "operator does not admit the matched signature kind".into(),
                ));
                continue;
            }
            if operator.requires_lift {
                saw_lift = true;
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                step.candidates.push(candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::RequiresLift,
                    "registered operator requires a separately licensed lift".into(),
                ));
                continue;
            }
            let equivalence_class = if let Some(key) = &proposal.equivalence_key {
                let Some(contract) = &operator.equivalence_contract else {
                    checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                    step.candidates.push(candidate_receipt(
                        &proposal,
                        proposal_state_sha256,
                        before,
                        CandidateVerdict::InvalidProposal,
                        "equivalence key supplied without a registered equivalence contract".into(),
                    ));
                    continue;
                };
                if key.trim().is_empty() {
                    checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                    step.candidates.push(candidate_receipt(
                        &proposal,
                        proposal_state_sha256,
                        before,
                        CandidateVerdict::InvalidProposal,
                        "equivalence key must be non-empty".into(),
                    ));
                    continue;
                }
                let full_key = format!("{}::{contract}::{key}", operator.operator_id.0);
                if established_equivalence.contains(&full_key) {
                    checked_add_counter(
                        &mut accounting.duplicate_pruned,
                        1,
                        "duplicate-pruned candidates",
                    )?;
                    checked_add_counter(
                        &mut accounting.predicted_avoided_by_quotient,
                        proposal.predicted_candidates_avoided,
                        "predicted quotient avoidance",
                    )?;
                    step.candidates.push(candidate_receipt(
                        &proposal,
                        proposal_state_sha256,
                        before,
                        CandidateVerdict::DuplicatePruned,
                        "duplicate after an eligible representative established full admission and post-measure congruence".into(),
                    ));
                    continue;
                }
                Some(full_key)
            } else {
                None
            };

            let assessment_result =
                adapter.assess_candidate(&packet, &carrier, &state, &proposal, operator);
            if wall_budget_exhausted(clock, budget) {
                checked_add_counter(
                    &mut accounting.budget_pruned,
                    proposal_count - proposal_index,
                    "budget-pruned candidates",
                )?;
                wall_exhausted = true;
                break;
            }
            let mut assessment = match assessment_result {
                Ok(assessment) => assessment,
                Err(failure) => {
                    checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                    let mut receipt = candidate_receipt(
                        &proposal,
                        proposal_state_sha256,
                        before,
                        CandidateVerdict::RejectedAdapter,
                        failure.to_string(),
                    );
                    if failure.kind == AdapterFailureKind::RequiresLift {
                        receipt.verdict = CandidateVerdict::RequiresLift;
                        saw_lift = true;
                    }
                    step.candidates.push(receipt);
                    continue;
                }
            };
            canonicalize_assessment(&mut assessment)?;
            if wall_budget_exhausted(clock, budget) {
                checked_add_counter(
                    &mut accounting.budget_pruned,
                    proposal_count - proposal_index,
                    "budget-pruned candidates",
                )?;
                wall_exhausted = true;
                break;
            }
            let preservation_ok = preservation_passes(operator, &assessment.preservation);
            if let Err(reason) = preservation_ok {
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                let mut receipt = candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::RejectedPreservation,
                    reason,
                );
                receipt.preservation = assessment.preservation;
                receipt.witnesses = assessment.witnesses;
                step.candidates.push(receipt);
                continue;
            }
            if let Err(reason) = witnesses_pass(operator, &assessment.witnesses, budget) {
                checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                let mut receipt = candidate_receipt(
                    &proposal,
                    proposal_state_sha256,
                    before,
                    CandidateVerdict::RejectedWitness,
                    reason,
                );
                receipt.preservation = assessment.preservation;
                receipt.witnesses = assessment.witnesses;
                step.candidates.push(receipt);
                continue;
            }
            let after_result = adapter.inspect(&packet, &carrier, &proposal.state);
            if wall_budget_exhausted(clock, budget) {
                checked_add_counter(
                    &mut accounting.budget_pruned,
                    proposal_count - proposal_index,
                    "budget-pruned candidates",
                )?;
                wall_exhausted = true;
                break;
            }
            let after_raw = match after_result {
                Ok(inspection) => inspection,
                Err(failure) => {
                    checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
                    let mut receipt = candidate_receipt(
                        &proposal,
                        proposal_state_sha256,
                        before,
                        CandidateVerdict::RejectedAdapter,
                        format!("candidate inspection failed: {failure}"),
                    );
                    receipt.preservation = assessment.preservation;
                    receipt.witnesses = assessment.witnesses;
                    step.candidates.push(receipt);
                    continue;
                }
            };
            let after_inspection = inspect_packet(&packet, after_raw)?;
            if wall_budget_exhausted(clock, budget) {
                checked_add_counter(
                    &mut accounting.budget_pruned,
                    proposal_count - proposal_index,
                    "budget-pruned candidates",
                )?;
                wall_exhausted = true;
                break;
            }
            checked_add_counter(&mut accounting.evaluated, 1, "evaluated candidates")?;
            let after = after_inspection.measure;
            let verdict = if before.strictly_descends_to(after) {
                CandidateVerdict::EligibleDescent
            } else {
                CandidateVerdict::RejectedNoDescent
            };
            let reason = if verdict == CandidateVerdict::EligibleDescent {
                "strict lexicographic obstruction descent".into()
            } else {
                "candidate does not strictly reduce the declared obstruction measure".into()
            };
            let mut receipt = candidate_receipt(
                &proposal,
                proposal_state_sha256.clone(),
                before,
                verdict,
                reason,
            );
            receipt.after = Some(after);
            receipt.preservation = assessment.preservation.clone();
            receipt.witnesses = assessment.witnesses.clone();
            receipt.post_inspection = Some(after_inspection.clone());
            let source_candidate_sha256 = sha256_json(&receipt)?;
            let compiled_operator = if verdict == CandidateVerdict::EligibleDescent {
                Some(compile_operator_candidate(OperatorCompilationInput {
                    packet_sha256: &packet_sha256,
                    operator_registry_sha256: &operator_registry_sha256,
                    source_step_index: step_index,
                    source_carrier_sha256: &step.carrier_sha256,
                    source_state_sha256: &state_sha256,
                    result_state_sha256: &proposal_state_sha256,
                    source_candidate_sha256: &source_candidate_sha256,
                    carrier_kind: carrier.kind,
                    proposal: &proposal,
                    operator,
                    signature,
                    before,
                    after,
                    post_inspection: &after_inspection,
                    assessment: &assessment,
                })?)
            } else {
                None
            };
            step.candidates.push(receipt);
            if verdict == CandidateVerdict::EligibleDescent {
                if let Some(full_key) = equivalence_class {
                    established_equivalence.insert(full_key);
                }
                eligible.push(EligibleCandidate {
                    proposal_id: proposal.proposal_id,
                    candidate_sha256: source_candidate_sha256,
                    state: proposal.state,
                    measure: after,
                    compiled_operator: compiled_operator
                        .expect("eligible descent compiles an operator candidate"),
                });
            }
        }

        if wall_exhausted || wall_budget_exhausted(clock, budget) {
            abandon_eligible_for_budget(&mut step, &mut eligible, &mut accounting)?;
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted before candidate selection".into(),
            });
            steps.push(step);
            break;
        }
        eligible.sort_by(|left, right| {
            left.measure
                .rank()
                .cmp(&right.measure.rank())
                .then_with(|| left.proposal_id.cmp(&right.proposal_id))
        });
        if wall_budget_exhausted(clock, budget) {
            abandon_eligible_for_budget(&mut step, &mut eligible, &mut accounting)?;
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted while ordering candidates".into(),
            });
            steps.push(step);
            break;
        }
        if let Some(selected) = eligible.into_iter().next() {
            step.selected_proposal_id = Some(selected.proposal_id);
            step.selected_candidate_sha256 = Some(selected.candidate_sha256);
            step.compiled_operator_candidate = Some(selected.compiled_operator);
            state = selected.state;
            checked_add_counter(
                &mut accounting.accepted_transitions,
                1,
                "accepted transitions",
            )?;
            checked_add_counter(
                &mut accounting.compiled_operator_candidates,
                1,
                "compiled operator candidates",
            )?;
            steps.push(step);
            continue;
        }

        let extension_result = adapter.extend_carrier(&packet, &carrier, &state, &inspection);
        if wall_budget_exhausted(clock, budget) {
            terminal = Some(TerminalReceipt {
                kind: TerminalKind::BudgetExhausted,
                reason: "max_wall_millis exhausted after extend_carrier".into(),
            });
            steps.push(step);
            break;
        }
        let extension = match extension_result {
            Ok(extension) => extension,
            Err(failure) => {
                terminal = Some(terminal_from_failure(failure)?);
                steps.push(step);
                break;
            }
        };
        if let Some(extension) = extension {
            let extended_carrier = validate_extension(&carrier, &extension, &inspection)?;
            if extended_carrier.cells.len() > budget.max_carrier_cells {
                terminal = Some(TerminalReceipt {
                    kind: TerminalKind::BudgetExhausted,
                    reason: "max_carrier_cells exhausted".into(),
                });
                steps.push(step);
                break;
            }
            let parent_carrier_sha256 = sha256_json(&carrier)?;
            let extended_carrier_sha256 = sha256_json(&extended_carrier)?;
            let mut added_cell_ids: Vec<_> = extension
                .new_cells
                .iter()
                .map(|cell| cell.cell_id.clone())
                .collect();
            added_cell_ids.sort();
            let added_cells: Vec<_> = extended_carrier
                .cells
                .iter()
                .filter(|cell| added_cell_ids.binary_search(&cell.cell_id).is_ok())
                .cloned()
                .collect();
            if wall_budget_exhausted(clock, budget) {
                terminal = Some(TerminalReceipt {
                    kind: TerminalKind::BudgetExhausted,
                    reason: "max_wall_millis exhausted while validating carrier extension".into(),
                });
                steps.push(step);
                break;
            }
            carrier = extended_carrier;
            step.carrier_extension = Some(CarrierExtensionReceipt {
                extension_id: extension.extension_id,
                trigger_signature_sha256: extension.trigger_signature_sha256,
                justification_ref: extension.justification_ref,
                parent_carrier_sha256,
                extended_carrier_sha256,
                added_cell_ids,
                added_cells,
            });
            checked_add_counter(&mut accounting.carrier_extensions, 1, "carrier extensions")?;
            steps.push(step);
            continue;
        }

        let (kind, reason) = if saw_lift {
            (
                TerminalKind::RequiresLift,
                "remaining candidate path requires an unlicensed lift".into(),
            )
        } else if step.candidates.is_empty() {
            (
                TerminalKind::NoRule,
                "no registered deformation proposal is available".into(),
            )
        } else {
            (
                TerminalKind::OpenObstruction,
                "all admitted candidates failed descent, preservation, or witness checks".into(),
            )
        };
        terminal = Some(TerminalReceipt { kind, reason });
        steps.push(step);
        break;
    }

    let terminal = terminal.unwrap_or_else(|| TerminalReceipt {
        kind: TerminalKind::BudgetExhausted,
        reason: "max_steps exhausted".into(),
    });
    if !accounting.is_balanced() {
        return Err(IteratorError::InvalidDeclaration(format!(
            "candidate accounting mismatch: proposed={}, evaluated={}, duplicate_pruned={}, budget_pruned={}",
            accounting.proposed,
            accounting.evaluated,
            accounting.duplicate_pruned,
            accounting.budget_pruned
        )));
    }
    let final_state_sha256 = sha256_json(&state)?;
    let mut receipt = RunReceipt {
        schema_version: MULTIPATH_RECEIPT_SCHEMA.into(),
        adapter_id: adapter.adapter_id().into(),
        packet,
        packet_sha256,
        operator_registry: registry.clone(),
        operator_registry_sha256,
        initial_carrier,
        final_carrier: carrier,
        initial_state_sha256,
        final_state_sha256,
        budget,
        accounting,
        steps,
        terminal,
        replay_sha256: String::new(),
        runtime_micros: clock.elapsed_micros(),
        authority_effect: AuthorityEffect::None,
    };
    receipt.replay_sha256 = replay_hash_for(&receipt)?;
    let receipt_bytes = serialized_len(&receipt)?;
    if receipt_bytes > budget.max_receipt_bytes {
        return Err(IteratorError::InvalidBudget(format!(
            "complete receipt requires {receipt_bytes} bytes, above max_receipt_bytes {}",
            budget.max_receipt_bytes
        )));
    }
    if !receipt.verify_replay_hash()? {
        return Err(IteratorError::InvalidDeclaration(
            "runtime produced a receipt rejected by public replay verification".into(),
        ));
    }
    Ok(receipt)
}

fn inspect_packet(
    packet: &ProblemPacket,
    mut inspection: Inspection,
) -> Result<InspectionReceipt, IteratorError> {
    nonempty(&inspection.observer.observer_id, "observer_id")?;
    nonempty(&inspection.observer.observer_family, "observer_family")?;
    nonempty(&inspection.observer.scope, "observer scope")?;
    nonempty(&inspection.comparison.comparison_id, "comparison_id")?;
    nonempty(&inspection.comparison.zero_rel, "ZeroRel")?;
    nonempty(&inspection.comparison.gauge_family, "gauge_family")?;

    inspection
        .projected_data
        .sort_by(|left, right| (left.degree, &left.datum_id).cmp(&(right.degree, &right.datum_id)));
    let datum_ids: Vec<_> = inspection
        .projected_data
        .iter()
        .map(|datum| datum.datum_id.clone())
        .collect();
    ensure_unique(&datum_ids, "projected datum ids")?;
    let datum_id_set: BTreeSet<_> = datum_ids.iter().cloned().collect();
    let mut projected_source_refs = BTreeSet::new();
    for datum in &mut inspection.projected_data {
        nonempty(&datum.datum_id, "projected datum id")?;
        if !is_sha256(&datum.value_sha256) {
            return Err(IteratorError::InvalidDeclaration(format!(
                "projected datum `{}` value_sha256 must be exactly 64 hexadecimal characters",
                datum.datum_id
            )));
        }
        if datum.source_refs.is_empty() {
            return Err(IteratorError::InvalidDeclaration(format!(
                "projected datum `{}` has no source_refs",
                datum.datum_id
            )));
        }
        datum.source_refs.sort();
        ensure_unique(&datum.source_refs, "projected datum source_refs")?;
        for source_ref in &datum.source_refs {
            nonempty(source_ref, "projected datum source_ref")?;
            projected_source_refs.insert(source_ref.clone());
        }
    }

    inspection
        .coverage
        .sort_by(|left, right| left.requirement.cmp(&right.requirement));
    let expected = &packet.protected_distinctions;
    let actual: Vec<_> = inspection
        .coverage
        .iter()
        .map(|assessment| assessment.requirement.clone())
        .collect();
    if expected.as_slice() != actual {
        return Err(IteratorError::InvalidDeclaration(format!(
            "detector coverage does not exactly match protected distinctions; expected={expected:?}, actual={actual:?}"
        )));
    }
    for assessment in &mut inspection.coverage {
        nonempty(&assessment.evidence_ref, "coverage evidence_ref")?;
        match assessment.disposition {
            CoverageDisposition::ProjectionLoss => {
                let Some(loss) = &mut assessment.projection_loss else {
                    return Err(IteratorError::InvalidDeclaration(format!(
                        "projection-loss assessment `{}` has no loss receipt",
                        assessment.requirement.key()
                    )));
                };
                validate_projection_loss(loss, &datum_id_set, &projected_source_refs)?;
            }
            CoverageDisposition::PreservedVisible | CoverageDisposition::DetectorInadequate
                if assessment.projection_loss.is_some() =>
            {
                return Err(IteratorError::InvalidDeclaration(format!(
                    "non-loss assessment `{}` carries a projection-loss receipt",
                    assessment.requirement.key()
                )));
            }
            CoverageDisposition::PreservedVisible | CoverageDisposition::DetectorInadequate => {}
        }
    }

    inspection
        .visible_defects
        .sort_by(|left, right| left.defect_id.cmp(&right.defect_id));
    let defect_ids: Vec<_> = inspection
        .visible_defects
        .iter()
        .map(|defect| defect.defect_id.clone())
        .collect();
    ensure_unique(&defect_ids, "visible defect ids")?;

    let mut defects = Vec::new();
    let mut signatures = Vec::new();
    let mut measure = ObstructionMeasure::default();
    for defect in inspection.visible_defects {
        nonempty(&defect.defect_id, "defect_id")?;
        nonempty(&defect.claim_id, "defect claim_id")?;
        nonempty(&defect.kind, "defect kind")?;
        nonempty(&defect.evidence_ref, "defect evidence_ref")?;
        let cochain: Option<CochainDiagnosticReceipt> = match defect.exact_binary_cochain {
            Some(probe) => {
                let diagnostic = probe.segment.diagnose(&probe.residual).map_err(|error| {
                    IteratorError::Dda(format!("defect {}: {error:?}", defect.defect_id))
                })?;
                match diagnostic.classification {
                    DegreeTrichotomy::Exact => {}
                    DegreeTrichotomy::StabilizedSurvivor => {
                        measure.stabilized_survivor_count += 1;
                        measure.phi_total += diagnostic.phi;
                    }
                    DegreeTrichotomy::Open => {
                        measure.open_defect_count += 1;
                        measure.phi_total += diagnostic.phi;
                        measure.gamma_total += diagnostic.gamma;
                    }
                }
                Some(diagnostic.into())
            }
            None => {
                measure.open_defect_count += 1;
                None
            }
        };
        let signature_sha256 = sha256_json(&(
            &defect.defect_id,
            &defect.claim_id,
            &defect.kind,
            &defect.cell_refs,
            &cochain,
        ))?;
        if cochain
            .as_ref()
            .is_none_or(|diagnostic| diagnostic.classification != "exact")
        {
            signatures.push(ObstructionSignature {
                defect_id: defect.defect_id.clone(),
                kind: defect.kind.clone(),
                signature_sha256: signature_sha256.clone(),
            });
        }
        defects.push(DefectReceipt {
            defect_id: defect.defect_id,
            claim_id: defect.claim_id,
            kind: defect.kind,
            cell_refs: defect.cell_refs,
            evidence_ref: defect.evidence_ref,
            signature_sha256,
            cochain,
        });
    }

    let mut detector_inadequate_count = 0;
    for assessment in &inspection.coverage {
        match assessment.disposition {
            CoverageDisposition::PreservedVisible => {}
            CoverageDisposition::ProjectionLoss => {
                measure.projection_loss_count += 1;
                let signature_sha256 =
                    sha256_json(&(assessment.requirement.key(), &assessment.projection_loss))?;
                signatures.push(ObstructionSignature {
                    defect_id: format!("projection-loss::{}", assessment.requirement.key()),
                    kind: "projection_loss".into(),
                    signature_sha256,
                });
            }
            CoverageDisposition::DetectorInadequate => detector_inadequate_count += 1,
        }
    }
    signatures.sort_by(|left, right| left.signature_sha256.cmp(&right.signature_sha256));

    canonicalize_inspection_receipt(
        packet,
        InspectionReceipt {
            observer: inspection.observer,
            comparison: inspection.comparison,
            projected_data: inspection.projected_data,
            coverage: inspection.coverage,
            defects,
            signatures,
            measure,
            detector_inadequate_count,
            higher_degree_need: inspection.higher_degree_need,
            discarded_information_refs: inspection.discarded_information_refs,
        },
    )
}

fn canonicalize_inspection_receipt(
    packet: &ProblemPacket,
    mut inspection: InspectionReceipt,
) -> Result<InspectionReceipt, IteratorError> {
    nonempty(&inspection.observer.observer_id, "observer_id")?;
    nonempty(&inspection.observer.observer_family, "observer_family")?;
    nonempty(&inspection.observer.scope, "observer scope")?;
    nonempty(&inspection.comparison.comparison_id, "comparison_id")?;
    nonempty(&inspection.comparison.zero_rel, "ZeroRel")?;
    nonempty(&inspection.comparison.gauge_family, "gauge_family")?;

    inspection
        .projected_data
        .sort_by(|left, right| (left.degree, &left.datum_id).cmp(&(right.degree, &right.datum_id)));
    let datum_ids: Vec<_> = inspection
        .projected_data
        .iter()
        .map(|datum| datum.datum_id.clone())
        .collect();
    ensure_unique(&datum_ids, "projected datum ids")?;
    let datum_id_set: BTreeSet<_> = datum_ids.iter().cloned().collect();
    let mut projected_source_refs = BTreeSet::new();
    for datum in &mut inspection.projected_data {
        nonempty(&datum.datum_id, "projected datum id")?;
        if !is_sha256(&datum.value_sha256) {
            return Err(IteratorError::InvalidDeclaration(format!(
                "projected datum `{}` value_sha256 must be lowercase SHA-256",
                datum.datum_id
            )));
        }
        if datum.source_refs.is_empty() {
            return Err(IteratorError::InvalidDeclaration(format!(
                "projected datum `{}` has no source_refs",
                datum.datum_id
            )));
        }
        datum.source_refs.sort();
        ensure_unique(&datum.source_refs, "projected datum source_refs")?;
        for source_ref in &datum.source_refs {
            nonempty(source_ref, "projected datum source_ref")?;
            projected_source_refs.insert(source_ref.clone());
        }
    }

    inspection
        .coverage
        .sort_by(|left, right| left.requirement.cmp(&right.requirement));
    let expected_coverage = &packet.protected_distinctions;
    let actual_coverage: Vec<_> = inspection
        .coverage
        .iter()
        .map(|assessment| assessment.requirement.clone())
        .collect();
    if expected_coverage.as_slice() != actual_coverage {
        return Err(IteratorError::InvalidDeclaration(
            "retained detector coverage does not match packet protected distinctions".into(),
        ));
    }
    for assessment in &mut inspection.coverage {
        nonempty(&assessment.evidence_ref, "coverage evidence_ref")?;
        match assessment.disposition {
            CoverageDisposition::ProjectionLoss => {
                let Some(loss) = &mut assessment.projection_loss else {
                    return Err(IteratorError::InvalidDeclaration(
                        "projection-loss coverage has no retained loss receipt".into(),
                    ));
                };
                validate_projection_loss(loss, &datum_id_set, &projected_source_refs)?;
            }
            CoverageDisposition::PreservedVisible | CoverageDisposition::DetectorInadequate
                if assessment.projection_loss.is_some() =>
            {
                return Err(IteratorError::InvalidDeclaration(
                    "non-loss coverage carries a projection-loss receipt".into(),
                ));
            }
            CoverageDisposition::PreservedVisible | CoverageDisposition::DetectorInadequate => {}
        }
    }

    inspection
        .defects
        .sort_by(|left, right| left.defect_id.cmp(&right.defect_id));
    let defect_ids: Vec<_> = inspection
        .defects
        .iter()
        .map(|defect| defect.defect_id.clone())
        .collect();
    ensure_unique(&defect_ids, "retained defect ids")?;

    let mut measure = ObstructionMeasure::default();
    let mut signatures = Vec::new();
    for defect in &mut inspection.defects {
        nonempty(&defect.defect_id, "defect_id")?;
        nonempty(&defect.claim_id, "defect claim_id")?;
        nonempty(&defect.kind, "defect kind")?;
        nonempty(&defect.evidence_ref, "defect evidence_ref")?;
        if defect.cell_refs.is_empty() {
            return Err(IteratorError::InvalidDeclaration(format!(
                "defect `{}` has no cell_refs",
                defect.defect_id
            )));
        }
        defect.cell_refs.sort();
        ensure_unique(&defect.cell_refs, "defect cell_refs")?;
        for cell_ref in &defect.cell_refs {
            nonempty(cell_ref, "defect cell_ref")?;
        }

        let retains_signature = match &defect.cochain {
            Some(diagnostic) => match diagnostic.classification.as_str() {
                "exact" if diagnostic.phi == 0 && diagnostic.gamma == 0 => false,
                "stabilized_survivor" if diagnostic.phi > 0 && diagnostic.gamma == 0 => {
                    checked_add_counter(
                        &mut measure.stabilized_survivor_count,
                        1,
                        "stabilized survivor count",
                    )?;
                    checked_add_counter(&mut measure.phi_total, diagnostic.phi, "Phi total")?;
                    true
                }
                "open" if diagnostic.phi > 0 && diagnostic.gamma > 0 => {
                    checked_add_counter(&mut measure.open_defect_count, 1, "open defects")?;
                    checked_add_counter(&mut measure.phi_total, diagnostic.phi, "Phi total")?;
                    checked_add_counter(&mut measure.gamma_total, diagnostic.gamma, "Gamma total")?;
                    true
                }
                _ => {
                    return Err(IteratorError::InvalidDeclaration(format!(
                        "defect `{}` has an inconsistent cochain classification",
                        defect.defect_id
                    )));
                }
            },
            None => {
                checked_add_counter(&mut measure.open_defect_count, 1, "open defects")?;
                true
            }
        };
        defect.signature_sha256 = sha256_json(&(
            &defect.defect_id,
            &defect.claim_id,
            &defect.kind,
            &defect.cell_refs,
            &defect.cochain,
        ))?;
        if retains_signature {
            signatures.push(ObstructionSignature {
                defect_id: defect.defect_id.clone(),
                kind: defect.kind.clone(),
                signature_sha256: defect.signature_sha256.clone(),
            });
        }
    }

    let mut detector_inadequate_count = 0usize;
    for assessment in &inspection.coverage {
        match assessment.disposition {
            CoverageDisposition::PreservedVisible => {}
            CoverageDisposition::ProjectionLoss => {
                checked_add_counter(
                    &mut measure.projection_loss_count,
                    1,
                    "projection loss count",
                )?;
                signatures.push(ObstructionSignature {
                    defect_id: format!("projection-loss::{}", assessment.requirement.key()),
                    kind: "projection_loss".into(),
                    signature_sha256: sha256_json(&(
                        assessment.requirement.key(),
                        &assessment.projection_loss,
                    ))?,
                });
            }
            CoverageDisposition::DetectorInadequate => checked_add_counter(
                &mut detector_inadequate_count,
                1,
                "detector inadequate count",
            )?,
        }
    }
    signatures.sort_by(|left, right| left.signature_sha256.cmp(&right.signature_sha256));
    let signature_hashes: Vec<_> = signatures
        .iter()
        .map(|signature| signature.signature_sha256.clone())
        .collect();
    ensure_unique(&signature_hashes, "obstruction signature hashes")?;

    if let Some(need) = &inspection.higher_degree_need {
        if need.required_degree <= need.current_max_degree {
            return Err(IteratorError::InvalidDeclaration(
                "higher-degree need must exceed the admitted degree".into(),
            ));
        }
        nonempty(&need.witness_ref, "higher-degree witness_ref")?;
        if let Some(license) = &need.licensed_lift_ref {
            nonempty(license, "higher-degree licensed_lift_ref")?;
        }
    }
    inspection.discarded_information_refs.sort();
    ensure_unique(
        &inspection.discarded_information_refs,
        "discarded information refs",
    )?;
    for discarded_ref in &inspection.discarded_information_refs {
        nonempty(discarded_ref, "discarded information ref")?;
    }

    inspection.signatures = signatures;
    inspection.measure = measure;
    inspection.detector_inadequate_count = detector_inadequate_count;
    Ok(inspection)
}

fn validate_projection_loss(
    loss: &mut ProjectionLossReceipt,
    datum_ids: &BTreeSet<String>,
    projected_source_refs: &BTreeSet<String>,
) -> Result<(), IteratorError> {
    nonempty(&loss.loss_id, "projection loss_id")?;
    nonempty(
        &loss.recovery_requirement,
        "projection loss recovery_requirement",
    )?;
    if !is_sha256(&loss.discarded_sha256) {
        return Err(IteratorError::InvalidDeclaration(format!(
            "projection loss `{}` discarded_sha256 must be exactly 64 hexadecimal characters",
            loss.loss_id
        )));
    }
    if loss.source_refs.is_empty() {
        return Err(IteratorError::InvalidDeclaration(format!(
            "projection loss `{}` has no source_refs",
            loss.loss_id
        )));
    }
    if loss.collided_projection_refs.is_empty() {
        return Err(IteratorError::InvalidDeclaration(format!(
            "projection loss `{}` has no collided_projection_refs",
            loss.loss_id
        )));
    }
    loss.source_refs.sort();
    loss.collided_projection_refs.sort();
    ensure_unique(&loss.source_refs, "projection loss source_refs")?;
    ensure_unique(
        &loss.collided_projection_refs,
        "projection loss collided_projection_refs",
    )?;
    for source_ref in &loss.source_refs {
        nonempty(source_ref, "projection loss source_ref")?;
        if !projected_source_refs.contains(source_ref) && !source_ref.starts_with("external:") {
            return Err(IteratorError::InvalidDeclaration(format!(
                "projection loss `{}` source_ref `{source_ref}` is neither projected nor explicitly external",
                loss.loss_id
            )));
        }
    }
    for collided_ref in &loss.collided_projection_refs {
        nonempty(collided_ref, "projection loss collided_projection_ref")?;
        if !datum_ids.contains(collided_ref) {
            return Err(IteratorError::InvalidDeclaration(format!(
                "projection loss `{}` collided_projection_ref `{collided_ref}` does not resolve to projected_data",
                loss.loss_id
            )));
        }
    }
    Ok(())
}

fn validate_proposals<S>(proposals: &[DeformationProposal<S>]) -> Result<(), IteratorError> {
    let mut ids = Vec::with_capacity(proposals.len());
    for proposal in proposals {
        nonempty(&proposal.proposal_id, "proposal_id")?;
        nonempty(&proposal.operator_id.0, "proposal operator_id")?;
        nonempty(&proposal.provenance.0, "proposal provenance")?;
        if !is_sha256(&proposal.matched_signature_sha256) {
            return Err(IteratorError::InvalidDeclaration(
                "proposal matched_signature_sha256 must be lowercase SHA-256".into(),
            ));
        }
        if let Some(key) = &proposal.equivalence_key {
            nonempty(key, "proposal equivalence_key")?;
        }
        ids.push(proposal.proposal_id.clone());
    }
    ids.sort();
    ensure_unique(&ids, "proposal ids")
}

fn canonicalize_assessment(assessment: &mut CandidateAssessment) -> Result<(), IteratorError> {
    for check in &assessment.preservation {
        nonempty(&check.obligation_id, "preservation obligation_id")?;
        nonempty(&check.evidence_ref, "preservation evidence_ref")?;
        if !is_sha256(&check.evidence_sha256) {
            return Err(IteratorError::InvalidDeclaration(
                "preservation evidence_sha256 must be lowercase SHA-256".into(),
            ));
        }
    }
    assessment
        .preservation
        .sort_by(|left, right| left.obligation_id.cmp(&right.obligation_id));
    let preservation_ids: Vec<_> = assessment
        .preservation
        .iter()
        .map(|check| check.obligation_id.clone())
        .collect();
    ensure_unique(&preservation_ids, "preservation obligation ids")?;

    for witness in &assessment.witnesses {
        nonempty(&witness.witness_id, "witness_id")?;
        nonempty(&witness.procedure, "witness procedure")?;
        nonempty(&witness.evidence_ref, "witness evidence_ref")?;
        if !is_sha256(&witness.evidence_sha256) {
            return Err(IteratorError::InvalidDeclaration(
                "witness evidence_sha256 must be lowercase SHA-256".into(),
            ));
        }
    }
    assessment
        .witnesses
        .sort_by(|left, right| left.witness_id.cmp(&right.witness_id));
    let witness_ids: Vec<_> = assessment
        .witnesses
        .iter()
        .map(|witness| witness.witness_id.clone())
        .collect();
    ensure_unique(&witness_ids, "witness ids")
}

fn candidate_receipt<S>(
    proposal: &DeformationProposal<S>,
    state_sha256: String,
    before: ObstructionMeasure,
    verdict: CandidateVerdict,
    reason: String,
) -> CandidateReceipt {
    CandidateReceipt {
        proposal_id: proposal.proposal_id.clone(),
        operator_id: proposal.operator_id.clone(),
        provenance: proposal.provenance.clone(),
        state_sha256,
        matched_signature_sha256: proposal.matched_signature_sha256.clone(),
        equivalence_key: proposal.equivalence_key.clone(),
        predicted_candidates_avoided: proposal.predicted_candidates_avoided,
        verdict,
        reason,
        before,
        after: None,
        preservation: Vec::new(),
        witnesses: Vec::new(),
        post_inspection: None,
    }
}

fn preservation_passes(
    operator: &RegisteredOperator,
    checks: &[PreservationCheck],
) -> Result<(), String> {
    let expected: BTreeSet<_> = operator.preservation_obligations.iter().cloned().collect();
    let actual: BTreeSet<_> = checks
        .iter()
        .map(|check| check.obligation_id.clone())
        .collect();
    if expected != actual || checks.len() != actual.len() {
        return Err(format!(
            "preservation coverage mismatch; expected={expected:?}, actual={actual:?}"
        ));
    }
    for check in checks {
        nonempty(&check.evidence_ref, "preservation evidence_ref")
            .map_err(|error| error.to_string())?;
        if !is_sha256(&check.evidence_sha256) {
            return Err(format!(
                "preservation obligation {} has an invalid evidence SHA-256",
                check.obligation_id
            ));
        }
        if check.verdict != CheckVerdict::Pass {
            return Err(format!(
                "preservation obligation `{}` is {:?}",
                check.obligation_id, check.verdict
            ));
        }
    }
    Ok(())
}

fn witnesses_pass(
    operator: &RegisteredOperator,
    witnesses: &[WitnessResult],
    budget: RunBudget,
) -> Result<(), String> {
    let passing: Vec<_> = witnesses
        .iter()
        .filter(|witness| {
            witness.procedure == operator.witness_procedure && witness.verdict == CheckVerdict::Pass
        })
        .collect();
    if passing.is_empty() {
        return Err(format!(
            "no passing witness for registered procedure `{}`",
            operator.witness_procedure
        ));
    }
    for witness in &passing {
        if witness.witness_id.trim().is_empty()
            || witness.evidence_ref.trim().is_empty()
            || !is_sha256(&witness.evidence_sha256)
        {
            return Err("passing witness has empty identity or evidence binding".into());
        }
    }
    if budget.require_independent_witness
        && !passing
            .iter()
            .any(|witness| witness.relation.supports_independence())
    {
        return Err(
            "passing receipts exist, but no witness has an established independent relation".into(),
        );
    }
    Ok(())
}

struct OperatorCompilationInput<'a, S> {
    packet_sha256: &'a str,
    operator_registry_sha256: &'a str,
    source_step_index: usize,
    source_carrier_sha256: &'a str,
    source_state_sha256: &'a str,
    result_state_sha256: &'a str,
    source_candidate_sha256: &'a str,
    carrier_kind: CarrierKind,
    proposal: &'a DeformationProposal<S>,
    operator: &'a RegisteredOperator,
    signature: &'a ObstructionSignature,
    before: ObstructionMeasure,
    after: ObstructionMeasure,
    post_inspection: &'a InspectionReceipt,
    assessment: &'a CandidateAssessment,
}

fn compile_operator_candidate<S>(
    input: OperatorCompilationInput<'_, S>,
) -> Result<CompiledOperatorCandidate, IteratorError> {
    let OperatorCompilationInput {
        packet_sha256,
        operator_registry_sha256,
        source_step_index,
        source_carrier_sha256,
        source_state_sha256,
        result_state_sha256,
        source_candidate_sha256,
        carrier_kind,
        proposal,
        operator,
        signature,
        before,
        after,
        post_inspection,
        assessment,
    } = input;
    for (label, value) in [
        ("packet", packet_sha256),
        ("operator registry", operator_registry_sha256),
        ("source carrier", source_carrier_sha256),
        ("source state", source_state_sha256),
        ("result state", result_state_sha256),
        ("source candidate", source_candidate_sha256),
        ("observed signature", signature.signature_sha256.as_str()),
        (
            "deformation descriptor",
            operator.deformation_descriptor_sha256.as_str(),
        ),
    ] {
        if !is_sha256(value) {
            return Err(IteratorError::InvalidDeclaration(format!(
                "compiled operator candidate has invalid {label} SHA-256"
            )));
        }
    }
    nonempty(&proposal.proposal_id, "compiled source proposal_id")?;
    nonempty(
        &proposal.provenance.0,
        "compiled source proposal provenance",
    )?;
    if post_inspection.measure != after {
        return Err(IteratorError::InvalidDeclaration(
            "compiled candidate post-inspection measure does not match after measure".into(),
        ));
    }

    let mut candidate = CompiledOperatorCandidate {
        candidate_operator_id: OperatorId(String::new()),
        source_operator_id: operator.operator_id.clone(),
        source_operator_sha256: String::new(),
        source_operator_signature_kinds: operator.signature_kinds.clone(),
        source_operator_carrier_kinds: operator.carrier_kinds.clone(),
        source_registry_sha256: operator_registry_sha256.into(),
        source_proposal_id: proposal.proposal_id.clone(),
        source_proposal_sha256: String::new(),
        source_assessment_sha256: String::new(),
        source_candidate_sha256: source_candidate_sha256.into(),
        source_step_index,
        source_packet_sha256: packet_sha256.into(),
        source_carrier_sha256: source_carrier_sha256.into(),
        source_state_sha256: source_state_sha256.into(),
        result_state_sha256: result_state_sha256.into(),
        source_provenance: proposal.provenance.clone(),
        source_equivalence_key: proposal.equivalence_key.clone(),
        source_predicted_candidates_avoided: proposal.predicted_candidates_avoided,
        signature_kind: signature.kind.clone(),
        observed_signature_sha256: signature.signature_sha256.clone(),
        carrier_kind,
        preconditions: operator.preconditions.clone(),
        deformation_ref: operator.deformation_ref.clone(),
        deformation_descriptor_sha256: operator.deformation_descriptor_sha256.clone(),
        preservation_obligations: operator.preservation_obligations.clone(),
        preservation_checks: assessment.preservation.clone(),
        witness_procedure: operator.witness_procedure.clone(),
        witness_results: assessment.witnesses.clone(),
        equivalence_contract: operator.equivalence_contract.clone(),
        requires_lift: operator.requires_lift,
        possible_terminals: operator.possible_terminals.clone(),
        before,
        after,
        post_inspection_sha256: sha256_json(post_inspection)?,
        pattern_sha256: String::new(),
        evidence_sha256: String::new(),
        authority_effect: AuthorityEffect::None,
    };
    candidate.source_operator_sha256 = source_operator_hash(&candidate)?;
    candidate.source_proposal_sha256 = source_proposal_hash(&candidate)?;
    candidate.source_assessment_sha256 = source_assessment_hash(&candidate)?;
    candidate.pattern_sha256 = operator_pattern_hash(&candidate)?;
    candidate.candidate_operator_id =
        OperatorId(format!("candidate.sha256.{}", candidate.pattern_sha256));
    candidate.evidence_sha256 = operator_evidence_hash(&candidate)?;
    if !candidate.verify_hashes()? {
        return Err(IteratorError::InvalidDeclaration(
            "compiled operator candidate failed internal hash verification".into(),
        ));
    }
    Ok(candidate)
}
fn validate_extension(
    carrier: &FiniteCarrier,
    extension: &CarrierExtension,
    inspection: &InspectionReceipt,
) -> Result<FiniteCarrier, IteratorError> {
    nonempty(&extension.extension_id, "carrier extension id")?;
    nonempty(
        &extension.trigger_signature_sha256,
        "carrier extension trigger_signature_sha256",
    )?;
    nonempty(
        &extension.justification_ref,
        "carrier extension justification",
    )?;
    if extension.new_cells.is_empty() {
        return Err(IteratorError::InvalidCarrier(
            "carrier extension must add at least one cell".into(),
        ));
    }
    if !inspection
        .signatures
        .iter()
        .any(|signature| signature.signature_sha256 == extension.trigger_signature_sha256)
    {
        return Err(IteratorError::InvalidCarrier(
            "carrier extension is not triggered by a current obstruction signature".into(),
        ));
    }

    let current_ids: BTreeSet<_> = carrier
        .cells
        .iter()
        .map(|cell| cell.cell_id.as_str())
        .collect();
    let mut added_ids = Vec::with_capacity(extension.new_cells.len());
    for cell in &extension.new_cells {
        nonempty(&cell.cell_id, "carrier extension cell id")?;
        if current_ids.contains(cell.cell_id.as_str()) {
            return Err(IteratorError::InvalidCarrier(format!(
                "carrier extension cell `{}` already exists",
                cell.cell_id
            )));
        }
        added_ids.push(cell.cell_id.clone());
    }
    added_ids.sort();
    ensure_unique(&added_ids, "carrier extension cell ids")?;

    let parent_sha256 = sha256_json(carrier)?;
    let mut extended = carrier.clone();
    extended.extend(extension)?;
    if sha256_json(&extended)? == parent_sha256 {
        return Err(IteratorError::InvalidCarrier(
            "carrier extension did not change the carrier hash".into(),
        ));
    }
    Ok(extended)
}

fn terminal_from_failure(failure: AdapterFailure) -> Result<TerminalReceipt, IteratorError> {
    let detail = failure.detail.trim();
    nonempty(detail, "adapter failure detail")?;
    // Adapter classifications are advisory; only host-observed evidence selects
    // DetectorInadequate, NoRule, or RequiresLift terminal envelopes.
    Ok(TerminalReceipt {
        kind: TerminalKind::Refused,
        reason: format!("adapter callback declared {:?}: {detail}", failure.kind),
    })
}

fn checked_add_counter(
    counter: &mut usize,
    amount: usize,
    label: &str,
) -> Result<(), IteratorError> {
    *counter = counter
        .checked_add(amount)
        .ok_or_else(|| IteratorError::InvalidDeclaration(format!("{label} accounting overflow")))?;
    Ok(())
}

fn abandon_eligible_for_budget<S>(
    step: &mut StepReceipt,
    eligible: &mut Vec<EligibleCandidate<S>>,
    accounting: &mut CandidateAccounting,
) -> Result<(), IteratorError> {
    let eligible_ids: BTreeSet<_> = eligible
        .iter()
        .map(|candidate| candidate.proposal_id.clone())
        .collect();
    let mut converted = 0usize;
    for candidate in &mut step.candidates {
        if eligible_ids.contains(&candidate.proposal_id)
            && candidate.verdict == CandidateVerdict::EligibleDescent
        {
            candidate.verdict = CandidateVerdict::BudgetPruned;
            candidate.reason =
                "max_wall_millis exhausted before selected transition mutation".into();
            converted += 1;
        }
    }
    if converted != eligible.len() {
        return Err(IteratorError::InvalidDeclaration(
            "eligible candidate accounting does not match step receipts".into(),
        ));
    }
    accounting.evaluated = accounting.evaluated.checked_sub(converted).ok_or_else(|| {
        IteratorError::InvalidDeclaration("evaluated candidate accounting underflow".into())
    })?;
    checked_add_counter(
        &mut accounting.budget_pruned,
        converted,
        "budget-pruned candidates",
    )?;
    eligible.clear();
    Ok(())
}

fn wall_budget_exhausted<C: RunClock + ?Sized>(clock: &C, budget: RunBudget) -> bool {
    clock.elapsed_micros() / 1_000 >= u128::from(budget.max_wall_millis)
}

fn serialized_len<T: Serialize + ?Sized>(value: &T) -> Result<usize, IteratorError> {
    serde_json::to_vec(value)
        .map(|bytes| bytes.len())
        .map_err(|error| IteratorError::Serialization(error.to_string()))
}

#[derive(Serialize)]
struct SourceOperatorCommitment<'a> {
    hash_domain: &'static str,
    operator: &'a RegisteredOperator,
}

#[derive(Serialize)]
struct SourceProposalCommitment<'a> {
    hash_domain: &'static str,
    proposal_id: &'a str,
    operator_id: &'a OperatorId,
    provenance: &'a Provenance,
    matched_signature_sha256: &'a str,
    equivalence_key: &'a Option<String>,
    predicted_candidates_avoided: usize,
    result_state_sha256: &'a str,
}

#[derive(Serialize)]
struct SourceAssessmentCommitment<'a> {
    hash_domain: &'static str,
    preservation: &'a [PreservationCheck],
    witnesses: &'a [WitnessResult],
}

#[derive(Serialize)]
struct OperatorPatternCommitment<'a> {
    hash_domain: &'static str,
    source_operator_id: &'a OperatorId,
    source_operator_sha256: &'a str,
    signature_kind: &'a str,
    carrier_kind: CarrierKind,
    preconditions: &'a [String],
    deformation_ref: &'a str,
    deformation_descriptor_sha256: &'a str,
    preservation_obligations: &'a [String],
    witness_procedure: &'a str,
    equivalence_contract: &'a Option<String>,
    requires_lift: bool,
    possible_terminals: &'a [TerminalKind],
    authority_effect: &'a AuthorityEffect,
}

fn source_operator_record(candidate: &CompiledOperatorCandidate) -> RegisteredOperator {
    RegisteredOperator {
        operator_id: candidate.source_operator_id.clone(),
        signature_kinds: candidate.source_operator_signature_kinds.clone(),
        carrier_kinds: candidate.source_operator_carrier_kinds.clone(),
        preconditions: candidate.preconditions.clone(),
        deformation_ref: candidate.deformation_ref.clone(),
        deformation_descriptor_sha256: candidate.deformation_descriptor_sha256.clone(),
        preservation_obligations: candidate.preservation_obligations.clone(),
        witness_procedure: candidate.witness_procedure.clone(),
        equivalence_contract: candidate.equivalence_contract.clone(),
        requires_lift: candidate.requires_lift,
        possible_terminals: candidate.possible_terminals.clone(),
    }
}

fn source_operator_hash(candidate: &CompiledOperatorCandidate) -> Result<String, IteratorError> {
    let operator = source_operator_record(candidate);
    sha256_json(&SourceOperatorCommitment {
        hash_domain: SOURCE_OPERATOR_HASH_DOMAIN,
        operator: &operator,
    })
}

fn source_proposal_hash(candidate: &CompiledOperatorCandidate) -> Result<String, IteratorError> {
    sha256_json(&SourceProposalCommitment {
        hash_domain: OPERATOR_PROPOSAL_HASH_DOMAIN,
        proposal_id: &candidate.source_proposal_id,
        operator_id: &candidate.source_operator_id,
        provenance: &candidate.source_provenance,
        matched_signature_sha256: &candidate.observed_signature_sha256,
        equivalence_key: &candidate.source_equivalence_key,
        predicted_candidates_avoided: candidate.source_predicted_candidates_avoided,
        result_state_sha256: &candidate.result_state_sha256,
    })
}

fn source_assessment_hash(candidate: &CompiledOperatorCandidate) -> Result<String, IteratorError> {
    sha256_json(&SourceAssessmentCommitment {
        hash_domain: SOURCE_ASSESSMENT_HASH_DOMAIN,
        preservation: &candidate.preservation_checks,
        witnesses: &candidate.witness_results,
    })
}

fn operator_pattern_hash(candidate: &CompiledOperatorCandidate) -> Result<String, IteratorError> {
    sha256_json(&OperatorPatternCommitment {
        hash_domain: OPERATOR_PATTERN_HASH_DOMAIN,
        source_operator_id: &candidate.source_operator_id,
        source_operator_sha256: &candidate.source_operator_sha256,
        signature_kind: &candidate.signature_kind,
        carrier_kind: candidate.carrier_kind,
        preconditions: &candidate.preconditions,
        deformation_ref: &candidate.deformation_ref,
        deformation_descriptor_sha256: &candidate.deformation_descriptor_sha256,
        preservation_obligations: &candidate.preservation_obligations,
        witness_procedure: &candidate.witness_procedure,
        equivalence_contract: &candidate.equivalence_contract,
        requires_lift: candidate.requires_lift,
        possible_terminals: &candidate.possible_terminals,
        authority_effect: &candidate.authority_effect,
    })
}

#[derive(Serialize)]
struct OperatorEvidenceCommitment<'a> {
    hash_domain: &'static str,
    pattern_sha256: &'a str,
    source_operator_sha256: &'a str,
    source_registry_sha256: &'a str,
    source_proposal_sha256: &'a str,
    source_assessment_sha256: &'a str,
    source_candidate_sha256: &'a str,
    source_step_index: usize,
    source_packet_sha256: &'a str,
    source_carrier_sha256: &'a str,
    source_state_sha256: &'a str,
    result_state_sha256: &'a str,
    observed_signature_sha256: &'a str,
    before: ObstructionMeasure,
    after: ObstructionMeasure,
    post_inspection_sha256: &'a str,
    authority_effect: &'a AuthorityEffect,
}

fn operator_evidence_hash(candidate: &CompiledOperatorCandidate) -> Result<String, IteratorError> {
    sha256_json(&OperatorEvidenceCommitment {
        hash_domain: OPERATOR_EVIDENCE_HASH_DOMAIN,
        pattern_sha256: &candidate.pattern_sha256,
        source_operator_sha256: &candidate.source_operator_sha256,
        source_registry_sha256: &candidate.source_registry_sha256,
        source_proposal_sha256: &candidate.source_proposal_sha256,
        source_assessment_sha256: &candidate.source_assessment_sha256,
        source_candidate_sha256: &candidate.source_candidate_sha256,
        source_step_index: candidate.source_step_index,
        source_packet_sha256: &candidate.source_packet_sha256,
        source_carrier_sha256: &candidate.source_carrier_sha256,
        source_state_sha256: &candidate.source_state_sha256,
        result_state_sha256: &candidate.result_state_sha256,
        observed_signature_sha256: &candidate.observed_signature_sha256,
        before: candidate.before,
        after: candidate.after,
        post_inspection_sha256: &candidate.post_inspection_sha256,
        authority_effect: &candidate.authority_effect,
    })
}

fn compiled_candidate_fields_are_canonical(candidate: &CompiledOperatorCandidate) -> bool {
    let required = [
        candidate.source_operator_id.0.as_str(),
        candidate.source_proposal_id.as_str(),
        candidate.source_provenance.0.as_str(),
        candidate.signature_kind.as_str(),
        candidate.deformation_ref.as_str(),
        candidate.witness_procedure.as_str(),
    ];
    if candidate.requires_lift
        || required.iter().any(|value| value.trim().is_empty())
        || candidate.preservation_obligations.is_empty()
        || candidate.possible_terminals.is_empty()
        || !strictly_sorted(&candidate.source_operator_signature_kinds)
        || !strictly_sorted(&candidate.source_operator_carrier_kinds)
        || !strictly_sorted(&candidate.preconditions)
        || !strictly_sorted(&candidate.preservation_obligations)
        || !candidate
            .source_operator_signature_kinds
            .contains(&candidate.signature_kind)
        || !candidate
            .source_operator_carrier_kinds
            .contains(&candidate.carrier_kind)
        || candidate
            .possible_terminals
            .windows(2)
            .any(|window| window[0] as u8 >= window[1] as u8)
        || candidate
            .equivalence_contract
            .as_ref()
            .is_some_and(|value| value.trim().is_empty())
    {
        return false;
    }

    let preservation_ids: Vec<_> = candidate
        .preservation_checks
        .iter()
        .map(|check| check.obligation_id.as_str())
        .collect();
    let obligation_ids: Vec<_> = candidate
        .preservation_obligations
        .iter()
        .map(String::as_str)
        .collect();
    if preservation_ids != obligation_ids
        || candidate.preservation_checks.iter().any(|check| {
            check.verdict != CheckVerdict::Pass
                || check.evidence_ref.trim().is_empty()
                || !is_sha256(&check.evidence_sha256)
        })
        || candidate.witness_results.is_empty()
        || candidate
            .witness_results
            .windows(2)
            .any(|window| window[0].witness_id >= window[1].witness_id)
        || candidate.witness_results.iter().any(|witness| {
            witness.witness_id.trim().is_empty()
                || witness.procedure.trim().is_empty()
                || witness.evidence_ref.trim().is_empty()
                || !is_sha256(&witness.evidence_sha256)
        })
        || !candidate.witness_results.iter().any(|witness| {
            witness.procedure == candidate.witness_procedure
                && witness.verdict == CheckVerdict::Pass
        })
    {
        return false;
    }
    true
}
#[derive(Serialize)]
struct CandidateInspectionTraceCommitment {
    proposal_id: String,
    state_sha256: String,
    post_inspection_sha256: String,
}

#[derive(Serialize)]
struct StepInspectionTraceCommitment {
    step_index: usize,
    state_sha256: String,
    carrier_sha256: String,
    inspection_sha256: String,
    candidate_post_inspections: Vec<CandidateInspectionTraceCommitment>,
}

#[derive(Serialize)]
struct InspectionTraceCommitment<'a> {
    hash_domain: &'static str,
    adapter_id: &'a str,
    packet_sha256: &'a str,
    steps: &'a [StepInspectionTraceCommitment],
}

fn inspection_trace_hash_for(receipt: &RunReceipt) -> Result<String, IteratorError> {
    let mut steps = Vec::with_capacity(receipt.steps.len());
    for step in &receipt.steps {
        let mut candidate_post_inspections = Vec::new();
        for candidate in &step.candidates {
            if let Some(post_inspection) = &candidate.post_inspection {
                candidate_post_inspections.push(CandidateInspectionTraceCommitment {
                    proposal_id: candidate.proposal_id.clone(),
                    state_sha256: candidate.state_sha256.clone(),
                    post_inspection_sha256: sha256_json(post_inspection)?,
                });
            }
        }
        steps.push(StepInspectionTraceCommitment {
            step_index: step.step_index,
            state_sha256: step.state_sha256.clone(),
            carrier_sha256: step.carrier_sha256.clone(),
            inspection_sha256: sha256_json(&step.inspection)?,
            candidate_post_inspections,
        });
    }
    sha256_json(&InspectionTraceCommitment {
        hash_domain: INSPECTION_TRACE_HASH_DOMAIN,
        adapter_id: &receipt.adapter_id,
        packet_sha256: &receipt.packet_sha256,
        steps: &steps,
    })
}

#[derive(Serialize)]
struct ReplayCommitment<'a> {
    schema_version: &'a str,
    adapter_id: &'a str,
    packet: &'a ProblemPacket,
    packet_sha256: &'a str,
    operator_registry: &'a OperatorRegistry,
    operator_registry_sha256: &'a str,
    initial_carrier: &'a FiniteCarrier,
    final_carrier: &'a FiniteCarrier,
    initial_state_sha256: &'a str,
    final_state_sha256: &'a str,
    budget: RunBudget,
    accounting: &'a CandidateAccounting,
    steps: &'a [StepReceipt],
    terminal: &'a TerminalReceipt,
    authority_effect: &'a AuthorityEffect,
}

fn replay_hash_for(receipt: &RunReceipt) -> Result<String, IteratorError> {
    sha256_json(&ReplayCommitment {
        schema_version: &receipt.schema_version,
        adapter_id: &receipt.adapter_id,
        packet: &receipt.packet,
        packet_sha256: &receipt.packet_sha256,
        operator_registry: &receipt.operator_registry,
        operator_registry_sha256: &receipt.operator_registry_sha256,
        initial_carrier: &receipt.initial_carrier,
        final_carrier: &receipt.final_carrier,
        initial_state_sha256: &receipt.initial_state_sha256,
        final_state_sha256: &receipt.final_state_sha256,
        budget: receipt.budget,
        accounting: &receipt.accounting,
        steps: &receipt.steps,
        terminal: &receipt.terminal,
        authority_effect: &receipt.authority_effect,
    })
}

fn sha256_json<T: Serialize + ?Sized>(value: &T) -> Result<String, IteratorError> {
    serde_json::to_vec(value)
        .map(|bytes| sha256_bytes(&bytes))
        .map_err(|error| IteratorError::Serialization(error.to_string()))
}

fn nonempty(value: &str, label: &str) -> Result<(), IteratorError> {
    if value.trim().is_empty() {
        Err(IteratorError::InvalidDeclaration(format!(
            "{label} must be non-empty"
        )))
    } else {
        Ok(())
    }
}

fn is_sha256(value: &str) -> bool {
    value.len() == 64
        && value
            .bytes()
            .all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
}

fn strictly_sorted<T: Ord>(values: &[T]) -> bool {
    values.windows(2).all(|window| window[0] < window[1])
}

fn ensure_unique<T: PartialEq>(values: &[T], label: &str) -> Result<(), IteratorError> {
    if values.windows(2).any(|window| window[0] == window[1]) {
        Err(IteratorError::InvalidDeclaration(format!(
            "{label} must be unique"
        )))
    } else {
        Ok(())
    }
}
