//! STUB — `omega_engine` subsystem (DELETED from omega_core). Scaffolding for
//! AP-0 build wiring ONLY. Reproduces just the Lean 4 bridge surface referenced
//! by `boundary_check`. This is NOT a real Lean bridge: `verify_content` always
//! returns `Verified`, i.e. AP-0 does NOT wire Lean verification. Boundary-check
//! tests that require a Lean *failure* (`Failed`/`Timeout`) fail honestly.

pub mod oe_adapters {
    pub mod lean4_bridge {
        /// STUB Lean 4 bridge (real adapter removed).
        #[derive(Debug, Clone, Default)]
        pub struct Lean4Bridge;

        impl Lean4Bridge {
            pub fn new() -> Self {
                Lean4Bridge
            }

            /// STUB: no Lean is invoked; everything is reported `Verified`.
            pub fn verify_content(&self, _content: &str) -> VerificationResult {
                VerificationResult::Verified(String::new())
            }

            /// STUB sandbox root for proof-path traversal checks. Returns an
            /// empty path, which is a prefix of every path — so the traversal
            /// guard never rejects (no sandbox configured). NOT a real root.
            pub fn proof_root_path(&self) -> std::path::PathBuf {
                std::path::PathBuf::new()
            }
        }

        #[derive(Debug, Clone)]
        pub enum VerificationResult {
            Verified(String),
            Failed(Vec<String>),
            Timeout,
            /// The Lean toolchain (`lake`) was not found — graceful degradation.
            LakeNotFound,
        }
    }
}
