//! Row validator — the strict reconciliation gate.
//!
//! [`validate_row`] enforces the two demands (authority and terminal descent) and the three
//! OmegaCore invariants (PrimitiveDifference, cochain `d1∘d0=0`, identity conservation), plus
//! the authority-ceiling laws and the two-axis honesty rule. It returns the list of findings;
//! an empty list means the row is clean. `ReconciliationRow::sample_good()` returns `vec![]`.
//
// TODO(phase2): wire governance into rows that touch authority/doctrine — governance is
// currently checked through `governance::check_governance_strict` via its own entry point,
// not through a row field.
use crate::cochain_validity::TriState;
use crate::row::{
    AuthorityBasis, ClaimDelta, ContractEffect, EvidenceCeiling, ReconciliationRow, TerminalStatus,
    VerifyResult,
};

/// Validate a reconciliation row against the strict regime. Empty == clean.
// Host gate. Observers (observers::run_all) are advisory proposals; this is the deterministic acceptance gate.
pub fn validate_row(row: &ReconciliationRow) -> Vec<String> {
    let mut findings = Vec::new();

    // Invariant I — PrimitiveDifference: a non-factoring observable MUST name a residual
    // class. A real obstruction with no residual class is an unaccounted leak.
    if !row.primitive_difference.factors_through_quotient
        && row.primitive_difference.residual_class.is_empty()
    {
        findings.push(
            "invariant-I: primitive difference does not factor through the quotient yet \
             declares no residual_class"
                .to_string(),
        );
    }

    // Invariant II — cochain validity: compute d₁∘d₀ over the row's carried F2 matrices rather
    // than trusting the declared `d1_d0_zero` flag (provisional carrier model, doctrine v000).
    let computed = row.cochain_validity.computed_d1_d0_zero();
    // (a) a verifiably-nonzero d1∘d0 is only admissible if terminalized as malformed.
    if computed == TriState::False
        && !matches!(
            row.terminal_status.status,
            TerminalStatus::RepresentationMalformed | TerminalStatus::CochainInvalid
        )
    {
        findings.push(
            "invariant-II: computed d1∘d0 != 0 but terminal status is not \
             RepresentationMalformed/CochainInvalid"
                .to_string(),
        );
    }
    // (b) closes the declared-trust gap: a row may not declare a d1_d0_zero that disagrees with its matrices.
    if row.cochain_validity.d1_d0_zero != computed {
        findings.push(
            "invariant-II: declared d1_d0_zero disagrees with computed d1∘d0 over the carried matrices"
                .to_string(),
        );
    }

    // Invariant III — identity conservation: classification may not erase identity.
    if row.identity_witness.identity_loss_risk || !row.identity_witness.conserved_across_edges {
        findings.push(
            "invariant-III: identity is at risk or not conserved across edges \
             (impersonation, not compression)"
                .to_string(),
        );
    }

    // Demand: authority (counterfeit guard). An Accurate/Undersold claim that asserts authority
    // basis must rest on a real basis — not a list whose every basis is None.
    if matches!(
        row.claim_delta,
        ClaimDelta::Accurate | ClaimDelta::Undersold
    ) && !row.authority_basis.is_empty()
        && row
            .authority_basis
            .iter()
            .all(|b| b.basis == AuthorityBasis::None)
    {
        findings.push(
            "demand-authority: counterfeit authority — every declared basis is None".to_string(),
        );
    }

    // Authority-ceiling drift: a declared effect may never exceed the role-pinned ceiling.
    // The canonical ContractEffect omits Ord, so compare via the loop-local strength rank.
    if crate::row::authority_rank(row.declared_authority_effect)
        > crate::row::authority_rank(row.role_pinned_ceiling)
    {
        findings.push(
            "ceiling drift: declared_authority_effect exceeds the role-pinned ceiling".to_string(),
        );
    }

    // Law 2 (authority bounded by evidence): a fact-or-stronger effect cannot rest on
    // shape-only evidence. "FactOnly or stronger" == not in the evidence layer's lower two
    // (None / EvidenceOnly).
    if !matches!(
        row.declared_authority_effect,
        ContractEffect::None | ContractEffect::EvidenceOnly
    ) && row.evidence_ceiling == EvidenceCeiling::ShapeOnly
    {
        findings.push(
            "Law 2: declared authority is FactOnly-or-stronger but evidence ceiling is ShapeOnly"
                .to_string(),
        );
    }

    // Demand: terminal descent. A terminal status must carry a reason; an open/unknown/no-rule
    // status must route work; and any oversold/missing claim must route remediation work.
    if row.terminal_status.reason.is_empty() {
        findings.push("demand-terminal-descent: terminal_status.reason is empty".to_string());
    }
    if matches!(
        row.terminal_status.status,
        TerminalStatus::OpenObstruction | TerminalStatus::BudgetUnknown | TerminalStatus::NoRule
    ) && row.routed_work.is_empty()
    {
        findings.push(
            "demand-terminal-descent: open/unknown/no-rule terminal status with empty routed_work"
                .to_string(),
        );
    }
    if matches!(row.claim_delta, ClaimDelta::Oversold | ClaimDelta::Missing)
        && row.routed_work.is_empty()
    {
        findings.push(
            "demand-terminal-descent: oversold/missing claim with empty routed_work".to_string(),
        );
    }

    // O1: a Refuted verdict means the defect was refuted, so the row must collapse to Accurate; a Refuted verdict on a non-Accurate delta is the obstruction we surface.
    if row.verify_verdict.result == VerifyResult::Refuted && row.claim_delta != ClaimDelta::Accurate
    {
        findings.push("O1: verification refuted while claim_delta is not Accurate".to_string());
    }

    // Two-axis honesty: prose mechanization is not Lean mechanization. A "machine-checked"
    // claim backed by MECHANIZED prose without a MECHANIZED Lean status is dishonest.
    let claimed_lower = row.claimed.to_lowercase();
    let claims_machine_checked = [
        "machine-checked",
        "machine checked",
        "lean-verified",
        "lean verified",
    ]
    .iter()
    .any(|t| claimed_lower.contains(t));
    if row.proof_status.status == "MECHANIZED"
        && row.proof_status.lean_status != "MECHANIZED"
        && claims_machine_checked
    {
        findings
            .push("two-axis: claims machine-checked but lean_status is not MECHANIZED".to_string());
    }

    findings
}
