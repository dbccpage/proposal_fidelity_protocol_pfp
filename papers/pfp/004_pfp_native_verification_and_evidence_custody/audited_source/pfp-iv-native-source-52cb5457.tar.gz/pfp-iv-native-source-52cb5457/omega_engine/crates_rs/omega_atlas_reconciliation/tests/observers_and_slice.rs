//! Seven deterministic observers + the strict A->B->C->D reconciliation slice.
use omega_atlas_reconciliation::observers;
use omega_atlas_reconciliation::row::*;
use omega_atlas_reconciliation::slice::*;

#[test]
fn public_risk_flags_forbidden_copy() {
    let mut r = ReconciliationRow::sample_good();
    r.surface = Surface::Public; // sample_good() is Private; the firewall only fires on Public
    r.claimed = "this certificate proves truth".into();
    let rd = observers::public_risk::check(&r);
    assert!(!rd.findings.is_empty());
}

#[test]
fn public_risk_silent_on_research_surface() {
    let mut r = ReconciliationRow::sample_good(); // Private
    r.surface = Surface::Research;
    r.claimed = "machine-checked certificate".into();
    assert!(observers::public_risk::check(&r).findings.is_empty());
}

#[test]
fn public_risk_no_false_positive_on_approves_improves() {
    let mut r = ReconciliationRow::sample_good();
    r.surface = Surface::Public;
    r.claimed = "the board approves and improves the rollout".into();
    assert!(observers::public_risk::check(&r).findings.is_empty());
}
#[test]
fn public_risk_still_matches_hyphenated_and_multiword() {
    let mut r = ReconciliationRow::sample_good();
    r.surface = Surface::Public;
    r.claimed = "this is machine-checked and certifies truth".into();
    let f = observers::public_risk::check(&r).findings;
    assert!(f.iter().any(|x| x.contains("machine-checked")));
    assert!(f.iter().any(|x| x.contains("certifies truth")));
}

#[test]
fn product_claim_undersold_is_ngd() {
    let r = ReconciliationRow::sample_good(); // Undersold
    assert!(observers::product_claim::check(&r)
        .findings
        .iter()
        .any(|x| x.contains("local-green/global-red")));
}

#[test]
fn product_claim_missing_is_claim_without_code() {
    let mut r = ReconciliationRow::sample_good();
    r.claim_delta = ClaimDelta::Missing;
    assert!(observers::product_claim::check(&r)
        .findings
        .iter()
        .any(|x| x.contains("CLAIM-WITHOUT-CODE")));
}

#[test]
fn sample_good_matches_canonical_role_pin() {
    let r = ReconciliationRow::sample_good();
    assert!(observers::contract_authority::check(&r).findings.is_empty());
}

#[test]
fn math_object_accepts_either_admitted_ceiling() {
    let mut none_ceiling = ReconciliationRow::sample_good();
    none_ceiling.role_pinned_ceiling = ContractEffect::None;
    none_ceiling.declared_authority_effect = ContractEffect::None;
    assert!(observers::contract_authority::check(&none_ceiling)
        .findings
        .is_empty());

    let mut outside = ReconciliationRow::sample_good();
    outside.role = ComponentRole::MathObject;
    outside.role_pinned_ceiling = ContractEffect::FactOnly;
    assert!(observers::contract_authority::check(&outside)
        .findings
        .iter()
        .any(|finding| finding.contains("not admitted")));
}

#[test]
fn run_all_returns_seven() {
    assert_eq!(
        observers::run_all(&ReconciliationRow::sample_good()).len(),
        7
    );
}

#[test]
fn slice_is_government_before_product() {
    let s = strict_slice();
    let last_gov = s
        .iter()
        .rposition(|a| a.tier == SliceTier::GovernmentCore)
        .unwrap();
    let first_prod = s
        .iter()
        .position(|a| a.tier == SliceTier::ProductSpine)
        .unwrap();
    assert!(
        last_gov < first_prod,
        "government must be reconciled before product"
    );
    // authority core first
    assert_eq!(s[0].tier, SliceTier::AuthorityCore);
}
