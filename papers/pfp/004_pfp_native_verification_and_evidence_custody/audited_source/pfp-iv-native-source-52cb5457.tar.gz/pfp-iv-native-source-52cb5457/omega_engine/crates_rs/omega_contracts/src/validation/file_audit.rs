use super::artifact::ValidationArtifact;
use super::violation::ValidationViolation;
use crate::kinds::{ContractEffect, SchemaHash};
use crate::witness::evidence::ValidationWitness;

pub struct FileAuditSubject {
    pub contract_id: &'static str,
    pub path: &'static str,
    pub declared_kind: &'static str,
    pub schema_hash: SchemaHash,
    pub authority_effect: ContractEffect,
    pub parts: &'static [FilePart],
}

pub struct FilePart {
    pub name: &'static str,
    pub required: bool,
    pub kind: &'static str,
}

pub trait FileValidator {
    type Witness: ValidationWitness;
    type Violation: ValidationViolation;

    const FILE_KIND: &'static str;

    fn validate_file(
        subject: &FileAuditSubject,
    ) -> ValidationArtifact<Self::Witness, Self::Violation>;
}
