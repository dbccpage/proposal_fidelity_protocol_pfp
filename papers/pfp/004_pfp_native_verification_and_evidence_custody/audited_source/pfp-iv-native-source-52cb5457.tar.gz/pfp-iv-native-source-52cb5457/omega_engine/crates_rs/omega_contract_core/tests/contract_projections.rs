//! Executable projection-boundary witnesses, not operational-contract proofs.
//! AuthorityEffect: None.

use omega_contract_core::registry::projections::{
    parse_manifest, verify_projected_corpus, CORPUS, MANIFEST,
};
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};

const SOURCE: &str =
    "omega_engine_governance/contracts/contract_governance/projection.contract.yaml";
const TARGET: &str = "omega_engine/crates_rs/omega_contracts/src/contract_canonical_definitions/core/projection.contract.yaml";
const PENDING: &str =
    "omega_engine/crates_rs/omega_contracts/src/contract_canonical_definitions/reference.yaml";
const RAW: &[u8] = b"schema_version: omega.contract.v1\ncontract_id: urn:test:projection:v1\n";
static NEXT: AtomicU64 = AtomicU64::new(0);

fn sha(raw: &[u8]) -> String {
    format!("{:x}", Sha256::digest(raw))
}

struct Fixture {
    root: PathBuf,
    manifest: Value,
}

impl Fixture {
    fn new() -> Self {
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos();
        let root = std::env::temp_dir().join(format!(
            "omega-projection-{}-{nonce}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        std::fs::create_dir(&root).unwrap();
        let fixture = Self {
            root,
            manifest: json!({
                "schema": "omega.contract-projections.v1", "authority_effect": "None",
                "entries": [{ "contract_id": "urn:test:projection:v1", "schema_version": "omega.contract.v1",
                    "source": SOURCE, "projection": TARGET, "source_sha256": sha(RAW),
                    "review": { "baseline_commit": "1".repeat(40), "previous_projection_sha256": sha(RAW), "decision": "IDENTICAL_DEFINITION" }}],
                "unreconciled": [{ "projection": PENDING, "sha256": sha(b"unreviewed: true\n"), "disposition": "RECONCILIATION_REQUIRED" }]
            }),
        };
        fixture.put(SOURCE, RAW);
        fixture.put(TARGET, RAW);
        fixture.put(PENDING, b"unreviewed: true\n");
        fixture.save();
        fixture
    }
    fn put(&self, path: &str, raw: &[u8]) {
        let path = self.root.join(path);
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(path, raw).unwrap();
    }
    fn save(&self) {
        self.put(MANIFEST, &serde_json::to_vec(&self.manifest).unwrap());
    }
    fn code(&self) -> &'static str {
        verify_projected_corpus(&self.root).unwrap_err().code
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        std::fs::remove_dir_all(&self.root).expect("remove only newly created test fixture");
    }
}

#[test]
fn byte_integrity_does_not_grandfather_unreconciled_inputs() {
    let fixture = Fixture::new();
    let report = verify_projected_corpus(&fixture.root).unwrap();
    assert_eq!(report.reviewed_projections, 1);
    assert_eq!(report.unreconciled, vec![PENDING]);
    assert_eq!(
        report.require_complete().unwrap_err().code,
        "PROJECTION_RECONCILIATION_INCOMPLETE"
    );
    for path in [MANIFEST, SOURCE, TARGET, PENDING] {
        assert!(
            report
                .watched_paths
                .contains(&fixture.root.canonicalize().unwrap().join(path)),
            "build must watch {path}"
        );
    }
}

#[test]
fn fully_reconciled_fixture_can_complete_without_a_magic_count() {
    let mut fixture = Fixture::new();
    fixture.manifest["unreconciled"] = json!([]);
    std::fs::remove_file(fixture.root.join(PENDING)).unwrap();
    fixture.save();
    verify_projected_corpus(&fixture.root)
        .unwrap()
        .require_complete()
        .unwrap();
}

#[test]
fn stale_projection_is_refused_by_the_build_verifier() {
    let fixture = Fixture::new();
    fixture.put(TARGET, &[RAW, b"# stale\n"].concat());
    let failure = verify_projected_corpus(&fixture.root).unwrap_err();
    assert_eq!(failure.code, "PROJECTION_VERIFIER_REFUSED");
    assert_eq!(failure.detail, "CONTRACT_PROJECTION_STALE");
}

#[test]
fn source_pin_refuses_coordinated_source_projection_edits() {
    let fixture = Fixture::new();
    let altered = [RAW, b"# coordinated byte change\n"].concat();
    fixture.put(SOURCE, &altered);
    fixture.put(TARGET, &altered);
    assert_eq!(fixture.code(), "PROJECTION_SOURCE_DIGEST_MISMATCH");
}

#[test]
fn unaccounted_yaml_cannot_silently_escape_the_manifest() {
    let fixture = Fixture::new();
    fixture.put(&format!("{CORPUS}extra.yaml"), b"unaccounted: true\n");
    assert_eq!(fixture.code(), "PROJECTION_POPULATION_MISMATCH");
}

#[test]
fn removed_mapping_missing_input_and_unreviewed_drift_are_named_refusals() {
    let mut fixture = Fixture::new();
    fixture.manifest["unreconciled"] = json!([]);
    fixture.save();
    assert_eq!(fixture.code(), "PROJECTION_POPULATION_MISMATCH");
    let fixture = Fixture::new();
    std::fs::remove_file(fixture.root.join(PENDING)).unwrap();
    assert_eq!(fixture.code(), "PROJECTION_POPULATION_MISMATCH");
    let fixture = Fixture::new();
    fixture.put(PENDING, b"drift: true\n");
    assert_eq!(fixture.code(), "PROJECTION_UNRECONCILED_INPUT_CHANGED");
}

#[test]
fn contract_and_schema_identities_are_bound_independently_of_bytes() {
    let mut fixture = Fixture::new();
    fixture.manifest["entries"][0]["contract_id"] = json!("urn:test:wrong:v1");
    fixture.save();
    let failure = verify_projected_corpus(&fixture.root).unwrap_err();
    assert_eq!(failure.detail, "CONTRACT_PROJECTION_IDENTITY_MISMATCH");
    let mut fixture = Fixture::new();
    fixture.manifest["entries"][0]["schema_version"] = json!("omega.file_contract.v1");
    fixture.save();
    assert_eq!(fixture.code(), "PROJECTION_SOURCE_IDENTITY_MISMATCH");
}

#[test]
fn manifest_parser_refuses_non_json_duplicate_fields_unknown_fields_and_empty_scope() {
    let fixture = Fixture::new();
    for raw in [
        b"schema: omega.contract-projections.v1".as_slice(),
        b"{\"schema\":\"one\",\"schema\":\"two\"}",
        b"\xff",
        b"\xef\xbb\xbf{}",
        b"{}",
    ] {
        assert!(parse_manifest(raw).is_err(), "must refuse {raw:?}");
    }
    let mut unknown = fixture.manifest.clone();
    unknown["pass"] = json!(true);
    assert_eq!(
        parse_manifest(&serde_json::to_vec(&unknown).unwrap())
            .unwrap_err()
            .code,
        "PROJECTION_MANIFEST_INVALID"
    );
    let mut empty = fixture.manifest.clone();
    empty["entries"] = json!([]);
    assert_eq!(
        parse_manifest(&serde_json::to_vec(&empty).unwrap())
            .unwrap_err()
            .code,
        "PROJECTION_POPULATION_INVALID"
    );
}

#[test]
fn portable_paths_refuse_traversal_and_windows_aliases() {
    let fixture = Fixture::new();
    for path in [
        "../outside.yaml".to_owned(),
        format!("{CORPUS}../outside.yaml"),
        format!("{CORPUS}a\\b.contract.yaml"),
        format!("{CORPUS}a//b.contract.yaml"),
        format!("{CORPUS}a./b.contract.yaml"),
        format!("{CORPUS}x:y.contract.yaml"),
        format!("{CORPUS}CON.contract.yaml"),
        "C:/outside.yaml".into(),
    ] {
        let mut bad = fixture.manifest.clone();
        bad["entries"][0]["projection"] = json!(path);
        assert_eq!(
            parse_manifest(&serde_json::to_vec(&bad).unwrap())
                .unwrap_err()
                .code,
            "PROJECTION_PATH_INVALID"
        );
    }
}

#[test]
fn duplicates_case_aliases_and_bad_review_pins_are_refused() {
    let fixture = Fixture::new();
    for kind in ["source", "target", "identity", "case"] {
        let mut bad = fixture.manifest.clone();
        let mut row = bad["entries"][0].clone();
        row["source"] = json!(SOURCE.replace("projection", "second"));
        row["projection"] = json!(TARGET.replace("projection", "second"));
        row["contract_id"] = json!("urn:test:second:v1");
        match kind {
            "source" => row["source"] = json!(SOURCE),
            "target" => row["projection"] = json!(TARGET),
            "identity" => row["contract_id"] = json!("urn:test:projection:v1"),
            _ => row["projection"] = json!(TARGET.replace("projection", "PROJECTION")),
        }
        bad["entries"].as_array_mut().unwrap().push(row);
        assert_eq!(
            parse_manifest(&serde_json::to_vec(&bad).unwrap())
                .unwrap_err()
                .code,
            "PROJECTION_DUPLICATE_ENTRY"
        );
    }
    for (field, value, code) in [
        ("source_sha256", "0", "PROJECTION_DIGEST_INVALID"),
        (
            "schema_version",
            "omega.contract.v99",
            "PROJECTION_CONTRACT_IDENTITY",
        ),
    ] {
        let mut bad = fixture.manifest.clone();
        bad["entries"][0][field] = json!(value);
        assert_eq!(
            parse_manifest(&serde_json::to_vec(&bad).unwrap())
                .unwrap_err()
                .code,
            code
        );
    }
    let mut bad = fixture.manifest.clone();
    bad["entries"][0]["review"]["baseline_commit"] = json!("HEAD");
    assert_eq!(
        parse_manifest(&serde_json::to_vec(&bad).unwrap())
            .unwrap_err()
            .code,
        "PROJECTION_REVIEW_BASELINE_INVALID"
    );
    bad = fixture.manifest.clone();
    bad["unreconciled"][0]["disposition"] = json!("GRANDFATHERED_PASS");
    assert_eq!(
        parse_manifest(&serde_json::to_vec(&bad).unwrap())
            .unwrap_err()
            .code,
        "PROJECTION_DISPOSITION_INVALID"
    );
}

#[test]
fn current_repository_registry_is_read_by_the_native_gate() {
    let repository = Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(3)
        .unwrap();
    let report = verify_projected_corpus(repository).unwrap();
    assert!(report.reviewed_projections > 0);
    let manifest: Value =
        serde_json::from_slice(&std::fs::read(repository.join(MANIFEST)).unwrap()).unwrap();
    assert_eq!(
        report.reviewed_projections,
        manifest["entries"].as_array().unwrap().len()
    );
    assert_eq!(
        report.unreconciled.len(),
        manifest["unreconciled"].as_array().unwrap().len()
    );
}

#[test]
fn reviewed_noncanonical_debate_decision_has_a_closed_vocabulary() {
    let mut fixture = Fixture::new();
    fixture.manifest["entries"][0]["review"]["decision"] =
        json!("GOVERNANCE_OMITS_NONCANONICAL_DEBATE");
    fixture.save();
    assert!(verify_projected_corpus(&fixture.root).is_ok());
    fixture.manifest["entries"][0]["review"]["decision"] = json!("GOVERNANCE_DROPS_LAWS");
    fixture.save();
    assert_eq!(
        verify_projected_corpus(&fixture.root).unwrap_err().code,
        "PROJECTION_REVIEW_DECISION_INVALID"
    );
}

#[test]
fn dependency_extension_review_has_a_named_closed_decision_not_a_law_waiver() {
    // This build parser admits the vocabulary, not the Git structural review.
    // Python review-check separately replays old law and the added dependencies.
    let mut fixture = Fixture::new();
    fixture.manifest["entries"][0]["review"]["decision"] = json!("GOVERNANCE_ADDS_DEPENDENCIES");
    fixture.save();
    assert!(verify_projected_corpus(&fixture.root).is_ok());
    for waiver in [
        "GOVERNANCE_CHANGES_LAWS",
        "GOVERNANCE_DROPS_DEPENDENCIES",
        "",
    ] {
        fixture.manifest["entries"][0]["review"]["decision"] = json!(waiver);
        fixture.save();
        assert_eq!(fixture.code(), "PROJECTION_REVIEW_DECISION_INVALID");
    }
}
