# Algorithm Prime 001 + 002 — `basic_matrix` triple face

**Date:** 2026-08-01  
**AuthorityEffect:** None  
**Prior:** Prime **000** full triple declaration — `prime000_basic_matrix_triple_face_20260801.md`  
**Honest status of prior session:** Prime **001** was only a **sketch**; Prime **002** was only a “recommended next” blurb.  
**This document:** full Prime **001** (three adapters) + full Prime **002** (continue / stop).

**Law:** every face is a **proposal**. Goal \(\phi = 0 + \varepsilon\). No GlobalGreen / host auth from this run.

| Face | Path |
| --- | --- |
| YAML | `math/basic_matrix.contract.yaml` |
| Rust | `omega_linear_algebra/.../basic_matrix.rs` |
| Lean | `lean4/.../BasicMatrix.lean` |

---

## Honesty checklist (what was done before)

| Prime | Before this receipt | Now |
| --- | --- | --- |
| **000** | Full 12-slot on YAML, RS, Lean | unchanged (inputs) |
| **001** | One-paragraph adapter sketch | **full 12-step × 3 adapters** |
| **002** | Soft “recommended next” | **CanContinue_n gates + stop reasons** |

---

# PART I — Prime 001 (adapter descent soundness)

Prime 001 prevents **template laundering**: a native face must not be smuggled into Omega meaning without an explicit adapter and loss ledger.

**Claim class \(\mathcal C\):** finite rectangular **storage** matrix laws (shape, length, access, add/sub shape, matmul shape, storage-only fence, no authority).  
**Protected distinctions \(P\):**

1. Zero-dim allowed (\(m,n \in \mathbb{N}_0\))  
2. Length law \(len = m\cdot n\)  
3. OOB refuse (no wrap)  
4. Op shape refuse (add/matmul)  
5. Storage ≠ linear-map `matrix` object  
6. No AuthorityEffect / GlobalGreen / PROVED from this object alone  
7. Scalar theory: field-grade vs Numeric/semiring vs abstract \(\alpha\) (**loss-bearing**)

---

## Adapter A1 — YAML (native) → Omega packet / RS semantics

### 12-step declaration

| Step | Name | Status | Fill |
| ---: | --- | --- | --- |
| 1 | Native carrier \(X\) | DECLARED | YAML presentation: `urn:omega:math:basic_matrix:v1.0.0` laws + negative_tests |
| 2 | Claim class \(\mathcal C\) | DECLARED | Storage shape laws + fences above |
| 3 | Protected \(P\) | DECLARED | \(P_1\)–\(P_7\) |
| 4 | Adapter \(A\) | DECLARED | `rust_binding` → `BasicMatrix` / `MatrixError` construction & ops |
| 5 | Comparison \(\bar A\) | DECLARED | Meaning map: YAML law text → RS type+error vocabulary |
| 6 | Adapter square | CHECKED | On shape/length/OOB/op-shape: \(\llbracket A(x)\rrbracket_{RS}\) matches \(\bar A(\llbracket x\rrbracket_{YAML})\) after B1 zero-dim |
| 7 | Detector adequacy | ADEQUATE for shape | `MatrixError` detects \(P_1\)–\(P_5\); **inadequate alone** for \(P_7\) field-grade |
| 8 | Loss ledger \(R_A\) | OPEN | \(R_{A1} =\) field-language in YAML vs `Numeric`/wrapping integers in RS |
| 9 | Prime 000 inside adapted | RUN | RS face 000 terminal reused |
| 10 | Descend | OK | Refusals descend as errors; success is storage value |
| 11 | Compare native vs Omega | PARTIAL | Shape: equal truth-values. Scalar theory: **not** equal |
| 12 | **Terminal** | **`AdapterLossy`** | Sound on shape package; lossy on scalar theory |

### A1 loss ledger (priced \(\varepsilon\))

| Loss ID | Protected distinction | Invertible? | Price |
| --- | --- | --- | --- |
| L1-SCALAR | \(P_7\) field vs Numeric | No | Must not claim theorem-grade field storage from RS alone |
| L1-HASH | content-addressed law hashes | No (missing on RS) | Witness ceiling ShapeOnly |
| L1-LAYOUT | nalgebra bridge (if used) | No (row↔col major copy) | Separate adapter when used |

**A1 verdict:** `AdapterLossy` — **not** `AdapterInadequate` (shape detectors work); **not** `AdapterSound` (scalar residual unpriced if ignored).

---

## Adapter A2 — YAML (native) → Lean packet

### 12-step declaration

| Step | Name | Status | Fill |
| ---: | --- | --- | --- |
| 1 | Native \(X\) | DECLARED | same YAML |
| 2 | \(\mathcal C\) | DECLARED | same |
| 3 | \(P\) | DECLARED | same |
| 4 | Adapter \(A\) | DECLARED | YAML laws → `BasicMatrix`/`lengthLaw`/`inBounds`/… Props + lemmas |
| 5 | \(\bar A\) | DECLARED | Law text → Prop; zero-dim → `empty_product_length_zero` family |
| 6 | Adapter square | PARTIAL | Shape fragment holds; **matmul algebra / field ops not in Lean** → square incomplete for full \(\mathcal C\) |
| 7 | Detector adequacy | PARTIAL | Props detect shape failures when used; no full runtime refuse suite |
| 8 | Loss ledger | OPEN | \(R_{A2} =\) LEAN_PARTIAL_COVER (ops suite, field, runtime refuse) |
| 9 | Prime 000 inside | RUN | Lean face 000 |
| 10 | Descend | OK | Prop true/false back as proof state |
| 11 | Compare | PARTIAL | Zero-dim + length law agree; full op suite not equal coverage |
| 12 | **Terminal** | **`AdapterLossy`** | Shape kernel sound as Prop; full YAML suite not descended |

### A2 loss ledger

| Loss ID | Distinction | Invertible? | Price |
| --- | --- | --- | --- |
| L2-OPS | add/mul correctness proofs | No yet | Do not claim Lean discharges YAML op suite |
| L2-SCALAR | abstract \(\alpha\) vs field prose | No | OpenScalarFieldResidual |
| L2-RUNTIME | Prop ≠ Result path | No | Lean is not the refuse engine |

**A2 verdict:** `AdapterLossy`.

---

## Adapter A3 — Rust (native) → Lean packet

### 12-step declaration

| Step | Name | Status | Fill |
| ---: | --- | --- | --- |
| 1 | Native \(X\) | DECLARED | `BasicMatrix<T>` + `MatrixError` |
| 2 | \(\mathcal C\) | DECLARED | operational shape enforcement + Numeric ops |
| 3 | \(P\) | DECLARED | same \(P\); add \(P_8\): `Result` refuse path |
| 4 | Adapter \(A\) | DECLARED | RS ops → Lean Props (semantic, not FFI codegen) |
| 5 | \(\bar A\) | DECLARED | Error variants → failed Props; success → WF |
| 6 | Adapter square | PARTIAL | Shape/OOB/shape-mismatch align; Numeric overflow **no** Lean image |
| 7 | Detector adequacy | PARTIAL | Lean does not re-detect all RS error constructors |
| 8 | Loss ledger | OPEN | \(R_{A3} =\) runtime+overflow+nalgebra not in Lean |
| 9 | Prime 000 | RUN | Lean 000 |
| 10 | Descend | PARTIAL | only shape Props |
| 11 | Compare | PARTIAL | local green shape; not full RS surface |
| 12 | **Terminal** | **`AdapterLossy`** | honest partial mechanization |

### A3 loss ledger

| Loss ID | Distinction | Invertible? | Price |
| --- | --- | --- | --- |
| L3-OVERFLOW | Numeric wrap | No | CheckedNumeric path separate obligation |
| L3-NALGEBRA | layout bridge | No | not in Lean |
| L3-PARTIAL | unproved ops | No | LEAN_PARTIAL_COVER |

**A3 verdict:** `AdapterLossy`.

---

## Prime 001 summary (all adapters)

| Adapter | Native → target | Terminal | Primary residual |
| --- | --- | --- | --- |
| **A1** | YAML → RS | **AdapterLossy** | scalar theory (field vs Numeric) |
| **A2** | YAML → Lean | **AdapterLossy** | op/proof cover |
| **A3** | RS → Lean | **AdapterLossy** | runtime + overflow + partial cover |

**None** are `AdapterSound` globally.  
**None** are `AdapterInadequate` for **shape-only** claim subclass \(\mathcal C_{\mathrm{shape}} \subset \mathcal C\).

**Refined claim split (anti-launder):**

| Sub-claim | A1 | A2 | A3 |
| --- | --- | --- | --- |
| \(\mathcal C_{\mathrm{shape}}\) | Sound | Sound (partial proofs) | Lossy→Sound on core shape |
| \(\mathcal C_{\mathrm{scalar}}\) | Lossy | Lossy | Lossy |
| \(\mathcal C_{\mathrm{full\_ops}}\) | near-sound operationally | Lossy | Lossy |

No-smuggling check: cochains **not** derived from storage \(\delta\) — correctly N/A on all faces (HANDOFF-002 respected).

---

# PART II — Prime 002 (continue until unauthorized)

Control law:

```text
Run 000 → Check 001 → if CanContinue_n then repacketize → Run 000 again
else STOP with typed reason
```

**Anti-cheat:** no “add dimensions until defect vanishes”; no degree/object laundering (`BasicMatrix` ↛ linear-map theorems).

---

## Outstanding obligations after 000+001

| ID | Obligation | Degree / kind |
| --- | --- | --- |
| O1 | Price or close \(\varepsilon_{\mathrm{scalar}}\) (YAML field prose vs RS Numeric vs Lean \(\alpha\)) | **first unresolved** |
| O2 | Lean cover for add/mul shape **and** algebraic correctness (optional later) | higher than O1 only after O1 priced |
| O3 | Content-addressed witnesses / stronger tests | evidence, not shape |
| O4 | nalgebra adapter explicit Prime-001 packet if used as meaning | separate carrier |

---

## CanContinue_n checklist (n = 0 → 1)

| Gate | Required | Result | Notes |
| --- | --- | --- | --- |
| Outstanding obligation | yes | **PASS** | O1–O4 exist |
| Higher-obligation witness | yes for lift | **FAIL for full \(\mathcal C\)** | no licensed witness that scalar residual is repaired |
| Next carrier declared | yes | **CONDITIONAL** | next carrier **must** be `scalar_theory_storage` or `CheckedNumeric_path` packet — **not** `matrix` linear-map |
| Adapter sound | yes | **FAIL global** | all A1–A3 are **Lossy** |
| Detector adequate | yes | **PASS shape / FAIL scalar** | |
| Minimal licensed lift | yes | **FAIL** | no host license to treat Lossy as Sound |
| Skeleton preserved or loss ledger | yes | **PASS** | loss ledgers L1–L3 recorded |
| Budget | yes | **PASS** | budget remains for one priced repacket |
| ¬GTLA refusal | yes | **PASS** | no GTLA_STOP claimed |

### Decision for **full claim class \(\mathcal C\)** (shape+field+ops-as-math)

\[
\texttt{CanContinue}_0(\mathcal C_{\mathrm{full}}) = \mathbf{false}
\]

**Stop reason (primary):** `ADAPTER_FAILURE` (lossy scalar adapter without licensed repair)  
**Stop reason (secondary):** `UNAUTHORIZED_CONTINUATION` if anyone continues by claiming field theorems or linear-map theorems on this object  
**Stop reason (anti-cheat):** would be degree laundering if we “fix” residual by switching object to Hard Lefschetz / full Mat_K without new packet

### Decision for **shape-only subclass \(\mathcal C_{\mathrm{shape}}\)**

\[
\texttt{CanContinue}_0(\mathcal C_{\mathrm{shape}}) = \mathbf{false}\ \text{for further shape repair}
\]

because \(\phi_{\mathrm{shape}} \approx 0\) already (000 terminals Closed/Exact on shape).  
**Stop reason:** `STUCK_CORPUS` / obligation exhausted on shape — **not** a failure; **valid terminal**.

### Decision for **repacketize on scalar residual only**

If and only if next packet is **explicitly** declared:

```text
K' = storage_scalar_theory_packet
  YAML: demote field language OR require CheckedNumeric/Ratio
  RS:   theorem-grade path uses CheckedNumeric
  Lean: optional α = Rat lemmas
```

Then **one** licensed repacket is allowed:

| Gate | Result for scalar-only repacket |
| --- | --- |
| Next carrier declared | **PASS** if \(K'\) as above |
| Adapter | re-run 001 on \(K'\) |
| Minimal lift | **PASS** if change is demotion/require-check, not object smash |
| Anti-launder | **PASS** if still storage-only |

**This run does not execute the repacket body** (no code/YAML edit in 002).  
**002 emits the authorization boundary only.**

---

## What Prime 002 produces (visible result)

```text
PRIME_000  [done]  three faces → structure + δ + (no C•) + Φ1_shape≈0 + ε_scalar OPEN
PRIME_001  [done]  A1,A2,A3 → AdapterLossy each; shape subclaim sound; scalar lossy
PRIME_002  [done]  CanContinue(full) = NO  → STOP ADAPTER_FAILURE / UNAUTHORIZED if ignore loss
                   CanContinue(shape) = NO  → STOP (shape obligation exhausted — local green)
                   CanContinue(scalar_repacket K') = YES only with explicit K' + re-001
```

### Terminal board

| Path | Terminal | Meaning |
| --- | --- | --- |
| Shape package | **Closed / Exact local green** | \(\phi_{\mathrm{shape}}=0+\varepsilon_{\mathrm{minor}}\) |
| Scalar package | **OpenResidual** | \(\varepsilon_{\mathrm{scalar}}\) priced, not deleted |
| Full package continue | **STOP** | `ADAPTER_FAILURE` |
| Launder to linear-map / field theorems | **STOP** | `UNAUTHORIZED_CONTINUATION` |
| Licensed scalar repacket | **MAY CONTINUE** | new carrier \(K'\), re-run 000→001 |

---

## Combined triad picture (all three primes)

```text
        YAML ──A1──► RS
         │ \         │
         │  \ A2     │ A3
         │   \       ▼
         │    └──► Lean

000: each vertex is a proposal packet (structure / primdiff / obstruction)
001: each edge is AdapterLossy (shape sound; scalar lossy)
002: do not continue full package; may repacketize scalar only under license
```

**\(\phi = 0 + \varepsilon\)** for this object:

- \(\phi_{\mathrm{shape}} \approx 0\) on YAML+RS; Lean partial  
- \(\varepsilon = \varepsilon_{\mathrm{scalar}} + \varepsilon_{\mathrm{lean\_cover}}\)  
- **No face mints auth**; all remain **proposals** for host CODA eval/auth later

---

## Explicit answers

### Did we do Prime 001 before?

**No — only a sketch.** This document is the first full Prime 001 on the triple face (three adapters, loss ledgers, terminals).

### What do we get from Prime 002?

A **control decision**, not more theorems:

1. **Stop** continuing the full claim (field + storage + “math complete”).  
2. **Stop** shape-looping (shape already local green).  
3. **Authorize at most one** continue: scalar-theory repacket \(K'\) with re-001 — or stop and hold residual.

That *is* the product of 002: **CanContinue_n truth value + stop reason**, with anti-launder fences.

---

**AuthorityEffect: None.**  
**Not PROVED. Not GlobalGreen. Not host authorization of PROD LIVE.**
