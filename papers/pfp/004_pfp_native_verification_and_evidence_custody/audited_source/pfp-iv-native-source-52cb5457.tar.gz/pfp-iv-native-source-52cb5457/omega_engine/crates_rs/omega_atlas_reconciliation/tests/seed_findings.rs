use omega_atlas_reconciliation::row::ClaimDelta;
use omega_atlas_reconciliation::runner::{run_reconciliation, seed_rows};
use omega_atlas_reconciliation::{ledger, observers, render};

#[test]
fn all_seed_rows_are_well_formed_and_accepted() {
    let res = run_reconciliation(seed_rows());
    assert!(
        res.rejected.is_empty(),
        "seed rows must be valid: {:?}",
        res.rejected
    );
    assert!(res.accepted.len() >= 7);
}

#[test]
fn seed_covers_all_four_claim_deltas() {
    let rows = seed_rows();
    for d in [
        ClaimDelta::Undersold,
        ClaimDelta::Oversold,
        ClaimDelta::Missing,
        ClaimDelta::Accurate,
    ] {
        assert!(
            rows.iter().any(|r| r.claim_delta == d),
            "missing claim_delta {:?}",
            d
        );
    }
}

#[test]
fn seed_ledger_roundtrips_and_renders() {
    let rows = seed_rows();
    let nd = ledger::write_ndjson(&rows).unwrap();
    assert_eq!(ledger::read_ndjson(&nd).unwrap().len(), rows.len());
    let md = render::render_md(&rows);
    assert!(md.contains("| asset | claim_delta | terminal | verdict |"));
}

#[test]
fn observers_fire_on_seed() {
    // the auto_p row (WrittenUnrun) must trip the code-reality observer
    let rows = seed_rows();
    let autop = rows.iter().find(|r| r.asset_id.contains("auto_p")).unwrap();
    assert!(observers::code::check(autop)
        .findings
        .iter()
        .any(|x| x.contains("written")));
}
