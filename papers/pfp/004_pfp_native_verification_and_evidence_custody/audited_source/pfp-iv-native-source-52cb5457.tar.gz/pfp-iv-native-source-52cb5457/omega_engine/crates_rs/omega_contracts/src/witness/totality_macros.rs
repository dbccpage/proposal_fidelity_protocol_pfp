/// Generates test-time totality checks for contracts that explicitly require totality.
///
/// Use this macro only when the contract's `WitnessDirective::REQUIRE_TOTAL`
/// is true. It does not emit persisted `ValidationWitness` artifacts.
#[macro_export]
macro_rules! generate_totality_witnesses {
    ($impl_ty:ty, $contract:ty, lambda) => {
        #[cfg(test)]
        mod __totality_property_witnesses {
            use super::*;
            use proptest::prelude::*;

            const _: () = {
                const REQUIRE_TOTAL: bool =
                    <$contract as $crate::witness::directive::WitnessDirective>::REQUIRE_TOTAL;
                let _ = [()][(!REQUIRE_TOTAL) as usize];
                fn assert_input_arbitrary<T: proptest::arbitrary::Arbitrary>() {}
                fn assert_input_debug<T: core::fmt::Debug>() {}

                let _ =
                    assert_input_arbitrary::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_debug::<<$contract as $crate::binding::BoundContract>::Input>;
            };

            proptest! {
                #[test]
                fn operator_is_total(
                    input in any::<<$contract as $crate::binding::BoundContract>::Input>()
                ) {
                    let op = <$impl_ty>::default();

                    let result = <$impl_ty as $crate::traits::operators::LambdaOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                        <$contract as $crate::binding::BoundContract>::Output,
                    >>::apply(&op, &input);

                    prop_assert!(
                        result.is_ok(),
                        "operator must be total over domain: input={:?}, error={:?}",
                        input,
                        result.err()
                    );
                }
            }
        }
    };
    ($impl_ty:ty, $contract:ty, reducer) => {
        #[cfg(test)]
        mod __totality_property_witnesses {
            use super::*;
            use proptest::prelude::*;

            const _: () = {
                const REQUIRE_TOTAL: bool =
                    <$contract as $crate::witness::directive::WitnessDirective>::REQUIRE_TOTAL;
                let _ = [()][(!REQUIRE_TOTAL) as usize];
                fn assert_input_arbitrary<T: proptest::arbitrary::Arbitrary>() {}
                fn assert_input_debug<T: core::fmt::Debug>() {}

                let _ =
                    assert_input_arbitrary::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_debug::<<$contract as $crate::binding::BoundContract>::Input>;
            };

            proptest! {
                #[test]
                fn operator_is_total(
                    input in any::<<$contract as $crate::binding::BoundContract>::Input>()
                ) {
                    let op = <$impl_ty>::default();

                    let result = <$impl_ty as $crate::traits::operators::ReducerOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                    >>::apply(&op, &input);

                    prop_assert!(
                        result.is_ok(),
                        "operator must be total over domain: input={:?}, error={:?}",
                        input,
                        result.err()
                    );
                }
            }
        }
    };
    ($impl_ty:ty, $contract:ty, transform) => {
        #[cfg(test)]
        mod __totality_property_witnesses {
            use super::*;
            use proptest::prelude::*;

            const _: () = {
                const REQUIRE_TOTAL: bool =
                    <$contract as $crate::witness::directive::WitnessDirective>::REQUIRE_TOTAL;
                let _ = [()][(!REQUIRE_TOTAL) as usize];
                fn assert_input_arbitrary<T: proptest::arbitrary::Arbitrary>() {}
                fn assert_input_debug<T: core::fmt::Debug>() {}

                let _ =
                    assert_input_arbitrary::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_debug::<<$contract as $crate::binding::BoundContract>::Input>;
            };

            proptest! {
                #[test]
                fn operator_is_total(
                    input in any::<<$contract as $crate::binding::BoundContract>::Input>()
                ) {
                    let op = <$impl_ty>::default();

                    let result = <$impl_ty as $crate::traits::operators::TransformOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                    >>::apply(&op, &input);

                    prop_assert!(
                        result.is_ok(),
                        "operator must be total over domain: input={:?}, error={:?}",
                        input,
                        result.err()
                    );
                }
            }
        }
    };
}
