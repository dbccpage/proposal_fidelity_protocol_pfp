use super::artifact::{ValidationArtifact, ValidationResult};
use super::violation::ValidationViolation;
use crate::kinds::ContractEffect;
use crate::witness::evidence::ValidationWitness;
use std::fmt::Debug;

pub fn assert_validation_artifact_contract<W, V>(artifact: &ValidationArtifact<W, V>)
where
    W: ValidationWitness + Debug,
    V: ValidationViolation + Debug,
{
    assert!(
        !artifact.validator_id.is_empty(),
        "validator_id must be non-empty"
    );
    assert!(
        !artifact.artifact_id.is_empty(),
        "artifact_id must be non-empty"
    );
    assert!(
        !artifact.validator_version.is_empty(),
        "validator_version must be non-empty"
    );
    assert!(
        !artifact.subject_type.is_empty(),
        "subject_type must be non-empty"
    );
    assert!(
        !artifact.subject_hash.is_empty(),
        "subject_hash must be non-empty"
    );
    assert!(!artifact.property.is_empty(), "property must be non-empty");
    assert_eq!(
        artifact.authority_effect,
        ContractEffect::EvidenceOnly,
        "validation artifacts must default to EvidenceOnly"
    );
    assert!(
        !artifact.artifact_hash.is_empty(),
        "artifact_hash must be non-empty"
    );

    match &artifact.result {
        ValidationResult::Valid(ws) => {
            assert!(
                !ws.is_empty(),
                "Valid result must carry non-empty witnesses"
            );
            for witness in ws {
                assert_eq!(
                    witness.property(),
                    artifact.property,
                    "witness property must match validation artifact property"
                );
            }
        }
        ValidationResult::Invalid(vs) => {
            assert!(
                !vs.is_empty(),
                "Invalid result must carry non-empty violations"
            );
        }
        ValidationResult::DomainError(vs) => {
            assert!(
                !vs.is_empty(),
                "DomainError result must carry non-empty violations"
            );
        }
    }
}
