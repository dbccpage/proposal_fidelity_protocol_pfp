//! STUB — `predual_norm` (Papers 024 & 025: ℓ¹ flat-comass predual-norm
//! expansion). The real module was never extracted into the AutoP tree; its
//! `mod` declaration in `mod.rs` previously pointed at a missing file (a hard
//! compile error). This minimal stub satisfies `streaming_compiler`'s single
//! reference so the tree builds. It returns 0.0 (no expansion) — clearly a
//! placeholder, not the real continuous limit.

pub struct PredualNormExpansion;

impl PredualNormExpansion {
    /// STUB: real flat-comass predual-norm limit removed. Returns 0.0.
    pub fn compute_flat_comass_limit(
        _kolmogorov_complexity: f64,
        _dim: usize,
        _num_nodes: usize,
    ) -> f64 {
        0.0
    }
}
