//! Live reconciliation: derive proposal rows from observed asset state.
//!
//! [`crate::runner::seed_rows`] carries the CONFIRMED first slice as hand-authored
//! rows. This module is the other half: given observations gathered from the
//! tree, it DERIVES the claim delta rather than restating a human's conclusion.
//!
//! # The comparison
//!
//! Each asset is observed on three axes — what the paper or product CLAIMS,
//! what the CODE shows, and what the LEAN proof shows. The rule is:
//!
//! > a claim is only as strong as its weakest support.
//!
//! so `support = min(code, proof)` and the delta compares `claim` against that
//! support. A paper claiming a mechanized theorem over an unproved
//! implementation is Oversold even if the code is excellent, because the proof
//! axis is what the claim leaned on.
//!
//! # This module is a PROPOSAL GENERATOR
//!
//! [`reconcile`] is a pure function of its argument. It performs no filesystem
//! access at all — no read, and emphatically no write. Gathering observations
//! is the caller's job precisely so that the judgment step cannot touch the
//! tree it is judging. Every emitted proposal carries
//! [`NormativeEffect::Proposal`] and `active_bytes_changed == false`, and
//! nothing here can promote, stage, commit, or edit source or paper text.
//! Acceptance of a row by [`crate::runner::run_reconciliation`] certifies only
//! that the row is a well-formed finite judgment; it mints no authority.

use omega_types::authority::NormativeEffect;
use serde::{Deserialize, Serialize};

use crate::primitive_difference::PrimitiveDifferenceJudgment;
use crate::row::*;

/// How far along one axis of an asset actually is.
///
/// Ordered deliberately: the derived comparison below is an ordering question,
/// so the ordering is the type's job rather than a pile of match arms.
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum MaturityV1 {
    /// Nothing there at all.
    Absent,
    /// A named placeholder with no behaviour.
    Stub,
    /// Some behaviour, known gaps.
    Partial,
    /// Complete and exercised.
    Implemented,
    /// Machine-checked.
    Proved,
}

impl MaturityV1 {
    pub fn as_str(self) -> &'static str {
        match self {
            MaturityV1::Absent => "absent",
            MaturityV1::Stub => "stub",
            MaturityV1::Partial => "partial",
            MaturityV1::Implemented => "implemented",
            MaturityV1::Proved => "proved",
        }
    }
}

/// One asset as observed across the three axes.
///
/// The caller gathers these; this module never reads the tree itself.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AssetObservationV1 {
    pub asset_id: String,
    /// What the paper / product claims for this asset.
    pub paper_claim: MaturityV1,
    /// What the implementation shows.
    pub code: MaturityV1,
    /// What Lean shows.
    pub proof: MaturityV1,
    pub enc_refs: Vec<String>,
    pub note: String,
}

impl AssetObservationV1 {
    /// The support a claim can actually lean on: the weaker of code and proof.
    pub fn support(&self) -> MaturityV1 {
        self.code.min(self.proof)
    }

    /// Derived delta between claim and support.
    pub fn claim_delta(&self) -> ClaimDelta {
        let support = self.support();
        if support == MaturityV1::Absent {
            return ClaimDelta::Missing;
        }
        match support.cmp(&self.paper_claim) {
            std::cmp::Ordering::Less => ClaimDelta::Oversold,
            std::cmp::Ordering::Equal => ClaimDelta::Accurate,
            std::cmp::Ordering::Greater => ClaimDelta::Undersold,
        }
    }
}

/// A batch of derived proposals. Carries the two facts that make it safe.
#[derive(Debug, Clone)]
pub struct ReconciliationProposalV1 {
    pub rows: Vec<ReconciliationRow>,
    /// Always [`NormativeEffect::Proposal`]. Constructed only by [`reconcile`].
    pub normative_effect: NormativeEffect,
    /// Always `false`: this crate never writes to the tree it reconciles.
    pub active_bytes_changed: bool,
}

/// Derive one proposal row per observation.
///
/// Pure: same observations in, same rows out, and no I/O of any kind.
pub fn reconcile(observations: &[AssetObservationV1]) -> ReconciliationProposalV1 {
    let rows = observations
        .iter()
        .enumerate()
        .map(|(index, observation)| row_for(index, observation))
        .collect();
    ReconciliationProposalV1 {
        rows,
        normative_effect: NormativeEffect::Proposal,
        active_bytes_changed: false,
    }
}

/// Build one well-formed row for `observation`.
///
/// Starts from [`ReconciliationRow::sample_good`] and mutates only what the
/// observation determines, so the invariants that make a row well-formed
/// (vanishing cochain, conserved identity, routed residual) are inherited
/// rather than re-derived per row and silently broken.
fn row_for(index: usize, observation: &AssetObservationV1) -> ReconciliationRow {
    let delta = observation.claim_delta();
    let support = observation.support();

    let mut row = ReconciliationRow::sample_good();
    row.row_id = format!("RECON-{:04}", index + 1);
    row.asset_id = observation.asset_id.clone();
    row.claimed = observation.paper_claim.as_str().to_string();
    row.observed = format!(
        "code={} proof={} (support={})",
        observation.code.as_str(),
        observation.proof.as_str(),
        support.as_str()
    );
    row.claim_delta = delta;

    row.recon_verdict = match delta {
        ClaimDelta::Accurate => ReconVerdict::Aligned,
        ClaimDelta::Undersold => ReconVerdict::Drifted,
        ClaimDelta::Oversold => ReconVerdict::Overclaim,
        ClaimDelta::Missing => ReconVerdict::ClaimWithoutCode,
    };

    row.build_status = match observation.code {
        MaturityV1::Absent => BuildStatus::UnbuiltUnwired,
        _ => BuildStatus::Builds,
    };
    row.tests_state = match observation.code {
        MaturityV1::Absent | MaturityV1::Stub => TestsState::None,
        MaturityV1::Partial => TestsState::Run,
        MaturityV1::Implemented | MaturityV1::Proved => TestsState::Green,
    };

    row.proof_status = ProofStatus {
        enc_refs: observation.enc_refs.clone(),
        status: match observation.proof {
            MaturityV1::Proved => "PROVED-PROSE".to_string(),
            MaturityV1::Implemented => "SKETCH".to_string(),
            _ => "OPEN".to_string(),
        },
        lean_status: match observation.proof {
            MaturityV1::Proved => "MECHANIZED".to_string(),
            MaturityV1::Implemented => "IN-PROGRESS".to_string(),
            _ => "NOT-STARTED".to_string(),
        },
        relative_axioms: vec![],
    };

    // The authority basis must not out-run the proof axis: only a machine-checked
    // asset may cite Lean as its basis.
    row.authority_basis = vec![AuthClaim {
        claim: format!("{} claimed at {}", observation.asset_id, row.claimed),
        basis: match observation.proof {
            MaturityV1::Proved => AuthorityBasis::Lean,
            MaturityV1::Absent => AuthorityBasis::None,
            _ => AuthorityBasis::Test,
        },
    }];

    row.primitive_difference = PrimitiveDifferenceJudgment {
        left_presentation: format!("claim:{}", observation.paper_claim.as_str()),
        right_presentation: format!("support:{}", support.as_str()),
        zero_difference_relation: "maturity ordering on the shared axis".to_string(),
        licensed_equivalences: vec!["crates/ prefix".to_string(), "rename".to_string()],
        quotient_residual: format!("{delta:?}"),
        residual_class: format!("{delta:?}").to_uppercase(),
        factors_through_quotient: true,
    };

    row.identity_witness.object_id = observation.asset_id.clone();
    row.identity_witness.canonical_name = observation.asset_id.clone();

    row.terminal_status = Terminal {
        status: match delta {
            // An aligned claim is a discharged difference, not an open one.
            ClaimDelta::Accurate => TerminalStatus::ExactRepair,
            _ => TerminalStatus::OpenObstruction,
        },
        reason: match delta {
            ClaimDelta::Accurate => "claim matches its weakest support".to_string(),
            ClaimDelta::Undersold => "support exceeds the claim".to_string(),
            ClaimDelta::Oversold => "claim exceeds its weakest support".to_string(),
            ClaimDelta::Missing => "claim has no support at all".to_string(),
        },
    };

    row.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: format!(
            "compared claim={} against min(code={}, proof={})",
            observation.paper_claim.as_str(),
            observation.code.as_str(),
            observation.proof.as_str()
        ),
    };

    // Route the residual to whoever can actually discharge it. An aligned row
    // still carries a routed item because `validate_row` requires routed work.
    row.routed_work = vec![RoutedItem {
        item: if observation.note.is_empty() {
            format!("reconcile {}", observation.asset_id)
        } else {
            observation.note.clone()
        },
        route: match delta {
            ClaimDelta::Accurate => Route::None,
            ClaimDelta::Oversold => Route::PaperHygiene,
            ClaimDelta::Missing => Route::Sprint,
            ClaimDelta::Undersold => Route::MathDev,
        },
    }];

    row
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::runner::run_reconciliation;
    use crate::validator::validate_row;

    fn observation(
        asset_id: &str,
        paper_claim: MaturityV1,
        code: MaturityV1,
        proof: MaturityV1,
    ) -> AssetObservationV1 {
        AssetObservationV1 {
            asset_id: asset_id.to_string(),
            paper_claim,
            code,
            proof,
            enc_refs: vec!["ENC-0001".to_string()],
            note: String::new(),
        }
    }

    #[test]
    fn a_claim_is_only_as_strong_as_its_weakest_support() {
        // Excellent code, no proof: a "proved" claim is still Oversold.
        let o = observation(
            "a",
            MaturityV1::Proved,
            MaturityV1::Implemented,
            MaturityV1::Partial,
        );
        assert_eq!(o.support(), MaturityV1::Partial);
        assert_eq!(o.claim_delta(), ClaimDelta::Oversold);
    }

    #[test]
    fn every_delta_is_reachable_and_correct() {
        assert_eq!(
            observation(
                "a",
                MaturityV1::Partial,
                MaturityV1::Partial,
                MaturityV1::Partial
            )
            .claim_delta(),
            ClaimDelta::Accurate
        );
        assert_eq!(
            observation(
                "b",
                MaturityV1::Stub,
                MaturityV1::Proved,
                MaturityV1::Proved
            )
            .claim_delta(),
            ClaimDelta::Undersold
        );
        assert_eq!(
            observation("c", MaturityV1::Proved, MaturityV1::Stub, MaturityV1::Stub).claim_delta(),
            ClaimDelta::Oversold
        );
        assert_eq!(
            observation(
                "d",
                MaturityV1::Proved,
                MaturityV1::Absent,
                MaturityV1::Proved
            )
            .claim_delta(),
            ClaimDelta::Missing,
            "absent support is Missing even when the other axis is strong"
        );
    }

    #[test]
    fn derived_rows_are_well_formed_judgments() {
        let observations = vec![
            observation(
                "a",
                MaturityV1::Partial,
                MaturityV1::Partial,
                MaturityV1::Partial,
            ),
            observation(
                "b",
                MaturityV1::Stub,
                MaturityV1::Proved,
                MaturityV1::Proved,
            ),
            observation("c", MaturityV1::Proved, MaturityV1::Stub, MaturityV1::Stub),
            observation(
                "d",
                MaturityV1::Proved,
                MaturityV1::Absent,
                MaturityV1::Proved,
            ),
        ];
        let proposal = reconcile(&observations);
        assert_eq!(proposal.rows.len(), 4);

        for row in &proposal.rows {
            assert!(
                validate_row(row).is_empty(),
                "derived row {} failed validation: {:?}",
                row.row_id,
                validate_row(row)
            );
        }

        // And the host adjudicator accepts all of them.
        let result = run_reconciliation(proposal.rows.clone());
        assert_eq!(result.accepted.len(), 4);
        assert!(result.rejected.is_empty(), "{:?}", result.rejected);
    }

    #[test]
    fn reconcile_is_deterministic_and_order_preserving() {
        let observations = vec![
            observation(
                "a",
                MaturityV1::Stub,
                MaturityV1::Proved,
                MaturityV1::Proved,
            ),
            observation("b", MaturityV1::Proved, MaturityV1::Stub, MaturityV1::Stub),
        ];
        let first = reconcile(&observations);
        let second = reconcile(&observations);
        let ids: Vec<&str> = first.rows.iter().map(|r| r.asset_id.as_str()).collect();
        assert_eq!(ids, vec!["a", "b"]);
        assert_eq!(
            ids,
            second
                .rows
                .iter()
                .map(|r| r.asset_id.as_str())
                .collect::<Vec<_>>()
        );
        assert_eq!(first.rows[0].row_id, "RECON-0001");
    }

    #[test]
    fn derived_rows_use_the_canonical_role_pin() {
        let proposal = reconcile(&[observation(
            "a",
            MaturityV1::Partial,
            MaturityV1::Partial,
            MaturityV1::Partial,
        )]);
        let row = &proposal.rows[0];
        assert_eq!(
            row.role_pinned_ceiling,
            crate::row::pinned_authority_effect(row.role)
        );
        assert!(crate::observers::contract_authority::check(row)
            .findings
            .is_empty());
    }

    #[test]
    fn an_unproved_asset_never_cites_lean_as_its_authority_basis() {
        let proposal = reconcile(&[observation(
            "a",
            MaturityV1::Proved,
            MaturityV1::Implemented,
            MaturityV1::Partial,
        )]);
        assert!(
            proposal.rows[0]
                .authority_basis
                .iter()
                .all(|claim| claim.basis != AuthorityBasis::Lean),
            "an asset without a machine-checked proof must not claim a Lean basis"
        );
    }

    #[test]
    fn empty_input_yields_an_empty_proposal_not_a_panic() {
        let proposal = reconcile(&[]);
        assert!(proposal.rows.is_empty());
        assert_eq!(proposal.normative_effect, NormativeEffect::Proposal);
        assert!(!proposal.active_bytes_changed);
    }
}
