//! Host adjudication runner + the confirmed first-slice seed findings.
//!
//! The host (this engine) is the only adjudicator: a proposed [`ReconciliationRow`] is
//! accepted iff [`validate_row`] returns no findings. No row mints authority by being
//! accepted — acceptance only certifies that the row is a *well-formed finite judgment*
//! (it preserves the three OmegaCore invariants, respects the authority ceiling, and
//! descends to a terminal status with routed residual work).
//!
//! [`seed_rows`] materializes the CONFIRMED first reconciliation slice: seven real
//! mismatches surfaced against the Anomalon atlas / product claims, each authored as a
//! well-formed row that PASSES `validate_row`. They cover all four claim deltas (Undersold,
//! Oversold, Missing, Accurate), two live security findings, and one held-open survivor
//! carrying a declared relative axiom.
use crate::cochain_validity::{CochainValidity, TriState};
use crate::identity_witness::IdentityWitness;
use crate::observers::contract_authority::pinned_authority_effect;
use crate::primitive_difference::PrimitiveDifferenceJudgment;
use crate::row::*;
use crate::validator::validate_row;

/// Outcome of running host adjudication over a batch of proposed rows.
#[derive(Debug, Clone)]
pub struct RunResult {
    /// Rows that passed `validate_row` (empty findings).
    pub accepted: Vec<ReconciliationRow>,
    /// Rejected rows, each as `(asset_id, findings)`.
    pub rejected: Vec<(String, Vec<String>)>,
}

/// Host adjudication: a proposed row is accepted iff validate_row returns no findings.
pub fn run_reconciliation(proposed: Vec<ReconciliationRow>) -> RunResult {
    let mut accepted = Vec::new();
    let mut rejected = Vec::new();
    for r in proposed {
        let f = validate_row(&r);
        if f.is_empty() {
            accepted.push(r);
        } else {
            rejected.push((r.asset_id.clone(), f));
        }
    }
    RunResult { accepted, rejected }
}

/// Build an identity witness for a named code/doctrine object, conserved across edges
/// (no impersonation) so invariant III is satisfied by construction.
fn ident(
    object_id: &str,
    kind: &str,
    canonical: &str,
    aliases: &[&str],
    note: &str,
) -> IdentityWitness {
    IdentityWitness {
        object_id: object_id.to_string(),
        object_kind: kind.to_string(),
        canonical_name: canonical.to_string(),
        aliases: aliases.iter().map(|s| s.to_string()).collect(),
        conserved_across_edges: true,
        identity_loss_risk: false,
        note: note.to_string(),
    }
}

/// A valid, vanishing cochain over the standard reconciliation chain (d1∘d0 = 0).
fn valid_cochain() -> CochainValidity {
    CochainValidity {
        chain: vec![
            "product".to_string(),
            "crate".to_string(),
            "proof".to_string(),
            "contract".to_string(),
        ],
        d0_declared: "atlas->crate".to_string(),
        d1_declared: "crate->proof".to_string(),
        d1_d0_zero: TriState::True,
        failure_reason: String::new(),
        terminal_if_failed: None,
        // Honest commuting carrier: d0=[[1],[1]], d1=[[1,1]] → 1⊕1=0 → computes True.
        d0: vec![vec![1u8], vec![1u8]],
        d1: vec![vec![1u8, 1u8]],
    }
}

/// A primitive-difference judgment that factors through the quotient (no residual leak).
fn factoring_diff(
    left: &str,
    right: &str,
    zero_rel: &str,
    residual_class: &str,
) -> PrimitiveDifferenceJudgment {
    PrimitiveDifferenceJudgment {
        left_presentation: left.to_string(),
        right_presentation: right.to_string(),
        zero_difference_relation: zero_rel.to_string(),
        licensed_equivalences: vec!["crates/ prefix".to_string(), "rename".to_string()],
        quotient_residual: residual_class.to_string(),
        residual_class: residual_class.to_string(),
        factors_through_quotient: true,
    }
}

/// The seven CONFIRMED first-slice findings as well-formed rows that PASS `validate_row`.
///
/// Each row starts from [`ReconciliationRow::sample_good`] and is mutated to its honest
/// finding. They cover all four `ClaimDelta`s plus two live security drifts and one
/// held-open survivor with a declared relative axiom.
pub fn seed_rows() -> Vec<ReconciliationRow> {
    vec![
        row_1_authority_undersold(),
        row_2_885_machine_checked_oversold(),
        row_3_symbol_game_enc_0081_oversold(),
        row_4_auto_p_missing_tests(),
        row_5_enc_0508_gttc1_drift(),
        row_6_representation_isauth_default_true(),
        row_7_gtta_14_survivor(),
    ]
}

/// 1. `omega_types::authority` — atlas "stub" vs HARDENED machine-checked. Undersold drift,
/// terminalized OpenObstruction, routed to a Sprint to wrap the surface. (≈ `sample_good`.)
fn row_1_authority_undersold() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S01".to_string();
    // MathObject pins EvidenceOnly; keep the row's declared role-ceiling on the canonical pin
    // so the contract-authority observer stays clean (declared None still <= EvidenceOnly).
    r.role = ComponentRole::MathObject;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r
}

/// 2. atlas "885 machine-checked statements" vs 293 lean-mechanized of 888. Oversold product
/// claim. proof_status is DEFINED / lean NOT-STARTED, so the two-axis rule does NOT fire
/// (it only fires when status=="MECHANIZED"); this is an Oversold count claim, not a
/// two-axis violation. Routed to Doctrine.
fn row_2_885_machine_checked_oversold() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S02".to_string();
    r.asset_id = "atlas::encyclopedia_count".to_string();
    r.claimed = "885 machine-checked statements".to_string();
    r.observed = "293 lean-mechanized of 888 entries".to_string();
    r.claim_delta = ClaimDelta::Oversold;
    r.recon_verdict = ReconVerdict::Overclaim;
    r.role = ComponentRole::MathObject;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r.proof_status = ProofStatus {
        enc_refs: vec!["ENC-INDEX".to_string()],
        status: "DEFINED".to_string(),
        lean_status: "NOT-STARTED".to_string(),
        relative_axioms: vec![],
    };
    r.evidence_ceiling = EvidenceCeiling::ShapeOnly;
    r.authority_basis = vec![];
    r.identity_witness = ident(
        "encyclopedia-mechanization-count",
        "claim",
        "encyclopedia machine-checked count",
        &["885 claim", "293 actual", "888 total"],
        "One count claim aliased across atlas/index — conserved.",
    );
    r.primitive_difference = factoring_diff(
        "atlas:885 machine-checked",
        "index:293 of 888 mechanized",
        "count rounding only",
        "OVERSOLD-COUNT",
    );
    r.terminal_status = Terminal {
        status: TerminalStatus::OpenObstruction,
        reason: "oversold mechanization count; 293/888 actual vs 885 claimed".to_string(),
    };
    r.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: "tried to find 885 mechanized; found 293 of 888".to_string(),
    };
    r.routed_work = vec![RoutedItem {
        item: "correct the encyclopedia mechanization count in atlas/product copy".to_string(),
        route: Route::Doctrine,
    }];
    r
}

/// 3. Symbol Game / ENC-0081 "ensures LLM cannot forge" but ENC-0081 is PROVED-PROSE with
/// lean NOT-STARTED. Oversold (the copy overstates an unmechanized result). Routed to
/// PaperHygiene.
fn row_3_symbol_game_enc_0081_oversold() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S03".to_string();
    r.asset_id = "omega_symbol_game::ENC-0081".to_string();
    r.claimed = "ensures LLM cannot forge a symbol".to_string();
    r.observed = "ENC-0081 PROVED-PROSE, Lean NOT-STARTED".to_string();
    r.claim_delta = ClaimDelta::Oversold;
    r.recon_verdict = ReconVerdict::Overclaim;
    r.surface = Surface::Public;
    r.role = ComponentRole::SymbolGame;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r.proof_status = ProofStatus {
        enc_refs: vec!["ENC-0081".to_string()],
        status: "PROVED-PROSE".to_string(),
        lean_status: "NOT-STARTED".to_string(),
        relative_axioms: vec![],
    };
    r.evidence_ceiling = EvidenceCeiling::BoundaryChecked;
    r.authority_basis = vec![];
    r.identity_witness = ident(
        "ENC-0081",
        "encyclopedia-entry",
        "Symbol Game forgery-resistance claim",
        &["paper claim", "product copy", "ENC entry"],
        "One ENC-0081 result aliased across paper/product — conserved.",
    );
    r.primitive_difference = factoring_diff(
        "copy:cannot forge (proved)",
        "ENC-0081:PROVED-PROSE / Lean NOT-STARTED",
        "phrasing only",
        "OVERSOLD-PROSE",
    );
    r.terminal_status = Terminal {
        status: TerminalStatus::OpenObstruction,
        reason: "public copy claims a forgery guarantee that is prose-only (Lean NOT-STARTED)"
            .to_string(),
    };
    r.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: "tried to find a mechanized forgery proof; ENC-0081 is PROVED-PROSE"
            .to_string(),
    };
    r.routed_work = vec![RoutedItem {
        item: "soften ENC-0081 copy to PROVED-PROSE; certificate != authority".to_string(),
        route: Route::PaperHygiene,
    }];
    r
}

/// 4. `auto_p` claims "323 tests" but ~17 are real and the backing `.rs` files are absent.
/// Missing (claim without code). build UnbuiltUnwired, tests WrittenUnrun. Routed to Sprint.
fn row_4_auto_p_missing_tests() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S04".to_string();
    r.asset_id = "auto_p::test_suite".to_string();
    r.claimed = "323 tests".to_string();
    r.observed = "~17 tests; backing .rs files absent".to_string();
    r.claim_delta = ClaimDelta::Missing;
    r.recon_verdict = ReconVerdict::ClaimWithoutCode;
    r.role = ComponentRole::Diagnostic;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r.build_status = BuildStatus::UnbuiltUnwired;
    r.tests_state = TestsState::WrittenUnrun;
    r.proof_status = ProofStatus {
        enc_refs: vec![],
        status: "DEFINED".to_string(),
        lean_status: "NOT-STARTED".to_string(),
        relative_axioms: vec![],
    };
    r.evidence_ceiling = EvidenceCeiling::ShapeOnly;
    r.authority_basis = vec![];
    r.identity_witness = ident(
        "auto_p-test-suite",
        "test-suite",
        "auto_p test suite",
        &["323 claim", "~17 actual"],
        "One auto_p suite aliased across claim/reality — conserved.",
    );
    r.primitive_difference = factoring_diff(
        "atlas:323 tests",
        "code:~17 tests, files absent",
        "naming only",
        "MISSING-CODE",
    );
    r.terminal_status = Terminal {
        status: TerminalStatus::OpenObstruction,
        reason: "claimed 323 tests; ~17 exist and backing .rs files are absent/unwired".to_string(),
    };
    r.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: "tried to enumerate 323 tests; found ~17 and missing files".to_string(),
    };
    r.routed_work = vec![RoutedItem {
        item: "write/wire the missing auto_p tests or correct the count".to_string(),
        route: Route::Sprint,
    }];
    r
}

/// 5. ENC-0508 (GTTC-1) lean_status drift: registry says MECHANIZED but the ledger says
/// TARGETED. Not Accurate — an Oversold drift (registry overstates the ledger). Routed to
/// MathDev.
fn row_5_enc_0508_gttc1_drift() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S05".to_string();
    r.asset_id = "encyclopedia::ENC-0508::GTTC-1".to_string();
    r.claimed = "lean_status MECHANIZED (registry)".to_string();
    r.observed = "lean_status TARGETED (ledger)".to_string();
    r.claim_delta = ClaimDelta::Oversold;
    r.recon_verdict = ReconVerdict::Drifted;
    r.role = ComponentRole::MathObject;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r.proof_status = ProofStatus {
        enc_refs: vec!["ENC-0508".to_string()],
        status: "SKETCH".to_string(),
        lean_status: "TARGETED".to_string(),
        relative_axioms: vec![],
    };
    r.evidence_ceiling = EvidenceCeiling::BoundaryChecked;
    r.authority_basis = vec![];
    r.identity_witness = ident(
        "ENC-0508",
        "encyclopedia-entry",
        "GTTC-1 mechanization status",
        &["registry view", "ledger view"],
        "One GTTC-1 status aliased registry/ledger — conserved.",
    );
    r.primitive_difference = factoring_diff(
        "registry:MECHANIZED",
        "ledger:TARGETED",
        "view label only",
        "REGISTRY-LEDGER-DRIFT",
    );
    r.terminal_status = Terminal {
        status: TerminalStatus::OpenObstruction,
        reason: "GTTC-1 registry lean_status MECHANIZED disagrees with ledger TARGETED".to_string(),
    };
    r.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: "tried to confirm MECHANIZED; ledger of record says TARGETED".to_string(),
    };
    r.routed_work = vec![RoutedItem {
        item: "reconcile ENC-0508 registry/ledger lean_status to the true depth".to_string(),
        route: Route::MathDev,
    }];
    r
}

/// 6. `omega_representation` IsAuth-default-true (authority.rs:222): a LIVE security drift —
/// `IsAuth` synthesizes `true` on an omitted field. Oversold (the surface silently claims
/// authority it should not). Routed to Sprint.
fn row_6_representation_isauth_default_true() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S06".to_string();
    r.asset_id = "omega_representation::authority.rs:222".to_string();
    r.claimed = "IsAuth defaults safe (false) on omitted field".to_string();
    r.observed = "LIVE: IsAuth synthesized true on omitted field".to_string();
    r.claim_delta = ClaimDelta::Oversold;
    r.recon_verdict = ReconVerdict::Drifted;
    r.surface = Surface::Private;
    r.proof_status = ProofStatus {
        enc_refs: vec![],
        status: "DEFINED".to_string(),
        lean_status: "NOT-STARTED".to_string(),
        relative_axioms: vec![],
    };
    r.evidence_ceiling = EvidenceCeiling::LocalReplay;
    // Live security drift: declared effect stays None (it must) — no ceiling breach is being
    // claimed; the drift is that the *default* silently mints authority. The role-ceiling sits
    // on the canonical MathObject pin (EvidenceOnly) so the contract-authority observer is clean.
    r.declared_authority_effect = ContractEffect::None;
    r.role = ComponentRole::MathObject;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r.authority_basis = vec![];
    r.identity_witness = ident(
        "omega_representation-IsAuth",
        "code-site",
        "IsAuth default-on-omitted-field",
        &["authority.rs:222", "serde default"],
        "One IsAuth derivation aliased across call sites — conserved.",
    );
    r.primitive_difference = factoring_diff(
        "claim:default-false",
        "code:synthesized-true",
        "field-presence only",
        "LIVE-SECURITY-DRIFT",
    );
    r.terminal_status = Terminal {
        status: TerminalStatus::OpenObstruction,
        reason: "LIVE: IsAuth synthesized true on omitted field (authority.rs:222) — fail-open"
            .to_string(),
    };
    r.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: "tried to show IsAuth fails safe; reproduced fail-open default-true"
            .to_string(),
    };
    r.routed_work = vec![RoutedItem {
        item: "make IsAuth fail-closed: require explicit field, default false".to_string(),
        route: Route::Sprint,
    }];
    r
}

/// 7. GTTA-14 firewall keystone: PROVED-PROSE, Lean MECHANIZED-PARTIAL, held open only modulo
/// the declared `anomalon_exists` axiom. Accurate and Aligned — a real StabilizedSurvivor
/// with a declared relative axiom, routing no remediation work (`Route::None`).
fn row_7_gtta_14_survivor() -> ReconciliationRow {
    let mut r = ReconciliationRow::sample_good();
    r.row_id = "ROW-S07".to_string();
    r.asset_id = "encyclopedia::GTTA-14::firewall_keystone".to_string();
    r.claimed = "firewall keystone holds (modulo anomalon_exists)".to_string();
    r.observed =
        "PROVED-PROSE, Lean MECHANIZED-PARTIAL, axiom anomalon_exists declared".to_string();
    r.claim_delta = ClaimDelta::Accurate;
    r.recon_verdict = ReconVerdict::Aligned;
    r.role = ComponentRole::MathObject;
    r.role_pinned_ceiling = pinned_authority_effect(r.role);
    r.proof_status = ProofStatus {
        enc_refs: vec!["ENC-0545".to_string()],
        status: "PROVED-PROSE".to_string(),
        lean_status: "MECHANIZED-PARTIAL".to_string(),
        relative_axioms: vec!["anomalon_exists".to_string()],
    };
    r.evidence_ceiling = EvidenceCeiling::BoundaryChecked;
    // Accurate row with a real (non-None) authority basis so the counterfeit guard is satisfied.
    r.authority_basis = vec![AuthClaim {
        claim: "firewall keystone holds modulo declared axiom".to_string(),
        basis: AuthorityBasis::Lean,
    }];
    r.identity_witness = ident(
        "GTTA-14",
        "encyclopedia-entry",
        "GTTA-14 firewall keystone",
        &["paper claim", "Lean partial", "ENC-0545"],
        "One GTTA-14 keystone aliased across paper/Lean — conserved.",
    );
    r.primitive_difference = factoring_diff(
        "claim:holds modulo anomalon_exists",
        "proof:PROVED-PROSE + Lean partial under anomalon_exists",
        "phrasing only",
        "AXIOM-RELATIVE-SURVIVOR",
    );
    r.cochain_validity = valid_cochain();
    r.terminal_status = Terminal {
        status: TerminalStatus::StabilizedSurvivor,
        reason: "held open under the declared anomalon_exists axiom; aligned and honest"
            .to_string(),
    };
    r.verify_verdict = VerifyVerdict {
        result: VerifyResult::Confirmed,
        refutation: "tried to find an undeclared dependency; only anomalon_exists is used"
            .to_string(),
    };
    // StabilizedSurvivor is not open/unknown/no-rule and the delta is Accurate, so no routed
    // work is required: this is a held-open, axiom-relative survivor.
    r.routed_work = vec![];
    r
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn run_partitions_accepted_and_rejected() {
        // sample_good passes; a row with an empty terminal reason is rejected.
        let good = ReconciliationRow::sample_good();
        let mut bad = ReconciliationRow::sample_good();
        bad.asset_id = "bad".to_string();
        bad.terminal_status.reason = String::new();
        let res = run_reconciliation(vec![good, bad]);
        assert_eq!(res.accepted.len(), 1);
        assert_eq!(res.rejected.len(), 1);
        assert_eq!(res.rejected[0].0, "bad");
    }

    #[test]
    fn every_seed_row_passes_validate_row() {
        for r in seed_rows() {
            let f = validate_row(&r);
            assert!(f.is_empty(), "{} produced findings: {:?}", r.asset_id, f);
        }
    }
}
