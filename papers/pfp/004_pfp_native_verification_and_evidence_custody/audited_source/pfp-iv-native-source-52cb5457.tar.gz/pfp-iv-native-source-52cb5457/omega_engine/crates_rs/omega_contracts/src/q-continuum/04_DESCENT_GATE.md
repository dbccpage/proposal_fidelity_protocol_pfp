Descent Gate
============

Definition
----------

The descent gate is the boundary between Q-layer proposals and the finite system. It translates high-level material into finite projections and obligations, then records results without pretending to solve them.

Rules
-----

1. Q objects can propose.
2. The descent gate decomposes proposals into finite obligations.
3. The finite descent engine attempts resolution.
4. The obstruction ledger records the result.
5. Authority updates only after finite results.
6. Terminal statuses are only valid within scope.
7. Failed descent is not failure of the idea; it is a typed residual.
8. Repeated failed descent without new structure weakens authority.

Implemented Interface
---------------------

`DescentGate` currently supports:

```rust
DescentGate::project_idea(&QIdea) -> FiniteProjection
DescentGate::project_claim(&QClaim) -> FiniteProjection
DescentGate::obligations_for_projection(&FiniteProjection) -> Vec<DescentObligation>
DescentGate::accept_results(&mut QContinuumLedger, about, Vec<DescentResult>)
DescentGate::verify_lean_witness(obligation_id, scope, &LeanWitness) -> DescentResult
```

`generate_probe_plan` uses the gate to build a first finite projection and obligations.

Lean Witness Verification (the enforced gate)
---------------------------------------------

`accept_results` trusts a caller-built `DescentResult`. The stronger surface is
`verify_lean_witness`, which takes a typed `LeanWitness` — a mechanized theorem
plus its `#print axioms` **receipt** — and *derives* the verdict from the
receipt's shape, so a caller cannot assert a verdict the proof does not support:

| Receipt shape | Verdict | Authority |
|---|---|---|
| `sorry`-free, only standard axioms (`propext`, `Classical.choice`, `Quot.sound`) | `Supported` | terminal within scope |
| `sorry`-free but depends on a non-standard axiom | `ConditionallySupported` (conditioning axioms recorded in notes) | conditional, **not** terminal |
| depends on `sorryAx` (an unfinished `sorry`) | `Residual` (`MissingWitness`) | none |

The safety property (covered by tests): a `Supported` verdict for a holey or
axiom-extended proof is **not representable** through this gate. `LeanWitness::is_clean`
is the predicate; `verify_lean_witness` is the only constructor that turns one
into terminal support.

`qm_holonomy_descent_witnesses()` is the **first real batch**: the mechanized
theorems of QM_030 (LQG) / QM_031 (GR) encoded with their actual captured axiom
receipts, each verified clean and terminal by the gate in the test suite.

Stubbed Boundary
----------------

The descent gate verifies the *receipt*, not the proof: this pure data crate
never invokes `lake`/`lean`. The receipt itself is produced externally by a real
`#print axioms` run (recorded in `LeanWitness::provenance`), exactly as the rest
of the corpus treats `#print axioms` output as the mechanization receipt. The
gate does not fabricate proof results, search results, theorem receipts, or
empirical measurements; for non-Lean obligations it still records the obligation
shape and accepts explicit descent results from a caller.

Result Handling
---------------

Supported results require witnesses. A `Supported`, `ConditionallySupported`, or `Implemented` result without a witness is recorded as a `MissingWitness` residual, not as authority.

Scope mismatches become `ScopeViolation` residuals. Counterexamples are recorded on the authority trace.
