#!/usr/bin/env python3
"""Inject empty nomos_debate_NOT_CANONICAL into math contracts missing it."""
from pathlib import Path

MATH = (
    Path(__file__).resolve().parents[2]
    / "src"
    / "contract_canonical_definitions"
    / "math"
)

BLOCK = """
# =============================================================================
# ⚠️  nomos_debate_NOT_CANONICAL  —  NON-CANONICAL DEBATE ONLY
#     NOT contract law · NOT enforced as obligations · AuthorityEffect: none
#     Do NOT treat this block as GTLA truth. Canonical law is everything ABOVE.
# =============================================================================
nomos_debate_NOT_CANONICAL:
  banner: "NON-CANONICAL DEBATE ONLY — not contract law; not enforced as obligations; AuthorityEffect None"
  not_part_of_contract_law: true
  authority_effect: none
  # §1 What is potentially wrong with this math YAML (debate, not law)
  potential_defects: []
  # §2 YAML vs implemented math file (empty list = ideal; open debate OK)
  realization_delta_vs_implemented_math_file: []
"""


def main() -> None:
    added = 0
    skipped = 0
    for path in sorted(MATH.glob("*.contract.yaml")):
        text = path.read_text(encoding="utf-8")
        if "nomos_debate_NOT_CANONICAL" in text:
            skipped += 1
            continue
        if not text.endswith("\n"):
            text += "\n"
        path.write_text(text + BLOCK, encoding="utf-8")
        added += 1
    print(f"added={added} skipped_already={skipped} dir={MATH}")


if __name__ == "__main__":
    main()
