//! PKT-20260722-M2-EPOCH18: the reconciler emits PROPOSALS and touches nothing.
//!
//! The load-bearing claim of this epoch is negative — "leaves source code and
//! paper text untouched on disk" — so it is tested the only way a negative
//! claim can be: build a fixture tree, digest every byte of it, run the
//! reconciler over observations describing it, and digest again.

use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};

use omega_atlas_reconciliation::reconciler::{reconcile, AssetObservationV1, MaturityV1};
use omega_atlas_reconciliation::row::ClaimDelta;
use omega_atlas_reconciliation::runner::run_reconciliation;
use omega_atlas_reconciliation::validator::validate_row;
use omega_types::authority::NormativeEffect;

fn observation(
    asset_id: &str,
    paper_claim: MaturityV1,
    code: MaturityV1,
    proof: MaturityV1,
) -> AssetObservationV1 {
    AssetObservationV1 {
        asset_id: asset_id.to_string(),
        paper_claim,
        code,
        proof,
        enc_refs: vec!["ENC-0001".to_string()],
        note: String::new(),
    }
}

/// The four-delta corpus: one observation per reachable `ClaimDelta`.
fn corpus() -> Vec<AssetObservationV1> {
    vec![
        observation(
            "omega_types::authority",
            MaturityV1::Stub,
            MaturityV1::Proved,
            MaturityV1::Proved,
        ),
        observation(
            "paper::885_machine_checked",
            MaturityV1::Proved,
            MaturityV1::Partial,
            MaturityV1::Stub,
        ),
        observation(
            "products::auto_p",
            MaturityV1::Implemented,
            MaturityV1::Absent,
            MaturityV1::Absent,
        ),
        observation(
            "omega_replay::retention",
            MaturityV1::Implemented,
            MaturityV1::Implemented,
            MaturityV1::Implemented,
        ),
    ]
}

#[test]
fn test_reconciler_emits_difference_proposals() {
    let proposal = reconcile(&corpus());

    assert_eq!(proposal.rows.len(), 4);
    assert_eq!(
        proposal.normative_effect,
        NormativeEffect::Proposal,
        "the reconciler is a proposal generator and nothing else"
    );
    assert!(
        !proposal.active_bytes_changed,
        "active_bytes_changed must be false"
    );

    // Every reachable delta is actually produced — a reconciler that only ever
    // says Accurate would pass a weaker test.
    let deltas: Vec<ClaimDelta> = proposal.rows.iter().map(|row| row.claim_delta).collect();
    assert_eq!(
        deltas,
        vec![
            ClaimDelta::Undersold,
            ClaimDelta::Oversold,
            ClaimDelta::Missing,
            ClaimDelta::Accurate,
        ]
    );

    // Each row is a well-formed finite judgment the host adjudicator accepts.
    for row in &proposal.rows {
        let findings = validate_row(row);
        assert!(
            findings.is_empty(),
            "row {} is not well formed: {findings:?}",
            row.row_id
        );
    }
    let result = run_reconciliation(proposal.rows.clone());
    assert_eq!(result.accepted.len(), 4);
    assert!(result.rejected.is_empty(), "{:?}", result.rejected);

    // Each row carries its primitive difference: the two presentations it
    // compared and the residual class that survived the quotient.
    for row in &proposal.rows {
        assert!(row
            .primitive_difference
            .left_presentation
            .starts_with("claim:"));
        assert!(row
            .primitive_difference
            .right_presentation
            .starts_with("support:"));
        assert!(row.primitive_difference.factors_through_quotient);
    }
}

/// Digest every file under `root`, keyed by relative path.
fn digest_tree(root: &Path) -> BTreeMap<String, Vec<u8>> {
    fn walk(root: &Path, dir: &Path, out: &mut BTreeMap<String, Vec<u8>>) {
        let mut entries: Vec<PathBuf> = fs::read_dir(dir)
            .expect("fixture dir readable")
            .map(|entry| entry.expect("entry readable").path())
            .collect();
        entries.sort();
        for path in entries {
            if path.is_dir() {
                walk(root, &path, out);
            } else {
                let relative = path
                    .strip_prefix(root)
                    .expect("under root")
                    .to_string_lossy()
                    .replace('\\', "/");
                out.insert(relative, fs::read(&path).expect("file readable"));
            }
        }
    }
    let mut out = BTreeMap::new();
    walk(root, root, &mut out);
    out
}

/// The negative claim, tested positively: running the reconciler over a tree
/// leaves every byte of that tree identical.
#[test]
fn reconciler_leaves_active_bytes_untouched() {
    let base = Path::new(env!("CARGO_TARGET_TMPDIR")).join("reconciler_immutability");
    let _ = fs::remove_dir_all(&base);
    fs::create_dir_all(base.join("papers")).expect("create fixture tree");
    fs::create_dir_all(base.join("src")).expect("create fixture tree");

    fs::write(
        base.join("papers/claim.md"),
        "# Claim\n\nThis theorem is machine-checked.\n",
    )
    .expect("write paper");
    fs::write(
        base.join("src/lib.rs"),
        "pub fn theorem() -> bool { todo!() }\n",
    )
    .expect("write code");
    fs::write(
        base.join("src/proof.lean"),
        "theorem t : True := by sorry\n",
    )
    .expect("write proof");

    let before = digest_tree(&base);
    assert_eq!(before.len(), 3, "fixture tree should hold three files");

    // A full run: derive, adjudicate, and inspect every row.
    let proposal = reconcile(&corpus());
    let result = run_reconciliation(proposal.rows.clone());
    assert!(!result.accepted.is_empty());

    let after = digest_tree(&base);
    assert_eq!(
        before, after,
        "the reconciler modified the tree it was reconciling"
    );

    // Nothing was created either — a new file is a mutation too.
    assert_eq!(
        before.keys().collect::<Vec<_>>(),
        after.keys().collect::<Vec<_>>(),
        "the reconciler added or removed a file"
    );

    let _ = fs::remove_dir_all(&base);
}

/// The proposal-only guarantee must be structural, not incidental: the module
/// may not reach for the filesystem or a process at all.
#[test]
fn reconciler_source_declares_no_write_capability() {
    let source = include_str!("../src/reconciler.rs");
    let production = match source.split_once("\n#[cfg(test)]") {
        Some((head, _)) => head,
        None => source,
    };
    for forbidden in [
        "std::fs",
        "fs::write",
        "File::create",
        "OpenOptions",
        "std::process",
        "Command::new",
        "remove_file",
        "remove_dir",
    ] {
        assert!(
            !production.contains(forbidden),
            "reconciler production code reaches for {forbidden:?}; it must stay a pure judgment"
        );
    }
}
