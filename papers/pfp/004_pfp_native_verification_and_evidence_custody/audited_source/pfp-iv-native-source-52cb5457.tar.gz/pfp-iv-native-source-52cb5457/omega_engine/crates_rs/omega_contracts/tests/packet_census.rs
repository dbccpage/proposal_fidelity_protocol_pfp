//! Two independent packet inventories, not a historical survey-count assertion.
//!
//! Governance rows describe only the current governance directory. Retained
//! Rust-local rows preserve that distinct corpus without asserting equivalence,
//! adoption, projection completion, or semantic reconciliation. Historical survey
//! findings remain historical; an absent survey is not an oracle for either set.
//! AuthorityEffect: None.

use std::collections::BTreeMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};

const REGISTER: &str = "omega_engine_governance/contracts/packets/README.md";
const RETAINED_DIR: &str =
    "omega_engine/crates_rs/omega_contracts/src/contract_canonical_definitions/09_core_packets";
const RETAINED_PREFIX: &str =
    "../../../omega_engine/crates_rs/omega_contracts/src/contract_canonical_definitions/09_core_packets/";

#[derive(Clone, Copy)]
enum Inventory {
    Governance,
    Retained,
}

impl Inventory {
    fn markers(self) -> (&'static str, &'static str) {
        match self {
            Self::Governance => (
                "<!-- packet-inventory:governance:start -->",
                "<!-- packet-inventory:governance:end -->",
            ),
            Self::Retained => (
                "<!-- packet-inventory:retained:start -->",
                "<!-- packet-inventory:retained:end -->",
            ),
        }
    }

    fn target_prefix(self) -> &'static str {
        match self {
            Self::Governance => "",
            Self::Retained => RETAINED_PREFIX,
        }
    }

    fn directory(self, root: &Path) -> PathBuf {
        match self {
            Self::Governance => root.join(REGISTER).parent().unwrap().to_path_buf(),
            Self::Retained => root.join(RETAINED_DIR),
        }
    }
}

fn repo_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(3)
        .expect("canonical Cargo workspace repository root")
        .to_path_buf()
}

fn inventory_section(register: &str, inventory: Inventory) -> Result<&str, String> {
    let (start, end) = inventory.markers();
    if register.matches(start).count() != 1 || register.matches(end).count() != 1 {
        return Err("PACKET_REGISTER_SECTION_INVALID".into());
    }
    let after = register.split_once(start).unwrap().1;
    let section = after
        .split_once(end)
        .ok_or("PACKET_REGISTER_SECTION_INVALID")?
        .0;
    if section.contains("<!-- packet-inventory:") {
        return Err("PACKET_REGISTER_SECTION_OVERLAP".into());
    }
    Ok(section)
}

fn inventory_rows(
    register: &str,
    inventory: Inventory,
) -> Result<BTreeMap<String, String>, String> {
    let mut rows = BTreeMap::new();
    for line in inventory_section(register, inventory)?
        .lines()
        .map(str::trim)
    {
        if line.is_empty() || line == "---" || line.starts_with("### ") {
            continue;
        }
        let (cell, description) = line
            .strip_prefix('|')
            .and_then(|tail| tail.strip_suffix('|'))
            .and_then(|tail| tail.split_once('|'))
            .ok_or("PACKET_REGISTER_ROW_MALFORMED")?;
        // Only split the filename cell: mathematical descriptions may themselves
        // contain escaped pipes. Require content, not a semantic prose schema.
        if !description
            .chars()
            .any(|value| !value.is_whitespace() && value != '|')
        {
            return Err("PACKET_REGISTER_ROW_MALFORMED".into());
        }
        let cell = cell.trim();
        if cell == "Packet Document" || cell == ":---" {
            continue;
        }
        let cell = cell
            .strip_prefix("**")
            .and_then(|value| value.strip_suffix("**"))
            .ok_or("PACKET_REGISTER_ROW_MALFORMED")?;
        let (name, target) = cell
            .strip_prefix("[\x60")
            .and_then(|value| value.split_once("\x60]("))
            .ok_or("PACKET_REGISTER_ROW_MALFORMED")?;
        let target = target
            .strip_suffix(')')
            .ok_or("PACKET_REGISTER_ROW_MALFORMED")?;
        if name.is_empty()
            || !name
                .bytes()
                .all(|value| value.is_ascii_alphanumeric() || b"_.-".contains(&value))
            || name.starts_with('.')
            || !(name.ends_with(".md") || name.ends_with(".json"))
            || name == "README.md"
        {
            return Err(format!("PACKET_REGISTER_FILENAME_INVALID:{name}"));
        }
        let expected = format!("{}{name}", inventory.target_prefix());
        if target != expected {
            return Err(format!("PACKET_REGISTER_TARGET_MISMATCH:{name}"));
        }
        if rows.insert(name.to_owned(), target.to_owned()).is_some() {
            return Err(format!("PACKET_REGISTER_DUPLICATE:{name}"));
        }
    }
    if rows.is_empty() {
        return Err("PACKET_REGISTER_EMPTY".into());
    }
    Ok(rows)
}

fn packet_names(directory: &Path, inventory: Inventory) -> Result<Vec<String>, String> {
    let entries = fs::read_dir(directory).map_err(|_| "PACKET_CORPUS_UNREADABLE".to_owned())?;
    let mut names = Vec::new();
    for entry in entries {
        let entry = entry.map_err(|_| "PACKET_CORPUS_UNREADABLE")?;
        let name = entry
            .file_name()
            .into_string()
            .map_err(|_| "PACKET_FILENAME_INVALID")?;
        if matches!(inventory, Inventory::Governance) && name == "README.md" {
            continue;
        }
        if !entry
            .file_type()
            .map_err(|_| "PACKET_CORPUS_UNREADABLE")?
            .is_file()
        {
            return Err(format!("PACKET_CORPUS_NONREGULAR:{name}"));
        }
        if !(name.ends_with(".md")
            || matches!(inventory, Inventory::Governance) && name.ends_with(".json"))
        {
            return Err(format!("PACKET_CORPUS_UNSUPPORTED_FILE:{name}"));
        }
        names.push(name);
    }
    names.sort();
    if names.is_empty() {
        return Err("PACKET_CORPUS_EMPTY".into());
    }
    Ok(names)
}

fn check_inventory(root: &Path, inventory: Inventory) -> Result<(), String> {
    let register_path = root.join(REGISTER);
    let register = fs::read_to_string(&register_path).map_err(|_| "PACKET_REGISTER_UNREADABLE")?;
    let rows = inventory_rows(&register, inventory)?;
    let directory = inventory.directory(root);
    let actual = packet_names(&directory, inventory)?;
    let declared: Vec<_> = rows.keys().cloned().collect();
    if declared != actual {
        let missing: Vec<_> = actual
            .iter()
            .filter(|name| !rows.contains_key(*name))
            .collect();
        let extra: Vec<_> = declared
            .iter()
            .filter(|name| !actual.contains(name))
            .collect();
        return Err(format!(
            "PACKET_INVENTORY_MISMATCH:unregistered={missing:?};absent={extra:?}"
        ));
    }
    for (name, target) in rows {
        let resolved = register_path
            .parent()
            .unwrap()
            .join(target)
            .canonicalize()
            .map_err(|_| "PACKET_TARGET_UNREADABLE")?;
        let expected = directory
            .join(&name)
            .canonicalize()
            .map_err(|_| "PACKET_TARGET_UNREADABLE")?;
        if resolved != expected {
            return Err(format!("PACKET_REGISTER_TARGET_MISMATCH:{name}"));
        }
    }
    Ok(())
}

#[test]
fn governance_packet_register_matches_its_own_corpus() {
    check_inventory(&repo_root(), Inventory::Governance).unwrap();
}

#[test]
fn retained_rust_packet_register_preserves_its_separate_corpus() {
    check_inventory(&repo_root(), Inventory::Retained).unwrap();
}

fn fixture_register(governance: &str, retained: &str) -> String {
    let (g_start, g_end) = Inventory::Governance.markers();
    let (r_start, r_end) = Inventory::Retained.markers();
    format!("{g_start}\n{governance}\n{g_end}\n{r_start}\n{retained}\n{r_end}\n")
}

fn fixture_row(name: &str, inventory: Inventory) -> String {
    format!(
        "| **[\x60{name}\x60]({}{name})** | fixture |\n",
        inventory.target_prefix()
    )
}

#[test]
fn register_parser_requires_exact_filename_and_portable_target_agreement() {
    let valid = fixture_row("a.md", Inventory::Governance);
    let retained = fixture_row("b.md", Inventory::Retained);
    let register = fixture_register(&valid, &retained);
    assert_eq!(
        inventory_rows(&register, Inventory::Governance)
            .unwrap()
            .len(),
        1
    );
    assert_eq!(
        inventory_rows(&register, Inventory::Retained)
            .unwrap()
            .len(),
        1
    );
    for (row, expected) in [
        ("| a.md | fixture |", "PACKET_REGISTER_ROW_MALFORMED"),
        (
            "| **[\x60a.md\x60](a.md)** | fixture",
            "PACKET_REGISTER_ROW_MALFORMED",
        ),
        (
            "| **[\x60a.md\x60](a.md)** |",
            "PACKET_REGISTER_ROW_MALFORMED",
        ),
        (
            "| **[\x60a.md\x60](a.md)** |   |",
            "PACKET_REGISTER_ROW_MALFORMED",
        ),
        (
            "| **[\x60a.md\x60](b.md)** | fixture |",
            "PACKET_REGISTER_TARGET_MISMATCH:a.md",
        ),
        (
            "| **[\x60a.md\x60](file:///a.md)** | fixture |",
            "PACKET_REGISTER_TARGET_MISMATCH:a.md",
        ),
        (
            "| **[\x60a.md\x60](../a.md)** | fixture |",
            "PACKET_REGISTER_TARGET_MISMATCH:a.md",
        ),
        (
            "| **[\x60../a.md\x60](../a.md)** | fixture |",
            "PACKET_REGISTER_FILENAME_INVALID:../a.md",
        ),
        (
            "| **[\x60README.md\x60](README.md)** | fixture |",
            "PACKET_REGISTER_FILENAME_INVALID:README.md",
        ),
    ] {
        assert_eq!(
            inventory_rows(&fixture_register(row, &retained), Inventory::Governance).unwrap_err(),
            expected
        );
    }
    assert_eq!(
        inventory_rows(
            &fixture_register(&(valid.clone() + &valid), &retained),
            Inventory::Governance
        )
        .unwrap_err(),
        "PACKET_REGISTER_DUPLICATE:a.md"
    );
}

#[test]
fn register_sections_are_nonempty_unique_and_cannot_leak_rows() {
    let gov = fixture_row("a.md", Inventory::Governance);
    let retained = fixture_row("b.md", Inventory::Retained);
    let original = fixture_register(&gov, &retained);
    let (start, end) = Inventory::Governance.markers();
    for damaged in [
        original.replace(start, ""),
        original.replace(end, ""),
        format!("{start}\n{original}"),
        format!("{end}\n{start}"),
    ] {
        assert_eq!(
            inventory_rows(&damaged, Inventory::Governance).unwrap_err(),
            "PACKET_REGISTER_SECTION_INVALID"
        );
    }
    assert_eq!(
        inventory_rows(&fixture_register("", &retained), Inventory::Governance).unwrap_err(),
        "PACKET_REGISTER_EMPTY"
    );
    assert_eq!(
        inventory_rows(&fixture_register(&gov, ""), Inventory::Retained).unwrap_err(),
        "PACKET_REGISTER_EMPTY"
    );
    assert_eq!(
        inventory_rows(&fixture_register(&retained, &gov), Inventory::Governance).unwrap_err(),
        "PACKET_REGISTER_TARGET_MISMATCH:b.md"
    );
    let (r_start, r_end) = Inventory::Retained.markers();
    let overlap = format!("{start}\n{r_start}\n{gov}{end}\n{retained}{r_end}");
    assert_eq!(
        inventory_rows(&overlap, Inventory::Governance).unwrap_err(),
        "PACKET_REGISTER_SECTION_OVERLAP"
    );
}

static NEXT_FIXTURE: AtomicU64 = AtomicU64::new(0);
struct FixtureRoot(PathBuf);

impl FixtureRoot {
    fn new() -> Self {
        let root = std::env::temp_dir().join(format!(
            "omega-packet-census-{}-{}-{}",
            std::process::id(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos(),
            NEXT_FIXTURE.fetch_add(1, Ordering::Relaxed),
        ));
        fs::create_dir(&root).expect("create owned finite fixture root");
        Self(root)
    }

    fn populate(&self) {
        let governance = Inventory::Governance.directory(&self.0);
        let retained = Inventory::Retained.directory(&self.0);
        fs::create_dir_all(&governance).unwrap();
        fs::create_dir_all(&retained).unwrap();
        fs::write(governance.join("a.md"), b"governance fixture").unwrap();
        fs::write(retained.join("b.md"), b"retained fixture").unwrap();
        fs::write(
            self.0.join(REGISTER),
            fixture_register(
                &fixture_row("a.md", Inventory::Governance),
                &fixture_row("b.md", Inventory::Retained),
            ),
        )
        .unwrap();
    }
}

impl Drop for FixtureRoot {
    fn drop(&mut self) {
        fs::remove_dir_all(&self.0).expect("remove only the owned finite fixture root");
    }
}

#[test]
fn actual_filesystem_census_refuses_missing_extra_empty_and_unreadable_inputs() {
    for inventory in [Inventory::Governance, Inventory::Retained] {
        let root = FixtureRoot::new();
        root.populate();
        assert!(check_inventory(&root.0, Inventory::Governance).is_ok());
        assert!(check_inventory(&root.0, Inventory::Retained).is_ok());
        let directory = inventory.directory(&root.0);
        let name = match inventory {
            Inventory::Governance => "a.md",
            Inventory::Retained => "b.md",
        };
        fs::remove_file(directory.join(name)).unwrap();
        assert_eq!(
            check_inventory(&root.0, inventory).unwrap_err(),
            "PACKET_CORPUS_EMPTY"
        );
        fs::write(directory.join("extra.md"), b"unregistered file").unwrap();
        let error = check_inventory(&root.0, inventory).unwrap_err();
        assert!(error.starts_with("PACKET_INVENTORY_MISMATCH:"));
        assert!(
            error.contains("extra.md") && error.contains(name),
            "{error}"
        );
        fs::write(directory.join(name), b"restored fixture").unwrap();
        assert!(check_inventory(&root.0, inventory)
            .unwrap_err()
            .contains("unregistered=[\"extra.md\"]"));
        fs::remove_file(directory.join("extra.md")).unwrap();
        assert!(check_inventory(&root.0, inventory).is_ok());
        let register_path = root.0.join(REGISTER);
        let original = fs::read_to_string(&register_path).unwrap();
        let end = inventory.markers().1;
        fs::write(
            &register_path,
            original.replace(
                end,
                &format!("{}{end}", fixture_row("missing.md", inventory)),
            ),
        )
        .unwrap();
        assert!(check_inventory(&root.0, inventory)
            .unwrap_err()
            .contains("absent=[\"missing.md\"]"));
        fs::write(&register_path, original).unwrap();
        assert!(check_inventory(&root.0, inventory).is_ok());
        fs::write(directory.join("unexpected.txt"), b"unsupported file").unwrap();
        assert_eq!(
            check_inventory(&root.0, inventory).unwrap_err(),
            "PACKET_CORPUS_UNSUPPORTED_FILE:unexpected.txt"
        );
        fs::remove_file(directory.join("unexpected.txt")).unwrap();
        fs::create_dir(directory.join("fake.md")).unwrap();
        assert_eq!(
            check_inventory(&root.0, inventory).unwrap_err(),
            "PACKET_CORPUS_NONREGULAR:fake.md"
        );
    }
    let root = FixtureRoot::new();
    assert_eq!(
        check_inventory(&root.0, Inventory::Governance).unwrap_err(),
        "PACKET_REGISTER_UNREADABLE"
    );
    assert_eq!(
        packet_names(&root.0.join("missing"), Inventory::Retained).unwrap_err(),
        "PACKET_CORPUS_UNREADABLE"
    );
    let file = root.0.join("not-a-directory");
    fs::write(&file, b"file").unwrap();
    assert_eq!(
        packet_names(&file, Inventory::Retained).unwrap_err(),
        "PACKET_CORPUS_UNREADABLE"
    );
}
