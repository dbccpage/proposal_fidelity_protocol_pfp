//! NDJSON ledger serialization for reconciliation rows.
//!
//! The reconciliation ledger is an append-only, line-oriented record: one
//! [`ReconciliationRow`] per line, each a self-contained JSON object. NDJSON is
//! chosen over a single JSON array so the ledger can be streamed, `tail`-ed, and
//! diffed line-by-line, and so a malformed tail never corrupts earlier rows.
//!
//! Round-trip law: `read_ndjson(write_ndjson(rows)) == rows` (up to row order,
//! which is preserved here).
//
// TODO(phase3): link live omega_contract_core::validate / anomalon_councils so the
// ledger writer can attach a council-signed seal per row.
use crate::row::ReconciliationRow;

/// Serialize rows to NDJSON: one compact JSON object per line, `\n`-joined, with
/// a trailing newline. An empty slice yields the empty string. Serialization is
/// fallible (a schema/serde failure is surfaced as `serde_json::Error`) rather than
/// panicking, so callers control how a malformed row is handled.
pub fn write_ndjson(rows: &[ReconciliationRow]) -> Result<String, serde_json::Error> {
    let mut out = String::new();
    for row in rows {
        let line = serde_json::to_string(row)?;
        out.push_str(&line);
        out.push('\n');
    }
    Ok(out)
}

/// Parse NDJSON back into rows. Blank lines (including the trailing newline) are
/// skipped; every non-blank line must be a valid `ReconciliationRow` JSON object.
pub fn read_ndjson(s: &str) -> Result<Vec<ReconciliationRow>, serde_json::Error> {
    let mut rows = Vec::new();
    for line in s.lines() {
        if line.trim().is_empty() {
            continue;
        }
        let row: ReconciliationRow = serde_json::from_str(line)?;
        rows.push(row);
    }
    Ok(rows)
}
