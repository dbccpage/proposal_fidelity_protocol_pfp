Atlas Reconciliation Crate Architecture Summary
===============================================

This document summarizes the architecture, purpose, and contents of the files in the [`omega_atlas_reconciliation`](.) crate.

Purpose of the Crate
--------------------

The `omega_atlas_reconciliation` crate acts as a deterministic verification and cross-examination loop. Its purpose is to reconcile and audit metadata relations across the entire repository spine:
$$\text{Code} \longleftrightarrow \text{Product Claim} \longleftrightarrow \text{Paper} \longleftrightarrow \text{Proof} \longleftrightarrow \text{Contract} \longleftrightarrow \text{Doctrine}$$

It ensures that code implementations, prose preprints, Lean proofs, and runtime authority contracts conform to defined invariants (representing a strict-regime version of the UROS Tower). Most of the actual mathematical logic and runtime contracts reside in the math and contracts crates; this crate functions primarily as a diagnostic wrapper and conformance-testing loop over their metadata representation (`ReconciliationRow`).

---

File Summaries
--------------

### 1. Core Engine and Adjudication

#### [`lib.rs`](./src/lib.rs)

* Defines the crate root and registers the module hierarchy.

#### [`row.rs`](./src/row.rs)

* Contains the main schema [`ReconciliationRow`](./src/row.rs#L160) which represents the complete finite judgment for an individual asset.
* Re-exports key kinds from downstream crates (e.g. `ComponentRole` and `EvidenceCeiling`) to prevent fragmentation.
* Implements authority ranking (`authority_rank`) to evaluate relative strength.

#### [`validator.rs`](./src/validator.rs)

* Implements [`validate_row`](./src/validator.rs#L19), the core deterministic verification gate.
* Enforces the three main invariants:
  1. **Invariant I (Primitive Difference):** Ensures non-factoring observables declare a residual class.
  2. **Invariant II (Cochain Validity):** Computes coboundaries overcarried matrices to ensure they compose to zero.
  3. **Invariant III (Identity Conservation):** Rejects any classification that risks erasing identity (no impersonation).
* Verifies that authority ceilings are respected and checks the two-axis honesty rule (no paper-only "mechanized" claims).

#### [`runner.rs`](./src/runner.rs)

* Implements the host adjudication runner (`run_reconciliation`) that validates a batch of proposed rows.
* Defines [`seed_rows`](./src/runner.rs#L108), providing seven confirmed first-slice seed finding rows representing real mismatches (e.g., oversold statements, missing tests, and authority drift).

#### [`slice.rs`](./src/slice.rs)

* Implements the strict slice ordering: `AuthorityCore -> GovernmentCore -> EncLibrary -> ProductSpine`.
* Sorts assets so foundational gates and authority definitions are verified before product-level logic consumes them.

---

### 2. Invariants and Serialization

#### [`primitive_difference.rs`](./src/primitive_difference.rs)

* Represents Invariant I. Models a basic finite checker for `PrimitiveDifference` and records judgments showing whether an observable factors through a zero-difference/equivalence quotient.

#### [`cochain_validity.rs`](./src/cochain_validity.rs)

* Represents Invariant II. Computes and validates if the consecutive coboundary maps compose to zero ($d_1 \circ d_0 = 0$) over $F_2$, signifying a valid cochain complex.

#### [`identity_witness.rs`](./src/identity_witness.rs)

* Represents Invariant III. Defines structural identity witnesses (e.g., the *Borges-tiger* exemplar) ensuring unique object identities are conserved across edges.

#### [`ledger.rs`](./src/ledger.rs)

* Implements newline-delimited JSON (NDJSON) reader/writer routines for streaming and diffing reconciliation rows line-by-line.

#### [`render.rs`](./src/render.rs)

* Formats a slice of `ReconciliationRow`s into a compact markdown table for reporting.

#### [`terminalize.rs`](./src/terminalize.rs)

* Maps the cochain boundary status into terminal classifications (`ExactRepair`, `StabilizedSurvivor`, `OpenObstruction`).

---

### 3. Observers (`src/observers/`)

The observers cross-examine each row from seven independent, pure, deterministic vantage points.

* **[`observers/mod.rs`](./src/observers/mod.rs):** Orchestrator executing all seven observers in standard order.
* **[`code.rs`](./src/observers/code.rs):** Verifies that code assets build and have green/CI-gated tests.
* **[`contract_authority.rs`](./src/observers/contract_authority.rs):** Evaluates if a declared authority effect exceeds its role pin.
* **[`government_law.rs`](./src/observers/government_law.rs):** Validates strict role/power separation and complete licensed lifts.
* **[`math_proof.rs`](./src/observers/math_proof.rs):** Checks for axomatic honesty on Lean vs prose proofs.
* **[`product_claim.rs`](./src/observers/product_claim.rs):** Cross-checks product claims against observations to map claim deltas.
* **[`public_risk.rs`](./src/observers/public_risk.rs):** Guards against unauthorized authority/minting language on public surfaces.
* **[`system_seam.rs`](./src/observers/system_seam.rs):** Checks if the product is reachable as a runnable system surface.
