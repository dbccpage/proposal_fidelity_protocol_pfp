status: mathematical_wip
authority_effect: none
customer_claim_allowed: false

Linear Algebra to Higher Mathematics Contract Graph
===================================================

This document combines and extends:

* `the_fiber_map.md`
* `the_fiber_map_with_obstruction_and_cohomological_extensions.md`

Its purpose is to give Omega Engine and LLM workers a top-down dependency graph for the mathematical contracts we need as we build from finite linear algebra into quantum mechanics, homology, homotopy, HoTT, category theory, sheaf theory, and higher category theory.

The contract doctrine is the same as `basic_matrix.md`: these contracts emit mathematical structures, facts, validation witnesses, and computation witnesses. They do not confer operational authority. Every artifact has `authority_effect: none` unless a separate authority layer terminalizes it.

---

0. Top-Down Primitive Object Graph
----------------------------------

Arrows point from provider to consumer. The graph is intentionally finite and Rust-encodable at the bottom. Infinite, smooth, or higher-categorical objects enter only through finite presentations, finite shadows, schemas, witnesses, or declared oracles.

```text
L0 Replay / Artifact Substrate
  ContractId
  Version
  Hash32
  CanonicalBytes
  StructureArtifact
  FactEnvelope
  ValidationWitness
  ComputationWitness
  FailureWitness
  LedgerRef
  DeterministicAlgorithmRef
        |
        v
L1 Scalar / Finite Carrier Primitives
  FieldSpec
  Scalar
  IndexSet
  Dimension
  OrderedBasis
  FiniteSet
  Relation
  EquivalenceRelation
  FunctionTable
  Permutation
        |
        v
L2 Linear Algebra Core
  VectorSpace
  Vector
  Covector
  DualSpace
  DualBasis
  BasicMatrix
  LinearMap
  BilinearForm
  InnerProduct
  TensorProduct
  ExteriorPower
  DirectSum
  QuotientSpace
  Subspace
  Projection
  Inclusion
        |
        v
L3 Operator / Spectral / Fiber Layer
  Endomorphism
  Adjoint
  Trace
  Determinant
  Rank
  Kernel
  Image
  Cokernel
  Projector
  Idempotent
  EigenPair
  SpectralDecomposition
  Fiber
  BaseSpace
  Bundle
  ProjectionMap
  Section
  Trivialization
  TransitionFunction
        |
        +-------------------------+
        |                         |
        v                         v
L4A Quantum Mechanics          L4B Chain / Cochain Algebra
  HilbertSpace                  GradedModule
  Ket                           ChainGroup
  Bra                           CochainGroup
  DensityMatrix                 BoundaryMap
  Observable                    CoboundaryMap
  Unitary                       ChainComplex
  Isometry                      CochainComplex
  Commutator                    Cycle
  ProjectiveMeasurement         Boundary
  POVM                          Cocycle
  QuantumChannel                Coboundary
  PartialTrace                  HomologyClass
  TensorFactorization           CohomologyClass
  EntanglementWitness           ExactSequence
        |                         |
        +-----------+-------------+
                    |
                    v
L5 Geometry / Cohomology / Obstruction
  TopologicalSpace
  SimplicialComplex
  CellComplex
  Cover
  Nerve
  DifferentialForm
  Connection
  Curvature
  CharacteristicForm
  CechCochain
  CechCocycle
  CechCohomology
  deRhamComplex
  deRhamCohomology
  Sheaf
  Presheaf
  RestrictionMap
  SheafCohomology
  ObstructionClass
  ObstructionTheory
  ExistenceOfSection
                    |
                    v
L6 Homotopy / HoTT
  Path
  Homotopy
  HomotopyClass
  FundamentalGroup
  HigherHomotopyGroup
  Fibration
  FiberSequence
  LongExactSequence
  TypeUniverse
  Type
  Term
  IdentityType
  Equivalence
  ContractibleType
  TruncationLevel
  UnivalenceWitness
                    |
                    v
L7 Category Theory
  Category
  Object
  Morphism
  IdentityMorphism
  CompositionLaw
  Isomorphism
  Functor
  NaturalTransformation
  Adjunction
  Limit
  Colimit
  MonoidalCategory
  EnrichedCategory
                    |
                    v
L8 Sheaves / Stacks / Higher Categories
  Site
  GrothendieckTopology
  SheafOnSite
  Stack
  Groupoid
  Bicategory
  TwoCategory
  DoubleCategory
  InfinityCategory
  HigherFunctor
  HigherNaturalTransformation
  DescentData
  Hypercover
  HigherObstructionClass
```

### Minimal Rust Bottom Layer

The bottom layer must be boring, deterministic, and aggressively replayable. Do not start with manifolds, sheaves, or quantum channels. Start with these Rust-encodable primitives:

```rust
pub struct Hash32(pub [u8; 32]);

pub struct ContractId(pub String);
pub struct ContractVersion(pub String);

pub struct CanonicalBytes {
    pub encoding_id: String,
    pub bytes_hash: Hash32,
    pub byte_len: u64,
}

pub struct StructureArtifact<D> {
    pub contract_id: ContractId,
    pub version: ContractVersion,
    pub descriptor: D,
    pub artifact_hash: Hash32,
}

pub struct ValidationWitness {
    pub validator_id: String,
    pub input_hashes: Vec<Hash32>,
    pub passed: bool,
    pub failure_code: Option<String>,
    pub witness_hash: Hash32,
}

pub struct ComputationWitness {
    pub algorithm_id: String,
    pub input_hashes: Vec<Hash32>,
    pub output_hashes: Vec<Hash32>,
    pub deterministic_trace_hash: Hash32,
}

pub struct FactEnvelope {
    pub fact_id: String,
    pub subject_hash: Hash32,
    pub witness_hashes: Vec<Hash32>,
    pub fact_hash: Hash32,
}
```

Everything else should compile down to descriptors that point at these structures.

---

1. Contract Artifact Doctrine
-----------------------------

Every math contract should declare:

1. Contract metadata.
2. Mathematical role.
3. Allowed artifact types.
4. Forbidden authority.
5. Required inputs.
6. Validation requirements.
7. Witness requirements.
8. Replay requirements.
9. Rust descriptor mapping.
10. Negative tests.
11. Open questions / WIP status.

The existing `basic_matrix.md` is the model.

### Allowed Artifacts

| Artifact | Role |
|---|---|
| `StructureArtifact` | The canonical mathematical structure and descriptor hash. |
| `FactEnvelope` | A decidable or witnessed fact about a structure. |
| `ValidationWitness` | Evidence that an input passed or failed a validator. |
| `ComputationWitness` | Evidence that a deterministic computation produced an output. |
| `FailureWitness` | Typed failure when a contract refuses construction or computation. |

### Forbidden Authority

No math contract may claim:

```text
safe
trusted
approved
admissible-for-production
legally certified
leaderboard-correct
runtime-authoritative
```

The contract can only say:

```text
this finite mathematical artifact is well formed under this contract
this deterministic computation replayed
this fact was witnessed under this validator
this construction failed for this typed reason
```

---

2. Existing Contract Inventory
------------------------------

Current math contracts already present in this folder:

| Existing file | Contract role |
|---|---|
| `field.md` | Field specification and scalar arithmetic source. |
| `scaler.md` | Scalar contract. Rename or alias to `scalar.md` later. |
| `vector_space.md` | Finite-dimensional vector-space carrier. |
| `vector.md` | Vector in a carrier/fiber. |
| `dual_basis.md` | Dual basis and covector/functionals. |
| `basic_matrix.md` | Dense matrix as finite representation of a linear map. |
| `matrix.md` | Matrix contract variant; should reconcile with `basic_matrix.md`. |
| `linear_map.md` | Linear map between finite-dimensional carriers/fibers. |
| `fiber.md` | Local vector-space fiber over a base point. |
| `base_space.md` | Base-space contract. |
| `bundle.md` | Bundle contract. |
| `fiber_bundle.md` | Fiber-bundle contract variant; should reconcile with `bundle.md`. |
| `projection_map.md` | Bundle projection. |
| `section.md` | Section of a bundle. |
| `trivialization.md` | Local trivialization. |
| `connection.md` | Connection structure. |
| `curvature.md` | Curvature structure. |
| `inner_product.md` | Inner product. |
| `metric_bundle.md` | Bundle with metric/inner-product structure. |
| `principal_bundle.md` | Principal bundle. |
| `orientation.md` | Orientation structure. |

Immediate cleanup needed:

1. Decide whether `scaler.md` is a typo for `scalar.md`; create alias or rename plan.
2. Reconcile `matrix.md` and `basic_matrix.md`; either split `BasicMatrix` from richer matrix facts or retire duplication.
3. Reconcile `bundle.md` and `fiber_bundle.md`; decide whether `Bundle` is generic and `FiberBundle` is a specialization.

---

3. Combined Fiber Map
---------------------

The original fiber map gives the local-to-global dependency spine:

```text
Field -> Scalar -> VectorSpace -> Fiber
                         |
                         v
Vector <-> LinearMap <-> Section
                         |
                         v
BaseSpace -> Bundle -> ProjectionMap -> Trivialization
                         |
                         v
                  TransitionFunction
                         |
                         v
                  Connection -> Curvature
                         |
                         v
                  InnerProduct -> MetricBundle
```

### Fiber-Layer Contracts

| Contract | Minimal contents | Why it is needed |
|---|---|---|
| `Field` | `field_id`, characteristic, representation, canonical encoding, arithmetic implementation hash. | All scalar arithmetic depends on this. |
| `Scalar` | `field_id`, canonical bytes, scalar hash. | Every vector/matrix entry is a scalar. |
| `VectorSpace` | field, finite dimension, ordered basis hash. | Common carrier for linear algebra. |
| `Fiber` | base point, field, dimension, ordered basis hash. | Local vector space indexed by a base point. |
| `Vector` | carrier/fiber hash, component list, vector hash. | Element of a vector space or fiber. |
| `DualBasis` | fiber/vector-space hash, dual functional list hash. | Enables covectors and evaluation. |
| `LinearMap` | domain, codomain, matrix/artifact hash. | Morphism between finite carriers. |
| `BaseSpace` | point representation, point hashing, optional topology/atlas. | Gives meaning to `base_point_id`. |
| `Bundle` | base space, rank, field, projection, local fibers. | Family of fibers over a base. |
| `ProjectionMap` | total space to base space map. | Assigns total-space points to fibers. |
| `Trivialization` | local product equivalence. | Makes abstract bundle locally computable. |
| `TransitionFunction` | overlap, source/target chart, linear isomorphism. | Glues local trivializations. |
| `Section` | deterministic assignment from base point to fiber vector. | Main operational use of bundles. |
| `InnerProduct` | Gram matrix on a carrier/fiber. | Norms, adjoints, Hilbert spaces. |
| `Connection` | covariant derivative / connection one-form data. | Parallel transport and curvature. |
| `Curvature` | curvature two-form / commutator of covariant derivatives. | Characteristic classes and obstruction signals. |

---

4. Obstruction and Cohomological Extension
------------------------------------------

The extended map adds differential, Cech, sheaf, and obstruction layers:

```text
Bundle -> TransitionFunction -> CechCocycle -> CechClass
      \                                      \
       Connection -> Curvature -> CharacteristicForm -> deRhamClass
          \                                      \
           \                                      v
            +-------------------------> ObstructionClass
                                              |
                                              v
                                      ObstructionTheory
                                              |
                                              v
                                      ExistenceOfSection
```

### Cohomology and Obstruction Contracts

| Contract | Minimal contents | Rust-encodable finite shadow |
|---|---|---|
| `DifferentialForm` | degree, base space, coefficient bundle, component representation. | Finite chart representation or symbolic form descriptor. |
| `ExteriorDerivative` | deterministic algorithm for `d`. | Computation witness from one form artifact to another. |
| `deRhamComplex` | graded forms and differential `d`. | Finite symbolic complex or sampled finite shadow. |
| `deRhamCohomology` | `ker d / im d`. | Finite cochain complex descriptor plus quotient witnesses. |
| `deRhamClass` | closed form modulo exact forms. | Class representative hash plus exactness/non-exactness witness. |
| `Cover` | indexed open cover or finite approximation. | Finite index set, overlap relation, chart hashes. |
| `Nerve` | simplicial complex of nonempty intersections. | Finite simplicial complex descriptor. |
| `CechCochain` | assignment to cover intersections. | Finite table keyed by simplex/index tuple. |
| `CechCocycle` | Cech cochain with zero coboundary. | Coboundary validation witness. |
| `CechCohomology` | Cech cocycles modulo coboundaries. | Finite cochain quotient. |
| `Sheaf` | local data plus restrictions satisfying gluing/locality. | Presheaf table plus sheaf-condition witnesses over finite cover. |
| `RestrictionMap` | map from larger open to smaller open. | Function table or deterministic algorithm ref. |
| `SheafCohomology` | derived/global obstruction classes. | Cech model over finite cover first. |
| `CharacteristicForm` | invariant polynomial applied to curvature. | Polynomial descriptor plus curvature input hash. |
| `ChernWeilMap` | invariant polynomial to deRham class. | Computation witness. |
| `ObstructionClass` | class in cohomology group obstructing lift/section/extension. | Cohomology class hash plus target problem descriptor. |
| `ObstructionTheory` | staged extension algorithm over filtration/skeleton. | Sequence of extension attempts and obstruction witnesses. |
| `ExistenceOfSection` | terminal fact about existence/nonexistence of global section. | FactEnvelope referencing vanishing/nonvanishing obstruction classes. |

### Obstruction Contract Rule

An obstruction contract must never merely say "fails." It must say:

```text
where the extension was attempted
what finite carrier or cover was used
which cochain/cocycle was produced
which quotient/cohomology group it lives in
whether it is zero, exact, closed non-exact, or open
what terminal follows
```

This aligns with CODA-FOC:

```text
Exact: obstruction repairs away.
Closed survivor: obstruction is coherent but nonzero.
Open: closure fails; lift/refusal/new regime required.
```

---

5. Primitive Contract Backlog by Layer
--------------------------------------

The backlog below is ordered by implementation priority, not mathematical glamour.

### L0: Replay and Artifact Substrate

These are shared by every contract.

| Contract | Required before |
|---|---|
| `CanonicalBytes` | every hash-bearing artifact |
| `HashAlgorithm` | every artifact |
| `StructureArtifact` | every structure |
| `FactEnvelope` | every fact contract |
| `ValidationWitness` | every validator |
| `ComputationWitness` | every operation |
| `FailureWitness` | every rejected construction |
| `DeterministicAlgorithmRef` | every replayable computation |

Rust priority:

```text
Hash32
ContractId
ContractVersion
ArtifactHash
ValidatorId
AlgorithmId
WitnessHash
FailureCode
```

### L1: Scalar and Carrier Primitives

| Contract | Rust descriptor fields |
|---|---|
| `FieldSpec` | field id, characteristic, exact/approx flag, arithmetic module hash, encoding id. |
| `Scalar` | field id, canonical bytes hash, scalar hash. |
| `IndexSet` | finite cardinality, labels hash, ordering policy. |
| `Dimension` | nonnegative integer, semantic role. |
| `OrderedBasis` | carrier id, basis vector labels, order hash. |
| `FiniteSet` | element encoding, element hashes, cardinality. |
| `Relation` | domain set, codomain set, relation table/hash. |
| `EquivalenceRelation` | set, relation, reflexive/symmetric/transitive witnesses. |
| `FunctionTable` | domain, codomain, output table hash, totality witness. |
| `Permutation` | finite set, bijection table, inverse witness. |

These contracts unblock matrices, vectors, bases, chain complexes, finite covers, Cech cochains, and finite category presentations.

### L2: Linear Algebra Core

| Contract | Depends on | Minimal validators |
|---|---|---|
| `VectorSpace` | FieldSpec, Dimension, OrderedBasis | basis length, field consistency. |
| `Vector` | VectorSpace, Scalar | component count, scalar field membership. |
| `Covector` | DualSpace, Scalar | dual dimension, field membership. |
| `DualSpace` | VectorSpace | dimension match, dual-basis construction. |
| `BasicMatrix` | FieldSpec, domain/codomain bases | row/col count, entry validity. |
| `LinearMap` | BasicMatrix, VectorSpace | matrix shape matches domain/codomain. |
| `BilinearForm` | VectorSpace, BasicMatrix | square matrix or two-carrier shape. |
| `InnerProduct` | BilinearForm | symmetry/hermitian, positive-definite witness where exact. |
| `TensorProduct` | VectorSpace pair | dimension product, basis product ordering. |
| `ExteriorPower` | VectorSpace | degree bound, alternating basis. |
| `DirectSum` | VectorSpace list | dimension sum, injection/projection maps. |
| `Subspace` | VectorSpace, basis list | independence and inclusion witness. |
| `QuotientSpace` | VectorSpace, Subspace | quotient basis and projection witness. |

### L3: Operators and Fiber Geometry

| Contract | Depends on | Required facts |
|---|---|---|
| `Endomorphism` | LinearMap | domain equals codomain. |
| `Adjoint` | InnerProduct, LinearMap | adjoint identity witness. |
| `Trace` | Endomorphism | diagonal sum computation witness. |
| `Determinant` | square BasicMatrix | determinant algorithm witness. |
| `Rank` | BasicMatrix | row-reduction or minor witness. |
| `Kernel` | LinearMap | nullspace basis witness. |
| `Image` | LinearMap | column-space/image basis witness. |
| `Cokernel` | LinearMap | quotient codomain/image witness. |
| `Projector` | Endomorphism | idempotence witness `P^2=P`. |
| `EigenPair` | Endomorphism | `A v = lambda v` witness. |
| `SpectralDecomposition` | Endomorphism | eigenbasis/projector decomposition witness. |
| `Fiber` | VectorSpace, BaseSpace point | base point hash, local basis. |
| `Bundle` | BaseSpace, Fiber schema | rank consistency, projection. |
| `TransitionFunction` | Bundle, LinearMap | overlap and cocycle compatibility. |
| `Section` | Bundle, Vector | pointwise fiber membership. |
| `Connection` | Bundle, forms/maps | covariant derivative contract. |
| `Curvature` | Connection | curvature computation witness. |

---

6. Quantum Mechanics Contracts
------------------------------

Quantum mechanics should not start with "quantum" types. It should start with exact linear algebra plus inner-product discipline.

### QM Dependency Spine

```text
FieldSpec(complex) -> VectorSpace -> InnerProduct -> HilbertSpace
HilbertSpace -> Ket / Bra -> LinearOperator -> Observable
HilbertSpace -> TensorProduct -> CompositeSystem -> PartialTrace
Observable -> Projector / POVM -> Measurement
DensityMatrix -> QuantumChannel -> Evolution / Noise
Commutator -> Compatibility / Uncertainty facts
```

### QM Contract Backlog

| Contract | Minimal contents | Validators |
|---|---|---|
| `ComplexField` | exact/symbolic complex or reproducible numeric complex. | canonical encoding, conjugation. |
| `HilbertSpace` | complex vector space plus inner product. | positive-definite/hermitian witness. |
| `Ket` | vector in Hilbert space. | vector membership, optional norm. |
| `Bra` | covector adjoint to ket. | conjugate-transpose witness. |
| `LinearOperator` | endomorphism of Hilbert space. | shape/domain equality. |
| `SelfAdjointOperator` | operator. | `A = A*` witness. |
| `UnitaryOperator` | operator. | `U*U=I` witness. |
| `ProjectorOperator` | operator. | `P^2=P`, self-adjoint if orthogonal. |
| `Observable` | self-adjoint operator. | spectral theorem witness when available. |
| `DensityMatrix` | positive trace-one operator. | trace = 1, positive semidefinite witness. |
| `PureState` | rank-one projector or normalized ket. | rank/norm witness. |
| `TensorFactorization` | Hilbert spaces and product basis. | dimension product, basis order. |
| `PartialTrace` | composite density matrix plus subsystem choice. | trace-out computation witness. |
| `POVM` | positive operators summing to identity. | positivity and sum witness. |
| `Measurement` | POVM or projective measurement plus outcome set. | probability normalization. |
| `QuantumChannel` | completely positive trace-preserving map. | Kraus representation witness or Choi witness. |
| `Commutator` | pair of operators. | `AB-BA` computation witness. |
| `EntanglementWitness` | observable/fact envelope. | witness inequality and state reference. |

Important Rust boundary:

```text
Exact symbolic QM first.
Floating-point QM only after FieldSpec declares reproducible rounding/tolerance.
```

---

7. Homology and Cohomology Contracts
------------------------------------

Homology is finite linear algebra over graded modules when implemented correctly.

### Homology Dependency Spine

```text
FieldSpec / RingSpec
  -> GradedModule
  -> BoundaryMap
  -> ChainComplex
  -> Cycle / Boundary
  -> HomologyGroup
  -> HomologyClass

DualSpace / LinearMap
  -> CoboundaryMap
  -> CochainComplex
  -> Cocycle / Coboundary
  -> CohomologyGroup
  -> CohomologyClass
```

### Contract Backlog

| Contract | Minimal contents | Validators |
|---|---|---|
| `RingSpec` | ring id, addition/multiplication encoding. | ring-law witnesses for finite rings. |
| `GradedModule` | degree-indexed modules/vector spaces. | degree map and carrier consistency. |
| `BoundaryMap` | degree `n` map `C_n -> C_{n-1}`. | domain/codomain degree check. |
| `ChainComplex` | graded modules plus boundary maps. | `d_n d_{n+1}=0`. |
| `Cycle` | chain in kernel of boundary. | boundary-zero witness. |
| `Boundary` | chain in image of previous boundary. | preimage witness. |
| `HomologyGroup` | `ker d / im d`. | quotient construction witness. |
| `HomologyClass` | cycle modulo boundaries. | representative and equivalence witness. |
| `CoboundaryMap` | degree `n` map `C^n -> C^{n+1}`. | `delta delta = 0`. |
| `CochainComplex` | cochain groups plus coboundary maps. | complex law. |
| `Cocycle` | cochain with zero coboundary. | closure witness. |
| `Coboundary` | cochain in image of previous coboundary. | preimage witness. |
| `CohomologyGroup` | `ker delta / im delta`. | quotient construction witness. |
| `CohomologyClass` | cocycle modulo coboundaries. | representative/equivalence witness. |
| `ExactSequence` | sequence of maps. | image equals kernel at each node. |
| `ChainMap` | maps between chain complexes. | commutes with boundary. |
| `ChainHomotopy` | homotopy between chain maps. | chain homotopy equation witness. |

CODA-FOC connects here directly:

```text
C^0 -> C^1 -> C^2
Q^1 = C^1 / im(d0)
closed residuals = ker(d1_bar)
survivors = ker(d1_bar) \ {0}
```

---

8. Homotopy and HoTT Contracts
------------------------------

Homotopy contracts must be finite-presented. HoTT contracts must be syntactic/proof-object contracts unless and until a trusted proof kernel is integrated.

### Homotopy Contracts

| Contract | Minimal finite presentation |
|---|---|
| `TopologicalSpace` | finite topology, simplicial complex, cell complex, or declared oracle. |
| `SimplicialComplex` | finite vertex set and simplex list closed under faces. |
| `CellComplex` | cells by dimension plus attaching maps. |
| `Path` | endpoints plus finite combinatorial path or symbolic path descriptor. |
| `Homotopy` | two paths/maps plus finite cylinder/simplicial witness. |
| `HomotopyClass` | representative plus equivalence witness. |
| `FundamentalGroup` | base point, loop generators, relations. |
| `HigherHomotopyGroup` | degree, base point, finite presentation or oracle witness. |
| `Fibration` | total/base/fiber plus lifting property witness. |
| `FiberSequence` | composable maps plus fiber identification. |
| `LongExactSequence` | exact sequence associated to fibration/pair. |
| `ObstructionClassHomotopy` | class in `H^{k+1}(B; pi_k(F))`. |

### HoTT Contracts

| Contract | Minimal contents |
|---|---|
| `TypeUniverse` | universe level, ruleset/kernel id. |
| `Type` | syntax tree hash, universe, context. |
| `Term` | syntax tree hash, type hash, context. |
| `Context` | ordered assumptions and variable bindings. |
| `Judgment` | typing/equality/proposition judgment. |
| `IdentityType` | type, left term, right term. |
| `PathTerm` | term inhabiting identity type. |
| `Equivalence` | functions, inverse data, homotopy witnesses. |
| `ContractibleType` | center and contraction witness. |
| `TruncationLevel` | h-level claim with witness/ref. |
| `UnivalenceWitness` | equivalence-to-identity witness under declared kernel. |

HoTT warning:

```text
Do not let a Markdown contract pretend to be a proof assistant.
HoTT contracts must reference a proof kernel, a checked proof object, or a typed WIP status.
```

---

9. Category Theory Contracts
----------------------------

Category theory should be encoded first as finite categories, presentations, or schemas with validation witnesses.

### Category Dependency Spine

```text
FiniteSet -> ObjectSet
FiniteSet -> MorphismSet
FunctionTable -> source/target/identity/composition
CompositionLaw + IdentityMorphism -> Category
Category + mapping data -> Functor
Functor pair + components -> NaturalTransformation
```

### Contract Backlog

| Contract | Minimal contents | Validators |
|---|---|---|
| `ObjectSet` | finite object ids. | uniqueness, canonical order. |
| `MorphismSet` | morphism ids, source/target maps. | source/target totality. |
| `IdentityMorphism` | object to identity morphism map. | source/target identity. |
| `CompositionLaw` | partial function on composable pairs. | associativity. |
| `Category` | objects, morphisms, identities, composition. | identity laws and associativity. |
| `Isomorphism` | morphism pair. | two-sided inverse witness. |
| `Functor` | object map, morphism map. | preserves identities/composition. |
| `NaturalTransformation` | component morphisms. | naturality square witness. |
| `Adjunction` | functors plus unit/counit or hom-set bijection. | triangle identities. |
| `Limit` | diagram, cone, universal property witness. | uniqueness/mediating map witness. |
| `Colimit` | dual of limit. | dual universal property. |
| `MonoidalCategory` | tensor, unit, associator, unitors. | pentagon/triangle coherence. |
| `EnrichedCategory` | hom-objects in monoidal category. | enriched composition/unit laws. |

Rust priority:

```text
FiniteCategoryDescriptor
FunctorDescriptor
NaturalTransformationDescriptor
DiagramDescriptor
ConeDescriptor
```

---

10. Sheaf and Higher Category Contracts
---------------------------------------

Sheaves build on topology/category/presheaf restriction discipline.

### Sheaf Dependency Spine

```text
TopologicalSpace / Site
  -> OpenSet / Cover
  -> Category
  -> Presheaf
  -> RestrictionMap
  -> SheafConditionWitness
  -> Sheaf
  -> SheafCohomology
  -> ObstructionClass
```

### Sheaf Contracts

| Contract | Minimal contents | Validators |
|---|---|---|
| `OpenSet` | base space, open identifier, inclusion relation. | openness/inclusion witness. |
| `Cover` | open set list covering target. | cover witness. |
| `Site` | category plus coverage relation. | Grothendieck topology axioms. |
| `GrothendieckTopology` | covering sieves/families. | max/base-change/local-character witnesses. |
| `Presheaf` | contravariant functor from opens/site to category. | functor laws. |
| `RestrictionMap` | maps for inclusions. | composition/identity laws. |
| `Sheaf` | presheaf plus locality/gluing. | sheaf condition over declared covers. |
| `SheafCohomology` | derived/global cohomology. | finite Cech model first. |
| `DescentData` | local objects plus cocycle/gluing data. | cocycle conditions. |

### Higher Category Contracts

Higher categories should start with weak/strict finite presentations. Do not jump straight to infinity categories without a finite nerve or model category presentation.

| Contract | Minimal contents |
|---|---|
| `Groupoid` | category where every morphism has inverse witness. |
| `TwoCategory` | objects, 1-morphisms, 2-morphisms, horizontal/vertical composition. |
| `Bicategory` | weak 2-category plus associators/unitors/coherence. |
| `DoubleCategory` | objects, horizontal/vertical morphisms, squares. |
| `SimplicialSet` | graded simplex sets plus face/degeneracy maps. |
| `Nerve` | category/higher-category to simplicial set. |
| `InfinityCategory` | finite model via quasicategory, complete Segal space, or marked simplicial set descriptor. |
| `HigherFunctor` | structure-preserving maps between higher categories. |
| `HigherNaturalTransformation` | higher comparison data. |
| `Hypercover` | higher cover used for descent/cohomology. |
| `HigherObstructionClass` | obstruction to descent/lift/equivalence in higher setting. |

---

11. Recommended Contract Creation Order
---------------------------------------

### Phase A: Finish Finite Linear Algebra Core

1. `CanonicalBytes`
2. `HashAlgorithm`
3. `StructureArtifact`
4. `ValidationWitness`
5. `ComputationWitness`
6. `FieldSpec`
7. `Scalar`
8. `IndexSet`
9. `OrderedBasis`
10. `VectorSpace`
11. `Vector`
12. `DualSpace`
13. `BasicMatrix`
14. `LinearMap`
15. `Subspace`
16. `QuotientSpace`
17. `DirectSum`
18. `TensorProduct`

### Phase B: Operators and Quantum Base

1. `Endomorphism`
2. `Adjoint`
3. `Trace`
4. `Determinant`
5. `Rank`
6. `Kernel`
7. `Image`
8. `Projector`
9. `HilbertSpace`
10. `Ket`
11. `Bra`
12. `DensityMatrix`
13. `Observable`
14. `UnitaryOperator`
15. `Measurement`
16. `QuantumChannel`

### Phase C: Chain / Cochain / CODA-FOC Core

1. `GradedModule`
2. `BoundaryMap`
3. `ChainComplex`
4. `Cycle`
5. `Boundary`
6. `HomologyGroup`
7. `HomologyClass`
8. `CoboundaryMap`
9. `CochainComplex`
10. `Cocycle`
11. `Coboundary`
12. `CohomologyGroup`
13. `CohomologyClass`
14. `ExactSequence`
15. `ChainMap`

### Phase D: Fiber / Bundle / Geometry

1. `BaseSpace`
2. `Fiber`
3. `Bundle`
4. `ProjectionMap`
5. `Trivialization`
6. `TransitionFunction`
7. `Section`
8. `InnerProduct`
9. `Connection`
10. `Curvature`
11. `DifferentialForm`
12. `CharacteristicForm`
13. `ChernWeilMap`

### Phase E: Cohomology / Obstruction / Sheaves

1. `Cover`
2. `Nerve`
3. `CechCochain`
4. `CechCocycle`
5. `CechCohomology`
6. `Presheaf`
7. `RestrictionMap`
8. `Sheaf`
9. `SheafCohomology`
10. `ObstructionClass`
11. `ObstructionTheory`
12. `ExistenceOfSection`

### Phase F: Homotopy / HoTT / Category / Higher Category

1. `SimplicialComplex`
2. `CellComplex`
3. `Path`
4. `Homotopy`
5. `FundamentalGroup`
6. `Fibration`
7. `TypeUniverse`
8. `Type`
9. `Term`
10. `IdentityType`
11. `Category`
12. `Functor`
13. `NaturalTransformation`
14. `Bicategory`
15. `SimplicialSet`
16. `InfinityCategory`

---

12. Contract Template for LLM Workers
-------------------------------------

When asking an LLM to create one of these contract docs, use this fixed prompt shape:

```text
Create omega_engine/src/law/contracts/math/<contract_name>.md.

Follow the structure and doctrine of basic_matrix.md:

1. Contract metadata
2. Mathematical role
3. Allowed artifacts
4. Forbidden authority
5. Required inputs
6. Validation requirements
7. Witness requirements
8. Replay requirements
9. Rust descriptor mapping
10. Negative tests
11. Open questions / WIP status

Constraints:

* authority_effect must be none.
* The contract must be finite/replayable or explicitly WIP.
* Every claim must be backed by StructureArtifact, FactEnvelope, ValidationWitness,
  ComputationWitness, or FailureWitness.

* Include Rust descriptor structs.
* Include negative tests.
* Do not claim production, legal, safety, or runtime authority.

Use these dependencies:
<list provider contracts>

This contract provides:
<list consumer contracts>
```

---

13. Immediate Next Contracts
----------------------------

Given the current folder already contains `basic_matrix.md`, the next high-value contract docs are:

1. `canonical_bytes.md`
2. `structure_artifact.md`
3. `validation_witness.md`
4. `computation_witness.md`
5. `ordered_basis.md`
6. `index_set.md`
7. `subspace.md`
8. `quotient_space.md`
9. `tensor_product.md`
10. `chain_complex.md`
11. `cochain_complex.md`
12. `homology_class.md`
13. `cohomology_class.md`

Reason: these unlock both quantum mechanics and CODA-FOC without requiring smooth manifolds, sheaves, or higher categories yet.

---

14. Final Kernel
----------------

The primitive path is:

```text
canonical bytes
-> finite scalar/carrier discipline
-> basis-indexed vectors and matrices
-> linear maps and operators
-> tensor products and quotients
-> Hilbert spaces and quantum states
-> chain/cochain complexes
-> homology/cohomology classes
-> bundles, transitions, sections
-> Cech/deRham/sheaf cohomology
-> obstruction classes
-> homotopy, HoTT, categories, sheaves, higher categories
```

The implementation rule is:

```text
If it cannot be represented as finite canonical bytes, a deterministic algorithm reference,
a proof/witness hash, or an explicitly declared WIP oracle, it is not ready for an Omega
Engine math contract.
```

