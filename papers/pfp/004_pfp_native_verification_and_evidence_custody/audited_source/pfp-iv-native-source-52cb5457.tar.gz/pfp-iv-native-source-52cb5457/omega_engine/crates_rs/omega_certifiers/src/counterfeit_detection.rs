//! Counterfeit Packet Detection
//!
//! Implements the **Exactness Fraud Criterion** from Paper 029 (AI Control):
//! a `CheckedPacket` claiming `ExactRepair` status must have obstruction mass
//! and closure defect within tolerance of zero. Any mismatch is counterfeit.

use crate::checked_packet::CheckedPacket;
use crate::closure_certificate::ClosureStatus;
use num_traits::Zero;
use omega_functional::hashes::Hash256;
use omega_functional::trichotomy::ObstructionDiagnosticClass;
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ToleranceProfile {
    pub exactness_tolerance: f64,
}

/// Why a packet was judged counterfeit.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum CounterfeitReason {
    /// Claims `ExactRepair` but obstruction mass exceeds tolerance / is non-zero.
    ObstructionMassFraud,
    /// Claims `ExactRepair` but closure defect `Gamma2` exceeds tolerance / is non-zero.
    ClosureDefectFraud,
    /// Packet `carrier_hash` differs from closure certificate `carrier_hash`.
    CarrierHashTamper,
    /// Closure certificate claims `is_closed = true` but `Gamma2 > tol / is non-zero`.
    ClosureInconsistency,
    NonFiniteObstructionMass,
    NegativeObstructionMass,
    NonFiniteClosureDefect,
    NegativeClosureDefect,
    MissingReplayHash,
}

/// Result of counterfeit detection on a `CheckedPacket`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CounterfeitVerdict {
    pub is_counterfeit: bool,
    pub reasons: Vec<CounterfeitReason>,
}

impl CounterfeitVerdict {
    fn no_counterfeit_detected() -> Self {
        Self {
            is_counterfeit: false,
            reasons: vec![],
        }
    }

    fn counterfeit(reasons: Vec<CounterfeitReason>) -> Self {
        Self {
            is_counterfeit: true,
            reasons,
        }
    }
}

/// Detect counterfeit packets using the Exactness Fraud Criterion in exact rational mode.
pub fn detect_exact(
    packet: &CheckedPacket,
    closure_cert: &crate::closure_certificate::ClosureCertificate,
) -> CounterfeitVerdict {
    let mut reasons = Vec::new();

    if packet.replay_hash().0 == Hash256([0u8; 32])
        || closure_cert.replay_hash.0 == Hash256([0u8; 32])
    {
        reasons.push(CounterfeitReason::MissingReplayHash);
    }

    if packet.carrier_hash() != &closure_cert.carrier_hash {
        reasons.push(CounterfeitReason::CarrierHashTamper);
    }

    let mass_opt = packet.obstruction_mass().try_exact_rational();
    let mass = match mass_opt {
        Some(m) => {
            if m < num_rational::BigRational::zero() {
                reasons.push(CounterfeitReason::NegativeObstructionMass);
            }
            Some(m)
        }
        None => {
            reasons.push(CounterfeitReason::NonFiniteObstructionMass);
            None
        }
    };

    let gamma_opt = closure_cert.gamma_2.try_exact_rational();
    let gamma = match gamma_opt {
        Some(g) => {
            if g < num_rational::BigRational::zero() {
                reasons.push(CounterfeitReason::NegativeClosureDefect);
            }
            Some(g)
        }
        None => {
            reasons.push(CounterfeitReason::NonFiniteClosureDefect);
            None
        }
    };

    if closure_cert.closure_status == ClosureStatus::Closed {
        if let Some(ref g) = gamma {
            if !g.is_zero() {
                reasons.push(CounterfeitReason::ClosureInconsistency);
            }
        }
    }

    if packet.status() == ObstructionDiagnosticClass::ExactRepair {
        if let Some(ref m) = mass {
            if !m.is_zero() {
                reasons.push(CounterfeitReason::ObstructionMassFraud);
            }
        }
        if let Some(ref g) = gamma {
            if !g.is_zero() {
                reasons.push(CounterfeitReason::ClosureDefectFraud);
            }
        }
    }

    if reasons.is_empty() {
        CounterfeitVerdict::no_counterfeit_detected()
    } else {
        CounterfeitVerdict::counterfeit(reasons)
    }
}

/// Detect counterfeit packets using the Exactness Fraud Criterion in tolerance-bound approximate mode.
pub fn detect_approx(
    packet: &CheckedPacket,
    closure_cert: &crate::closure_certificate::ClosureCertificate,
    tolerance_profile: &ToleranceProfile,
) -> CounterfeitVerdict {
    let mut reasons = Vec::new();
    let tol = tolerance_profile.exactness_tolerance;

    if packet.replay_hash().0 == Hash256([0u8; 32])
        || closure_cert.replay_hash.0 == Hash256([0u8; 32])
    {
        reasons.push(CounterfeitReason::MissingReplayHash);
    }

    if packet.carrier_hash() != &closure_cert.carrier_hash {
        reasons.push(CounterfeitReason::CarrierHashTamper);
    }

    // `to_f64_diagnostic` yields None when no faithful projection exists: NaN,
    // non-finite, or a nonzero value that underflows to 0.0. Absence is treated
    // as the non-finite fault, never as zero.
    let mass_approx = packet.obstruction_mass().to_f64_diagnostic();
    match mass_approx {
        None => reasons.push(CounterfeitReason::NonFiniteObstructionMass),
        Some(m) if m < 0.0 => reasons.push(CounterfeitReason::NegativeObstructionMass),
        Some(_) => {}
    }

    let gamma_approx = closure_cert.gamma_2.to_f64_diagnostic();
    let gamma = gamma_approx.unwrap_or(f64::NAN);
    match gamma_approx {
        None => reasons.push(CounterfeitReason::NonFiniteClosureDefect),
        Some(g) if g < 0.0 => reasons.push(CounterfeitReason::NegativeClosureDefect),
        Some(_) => {}
    }

    // `Closed` is an EXACT-zero claim, so this check gets the same exact
    // backstop the ExactRepair branch below already carries (red-team #911 P2).
    // Consulting only `gamma.abs() > tol` let a sub-f64-floor nonzero Gamma2
    // (e.g. 1/10^400) underflow to 0.0 and satisfy a `Closed` certificate --
    // the identical hole, twenty lines apart, patched on one branch only.
    let gamma_exactly_zero = closure_cert.gamma_2.is_exactly_zero();
    if closure_cert.closure_status == ClosureStatus::Closed
        && (gamma.abs() > tol || !gamma_exactly_zero)
    {
        reasons.push(CounterfeitReason::ClosureInconsistency);
    }

    if packet.status() == ObstructionDiagnosticClass::ExactRepair {
        // The ExactRepair claim is an EXACT-zero claim. The tolerance relaxes
        // the *positive* comparison (a small non-zero mass is within tol), but
        // it must NOT relax the *zero* test: an f64 underflow to 0.0 of a tiny
        // sub-f64-floor rational (e.g. 1 / 10^400) would otherwise let genuine
        // obstruction-mass / closure-defect fraud pass (red-team #911 P2). So
        // for the ExactRepair branch we ALSO consult the exact rational: a
        // non-zero exact value that underflowed to f64 0.0 is still fraud.
        //
        // mass: f64 path catches values above tolerance; the exact path catches
        // sub-f64-floor non-zero rationals.
        // Three ways an ExactRepair claim is fraudulent:
        //   (a) a faithful projection exists and exceeds tolerance;
        //   (b) a faithful projection exists within tolerance, but the exact
        //       rational is nonzero (sub-tolerance fraud);
        //   (c) NO faithful projection exists (underflow/non-finite) and the
        //       value is not exactly zero.
        // Case (c) must be stated separately: with no projection there is no
        // f64 to compare, so both tolerance tests are false and the earlier
        // formulation silently stopped flagging exactly the sub-f64-floor fraud
        // this branch exists to catch.
        let mass_exactly_zero = packet.obstruction_mass().is_exactly_zero();
        let mass_fraud = match mass_approx {
            Some(m) if m.abs() > tol => true,
            Some(_) => !mass_exactly_zero,
            None => !mass_exactly_zero,
        };
        if mass_fraud {
            reasons.push(CounterfeitReason::ObstructionMassFraud);
        }

        let gamma_exactly_zero = closure_cert.gamma_2.is_exactly_zero();
        let gamma_fraud = match gamma_approx {
            Some(g) if g.abs() > tol => true,
            Some(_) => !gamma_exactly_zero,
            None => !gamma_exactly_zero,
        };
        if gamma_fraud {
            reasons.push(CounterfeitReason::ClosureDefectFraud);
        }
    }

    if reasons.is_empty() {
        CounterfeitVerdict::no_counterfeit_detected()
    } else {
        CounterfeitVerdict::counterfeit(reasons)
    }
}

#[cfg(test)]
mod tests {
    use num_bigint::BigInt;
    use num_rational::BigRational;
    use omega_functional::gamma2::{DegreeOneResidualQ, ExactCochainComplexQ, Gamma2Functional};
    use omega_functional::phi1::{ExactPhi1Certificate, Phi1Functional};
    use omega_functional::trichotomy::{classify_exact, TrichotomyOutcome};
    use omega_types::EvidenceCeiling;

    use super::*;
    use crate::checked_packet::*;
    use crate::closure_certificate::{ClosureCertificate, ClosureStatus};

    fn r(value: i64) -> BigRational {
        BigRational::from_integer(BigInt::from(value))
    }

    fn make_packet(
        gamma_2_num: i64,
        gamma_2_den: i64,
        carrier_hash: [u8; 32],
        cert_carrier_hash: [u8; 32],
        closure_status: ClosureStatus,
        closure_replay_hash: [u8; 32],
    ) -> (CheckedPacket, ClosureCertificate, ToleranceProfile) {
        let phi1 = Phi1Functional::verify_exact_certificate(ExactPhi1Certificate {
            omega: vec![r(1)],
            d0: vec![vec![r(1)]],
            weights: vec![r(1)],
            alpha: vec![r(1)],
            primal_residual: vec![r(0)],
            dual_witness: vec![r(0)],
            reported_value: r(0),
        })
        .unwrap();
        let complex =
            ExactCochainComplexQ::try_new(1, 1, 1, phi1.d0().to_vec(), vec![vec![r(0)]]).unwrap();
        let residual =
            DegreeOneResidualQ::try_new(&complex, phi1.primal_residual().to_vec()).unwrap();
        let gamma2 = Gamma2Functional::try_compute_exact_quotient(&residual).unwrap();

        let TrichotomyOutcome::Classified(trichotomy) = classify_exact(&phi1, &gamma2) else {
            panic!("exact packet evidence must classify");
        };
        let cert = ClosureCertificate {
            gamma_2: CertifiedScalar::ExactRational(RationalValue {
                numerator: BigInt::from(gamma_2_num),
                denominator: BigInt::from(gamma_2_den),
            }),
            closure_status,
            carrier_hash: CarrierManifestHash(Hash256(cert_carrier_hash)),
            checker_ref: CheckerRef("test".to_string()),
            replay_hash: ReplayHash(Hash256(closure_replay_hash)),
        };
        let pkt = CheckedPacket::new_checked(
            CheckedPacketArgs {
                packet_id: Hash256([0u8; 32]),
                evidence_refs: vec![EvidenceRef(Hash256([0u8; 32]))],
                checker_ref: CheckerRef("test".to_string()),
                schema_hash: Hash256([0u8; 32]),
                carrier_hash: CarrierManifestHash(Hash256(carrier_hash)),
                boundary_maps_hash: BoundaryMapsHash(Hash256([0u8; 32])),
                weights_and_gauges_hash: WeightsAndGaugesHash(Hash256([0u8; 32])),
                submitted_defect_hash: DefectFieldHash(Hash256([0u8; 32])),
                phi1_certificate_ref: CertificateRef(Hash256([0xCC; 32])),
                closure_certificate_ref: CertificateRef(Hash256([0xDD; 32])),
                observer_boundary_hash: ObserverBoundaryHash(Hash256([0u8; 32])),
                tolerance_profile_hash: ToleranceProfileHash(Hash256([0u8; 32])),
                replay_hash: ReplayHash(Hash256(REPLAY)),
                certificate_status: CertificateVerdict::Verified,
                checked_scope: CheckedClaimScope {
                    claim_kind: CheckedClaimKind::ObstructionSummary,
                    authority_ceiling: EvidenceCeiling::BoundaryChecked,
                    law_refs: vec![],
                },
            },
            &phi1,
            &trichotomy,
        )
        .unwrap();
        let tol = ToleranceProfile {
            exactness_tolerance: 1e-10,
        };
        (pkt, cert, tol)
    }

    const HASH_A: [u8; 32] = [0xAA; 32];
    const HASH_B: [u8; 32] = [0xBB; 32];
    const REPLAY: [u8; 32] = [0x11; 32];

    #[test]
    fn test_counterfeit_rejects_zero_closure_replay_hash_in_production_mode() {
        let (pkt, cert, _tol) = make_packet(0, 1, HASH_A, HASH_A, ClosureStatus::Closed, [0u8; 32]);
        let verdict = detect_exact(&pkt, &cert);
        assert!(verdict.is_counterfeit);
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::MissingReplayHash));
    }

    #[test]
    fn test_counterfeit_rejects_negative_closure_defect() {
        let (pkt, cert, _tol) = make_packet(-1, 1, HASH_A, HASH_A, ClosureStatus::Closed, REPLAY);
        let verdict = detect_exact(&pkt, &cert);
        assert!(verdict.is_counterfeit);
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::NegativeClosureDefect));
    }

    #[test]
    fn test_counterfeit_reports_multiple_reasons() {
        let (pkt, cert, _tol) =
            make_packet(-1, 1, HASH_A, HASH_B, ClosureStatus::Closed, [0u8; 32]);
        let verdict = detect_exact(&pkt, &cert);
        assert!(verdict.is_counterfeit);
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::NegativeClosureDefect));
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::CarrierHashTamper));
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::MissingReplayHash));
    }

    #[test]
    fn test_counterfeit_exact_gamma2_fraud() {
        // Packet claims ExactRepair (obstruction = 0), but certified closure defect Gamma2 is > 0 (e.g. 1/2)
        let (pkt, cert, _tol) = make_packet(1, 2, HASH_A, HASH_A, ClosureStatus::Open, REPLAY);
        let verdict = detect_exact(&pkt, &cert);
        assert!(verdict.is_counterfeit);
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::ClosureDefectFraud));
    }

    #[test]
    fn test_counterfeit_closure_status_inconsistency() {
        // Closure certificate claims Closed, but Gamma2 is > 0 (e.g. 1/1000)
        let (pkt, cert, _tol) = make_packet(1, 1000, HASH_A, HASH_A, ClosureStatus::Closed, REPLAY);
        let verdict = detect_exact(&pkt, &cert);
        assert!(verdict.is_counterfeit);
        assert!(verdict
            .reasons
            .contains(&CounterfeitReason::ClosureInconsistency));
    }

    /// Build a closure cert whose `gamma_2` is a non-zero rational so small it
    /// underflows to f64 `0.0` (denominator `10^400`). `make_packet`'s i64
    /// denominator cannot express this, so we rebuild the cert with a huge
    /// `BigInt` denominator.
    fn cert_with_subfloor_gamma2(base: ClosureCertificate) -> ClosureCertificate {
        let huge_den = BigInt::from(10u32).pow(400);
        ClosureCertificate {
            gamma_2: CertifiedScalar::ExactRational(RationalValue {
                numerator: BigInt::from(1),
                denominator: huge_den,
            }),
            ..base
        }
    }

    /// Red-team #911 P2: `detect_approx` must NOT miss obstruction/closure fraud
    /// when the exact rational underflows to f64 0.0. A `gamma_2 = 1 / 10^400`
    /// reads as `0.0` in `to_f64_diagnostic()` (within tolerance), but the EXACT
    /// rational is non-zero, so the ExactRepair claim is fraudulent and MUST be
    /// flagged.
    #[test]
    fn detect_approx_catches_subfloor_gamma2_fraud_via_exact_zero_test() {
        let (pkt, base_cert, tol) = make_packet(0, 1, HASH_A, HASH_A, ClosureStatus::Open, REPLAY);
        let cert = cert_with_subfloor_gamma2(base_cert);

        // Precondition: this value has no faithful f64 projection. It used to
        // underflow silently to 0.0 -- within tolerance, so the f64-only test
        // passed it -- which is the hole this test was written for.
        // `to_f64_diagnostic` now reports that underflow as `None` instead of
        // returning a zero indistinguishable from an exact zero, so the fraud is
        // detectable one layer earlier, at the projection rather than only at
        // the exact backstop below.
        assert!(
            cert.gamma_2.to_f64_diagnostic().is_none(),
            "fixture precondition: sub-f64-floor gamma_2 must refuse to project, not read as 0.0"
        );
        // But the EXACT rational is non-zero.
        assert!(!cert
            .gamma_2
            .try_exact_rational()
            .expect("exact rational present")
            .is_zero());

        let verdict = detect_approx(&pkt, &cert, &tol);
        assert!(
            verdict.is_counterfeit,
            "sub-f64-floor non-zero gamma_2 on an ExactRepair packet MUST be counterfeit"
        );
        assert!(
            verdict
                .reasons
                .contains(&CounterfeitReason::ClosureDefectFraud),
            "must flag ClosureDefectFraud via the exact-zero test; reasons: {:?}",
            verdict.reasons
        );
    }

    /// Positive control: a GENUINELY zero gamma_2 (`0/1`) on an ExactRepair
    /// packet passes `detect_approx` cleanly. Paired with the negative control
    /// above, this proves the exact-zero gate discriminates (it does not flag
    /// every ExactRepair packet).
    #[test]
    fn detect_approx_passes_genuinely_zero_gamma2() {
        let (pkt, cert, tol) = make_packet(0, 1, HASH_A, HASH_A, ClosureStatus::Open, REPLAY);
        let verdict = detect_approx(&pkt, &cert, &tol);
        assert!(
            !verdict.is_counterfeit,
            "a genuinely zero gamma_2 ExactRepair packet must NOT be counterfeit; reasons: {:?}",
            verdict.reasons
        );
    }
}
