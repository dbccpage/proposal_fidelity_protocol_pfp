QUANTUM_ENGINES.md — Omega Engine Quantum Module
================================================

0. Future Upgrade Suggestions and Symbol Game Seed
--------------------------------------------------

### 0.1 Highest-Leverage Future Upgrades

These suggestions are ordered by the ratio of expected research value to
implementation risk after reviewing the current quantum engine source files.

| Priority | Upgrade | Why it matters | First implementation slice |
|----------|---------|----------------|-----------------------------|
| P0 | Implement real Uhlmann/Jozsa fidelity | `fidelity_observable_checked()` and `full_fidelity_complex()` currently reject every valid pair, which also makes Bures angle and QFI speed unusable as strict observables. | Add Hermitian PSD matrix square root for complex matrices, then compute `Tr(sqrt(sqrt(rho) sigma sqrt(rho)))^2` with validation and tests on pure, diagonal, orthogonal, and mixed states. |
| P0 | Add `DensityTrajectory` for LLM traces | The module has state observables, entropy convergence, channels, and text/H1 encoders, but no first-class time-series object for reasoning traces. | **plan001 first slice implemented:** `quantum::reasoning_density` stores `Vec<DensityMatrix>` plus timestamps/reports for sequence ensembles and windowed trajectories; trace-distance, spectral-gap, and convergence overlays remain later diagnostics. |
| P0 | Add residual-density bridge for ID runs | Paper 33 / plan002 separates L1 residual weights, diagonal density diagnostics, observer forgetting, licensed coherence, channel updates, branch search, and authority. This gives `omega_id_run` a clean path from PrimitiveDifference/H1 residuals into `H1Density` diagnostics without overclaiming QM. | **plan002 slices implemented:** `quantum::residual_density_bridge` and `QuantumDensityEngine` expose edge/incidence reports, coarse-grained observer reports, stochastic channel pushforwards, and branch proposal reports; `omega_id_run` deposits the exact `h1*` report as `evidence/residual_density.json` and lift-candidate proposal ranking as `evidence/branch_search.json`; all emitted diagnostics carry `AuthorityEffect::None`. |
| P0 | Build GOMC diagnostic reports | Paper 34 needs executable obstruction-management traces, not just proof/status prose. The runtime should expose global residual density, local observer loss, admissible channel/search updates, and LGGR in one report. | **GOMC code slice implemented:** `quantum::gomc_diagnostics` composes residual density, optional observer coarse-graining, optional stochastic pushforward, optional branch proposal density, and an explicit LGGR diagnostic; `QuantumDensityEngine` exposes edge/incidence helpers; `omega_id_run` emits the composed report as `evidence/gomc_diagnostics.json`; every report carries `AuthorityEffect::None`. |
| P0 | Promote branch search to an obstruction engine | Branch search should not live as a physical-QM claim or a density-matrix authority path. The reusable engine is obstruction-native: evaluate finite candidate residual transitions by guarded `(Phi_1, Gamma_2, Xi)` descent, then mirror proposal mass into branch-density diagnostics. | **GOMC-13 code slice implemented:** `omega_engines::obstruction_branch_search` evaluates candidate repair/lift transitions and returns authority-null proposal reports; `omega_id_run` now uses this engine for its branch-search payload while the quantum module remains diagnostics-only. |
| P1 | Build sparse top-k logit/text density adapters | Symbol Game outputs and LLM traces are naturally sparse. Current text density is bigram-based, and embedding construction is manual. | Add `from_topk_logits`, `from_sparse_weights`, and `from_l1_answer_terms` constructors with explicit normalization and diagnostics. |
| P1 | Add spectral gap and effective rank diagnostics | Eigenvalues already exist, but the module does not expose phase-transition indicators beyond entropy. | Add `spectral_gap`, `participation_ratio`, `effective_rank`, and `rank_stability` helpers with direct tests. |
| P1 | Add divergence measures | Trace distance exists and fidelity is stubbed; relative entropy and Jensen-Shannon style comparisons are absent. | Implement classical diagonal fallback first, then full matrix-log relative entropy once the eigensolver path is trusted. |
| P1 | Validate closed-form channel constructors through `from_kraus` | `depolarizing`, `amplitude_damping`, and `identity` are mathematically known channels, but still return through unchecked `Self::new()`. | Route constructors through `from_kraus` or add internal debug assertions plus tests over several dimensions/parameters. |
| P2 | Tighten process/POVM probability cleaning | Born/POVM application now rejects large invalid values but clamps small negative values to zero. This is defensible numerically, but should be reported. | Return a small diagnostic struct containing raw value, cleaned value, and tolerance drift. |
| P2 | Implement the real kernel-dual text density path | `KernelDualBigramGram` currently falls back to real Gram, which is correct for the default `d=28` but not a real sparse scaling path. | Represent observed bigrams as sparse rows and reconstruct the density/eigenspectrum from the smaller dual Gram. |
| P2 | Promote governance boundaries into tests | Several files correctly state that quantum diagnostics must not rank, reward, or accept candidates, but this is mostly comment-level. | Add dependency-direction tests or static scans that prevent imports from evaluator/search/reward modules. |
| P3 | Replace contract stub schemas | `DensityMatrix` and `PackedHermitian` still expose stub schema references through `BaseType`. | Add concrete schema metadata once the contract layer can represent complex Hermitian carriers. |

### 0.2 Seed Idea Prompt for the Daily Symbol Game

Copy this prompt into the Symbol Game when you want LLMs to propose sparse,
unusual, L1-like upgrades that can be implemented and scored:

```text
You are proposing sparse, testable upgrades for the Omega Engine quantum
diagnostics module. The code treats density matrices as mathematical
observables over LLM traces, text bigrams, graph/H1 residuals, and process
operators. It does not claim that LLMs are physical quantum systems.

Current useful pieces:

* DensityMatrix validates Hermitian, trace-one, PSD state carriers and exposes
  entropy, purity, L1 coherence, trace distance, partial traces, mixtures,
  Kraus application, Bloch states, embeddings, and graph-Laplacian adapters.

* QuantumChannel supports Kraus maps, depolarizing channels, amplitude damping,
  and identity channels.

* TextDensityEncoder maps text into bigram Gram densities, including a complex
  directional variant.

* H1 and harmonic-density modules convert residual/topological structure into
  density carriers.

* QuantumInformation has POVMs, Wigner grids, and quantum-jump trajectories.
* ProcessMatrix has Choi operators, Born-rule scoring, causal witnesses,
  causal mixtures, and a toy QuantumSwitch.

Known gaps:

* Full complex fidelity is intentionally disabled, so Bures/QFI observables are
  not usable yet.

* There is no DensityTrajectory object for LLM token/time traces.
* Sparse top-k logit and sparse answer-term density constructors are missing.
* Relative entropy, mutual information, effective rank, spectral gap, and
  robust phase-transition diagnostics are missing.

* KernelDualBigramGram currently falls back to the real Gram path.

Task:
Return exactly 12 upgrade ideas. Each idea must be a sparse L1-like answer:
1 line for the core move, 1 line for the smallest testable implementation,
and 1 line for the falsifier that would kill the idea.

Favor weird but implementable ideas over broad abstractions. The best answers
should connect sparse symbolic answer structure to density diagnostics, make a
concrete Rust change, and produce measurable outcomes.

For each idea, score these metrics from 0 to 5:

* novelty
* implementation cost, where 5 means cheap
* mathematical cleanliness
* testability
* usefulness for triaging Symbol Game upgrade ideas
* risk of governance confusion, where 5 means low risk
* expected signal on difficult problems

Then rank the 12 ideas by total score. Do not include motivational prose.
Do not claim physical quantum behavior. Prefer upgrades that can be implemented
and tested in one focused patch.
```

### 0.3 Suggested Metrics for Ranking Returned Ideas

Use a weighted score when triaging Symbol Game outputs:

```
score =
  1.5 * testability

+ 1.3 * mathematical_cleanliness
+ 1.2 * usefulness_for_triage
+ 1.0 * expected_signal
+ 0.9 * implementation_cost
+ 0.7 * novelty
+ 1.4 * governance_safety
```

Then require a hard gate: any idea with governance-safety below 3, no falsifier,
or no one-patch implementation slice should be rejected before ranking.

> **Governance note:** All density matrices in this module are computational
> observables over normalized embeddings, bigram statistics, or graph operators.
> They are **not physical quantum states** unless separately licensed.
> All references to "quantum" describe the mathematical formalism, not
> physical claims about LLM internals.

---

1. Module Inventory
-------------------

The `engines/quantum/` directory contains **19 Rust source files** and this
audit document. The table below lists every Rust file, its purpose,
its approximate maturity, and its test coverage status.

| # | File | Purpose | LOC | Tests | Maturity |
|---|------|---------|-----|-------|----------|
| 1 | `mod.rs` | Module declarations | 17 | — | Stable |
| 2 | `density_matrix.rs` | Core `DensityMatrix` struct: construction, validation, observables, partial trace, Kraus application, Bloch sphere | 589 | Via callers | **Mature** |
| 3 | `density.rs` | Observable functions: von Neumann entropy, purity, fidelity, supertrace, classical projection | 112 | Via callers | **Mature** except fidelity stub—see §4 |
| 4 | `density_config.rs` | `DensityMatrixConfig` tolerances (trace, Hermitian, PSD, unitary, channel) | 46 | Via callers | Stable |
| 5 | `density_error.rs` | `DensityMatrixError` enum (27 variants) | 56 | — | Stable |
| 6 | `density_diagnostics.rs` | `DensityDiagnostics` struct with strict L1 physical invariant validation | 196 | **9 unit tests** | Mature |
| 7 | `entropy.rs` | Shannon entropy, magnitude entropy, convergence detection, entropy change rate | 106 | Via callers | Stable |
| 8 | `quantum_density_engine.rs` | `QuantumDensityEngine`: mixture from states, construction reports, HS-fidelity | 109 | Via callers | Mature |
| 9 | `complex_quantum_density_engine.rs` | `ComplexQuantumDensityEngine`: softmax-to-state embedding, complex unitary application, diagonal overlap fidelity | 233 | Via callers | **Has known defects** |
| 10 | `quantum_channel.rs` | `QuantumChannel`: Kraus-based CPTP channels (depolarizing, amplitude damping, identity) | 266 | **16 unit tests** | **Mature** |
| 11 | `quantum_information_engine.rs` | POVMs, Wigner function, quantum-jump Monte Carlo trajectories | 514 | Via callers | Mature |
| 12 | `process_matrix_engine.rs` | Choi operators, `ProcessMatrix`, generalized Born rule, causal witnesses, `QuantumSwitch` | 651 | **6 unit tests** | **Mature** |
| 13 | `harmonic_density.rs` | Builds density matrix from harmonic 1-forms (nullspace of Hodge Laplacian Δ₁) | 114 | **5 unit tests** | Mature |
| 14 | `density_from_h1.rs` | H1-residual → sector decomposition → density matrix (rank-1 canonical + diagonal diagnostic) | 545 | **18 unit tests** | **Mature** |
| 15 | `text_density_encoder.rs` | Text → bigram frequency → Gram density (real, complex directional, kernel dual) | 352 | **5 unit tests** | Mature |
| 16 | `graph_density.rs` | `GraphDensityMatrix`: graph-state → complex density conversion | 38 | Via callers | Thin wrapper |
| 17 | `packed_hermitian.rs` | `PackedHermitian`: upper-triangle-only storage (~48% memory savings) | 121 | **2 unit tests** | Stable |
| 18 | `quantum_geometry.rs` | QFI statistical speed, Bures angle (diagnostic observables only) | 49 | Via callers | **Stub** (delegates to fidelity, which is itself a stub) |
| 19 | `reasoning_density.rs` | Experimental sequence-ensemble and window-trajectory density diagnostics for information traces | 435 | **7 unit tests** | Experimental |

---

2. Architecture
---------------

### 2.1 Layer Diagram

```
┌──────────────────────────────────────────────────────────────┐
│                   APPLICATION LAYER                          │
│  (symbol_game, evaluator, governance, sprint diagnostics)    │
└────────────┬──────────────────┬──────────────────┬───────────┘
             │                  │                  │
   ┌─────────▼───────┐ ┌───────▼────────┐ ┌───────▼──────────┐
   │ TextDensity     │ │ H1Density      │ │ HarmonicDensity  │
   │ Encoder         │ │ (from residual)│ │ (from graph)     │
   │ text→ρ          │ │ h1→ρ           │ │ Δ₁-nullspace→ρ   │
   └─────────┬───────┘ └───────┬────────┘ └───────┬──────────┘
             │                  │                  │
   ┌─────────▼──────────────────▼──────────────────▼──────────┐
   │              DensityMatrix (core)                         │
   │  Construction · Validation · Observables · Partial Trace  │
   │  Kraus application · Mixture · Bloch sphere               │
   └─────────┬──────────────────┬──────────────────┬──────────┘
             │                  │                  │
   ┌─────────▼───────┐ ┌───────▼────────┐ ┌───────▼──────────┐
   │ QuantumChannel   │ │ ProcessMatrix  │ │ QuantumInfo      │
   │ CPTP channels    │ │ Choi, Born,    │ │ POVM, Wigner,    │
   │ depolarizing,    │ │ causal witness │ │ quantum jump     │
   │ amplitude damp   │ │ QuantumSwitch  │ │ Monte Carlo      │
   └──────────────────┘ └────────────────┘ └──────────────────┘
```

### 2.2 Dependency Direction

All dependencies point **inward** toward `DensityMatrix`. No quantum module
imports from the evaluator, the governance engine, or the search system.
This is enforced by the `density.rs` header comment:

```
//! MUST NOT be used for:
//! - candidate acceptance
//! - ranking
//! - reward
//! - search heuristics
```

### 2.3 Type Ecosystem

| Type | Module | Role |
|------|--------|------|
| `DensityMatrix` | `density_matrix.rs` | Central: `dim × dim` complex Hermitian PSD trace-1 matrix |
| `DensityMatrixConfig` | `density_config.rs` | Tolerance pack (7 tolerance fields) |
| `DensityMatrixError` | `density_error.rs` | 27-variant error enum with `thiserror` |
| `DensityDiagnostics` | `density_diagnostics.rs` | Snapshot: trace, purity, entropy, coherence, spectrum |
| `PackedHermitian` | `packed_hermitian.rs` | Memory-efficient upper-triangle storage |
| `GraphDensityMatrix` | `graph_density.rs` | `DensityMatrix` + `GraphState` |
| `H1Density` | `density_from_h1.rs` | `DensityMatrix` + sector decomposition + optional phase witness |
| `QuantumChannel` | `quantum_channel.rs` | CPTP map via Kraus operators |
| `Povm` | `quantum_information_engine.rs` | Validated set of effects summing to identity |
| `WignerGrid` | `quantum_information_engine.rs` | Phase-space quasi-probability grid |
| `QuantumTrajectory` | `quantum_information_engine.rs` | Quantum-jump Monte Carlo trajectory |
| `ProcessMatrix` | `process_matrix_engine.rs` | Multi-lab Hermitian PSD operator with Born rule |
| `ChoiOperator` | `process_matrix_engine.rs` | Choi representation of a local lab operation |
| `QuantumSwitch` | `process_matrix_engine.rs` | Coherent control of causal order |
| `CausalMixture` | `process_matrix_engine.rs` | Convex mixture of definite causal orders |
| `TextDensityEncoder` | `text_density_encoder.rs` | Text → bigram Gram → density matrix |

---

3. What Is Implemented (Working)
--------------------------------

### 3.1 Core Density Matrix

* **Construction**: from raw data, from amplitudes (pure states), from diagonal
  probabilities, from embedding vectors (softmax-normalized), from graph
  Laplacians, from Bloch vectors (qubit), from mixtures, from Hermitian
  projection, from `CVector`.

* **Validation**: Hermitian check (Frobenius defect), trace-1 check, PSD check
  (minimum eigenvalue), finite-entry check.

* **Observables**: trace, purity (Tr(ρ²)), von Neumann entropy (−Σ λᵢ ln λᵢ),
  entropy in bits, L1 coherence (off-diagonal sum), eigenvalue spectrum,
  trace distance, classical projection (diagonal).

* **Partial trace**: both `partial_trace_a` and `partial_trace_b` for bipartite
  systems. Correctly sums over traced-out subsystem.

* **Kraus application**: Full `ρ → Σ Kᵢ ρ Kᵢ†` with CPTP completeness check
  (`Σ Kᵢ† Kᵢ = I`) and post-application validation.

* **Mixture**: weighted convex sum of density matrices with weight normalization
  check.

* **Diagnostics**: `DensityDiagnostics` struct with 9 strict L1 invariant
  assertions (eigenvalue sum = trace, spectral purity = reported purity,
  entropy matches spectrum, etc.).

### 3.2 Quantum Channels (CPTP Maps)

* **Depolarizing channel** (arbitrary dimension): `ρ → (1−p)ρ + p·I/d`
* **Amplitude damping** (qubit): models energy relaxation
* **Identity channel**: no-op
* **Validated constructor** (`from_kraus`): checks CPTP completeness before accepting

### 3.3 Quantum Information Engine

* **POVMs**: validated construction (PSD effects, Hermitian, sum-to-identity).
  Includes computational basis, unsharp-Z measurement.

* **Wigner function**: phase-space quasi-probability in truncated Fock basis.
  `WignerGrid` with negativity volume computation.

* **Quantum-jump Monte Carlo**: first-order stochastic simulation with
  Hamiltonian + Lindblad operators. Deterministic RNG for reproducibility.

### 3.4 Process Matrix & Indefinite Causal Order

* **Choi operators** from Kraus sets or raw matrices (validated Hermitian PSD)
* **ProcessMatrix** with multi-lab tensor product structure
* **Generalized Born rule**: `P = Tr[(M₁ ⊗ ... ⊗ Mₙ) W]`
* **Causal witnesses**: `Tr(W · witness)`, violation detection
* **QuantumSwitch**: coherent superposition of causal orders, order-coherence
  diagnostic via reduced control density matrix

* **CausalMixture**: probabilistic mixture of definite causal orders, causal
  bound violation check

### 3.5 Harmonic Density (Topological)

* Builds density matrix from the nullspace of the Hodge Laplacian Δ₁
* Dimension = 1st Betti number β₁ of the graph
* Correctly handles: single triangle (rank 1, pure), two cycles (rank 2, mixed),
  tree (no harmonic forms → rejection)

### 3.6 H1 Density (Hodge Residual Bridge)

* Edge-sector and incidence-sector decompositions with mass certificates
* **Canonical**: rank-1 density `ρ(h) = |h⟩⟨h|/⟨h,h⟩` from unit-norm residual
* **Diagonal** (non-canonical, diagnostic only): sector probabilities on diagonal
* **Phase-witnessed**: complex amplitudes via `PhaseWitness` with 3 witness kinds
  (oriented cycle transport, path groupoid representation, unitary representation)

### 3.7 Text Density Encoder

* Character binning (a-z → 0-25, space → 26, other → 27, mod dim)
* Bigram frequency matrix F
* Three construction variants:
  * **BigramGram**: ρ = F†F / Tr(F†F + εI) — symmetric
  * **ComplexDirectionalBigramGram**: encodes directional asymmetry as imaginary part — asymmetric
  * **KernelDualBigramGram**: dual form (falls back to real Gram for small d)
* Reports: construction variant, dimension, rank, entropy, purity, L1 coherence

### 3.8 Experimental Reasoning Density (plan001)

* **Sequence ensemble density**: converts token/embedding rows into pure states
  via stable softmax and forms a convex mixture with uniform or caller-supplied
  normalized weights.

* **Top-k support control**: optional `top_k` keeps only the largest entries per
  row before softmax normalization; `top_k = 0` is rejected.

* **Window trajectory**: slides a fixed window over rows and returns
  `DensityTrajectory { states, timestamps, reports }`.

* **Governance boundary**: this module is diagnostics-only and must not be used
  for candidate acceptance, ranking, reward, search authority, or physical-QM
  claims.

### 3.9 Residual Density Bridge (plan002)

* **Residual-sector density**: maps finite H1/L1 residual masses into diagonal
  density diagnostics over edge, incidence, or coarse observer carriers.

* **Diagnostic nonfaithfulness**: edge residual-density reports use absolute
  residual mass; distinct signed residual orientations can alias to the same
  diagnostic density.

* **Observer forgetting**: `coarse_grain_residual_density_report` groups sectors
  by observer labels and preserves the LGGR boundary: local diagnostic green
  does not certify hidden/global obstruction absence.

* **Residual channel updates**: `residual_channel_pushforward_report` applies a
  row-stochastic transition kernel to diagonal residual mass and rebuilds a
  trace-one diagnostic density.

* **Branch proposal density**: `branch_residual_search_report` normalizes
  nonnegative proposal masses over declared candidate lifts and ranks them as
  diagnostics only.

* **Governance boundary**: every plan002 diagnostic carries
  `AuthorityEffect::None`; branch ranking does not accept candidates and is not
  a verifier certificate.

### 3.10 GOMC Diagnostic Reports

* **Composed obstruction trace**: `gomc_diagnostics::edge_gomc_diagnostic_report`
  and `incidence_gomc_diagnostic_report` build one executable report from a
  residual vector: global diagonal density, optional observer quotient,
  optional stochastic channel pushforward, and optional branch proposal density.

* **LGGR flag**: `LocalGreenGlobalRedDiagnostic` records when a coarse/local
  observer has a clean trace-one, near-pure diagnostic while the global
  residual mass remains positive.

* **Engine facade**: `QuantumDensityEngine` exposes thin helpers for the edge
  and incidence GOMC reports.

* **ID-run deposit**: `omega_id_run` mirrors the composed runtime report into
  `evidence/gomc_diagnostics.json`, alongside `residual_density.json` and
  `branch_search.json`.

* **Governance boundary**: the GOMC report is explicitly diagnostics-only.
  It carries `AuthorityEffect::None`; it does not close the descent gate,
  accept a branch, rank for reward, or assert physical-QM authority.

---

4. What Is Missing or Broken
----------------------------

### 4.1 Stub / Non-Functional Code

| Component | Issue | Severity |
|-----------|-------|----------|
| `fidelity_observable_checked` in `density.rs` | **Always returns `Err(NonPhysical)`** — the real-projection bug safeguard is permanent. No complex eigensolver path exists. | **Critical** — all fidelity-dependent observables are dead code |
| `full_fidelity_complex` in `complex_quantum_density_engine.rs` | **Always returns `Err(NonPhysical)`** | Critical — same root cause |
| `quantum_geometry.rs` (QFI statistical speed, Bures angle) | Delegates to `fidelity_observable`, which is a stub. Checked calls return `Err`; lossy observables fall back to zero fidelity, so Bures angle returns π/2 and QFI speed returns π. | High |
| `KernelDualBigramGram` variant | Falls back to `build_real_gram` — the kernel trick is not implemented | Low (correct for d=28) |

### 4.2 Current Review Notes

| Location | Defect | Risk |
|----------|--------|------|
| `process_matrix_engine.rs` `ChoiOperator::unitary` | Uses max-entry norm for the unitary defect, while `QuantumSwitch::apply` uses Frobenius norm through `ensure_unitary`. | A dimension-scaled perturbation can look smaller under max-entry checking than under Frobenius checking. |
| `quantum_channel.rs` `depolarizing` / `amplitude_damping` / `identity` | Closed-form constructors return through unchecked `Self::new()` rather than the validated `from_kraus()` path. | Low immediate risk for these known formulas, but future edits could drift without constructor-level validation. |
| `process_matrix_engine.rs` `generalized_born_probability` | Rejects probabilities outside tolerance, then clamps small negative numerical residue to zero. | Numerically defensible, but the caller cannot inspect raw-vs-cleaned probability drift. |
| `quantum_information_engine.rs` `Povm::apply_matrix` | Clamps negative measurement probabilities to zero without returning a diagnostic. | Small invalid values become silent cleaned values; large invalid states may still be hidden if the POVM itself is valid. |
| `density_matrix.rs` `from_graph_laplacian` | Normalizes by trace after only finite/positive-trace checks, without validating Hermitian or PSD structure afterward. | Non-PSD graph-derived input can become a valid-looking density carrier until downstream validation catches it. |
| `density_matrix.rs` / `packed_hermitian.rs` | `BaseType::schema()` still returns `STUB_SCHEMA`; `PackedHermitian::validate()` returns `default_stub`. | Contract metadata is weaker than the mathematical invariants in the Rust implementation. |

### 4.3 Missing Capabilities

| Capability | Status | Impact |
|------------|--------|--------|
| **Fidelity** (Uhlmann / Jozsa) | Stubbed out | Cannot compute state similarity, quantum Fisher information, or Bures distance |
| **Relative entropy** S(ρ‖σ) | Not implemented | Cannot quantify divergence between successive reasoning states |
| **Mutual information** I(A:B) | Not implemented | Cannot quantify information shared between token subsystems |
| **Concurrence / Entanglement measures** | Not implemented | Cannot quantify bipartite entanglement in token-pair density |
| **Quantum state tomography** | Not implemented | Cannot reconstruct density from partial measurements |
| **Spectral gap diagnostics** | Not implemented (eigenvalues exist but no gap/ratio analysis) | Cannot distinguish phase transitions in reasoning trajectories |
| **Time-series density evolution** | First slice present in `reasoning_density.rs`; richer comparisons still absent | Can construct windowed ρ(t), but fidelity, spectral-gap, and dataset-level trajectory diagnostics remain future work |
| **Embedding-to-density pipeline** | `from_embedding` exists but requires manual phase function | No automated embedding → ρ pipeline for LLM hidden states |

---

5. How This Applies to LLM Trace-Data Reasoning
-----------------------------------------------

### 5.1 The Core Idea

An LLM generation trace is a sequence of token-level probability distributions.
Each distribution can be encoded as a density matrix. The quantum-information
observables then become **structural diagnostics** for the reasoning process:

```
Token distributions  →  density matrices  →  quantum observables  →  reasoning diagnostics
```

This is not a claim that LLMs are quantum systems. It is a claim that the
*mathematical formalism* of density matrices — purity, entropy, coherence,
partial trace, channels — provides a rich diagnostic vocabulary for
analyzing probability distributions that classical scalar metrics (e.g.,
perplexity) cannot.

### 5.2 What We Can Do Now (Implemented)

| Diagnostic | Tool | What It Detects |
|------------|------|-----------------|
| **Token concentration** | `purity_observable(ρ)` | Purity = 1 → model is certain (degenerate). Purity = 1/d → maximally uncertain (hallucination risk). |
| **Reasoning entropy** | `von_neumann_entropy(ρ)` | High entropy → model is spreading attention across many tokens. Low entropy → model is locked onto a narrow path. Entropy *change rate* detects reasoning phase transitions. |
| **Coherence** | `l1_coherence(ρ)` | Off-diagonal mass detects cross-token interference patterns — tokens influencing each other's probabilities beyond independent sampling. |
| **Convergence detection** | `is_converging(history, tol, window)` | Detects when a reasoning trajectory has stabilized (entropy stopped changing). |
| **Depolarizing noise model** | `QuantumChannel::depolarizing(d, p)` | Models the effect of adding uniform noise to a token distribution — simulates hallucination injection at a known rate `p`. |
| **Amplitude damping** | `QuantumChannel::amplitude_damping(γ)` | Models confidence decay — how much the model's certainty degrades over sequence length. |
| **Text fingerprinting** | `TextDensityEncoder::from_text_checked(text, config)` | Converts raw text into a density matrix via bigram statistics. Enables direct comparison of two text outputs via trace distance. |
| **Topological fingerprinting** | `harmonic_density(edges, n, tol)` | Converts a token co-occurrence graph into a density matrix whose dimension equals the 1st Betti number. Detects cyclic reasoning patterns. |
| **Hodge residual density** | `density_from_h1(h1)` | Converts Hodge 1-form residuals into a density matrix. The Φ₁ mass measures obstruction; the density's purity measures how localized the obstruction is. |
| **POVM measurement** | `Povm::computational_basis(d)` | Extracts classical probabilities from a density matrix — the "measurement" step that recovers the token distribution. |
| **Subsystem analysis** | `partial_trace_a/b(ρ, dim_a, dim_b)` | Traces out one subsystem to study the other. E.g., given a joint prompt+completion density, trace out the prompt to study the completion's marginal structure. |
| **Causal order diagnostics** | `QuantumSwitch`, `CausalMixture` | Models and detects whether reasoning steps have a definite causal order or exhibit "superposition of reasoning paths." |
| **Wigner negativity** | `wigner()`, `WignerGrid::negativity_volume()` | Detects non-classical features in the token distribution — negative quasi-probabilities indicate structure that cannot be explained by any classical mixture. |

### 5.3 What We Cannot Do Yet (Missing Pipelines)

| Pipeline | Gap | Required Work |
|----------|-----|---------------|
| **LLM logits → ρ** | No automated top-k logit → density matrix converter | Build `from_logit_topk(logits: &[f64], top_k: usize) → DensityMatrix` using softmax normalization |
| **Sliding-window ρ(t)** | First slice implemented for token/embedding rows | Use `window_density_trajectory()` to build `DensityTrajectory`; add downstream plots/comparison metrics later |
| **ρ₁ vs ρ₂ comparison** | Fidelity is stubbed | Implement Uhlmann fidelity via complex Hermitian eigensolver (nalgebra `eigenvalues()` exists; the issue is the matrix square root `√ρ`) |
| **Divergence tracking** | No relative entropy | Implement `S(ρ‖σ) = Tr(ρ(log ρ − log σ))` using eigendecomposition |
| **Reasoning phase detection** | No spectral gap analysis | Compute `Δλ = λ₁ − λ₂` from eigenvalue spectrum; threshold for phase transitions |
| **Multi-turn density** | No cross-turn partial trace | Build `from_turn_pair(turn_a: &[f64], turn_b: &[f64]) → DensityMatrix` for bipartite analysis |

### 5.4 Concrete Next Experiments

These are *falsifiable* experiments that the current codebase supports or
nearly supports, ordered by implementation distance:

1. **Purity vs Hallucination Correlation** (ready now)
   * Encode top-k token distributions as diagonal density matrices
   * Compute purity for each generation step
   * Correlate low-purity steps with known hallucination instances
   * **Falsifier**: If purity does not correlate with hallucination rate, the diagnostic is not useful for this purpose

2. **Entropy Trajectory Phase Detection** (ready now)
   * Track `von_neumann_entropy(ρ_t)` across generation steps
   * Use `is_converging()` to detect entropy stabilization
   * **Falsifier**: If entropy trajectories show no distinguishable phases across diverse prompts, the diagnostic does not capture reasoning structure

3. **Text Density Fingerprinting** (ready now)
   * Encode two model outputs with `TextDensityEncoder`
   * Compare via `trace_distance(ρ₁, ρ₂)`
   * **Falsifier**: If trace distance does not distinguish semantically different outputs, bigram Gram is too coarse

4. **Depolarizing Noise Injection** (ready now)
   * Apply `QuantumChannel::depolarizing(d, p)` to a high-purity density
   * Measure entropy increase
   * Calibrate `p` against known noise injection rates in fine-tuning
   * **Falsifier**: If the channel model does not match empirical noise profiles, the depolarizing model is wrong for LLM noise

5. **Harmonic Density for Cyclic Reasoning** (ready now)
   * Build token co-occurrence graph from an LLM trace
   * Compute `harmonic_density(edges, n, tol)`
   * **Falsifier**: If β₁ = 0 for all traces, there are no cyclic reasoning patterns to detect

6. **Fidelity-Based Similarity** (requires fidelity fix)
   * Compare successive ρ(t) and ρ(t+1) via Uhlmann fidelity
   * Track fidelity decay across sequence length
   * **Falsifier**: If fidelity is always ~1.0, successive states are too similar for the diagnostic to resolve

---

6. Test Summary
---------------

| Module | Unit Tests | Coverage Notes |
|--------|-----------|----------------|
| `density_diagnostics.rs` | 9 (includes 3 `should_panic`) | Strong: invariant validation |
| `quantum_channel.rs` | 16 | Strong: depolarizing, amplitude damping, CPTP rejection |
| `process_matrix_engine.rs` | 6 | Moderate: Born rule, causal witness, QuantumSwitch |
| `reasoning_density.rs` | 7 | Experimental: sequence mixtures, top-k support, weights, window trajectories |
| `density_from_h1.rs` | 18 | Strong: sector decomposition, phase witness, normalization |
| `text_density_encoder.rs` | 5 | Moderate: binning, Gram validity |
| `harmonic_density.rs` | 5 | Strong: topological correctness |
| `packed_hermitian.rs` | 2 | Minimal: round-trip only |
| `density_matrix.rs` | 0 (direct) | Tested indirectly via all callers |
| `density.rs` | 0 (direct) | Tested indirectly; fidelity path is dead code |
| `quantum_information_engine.rs` | 0 (direct) | Not directly tested |

**Total: ~68 unit tests across the quantum module.**

---

7. What This Document Supports and Does Not Support
---------------------------------------------------

1. **What it supports**: A detailed inventory of implemented quantum-information
   tools in the Omega Engine, their mathematical soundness (within the tolerance
   framework), and concrete proposals for applying them to LLM trace diagnostics.

2. **What it does not support**: Any claim that LLMs are quantum systems, that
   these diagnostics will predict LLM behavior, or that the stubbed fidelity
   code is functional. The experiments above are falsifiable proposals, not
   validated results.

3. **Narrowest defensible claim**: The quantum engine provides a mathematically
   rigorous toolkit for analyzing probability distributions as density matrices.
   The toolkit has strong construction and validation, moderate test coverage,
   one critical stub (fidelity), and several known silent-failure paths that
   have been audited but not all fully fixed.

4. **Next test needed**: Implement `from_logit_topk()` and run experiment #1
   (purity vs hallucination) on a real LLM trace dataset. If purity does not
   distinguish hallucination from reliable generation, the entire
   density-matrix diagnostic thesis requires re-evaluation.
