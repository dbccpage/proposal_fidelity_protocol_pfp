use crate::kinds::BaseType;
use crate::traits::identity::NamedComponent as OperatorIdentity;

/// BoundaryOperatorIdentity is used for operations mapping between the internal representation
/// and external or raw data shapes.
pub trait BoundaryOperatorIdentity {
    fn name(&self) -> &'static str;
}

// ─── Lambda Failure States ──────────────────────────────────────────────────

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum LambdaFailure {
    /// Input falls outside the Lambda's admitted domain.
    OutsideAdmissibleDomain,
    /// A declared invariant was violated during transformation.
    InvariantViolation { invariant: &'static str },
    /// The transformation is undefined for this input by declared law.
    UndefinedTransformation { reason: &'static str },
    /// Input contains non-finite values (NaN, Inf).
    NonFiniteInput,
}

// ─── Operator Execution Laws & Witnesses ────────────────────────────────────

/// Explicit mapping of Phi measurement references, satisfying OP-L2.
#[derive(Debug, Clone)]
pub struct LambdaWitness {
    pub phi_functional_id: &'static str,
    pub before_ref: String,
    pub after_ref: String,
    pub comparison: PhiComparison,
    pub certificate_refs: Vec<String>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum PhiComparison {
    NonIncreasing,
    StrictDecrease,
    Incomparable,
    DiagnosticOnly,
}

/// The declared behavior law for a functional Lambda operator.
pub struct LambdaLaw {
    pub preserved_invariants: &'static [&'static str],
    pub phi_law: &'static dyn PhiLaw,
}

impl std::fmt::Debug for LambdaLaw {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("LambdaLaw")
            .field("preserved_invariants", &self.preserved_invariants)
            .field("phi_law", &"dyn PhiLaw")
            .finish()
    }
}

impl Clone for LambdaLaw {
    fn clone(&self) -> Self {
        Self {
            preserved_invariants: self.preserved_invariants,
            phi_law: self.phi_law,
        }
    }
}

pub use crate::traits::authority_laws::PhiLaw;

// ─── OS Doctrine Operator Traits ────────────────────────────────────────────

/// LambdaOp: deterministic, stateless, unary internal-descent morphism.
/// Maps S -> T without carrier enlargement, satisfying OP-L1 and OP-L2.
pub trait LambdaOp<S: BaseType, T: BaseType>: OperatorIdentity {
    fn apply(&self, input: &S) -> Result<T, LambdaFailure>;
    fn law(&self) -> &'static LambdaLaw;
}

/// ReducerOp: idempotent structure-shrinking endomorphism S -> S.
/// Satisfies OP-L3 and OP-L4 (idempotent, non-expanding).
pub trait ReducerOp<S: BaseType>: OperatorIdentity {
    fn apply(&self, input: &S) -> Result<S, LambdaFailure>;
}

/// TransformOp: pure endomorphism S -> S without Phi-monotonicity constraints.
/// Maps structure-preserving transformations.
pub trait TransformOp<S: BaseType>: OperatorIdentity {
    fn apply(&self, input: &S) -> Result<S, LambdaFailure>;
}

// ─── OS Doctrine Boundary Traits ────────────────────────────────────────────

/// MetaRule: deterministic structural classifier producing admissibility/composability judgments.
pub trait MetaRule<T> {
    type Output;
    fn evaluate(&self, subject: &T) -> Result<Self::Output, String>;
}

pub use crate::traits::intake::ConstructorError;

/// ConstructorOp: ingests raw/heterogeneous data and maps it formally into BaseType.
pub trait ConstructorOp<Raw, T: BaseType>: BoundaryOperatorIdentity {
    type Error;
    fn construct(&self, raw: Raw) -> Result<T, Self::Error>;
}

/// GeneratorOp: proposes domain-specific structural modifications to an existing BaseType.
pub trait GeneratorOp<S: BaseType, T: BaseType>: BoundaryOperatorIdentity {
    type Error;
    fn generate(&self, input: &S) -> Result<T, Self::Error>;
}

/// AdapterOp: bridges external representations into verified internal BaseType bounds.
pub trait AdapterOp<S, T: BaseType>: BoundaryOperatorIdentity {
    type Error;
    fn adapt(&self, input: &S) -> Result<T, Self::Error>;
}

/// DecoderOp: explicit structural type deserialization.
pub trait DecoderOp<S: BaseType, T: BaseType>: BoundaryOperatorIdentity {
    type Error;
    fn decode(&self, input: &S) -> Result<T, Self::Error>;
}

/// EncoderOp: explicit structural type serialization.
pub trait EncoderOp<S: BaseType, T: BaseType>: BoundaryOperatorIdentity {
    type Error;
    fn encode(&self, input: &S) -> Result<T, Self::Error>;
}
