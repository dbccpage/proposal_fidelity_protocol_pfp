Probe Model
===========

Purpose
-------

Probe generation turns a vague idea into finite questions. The first implementation is deterministic and heuristic. It does not call an LLM, database, network service, or external proof engine.

Probe Kinds
-----------

Implemented `ProbeKind` values:

* `DefinitionProbe`
* `ExampleProbe`
* `CounterexampleProbe`
* `TypeProbe`
* `InvariantProbe`
* `BoundaryProbe`
* `DescentProbe`
* `SimulationProbe`
* `FormalizationProbe`
* `ImplementationProbe`
* `SourceAuthorityProbe`
* `AnalogyBreakProbe`
* `MeasurementProbe`
* `PhysicsProbe`
* `ContinuumLimitProbe`

`PhysicsProbe` is only a scope and definition probe. It is not a physics result. `ContinuumLimitProbe` is only useful when a finite approximation or limit obligation can be described.

Required Probe Fields
---------------------

Each `QProbe` records:

* target,
* question,
* expected finite output,
* required witness,
* obstruction classes,
* terminal conditions,
* failure conditions.

Generation Interface
--------------------

The interface is:

```rust
fn generate_probe_plan(idea: &QIdea) -> ProbePlan
```

It always emits a finite projection, a baseline set of probes, and one descent obligation per probe. Additional probes are selected by simple text cues:

* paper/proof/theorem cues add formalization and analogy-break probes,
* Rust/code/test cues add implementation, invariant, and type probes,
* product/business cues add measurement probes,
* curvature/physics/quantum/bundle cues add physics and analogy-break probes,
* continuum/infinite/limit cues add continuum-limit probes.

Obstruction Output
------------------

Every probe can fail. Failure emits an `ObstructionKind` and usually a `Residual`. A failed probe is not hidden or rewritten as support.

Terminal Conditions
-------------------

A probe can help terminalize a claim only when the finite output matches the declared scope and the required witness exists. Otherwise the result remains residual, refused, underdetermined, refuted, or speculative.
