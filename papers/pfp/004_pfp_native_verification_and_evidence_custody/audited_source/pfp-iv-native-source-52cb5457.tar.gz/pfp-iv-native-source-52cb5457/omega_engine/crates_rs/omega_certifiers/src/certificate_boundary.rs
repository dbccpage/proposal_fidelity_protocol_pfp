use crate::checked_packet::{
    CheckedPacket, CheckedPacketCertificateError, CheckedPacketCertificateV1,
};
use omega_types::authority::{DescentWitness, IsAuth};
use serde::{Deserialize, Serialize};

/// Audit record for either packet-bound certificate evidence or a none-effect
/// diagnostic. Populated certificate fields remain evidence; `effect` is
/// always `None` on the checked-packet path.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[must_use = "an AuthorityVerdict records a firewall decision; dropping it discards the audit record"]
pub struct AuthorityVerdict {
    /// "None" or "Refused". Checked-packet certificates never set "Certified".
    pub effect: String,
    /// Candidate authority terminal carried as evidence, when present.
    pub terminal: Option<String>,
    /// The seven packet-bound IsAuth guards, when present.
    pub guards: Option<[bool; 7]>,
    /// Replay hash binding the evidence certificate to its packet.
    pub descent_replay_hash: Option<String>,
    /// The firewall rule that decided the verdict.
    pub firewall: String,
}

impl AuthorityVerdict {
    pub fn from_certificate(
        certificate: &CheckedPacketCertificateV1,
        firewall: impl Into<String>,
    ) -> Self {
        let guards = certificate.is_auth().guards();
        Self {
            effect: "None".to_owned(),
            terminal: Some(format!("{:?}", certificate.terminal())),
            guards: Some([
                guards.accessible,
                guards.deterministic,
                guards.obstruction_vanishes,
                guards.exhaustive,
                guards.skeletal,
                guards.no_lift,
                guards.no_refuse,
            ]),
            descent_replay_hash: Some(certificate.packet_replay_hash().to_owned()),
            firewall: firewall.into(),
        }
    }

    pub fn none_record(firewall: impl Into<String>) -> Self {
        Self {
            effect: "None".to_owned(),
            terminal: None,
            guards: None,
            descent_replay_hash: None,
            firewall: firewall.into(),
        }
    }
}

/// Seal a packet-bound evidence certificate. This function never constructs a
/// `CertifiedAuthority` or an `AuthorizedLocalResult`.
pub fn certify_checked_packet(
    packet: &CheckedPacket,
    witness: DescentWitness,
    is_auth: IsAuth,
) -> Result<CheckedPacketCertificateV1, CheckedPacketCertificateError> {
    packet.certify_evidence(witness, is_auth)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::checked_packet::{
        BoundaryMapsHash, CarrierManifestHash, CertificateRef, CertificateVerdict,
        CheckedClaimKind, CheckedClaimScope, CheckedPacketArgs, CheckerRef, DefectFieldHash,
        EvidenceRef, Hash256, ObserverBoundaryHash, ReplayHash, ToleranceProfileHash,
        WeightsAndGaugesHash,
    };
    use num_bigint::BigInt;
    use num_rational::BigRational;
    use omega_functional::gamma2::{DegreeOneResidualQ, ExactCochainComplexQ, Gamma2Functional};
    use omega_functional::phi1::{ExactPhi1Certificate, Phi1Functional, VerifiedExactPhi1};
    use omega_functional::trichotomy::{
        classify_exact, CertifiedExactTrichotomy, ObstructionDiagnosticClass, TrichotomyOutcome,
    };
    use omega_types::authority::{AuthorityTerminal, IsAuth};
    use omega_types::EvidenceCeiling;
    use omega_types::GuardEvidence;

    fn r(value: i64) -> BigRational {
        BigRational::from_integer(BigInt::from(value))
    }

    fn exact_evidence() -> (VerifiedExactPhi1, CertifiedExactTrichotomy) {
        let phi1 = Phi1Functional::verify_exact_certificate(ExactPhi1Certificate {
            omega: vec![r(1)],
            d0: vec![vec![r(1)]],
            weights: vec![r(1)],
            alpha: vec![r(1)],
            primal_residual: vec![r(0)],
            dual_witness: vec![r(0)],
            reported_value: r(0),
        })
        .unwrap();
        let complex =
            ExactCochainComplexQ::try_new(1, 1, 1, phi1.d0().to_vec(), vec![vec![r(0)]]).unwrap();
        let residual =
            DegreeOneResidualQ::try_new(&complex, phi1.primal_residual().to_vec()).unwrap();
        let gamma2 = Gamma2Functional::try_compute_exact_quotient(&residual).unwrap();
        let TrichotomyOutcome::Classified(trichotomy) = classify_exact(&phi1, &gamma2) else {
            panic!("exact evidence must classify");
        };
        (phi1, trichotomy)
    }

    fn args() -> CheckedPacketArgs {
        CheckedPacketArgs {
            packet_id: Hash256([1; 32]),
            evidence_refs: vec![EvidenceRef(Hash256([2; 32]))],
            checker_ref: CheckerRef("test-checker".to_owned()),
            schema_hash: Hash256([3; 32]),
            carrier_hash: CarrierManifestHash(Hash256([4; 32])),
            boundary_maps_hash: BoundaryMapsHash(Hash256([5; 32])),
            weights_and_gauges_hash: WeightsAndGaugesHash(Hash256([6; 32])),
            submitted_defect_hash: DefectFieldHash(Hash256([7; 32])),
            phi1_certificate_ref: CertificateRef(Hash256([8; 32])),
            closure_certificate_ref: CertificateRef(Hash256([9; 32])),
            observer_boundary_hash: ObserverBoundaryHash(Hash256([10; 32])),
            tolerance_profile_hash: ToleranceProfileHash(Hash256([11; 32])),
            replay_hash: ReplayHash(Hash256([12; 32])),
            certificate_status: CertificateVerdict::Verified,
            checked_scope: CheckedClaimScope {
                claim_kind: CheckedClaimKind::ObstructionSummary,
                authority_ceiling: EvidenceCeiling::BoundaryChecked,
                law_refs: vec![],
            },
        }
    }

    fn all_true_is_auth(terminal: AuthorityTerminal) -> IsAuth {
        IsAuth::decide(
            terminal,
            GuardEvidence::new_valid(["cand_01"], "K_carrier_01", "blake3:deadbeef"),
        )
        .expect("fixture guards satisfy IsAuth")
    }

    fn certificate() -> CheckedPacketCertificateV1 {
        let (phi1, trichotomy) = exact_evidence();
        let packet = CheckedPacket::new_checked(args(), &phi1, &trichotomy).unwrap();
        assert_eq!(packet.status(), ObstructionDiagnosticClass::ExactRepair);
        let witness = DescentWitness::from_verified_replay(
            AuthorityTerminal::ExactRuleDerived,
            "descent-A",
            "0c".repeat(32),
        )
        .unwrap();
        certify_checked_packet(
            &packet,
            witness,
            all_true_is_auth(AuthorityTerminal::ExactRuleDerived),
        )
        .unwrap()
    }

    #[test]
    fn certify_checked_packet_seals_none_effect_evidence() {
        let certificate = certificate();
        assert_eq!(certificate.terminal(), AuthorityTerminal::ExactRuleDerived);
        assert!(certificate.authority_effect().is_none());
    }

    #[test]
    fn authority_verdict_transcribes_certificate_without_promoting() {
        let certificate = certificate();
        let verdict = AuthorityVerdict::from_certificate(&certificate, "certify_checked_packet");
        assert_eq!(verdict.effect, "None");
        assert_eq!(verdict.terminal.as_deref(), Some("ExactRuleDerived"));
        assert_eq!(verdict.guards, Some([true; 7]));
        assert_eq!(
            verdict.descent_replay_hash.as_deref(),
            Some("0c".repeat(32).as_str())
        );
    }

    #[test]
    fn authority_verdict_none_record_leaves_evidence_fields_empty() {
        let verdict = AuthorityVerdict::none_record("diagnostic-only");
        assert_eq!(verdict.effect, "None");
        assert!(verdict.terminal.is_none());
        assert!(verdict.guards.is_none());
        assert!(verdict.descent_replay_hash.is_none());
    }
}
