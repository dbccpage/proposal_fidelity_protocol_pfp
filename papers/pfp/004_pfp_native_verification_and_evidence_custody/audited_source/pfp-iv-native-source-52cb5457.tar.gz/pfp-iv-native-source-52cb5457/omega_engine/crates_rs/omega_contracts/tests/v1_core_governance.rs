//! 05_governance — the 6 migrated governance contracts load and pass validate_registry
//! (AuthInterface / Evaluator / TerminalMapper / Validator validators + id-gated Policy;
//! CouncilDecision is classified Policy with a non-anomalon.policy id, validated via
//! validate_common only).
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn governance_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/05_core_governance");
    let report = load_v1_dir(&dir).expect("dir readable");
    assert_eq!(report.loaded, 8, "expected 8 migrated governance contracts");
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
