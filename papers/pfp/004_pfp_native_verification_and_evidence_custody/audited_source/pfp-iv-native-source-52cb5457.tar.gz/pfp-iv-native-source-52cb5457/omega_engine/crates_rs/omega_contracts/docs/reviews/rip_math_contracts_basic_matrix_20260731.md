# `/rip-math-contracts basic_matrix` — triple panel receipt

**Date:** 2026-07-31  
**Target:** `math/basic_matrix.contract.yaml`  
**Realization:** `omega_linear_algebra/src/backend/basic_matrix.rs`  
**AuthorityEffect:** `None`

## Stages

| Stage | Skill | Output locus |
| --- | --- | --- |
| 1 | `/panepistimion-math-prof` | `potential_defects` (MATH_CANONICAL_REVIEW) |
| 2 | `/panepistimion-cs-prof-ml-ai-info` | `realization_delta_vs_implemented_math_file` (CS_IMPL_DELTA_REVIEW) |
| 3 | `/techne-master-of-proofs-and-derivations` | meta items `PROOF_META_REVIEW` |

## Verdict

```text
RIP_MATH_CONTRACTS: PASS_WITH_RESIDUAL
Stages: math=NEEDS_MATH_YAML_REPAIR cs=DELTAS_DOCUMENTED proof_meta=PANEL_CONSISTENT
Residuals: ZERO_DIM_LAW, FIELD_LANGUAGE, CODE_PERMITS_0_DIM, REPLAY_PARTIAL
AuthorityEffect: None
```

## Load-bearing agreements (all three)

1. **Zero-dim:** YAML `>0` conflicts with FinVect/cochain use; code allows 0-dim; do not silent-weaken YAML for slop; math repair or second object first (007a).  
2. **Field:** YAML overclaims field; code is `Numeric` semiring-capable array; field theorems out of scope for storage.  
3. **Shape core:** len/OOB/matmul/add checks **MATCH** YAML structural core — not theorem discharge.  
4. **Split:** keep `basic_matrix` ≠ `matrix` linear-map object.

## Nonclaims

Not PROVED. Not wave exit. Not GlobalGreen. Not HoTT.

**Skill formalized:** `.grok/skills/rip-math-contracts/SKILL.md` (+ `.agents` / `.claude` mirrors).
