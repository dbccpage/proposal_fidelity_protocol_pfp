//! --- yaml
//! title: atp_lexer
//! file_name: lexer.rs
//! file_location: ~/anomalon/anomalon_kernel/omega_core/src/compiler/lexer.rs
//! status: Diamond
//! invariance_level: Tier 1
//! logic_system: Self-Repair Cohomology
//! substrate: Rust
//! description: >
//!   Phase 1 of the AutoP compiler frontend. Tokenizes raw .atp source text into
//!   a stream of SpannedTokens. Every token carries its byte-offset Span so the
//!   Phase 3 boundary checker can map H^1 / H^2 tears back to exact source positions
//!   for the Geometric IDE (Lambda X-012).
//! omega_assertions:
//!   - "Keywords are reserved: manifold, morphism, functor, adjunction, sheaf, section, proof, tensor, orbit"
//!   - "Ident regex must not shadow keywords (logos priority handles this)"
//!   - "DimBound extracts the integer from Dim(N) at lex time"
//!   - "Comments (--) and whitespace are discarded, never reach the parser"
//! content_hash: 3af336a0efb798adbf64021778b1e4ad8b7b1dec5b62dc453b9415b1b2ae5296
//! version: 2
//! ---

use logos::{Logos, Span};
use serde::{Deserialize, Serialize};

#[derive(Default, Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum LexError {
    #[default]
    InvalidToken,
    NumericOverflow,
    MalformedDimBound,
}

/// Token types for the AutoP (.atp) language.
///
/// Design decisions (from results_autop.md roadmap):
///   - Keywords map 1:1 to topological declaration kinds (manifold, morphism, etc.)
///   - Operators map to category-theoretic constructs (Arrow = morphism mapping,
///     Product = Cartesian product, Parallel = tensor product execution)
///   - Ident/IntLit/DimBound carry parsed values to avoid re-parsing downstream
///   - Comments and whitespace are skipped at lex time (never enter the AST)
#[derive(Logos, Debug, PartialEq, Clone, Serialize, Deserialize)]
#[logos(error = LexError)]
#[logos(skip r"[ \t\n\r\f]+")]
#[logos(skip r"//[^\n\r]*")]
pub enum Token {
    // ------------------------------------------------------------------
    // Keywords (Self-Repair Logic & Category Theory)
    // All priority = 3 to strictly outrank Identifiers.
    // ------------------------------------------------------------------
    #[token("manifold", priority = 3)]
    Manifold,
    #[token("morphism", priority = 3)]
    Morphism,
    #[token("functor", priority = 3)]
    Functor,
    #[token("adjunction", priority = 3)]
    Adjunction,
    #[token("sheaf", priority = 3)]
    Sheaf,
    #[token("section", priority = 3)]
    Section,
    #[token("proof", priority = 3)]
    Proof,
    #[token("tensor", priority = 3)]
    Tensor,
    #[token("category", priority = 3)]
    Category,
    #[token("natural", priority = 3)]
    Natural,
    #[token("component", priority = 3)]
    Component,
    #[token("object", priority = 3)]
    Object,
    #[token("orbit", priority = 3)]
    Orbit,
    #[token("where", priority = 3)]
    Where,
    #[token("invariant", priority = 3)]
    Invariant,
    #[token("detect", priority = 3)]
    Detect,
    #[token("forall", priority = 3)]
    #[token("\u{2200}", priority = 3)] // ∀  forall
    Forall,
    #[token("exists", priority = 3)]
    #[token("\u{2203}", priority = 3)] // ∃  exists
    Exists,
    #[token("left", priority = 3)]
    Left,
    #[token("right", priority = 3)]
    Right,
    #[token("unit", priority = 3)]
    Unit,
    #[token("counit", priority = 3)]
    Counit,
    #[token("disjoint", priority = 3)]
    Disjoint,
    #[token("execute", priority = 3)]
    Execute,
    #[token("intersect", priority = 3)]
    Intersect,
    #[token("empty", priority = 3)]
    Empty,
    #[token("Dim", priority = 3)]
    Dim,
    #[token("dim", priority = 3)]
    DimLower,
    #[token("network", priority = 3)]
    Network,
    #[token("node", priority = 3)]
    Node,
    #[token("deploy", priority = 3)]
    Deploy,
    #[token("on", priority = 3)]
    On,
    #[token("operad", priority = 3)]
    Operad,
    #[token("bundle", priority = 3)]
    Bundle,
    #[token("topos", priority = 3)]
    Topos,
    #[token("presheaf", priority = 3)]
    Presheaf,
    #[token("cohomology", priority = 3)]
    Cohomology,
    #[token("operator", priority = 3)]
    Operator,
    #[token("end", priority = 3)]
    End,

    // ------------------------------------------------------------------
    // Topological Operators & Punctuation
    // ------------------------------------------------------------------
    #[token("->")]
    #[token("\u{2192}")] // →  arrow
    Arrow,
    #[token("=>")]
    #[token("\u{21D2}")] // ⇒  double arrow
    DoubleArrow,
    #[token(">>>")]
    #[token("\u{2218}")] // ∘  composition
    Compose,
    #[token("*")]
    Product,
    #[token("||")]
    #[token("\u{2297}")] // ⊗  tensor product
    Parallel,
    #[token("|")]
    Bar,
    #[token(":")]
    Colon,
    #[token(";")]
    Semi,
    #[token("=")]
    Equals,
    #[token("!=")]
    #[token("\u{2260}")] // ≠  not equals
    NotEquals,
    #[token("(")]
    LParen,
    #[token(")")]
    RParen,
    #[token("{")]
    LBrace,
    #[token("}")]
    RBrace,
    #[token("[")]
    LBracket,
    #[token("]")]
    RBracket,
    #[token(",")]
    Comma,
    #[token("+")]
    Plus,
    #[token("-")]
    Minus,
    #[token("/")]
    Slash,
    #[token("^")]
    Caret,
    #[token("<=")]
    #[token("\u{2264}")] // ≤  less-equal
    LessEq,
    #[token(">=")]
    #[token("\u{2265}")] // ≥  greater-equal
    GreaterEq,
    #[token("<")]
    Less,
    #[token(">")]
    Greater,

    // ------------------------------------------------------------------
    // Identifiers and Literals
    // ------------------------------------------------------------------
    #[regex("[a-zA-Z_][a-zA-Z0-9_]*", |lex| lex.slice().to_string())]
    Ident(String),

    // A digit run is one token. More than 20 digits, or a 20-digit value above
    // u64::MAX, is NumericOverflow. Capping the regex at 20 digits split the
    // tail into a second literal whenever the prefix still fit in u64.
    #[regex("[0-9]+", |lex| {
        let s = lex.slice();
        if s.len() > 20 {
            return Err(LexError::NumericOverflow);
        }
        s.parse().map_err(|_| LexError::NumericOverflow)
    })]
    IntLit(u64),

    // Virtual EOF tag output mechanically at end of stream mapping
    EOF,
}

impl Token {
    /// Returns true if the token is a reserved language keyword.
    pub fn is_keyword(&self) -> bool {
        matches!(
            self,
            Token::Manifold
                | Token::Morphism
                | Token::Functor
                | Token::Adjunction
                | Token::Sheaf
                | Token::Section
                | Token::Proof
                | Token::Tensor
                | Token::Category
                | Token::Natural
                | Token::Component
                | Token::Object
                | Token::Orbit
                | Token::Where
                | Token::Invariant
                | Token::Detect
                | Token::Forall
                | Token::Exists
                | Token::Left
                | Token::Right
                | Token::Unit
                | Token::Counit
                | Token::Disjoint
                | Token::Execute
                | Token::Intersect
                | Token::Empty
                | Token::Dim
                | Token::DimLower
                | Token::Network
                | Token::Node
                | Token::Deploy
                | Token::On
                | Token::Operad
                | Token::Bundle
                | Token::Topos
                | Token::Presheaf
                | Token::Cohomology
                | Token::Operator
                | Token::End
        )
    }
}

/// A token paired with its byte-offset span in the source text.
///
/// The `span` field is critical for Phase 3: when the boundary checker detects
/// an H^1 or H^2 tear, it uses these coordinates to report the exact source
/// location of the topological fracture.
#[derive(Debug, PartialEq, Clone, Serialize, Deserialize)]
pub struct SpannedToken {
    pub token: Result<Token, LexError>,
    pub span: Span,
}

/// A pre-computed index for O(log N) line/col lookups.
/// This prevents O(N^2) behavior in IDE diagnostics.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LineIndex {
    newline_offsets: Vec<usize>,
}

impl LineIndex {
    pub fn new(source: &str) -> Self {
        let mut offsets = vec![0]; // Line 1 starts at index 0
        for (i, b) in source.bytes().enumerate() {
            if b == b'\n' {
                offsets.push(i + 1);
            }
        }
        Self {
            newline_offsets: offsets,
        }
    }

    /// Computes a 1-indexed line and column number from a byte offset.
    pub fn line_col(&self, offset: usize) -> (usize, usize) {
        match self.newline_offsets.binary_search(&offset) {
            Ok(line_idx) => (line_idx + 1, 1),
            Err(line_idx) => {
                let start_of_line = self.newline_offsets[line_idx - 1];
                let col = offset - start_of_line + 1;
                (line_idx, col)
            }
        }
    }
}

/// Computes a line and column number from a byte-offset span.
/// DEPRECATED: Use `LineIndex` instead for performance. This is kept for backwards compatibility.
pub fn span_to_line_col(source: &str, span: Span) -> (usize, usize) {
    LineIndex::new(source).line_col(span.start)
}

/// Tokenize raw `.atp` source into a vector of spanned tokens.
///
/// This is the Phase 1 entry point. The output feeds directly into the
/// Phase 2 parser which constructs the Topological AST.
pub fn tokenize(source: &str) -> Vec<SpannedToken> {
    let mut lexer = Token::lexer(source);
    let mut tokens = Vec::new();

    while let Some(token) = lexer.next() {
        tokens.push(SpannedToken {
            token,
            span: lexer.span(),
        });
    }

    tokens.push(SpannedToken {
        token: Ok(Token::EOF),
        span: source.len()..source.len(),
    });

    tokens
}

/// Strict tokenizer that aborts on the first lexical error.
/// Used when Phase 3 requires an uncorrupted structural map.
pub fn tokenize_strict(source: &str) -> Result<Vec<SpannedToken>, LexError> {
    let mut lexer = Token::lexer(source);
    let mut tokens = Vec::new();

    while let Some(token) = lexer.next() {
        if let Err(err) = &token {
            return Err(err.clone());
        }
        tokens.push(SpannedToken {
            token,
            span: lexer.span(),
        });
    }

    tokens.push(SpannedToken {
        token: Ok(Token::EOF),
        span: source.len()..source.len(),
    });

    Ok(tokens)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_keyword_recognition() {
        let tokens =
            tokenize("manifold morphism functor adjunction sheaf section proof tensor orbit category natural component object operad bundle topos presheaf cohomology operator");
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Manifold),
                Ok(Token::Morphism),
                Ok(Token::Functor),
                Ok(Token::Adjunction),
                Ok(Token::Sheaf),
                Ok(Token::Section),
                Ok(Token::Proof),
                Ok(Token::Tensor),
                Ok(Token::Orbit),
                Ok(Token::Category),
                Ok(Token::Natural),
                Ok(Token::Component),
                Ok(Token::Object),
                Ok(Token::Operad),
                Ok(Token::Bundle),
                Ok(Token::Topos),
                Ok(Token::Presheaf),
                Ok(Token::Cohomology),
                Ok(Token::Operator),
                Ok(Token::EOF)
            ]
        );
    }

    #[test]
    fn test_quantifiers() {
        let tokens = tokenize("forall exists where");
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Forall),
                Ok(Token::Exists),
                Ok(Token::Where),
                Ok(Token::EOF)
            ]
        );
    }

    #[test]
    fn test_operators() {
        let tokens = tokenize("-> => >>> * || | : ; = ( ) { } [ ] ,");
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Arrow),
                Ok(Token::DoubleArrow),
                Ok(Token::Compose),
                Ok(Token::Product),
                Ok(Token::Parallel),
                Ok(Token::Bar),
                Ok(Token::Colon),
                Ok(Token::Semi),
                Ok(Token::Equals),
                Ok(Token::LParen),
                Ok(Token::RParen),
                Ok(Token::LBrace),
                Ok(Token::RBrace),
                Ok(Token::LBracket),
                Ok(Token::RBracket),
                Ok(Token::Comma),
                Ok(Token::EOF)
            ]
        );
    }

    #[test]
    fn test_ident_extraction() {
        let tokens = tokenize("Natural zero succ add_numbers x1");
        for t in &tokens[..tokens.len() - 1] {
            assert!(matches!(t.token, Ok(Token::Ident(_))));
        }
        // Last token is EOF
        assert_eq!(tokens.last().unwrap().token, Ok(Token::EOF));
        assert_eq!(tokens[0].token, Ok(Token::Ident("Natural".to_string())));
        assert_eq!(tokens[3].token, Ok(Token::Ident("add_numbers".to_string())));
    }

    #[test]
    fn test_int_literal() {
        let tokens = tokenize("42 0 1 999");
        assert_eq!(tokens[0].token, Ok(Token::IntLit(42)));
        assert_eq!(tokens[1].token, Ok(Token::IntLit(0)));
        assert_eq!(tokens[2].token, Ok(Token::IntLit(1)));
        assert_eq!(tokens[3].token, Ok(Token::IntLit(999)));
    }

    #[test]
    fn test_int_overflow_rejected() {
        // 24 digits. The whole run is one overflow, not a 20-digit slice plus a tail.
        let src = "184467440737095516160000";
        let tokens = tokenize(src);
        assert_eq!(tokens.len(), 2);
        assert_eq!(tokens[0].token, Err(LexError::NumericOverflow));
        assert_eq!(tokens[0].span, 0..src.len());
        assert_eq!(tokens[1].token, Ok(Token::EOF));
    }

    #[test]
    fn test_int_twenty_one_digits_not_split_after_u64_prefix() {
        // First 20 digits are u64::MAX. The 21st digit must not become IntLit(0).
        let src = "184467440737095516150";
        let tokens = tokenize(src);
        assert_eq!(tokens.len(), 2);
        assert_eq!(tokens[0].token, Err(LexError::NumericOverflow));
        assert_eq!(tokens[0].span, 0..src.len());
        assert_eq!(tokens[1].token, Ok(Token::EOF));
    }

    #[test]
    fn test_u64_max_literal_accepted() {
        let tokens = tokenize("18446744073709551615");
        assert_eq!(tokens[0].token, Ok(Token::IntLit(u64::MAX)));
        assert_eq!(tokens.len(), 2);
    }

    #[test]
    fn test_dim_bound_extraction() {
        let tokens = tokenize("Dim(3)");
        assert_eq!(tokens[0].token, Ok(Token::Dim));
        assert_eq!(tokens[1].token, Ok(Token::LParen));
        assert_eq!(tokens[2].token, Ok(Token::IntLit(3)));
        assert_eq!(tokens[3].token, Ok(Token::RParen));
        assert_eq!(tokens[4].token, Ok(Token::EOF));
    }

    #[test]
    fn test_dim_bound_large() {
        let tokens = tokenize("Dim(11)");
        assert_eq!(tokens[0].token, Ok(Token::Dim));
        assert_eq!(tokens[1].token, Ok(Token::LParen));
        assert_eq!(tokens[2].token, Ok(Token::IntLit(11)));
        assert_eq!(tokens[3].token, Ok(Token::RParen));
        assert_eq!(tokens[4].token, Ok(Token::EOF));
    }

    #[test]
    fn test_comments_stripped() {
        let tokens = tokenize("manifold // this is a comment\nmorphism");
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![Ok(Token::Manifold), Ok(Token::Morphism), Ok(Token::EOF)]
        );
    }

    #[test]
    fn test_whitespace_stripped() {
        let tokens = tokenize("  manifold  \t\n  morphism  ");
        assert_eq!(tokens.len(), 3); // Manifold + Morphism + EOF
    }

    #[test]
    fn test_span_tracking() {
        let source = "manifold Natural";
        let tokens = tokenize(source);
        // "manifold" is bytes 0..8
        assert_eq!(tokens[0].span, 0..8);
        // "Natural" is bytes 9..16
        assert_eq!(tokens[1].span, 9..16);
    }

    #[test]
    fn test_line_col_conversion() {
        let source = "manifold\n  Natural";
        let tokens = tokenize(source);
        let span = tokens[1].span.clone();
        let (line, col) = span_to_line_col(source, span);
        assert_eq!(line, 2);
        assert_eq!(col, 3);
    }

    #[test]
    fn test_manifold_declaration() {
        let source = "manifold Natural : Dim(1) where";
        let tokens = tokenize(source);
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Manifold),
                Ok(Token::Ident("Natural".to_string())),
                Ok(Token::Colon),
                Ok(Token::Dim),
                Ok(Token::LParen),
                Ok(Token::IntLit(1)),
                Ok(Token::RParen),
                Ok(Token::Where),
                Ok(Token::EOF)
            ]
        );
    }

    #[test]
    fn test_morphism_signature() {
        let source = "morphism add : Natural * Natural -> Natural where";
        let tokens = tokenize(source);
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Morphism),
                Ok(Token::Ident("add".to_string())),
                Ok(Token::Colon),
                Ok(Token::Ident("Natural".to_string())),
                Ok(Token::Product),
                Ok(Token::Ident("Natural".to_string())),
                Ok(Token::Arrow),
                Ok(Token::Ident("Natural".to_string())),
                Ok(Token::Where),
                Ok(Token::EOF),
            ]
        );
    }

    #[test]
    fn test_section_with_function_application() {
        let source = "section succ : Natural -> Natural";
        let tokens = tokenize(source);
        assert_eq!(tokens[0].token, Ok(Token::Section));
        assert_eq!(tokens[1].token, Ok(Token::Ident("succ".to_string())));
        assert_eq!(tokens[2].token, Ok(Token::Colon));
    }

    #[test]
    fn test_proof_with_forall() {
        let source = "proof bounded : forall n, dim(n) = 1";
        let tokens = tokenize(source);
        assert_eq!(tokens[0].token, Ok(Token::Proof));
        assert_eq!(tokens[3].token, Ok(Token::Forall));
    }

    #[test]
    fn test_adjunction_keywords() {
        let source =
            "adjunction FileIO where\n  left open_file\n  right close_file\n  unit\n  counit";
        let tokens = tokenize(source);
        let kinds: Vec<_> = tokens.iter().filter_map(|t| t.token.clone().ok()).collect();
        assert!(kinds.contains(&Token::Adjunction));
        assert!(kinds.contains(&Token::Left));
        assert!(kinds.contains(&Token::Right));
        assert!(kinds.contains(&Token::Unit));
        assert!(kinds.contains(&Token::Counit));
    }

    #[test]
    fn test_tensor_with_disjoint() {
        let source = "tensor parallel(a, b) where\n  disjoint : a intersect b = empty";
        let tokens = tokenize(source);
        let kinds: Vec<_> = tokens.iter().filter_map(|t| t.token.clone().ok()).collect();
        assert!(kinds.contains(&Token::Tensor));
        assert!(kinds.contains(&Token::Disjoint));
        assert!(kinds.contains(&Token::Intersect));
        assert!(kinds.contains(&Token::Empty));
    }

    #[test]
    fn test_equation_with_comma() {
        let source = "add(zero, n) = n";
        let tokens = tokenize(source);
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Ident("add".to_string())),
                Ok(Token::LParen),
                Ok(Token::Ident("zero".to_string())),
                Ok(Token::Comma),
                Ok(Token::Ident("n".to_string())),
                Ok(Token::RParen),
                Ok(Token::Equals),
                Ok(Token::Ident("n".to_string())),
                Ok(Token::EOF),
            ]
        );
    }

    #[test]
    fn test_full_manifold_block() {
        let source = r#"// AutoP manifold declaration
manifold Natural : Dim(1) where
  section zero : Natural
  section succ : Natural -> Natural
  proof bounded : forall n, dim(n) = 1"#;

        let tokens = tokenize(source);
        // Comments stripped, all keywords and structure preserved
        assert!(tokens.len() > 10);
        assert_eq!(tokens[0].token, Ok(Token::Manifold));
        // Ensure ends with EOF
        let last = tokens.last().unwrap();
        assert_eq!(last.token, Ok(Token::EOF));
    }

    #[test]
    fn test_empty_source() {
        let tokens = tokenize("");
        assert_eq!(tokens.len(), 1);
        assert_eq!(tokens[0].token, Ok(Token::EOF));
    }

    #[test]
    fn test_comment_only_source() {
        let tokens = tokenize("// just a comment\n// another one");
        assert_eq!(tokens.len(), 1);
        assert_eq!(tokens[0].token, Ok(Token::EOF));
    }

    #[test]
    fn test_no_error_tokens_on_valid_input() {
        let source =
            "manifold M : Dim(3) where\n  section x : M\n  proof p : forall a, exists b, a = b";
        let tokens = tokenize(source);
        for t in &tokens {
            assert!(
                t.token.is_ok(),
                "Unexpected error token at span {:?}",
                t.span
            );
        }
    }

    #[test]
    fn test_unicode_operators() {
        let tokens = tokenize("∘ ⊗ → ⇒ ≠ ≤ ≥ ∀ ∃");
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Compose),
                Ok(Token::Parallel),
                Ok(Token::Arrow),
                Ok(Token::DoubleArrow),
                Ok(Token::NotEquals),
                Ok(Token::LessEq),
                Ok(Token::GreaterEq),
                Ok(Token::Forall),
                Ok(Token::Exists),
                Ok(Token::EOF),
            ]
        );
    }

    #[test]
    fn test_unicode_identifiers() {
        // We disabled Greek alpha, beta, etc. in Ident regex to prevent
        // homoglyph attacks. So these should all be LexError::InvalidToken
        let tokens = tokenize("δ λ ψ αβγ");
        for t in &tokens[..tokens.len() - 1] {
            if let Ok(Token::Ident(_)) = t.token {
                panic!("Greek character erroneously parsed as Ident: {:?}", t);
            }
        }
    }

    #[test]
    fn test_end_keyword() {
        let tokens = tokenize("category Grp where end");
        let kinds: Vec<_> = tokens.iter().map(|t| t.token.clone()).collect();
        assert_eq!(
            kinds,
            vec![
                Ok(Token::Category),
                Ok(Token::Ident("Grp".to_string())),
                Ok(Token::Where),
                Ok(Token::End),
                Ok(Token::EOF),
            ]
        );
    }

    #[test]
    fn test_dead_tokens_now_idents() {
        // tensor_transition and geometry_validation are no longer keywords
        let tokens = tokenize("tensor_transition geometry_validation");
        assert_eq!(
            tokens[0].token,
            Ok(Token::Ident("tensor_transition".to_string()))
        );
        assert_eq!(
            tokens[1].token,
            Ok(Token::Ident("geometry_validation".to_string()))
        );
    }

    #[test]
    fn test_minus_minus_operator() {
        // Formerly: `a--b` tokenized as `Ident(a)` and comment `--b`.
        // Now it must tokenize as `a`, `-`, `-`, `b`.
        let tokens = tokenize("a--b");
        assert_eq!(tokens[0].token, Ok(Token::Ident("a".to_string())));
        assert_eq!(tokens[1].token, Ok(Token::Minus));
        assert_eq!(tokens[2].token, Ok(Token::Minus));
        assert_eq!(tokens[3].token, Ok(Token::Ident("b".to_string())));
    }

    #[test]
    fn test_homoglyph_attack_prevention() {
        // Greek 'Nu' Ν vs Latin 'N', token should fail
        let tokens = tokenize("Νatural");
        // Logo's behavior on unrecognized characters is to return an error token
        assert!(matches!(tokens[0].token, Err(LexError::InvalidToken)));
    }

    #[test]
    fn test_operator_prefix_ambiguity() {
        // Test that longest match works for >>>>
        let tokens = tokenize(">>>>");
        assert_eq!(tokens[0].token, Ok(Token::Compose)); // >>>
        assert_eq!(tokens[1].token, Ok(Token::Greater)); // >

        let tokens = tokenize(">>=>");
        assert_eq!(tokens[0].token, Ok(Token::Greater)); // >
        assert_eq!(tokens[1].token, Ok(Token::GreaterEq)); // >=
        assert_eq!(tokens[2].token, Ok(Token::Greater)); // >
    }
}
