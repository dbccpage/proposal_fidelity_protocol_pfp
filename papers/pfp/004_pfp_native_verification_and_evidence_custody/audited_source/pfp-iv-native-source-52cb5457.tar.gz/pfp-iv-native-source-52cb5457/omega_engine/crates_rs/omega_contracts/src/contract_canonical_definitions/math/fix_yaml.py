import re

with open('functional_layer_boundary.contract.yaml', 'r', encoding='utf-8') as f:
    text = f.read()

deps = '''    - "urn:omega:math:finite_obstruction_trichotomy:v0.2.0"
    - "urn:omega:math:evaluation_hierarchy:v1.0.0"
    - "urn:omega:math:validated_cochain_complex:v1.0.0"
    - "urn:omega:math:raw_closure_defect:v1.0.0"
    - "urn:omega:math:candidate_obstruction_window:v1.0.0"
    - "urn:omega:math:quotient_transport:v1.0.0"
    - "urn:omega:math:transport_loss_ledger:v1.0.0"
    - "urn:omega:math:tie_r:v1.0.0"'''

# Just append to the end of dependencies list
# The list is under 'dependencies: contracts:'
text = re.sub(r'(\s+-\s+"urn:omega:math:evaluation_hierarchy:v1.0.0"\n)', r'\1' + deps[deps.find('- "urn:omega:math:validated_cochain_complex:v1.0.0"'):] + '\n', text)

with open('functional_layer_boundary.contract.yaml', 'w', encoding='utf-8') as f:
    f.write(text)
