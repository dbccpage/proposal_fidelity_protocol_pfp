//! code-reality observer: committed source must correspond to a built, passing artifact.
//!
//! Two canaries:
//! * tests that are *written but unrun* are not evidence — they are the AutoP failure mode
//!   where green-looking source has never actually executed;
//! * source that is *committed but unbuilt/unwired* is not a built artifact and cannot back
//!   any runnable claim.
use super::ObserverReading;
use crate::row::{BuildStatus, ReconciliationRow, TestsState};

/// Deterministic code-reality reading for a row.
pub fn check(row: &ReconciliationRow) -> ObserverReading {
    let mut findings = Vec::new();

    if row.tests_state == TestsState::WrittenUnrun {
        findings.push("written != passing (AutoP canary)".to_string());
    }
    if row.build_status == BuildStatus::UnbuiltUnwired {
        findings.push("committed source is not a built artifact".to_string());
    }

    ObserverReading {
        observer: "code-reality",
        findings,
    }
}
