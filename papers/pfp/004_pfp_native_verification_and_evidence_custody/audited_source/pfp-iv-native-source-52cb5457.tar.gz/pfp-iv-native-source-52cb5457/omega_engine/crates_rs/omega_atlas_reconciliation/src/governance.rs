//! Governance Doctrine v000 — strict-regime checks.
//!
//! Authority is never minted ambiently. Any change that would expand authority, waive
//! evidence, mutate doctrine, promote a residual, self-certify, or relax a boundary must
//! arrive as a *complete licensed lift*: a ten-field [`GovernanceRecord`] that names the
//! obstruction, the prior and proposed rule, the zero-difference relation, the residual
//! class, the authority and evidence basis, the affected roles, the non-harm consequences,
//! and the terminal status. Anything short of that is refused.
//!
//! Role powers are pinned: enforcement, diagnosis, voting, waiving, and doctrine revision
//! are separated so that no single role can both propose and bless a change. In particular
//! a Model mints nothing — it may not even diagnose authoritatively.
use serde::{Deserialize, Serialize};

/// The ten-field licensed-lift record required for any strict-regime governance change.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GovernanceRecord {
    pub obstruction: String,
    pub prior_rule: String,
    pub proposed_rule: String,
    pub zero_difference_relation: String,
    pub residual_class: String,
    pub authority_basis: String,
    pub evidence_basis: String,
    pub affected_roles: Vec<String>,
    pub non_harm_consequences: String,
    pub terminal_status: String,
}

impl GovernanceRecord {
    /// Complete iff every string field is non-empty AND at least one role is affected.
    pub fn is_complete(&self) -> bool {
        !self.obstruction.is_empty()
            && !self.prior_rule.is_empty()
            && !self.proposed_rule.is_empty()
            && !self.zero_difference_relation.is_empty()
            && !self.residual_class.is_empty()
            && !self.authority_basis.is_empty()
            && !self.evidence_basis.is_empty()
            && !self.affected_roles.is_empty()
            && !self.non_harm_consequences.is_empty()
            && !self.terminal_status.is_empty()
    }

    /// A fully-populated record (a complete licensed lift).
    pub fn full_sample() -> Self {
        Self {
            obstruction: "authority surface declared but unpinned to a role ceiling".to_string(),
            prior_rule: "authority effect inferred ambiently from code".to_string(),
            proposed_rule: "authority effect must equal the role-pinned ceiling".to_string(),
            zero_difference_relation: "rename + path normalization only".to_string(),
            residual_class: "licenseD-LIFT".to_string(),
            authority_basis: "Lean-mechanized sealed authority type".to_string(),
            evidence_basis: "local replay + green CI-gated tests".to_string(),
            affected_roles: vec!["Blackrod".to_string(), "Council".to_string()],
            non_harm_consequences: "no public surface widened; defensive-only preserved"
                .to_string(),
            terminal_status: "LicensedLift".to_string(),
        }
    }
}

/// The governance roles in the council tower.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Role {
    Blackrod,
    Woland,
    Logos,
    Pilate,
    Council,
    Model,
}

/// Powers a role may or may not hold.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Power {
    Diagnose,
    Enforce,
    Block,
    Terminalize,
    Vote,
    WaiveEvidence,
    ReviseDoctrine,
}

/// Strict role/power separation. Default deny.
///
/// * Blackrod enforces and blocks, but may not vote, waive evidence, or revise doctrine.
/// * Woland diagnoses (adversarial review) but may not enforce, block, or terminalize.
/// * Council votes and diagnoses.
/// * Logos and Pilate diagnose.
/// * Model mints nothing — even diagnosis is non-authoritative, so it holds no power here.
pub fn role_may(role: Role, power: Power) -> bool {
    match (role, power) {
        (Role::Blackrod, Power::Enforce) => true,
        (Role::Blackrod, Power::Block) => true,
        (Role::Blackrod, _) => false,

        (Role::Woland, Power::Diagnose) => true,
        (Role::Woland, _) => false,

        (Role::Council, Power::Vote) => true,
        (Role::Council, Power::Diagnose) => true,
        (Role::Council, _) => false,

        (Role::Logos, Power::Diagnose) => true,
        (Role::Logos, _) => false,

        (Role::Pilate, Power::Diagnose) => true,
        (Role::Pilate, _) => false,

        (Role::Model, _) => false,
    }
}

/// The kind of governance change being attempted.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum GovKind {
    AuthorityExpansion,
    EvidenceWaiver,
    DoctrineMutation,
    ResidualPromotion,
    SelfCertification,
    BoundaryRelaxation,
}

impl GovKind {
    fn label(self) -> &'static str {
        match self {
            GovKind::AuthorityExpansion => "authority-expansion",
            GovKind::EvidenceWaiver => "evidence-waiver",
            GovKind::DoctrineMutation => "doctrine-mutation",
            GovKind::ResidualPromotion => "residual-promotion",
            GovKind::SelfCertification => "self-certification",
            GovKind::BoundaryRelaxation => "boundary-relaxation",
        }
    }
}

/// A proposed governance change: a kind plus the (optional) licensed-lift record backing it.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GovChange {
    pub kind: GovKind,
    pub record: Option<GovernanceRecord>,
}

impl GovChange {
    /// An authority expansion with no record attached (refused).
    pub fn authority_expansion_no_record() -> Self {
        Self {
            kind: GovKind::AuthorityExpansion,
            record: None,
        }
    }

    /// An authority expansion backed by a complete ten-field licensed lift (passes).
    pub fn licensed_lift_full_10_fields() -> Self {
        Self {
            kind: GovKind::AuthorityExpansion,
            record: Some(GovernanceRecord::full_sample()),
        }
    }

    /// A council attempting to self-certify (refused outright).
    pub fn council_self_certify() -> Self {
        Self {
            kind: GovKind::SelfCertification,
            record: None,
        }
    }
}

/// Strict-regime governance check. Returns the findings (empty == passes).
///
/// * Self-certification is always refused.
/// * Any change not backed by a complete licensed lift (missing record, or an incomplete
///   ten-field record) is refused.
pub fn check_governance_strict(change: &GovChange) -> Vec<String> {
    let mut findings = Vec::new();

    if change.kind == GovKind::SelfCertification {
        findings.push("governance: self-certification refused (no self-cert)".to_string());
    }

    let complete_lift = change
        .record
        .as_ref()
        .map(GovernanceRecord::is_complete)
        .unwrap_or(false);

    if !complete_lift {
        findings.push(format!(
            "governance: {} requires a complete licensed lift (10-field record)",
            change.kind.label()
        ));
    }

    findings
}
