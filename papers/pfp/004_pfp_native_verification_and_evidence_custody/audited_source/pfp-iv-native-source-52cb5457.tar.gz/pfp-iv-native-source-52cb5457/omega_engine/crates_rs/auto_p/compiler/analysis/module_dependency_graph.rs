use std::collections::{HashMap, HashSet};

#[derive(Debug, Clone, Default)]
pub struct ModuleDependencyGraph {
    edges: HashMap<String, HashSet<String>>,
}

impl ModuleDependencyGraph {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add_edge(&mut self, from: impl Into<String>, to: impl Into<String>) {
        self.edges.entry(from.into()).or_default().insert(to.into());
    }

    pub fn add_import(&mut self, from: impl Into<String>, to: impl Into<String>) {
        self.add_edge(from, to);
    }

    pub fn has_path(&self, from: &str, to: &str) -> bool {
        let mut stack = vec![from.to_string()];
        let mut seen = HashSet::new();
        while let Some(node) = stack.pop() {
            if node == to {
                return true;
            }
            if !seen.insert(node.clone()) {
                continue;
            }
            if let Some(next) = self.edges.get(&node) {
                stack.extend(next.iter().cloned());
            }
        }
        false
    }
}
