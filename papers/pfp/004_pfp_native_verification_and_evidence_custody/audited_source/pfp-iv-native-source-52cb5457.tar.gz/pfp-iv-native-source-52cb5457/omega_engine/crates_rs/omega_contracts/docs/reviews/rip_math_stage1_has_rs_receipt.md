# Stage-1 mechanical (HAS_RS only)

**AuthorityEffect:** None  
**Stems:** 119 from `rip_math_has_rs_stems.txt`

| Metric | Count |
| --- | ---: |
| mechanical PASS (or already tagged) | 74 |
| defects injected / residual | 45 |

Scope: Stage-1 mechanical field gates only on contracts with Stage-2 realization notes.  
Not PROVED · Not GlobalGreen · Not full semantic math re-review.

**AuthorityEffect: None.**
