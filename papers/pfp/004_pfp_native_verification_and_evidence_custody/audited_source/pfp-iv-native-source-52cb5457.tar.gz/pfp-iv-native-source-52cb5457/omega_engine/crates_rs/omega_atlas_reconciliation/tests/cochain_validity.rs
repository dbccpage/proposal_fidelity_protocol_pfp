use omega_atlas_reconciliation::cochain_validity::*;
#[test]
fn d1_d0_zero_over_f2() {
    // d0 has 2 rows (C1 dim = 2); d1 row len 2 matches → dimensions compose.
    // col0: (1&1) XOR (1&1) = 0 ; col1: (1&1) XOR (1&1) = 0 → d1·d0 = 0 over F2.
    let d0 = vec![vec![1u8, 1], vec![1u8, 1]];
    let d1 = vec![vec![1u8, 1]];
    assert_eq!(check_d1_d0_zero_f2(&d1, &d0), TriState::True);
}
#[test]
fn broken_chain_is_malformed() {
    // d0 has 1 row (C1 dim = 1); d1 row len 2 ≠ 1 → dimensions do not compose → Unknown.
    let d0 = vec![vec![1u8, 0]];
    let d1 = vec![vec![1u8, 1]];
    assert_eq!(check_d1_d0_zero_f2(&d1, &d0), TriState::Unknown);
}
#[test]
fn nonbinary_entries_reduce_mod_2() {
    // a '2' entry must behave as 0 mod 2, not silently XOR-cancel
    let d0 = vec![vec![2u8, 0]]; // 2 ≡ 0 (mod 2)
    let d1 = vec![vec![1u8]]; // inner len 1 == d0.len() 1
    assert_eq!(check_d1_d0_zero_f2(&d1, &d0), TriState::True); // 1&2&1 = 0 → True
    let d0b = vec![vec![1u8, 0]];
    let d1b = vec![vec![3u8]]; // 3 ≡ 1 (mod 2); 1&1&1 = 1 → False
    assert_eq!(check_d1_d0_zero_f2(&d1b, &d0b), TriState::False);

    // Load-bearing regression: 2 & 2 == 2 is a single NON-BINARY product. Mod 2 it is 0,
    // so the composite is the zero map → True. The UNMASKED code computed `acc ^= 2`,
    // saw acc != 0, and wrongly returned False. Only `(r[k] & d0[k][j]) & 1` fixes this.
    let d0c = vec![vec![2u8]]; // single entry 2 (≡ 0 mod 2)
    let d1c = vec![vec![2u8]]; // inner len 1 == d0.len() 1; product 2&2 = 2 ≡ 0
    assert_eq!(check_d1_d0_zero_f2(&d1c, &d0c), TriState::True);
}
#[test]
fn ragged_d0_with_empty_first_row_is_unknown() {
    // cols == 0 (empty first row) used to skip the column loop and wrongly return True.
    let d0 = vec![vec![], vec![1u8]]; // first row len 0 → cols 0; second row len 1 → ragged
    let d1 = vec![vec![0u8, 0u8]]; // row len 2 == d0.len() 2
    assert_eq!(check_d1_d0_zero_f2(&d1, &d0), TriState::Unknown);
}
#[test]
fn worked_malformed_chain_computes_false() {
    // C⁰={fix}, C¹={defect@crate, defect@proof}, C²={obligation}. d1=[[1,0]] leaves proof-defect unclosed.
    let d0 = vec![vec![1u8], vec![1u8]];
    let d1 = vec![vec![1u8, 0u8]];
    assert_eq!(check_d1_d0_zero_f2(&d1, &d0), TriState::False);
    let d1_ok = vec![vec![1u8, 1u8]]; // both defects feed the obligation → closed
    assert_eq!(check_d1_d0_zero_f2(&d1_ok, &d0), TriState::True);
}
