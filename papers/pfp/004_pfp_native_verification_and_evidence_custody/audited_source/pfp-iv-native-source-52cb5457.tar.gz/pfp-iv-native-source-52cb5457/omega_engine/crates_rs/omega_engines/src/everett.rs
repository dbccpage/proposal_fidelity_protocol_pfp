use omega_types::everett_dag_state::{EverettArena, EverettNode, EverettNodeId};

#[derive(Debug, Clone)]
pub struct ManyWorldsDAG {
    pub arena: EverettArena,
    pub root_index: usize,
}

impl ManyWorldsDAG {
    pub fn new_root(id: &str, amplitude: f64, sign_field: Vec<i8>) -> Self {
        let root = EverettNode {
            id: EverettNodeId::from(id),
            amplitude,
            configuration_sign_field: sign_field,
            child_indices: Vec::new(),
        };

        Self {
            arena: EverettArena { nodes: vec![root] },
            root_index: 0,
        }
    }
}
