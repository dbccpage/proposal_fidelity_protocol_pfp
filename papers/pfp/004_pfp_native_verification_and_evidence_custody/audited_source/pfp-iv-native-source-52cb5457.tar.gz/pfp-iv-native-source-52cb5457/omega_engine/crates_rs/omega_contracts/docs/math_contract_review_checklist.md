# Math contract re-review checklist (ADR-007 §6 + ADR-007a)

**AuthorityEffect:** `None`  
**Status:** ACTIVE  
**Controlling ADRs:**  
- `omega_business_contracts/docs/adr/adr-007-math-first-contract-lifecycle.md`  
- `omega_business_contracts/docs/adr/adr-007a-one-yaml-per-math-file-and-code-follows-yaml.md`  

**Corpus:** `contract_canonical_definitions/math/`  
**Owner skill:** `/nomos-law-contract-manager`

---

## Operator laws (007a)

1. **If two math objects differ → two YAMLs + two code homes** (e.g. `basic_matrix` storage ≠ `matrix` linear map).  
2. **One and only one math YAML per math code file/module.**  
3. **Always align code to YAML.** Never weaken YAML because LLM/human code is sloppy.  
4. YAML may change only under **meth-level math re-review** (contract wrong as mathematics), not as surrender to non-compliant code.  
5. Math contracts are **human-built, not God-given** — authorship ≠ certification.  
6. Wrong YAML + wrong/under-tested code + HoTT vocabulary = **forbidden**.  
7. Every math YAML must carry **`nomos_debate_NOT_CANONICAL`** (loud, non-law):  
   - **§1 `potential_defects`** — what may be wrong with this YAML  
   - **§2 `realization_delta_vs_implemented_math_file`** — YAML vs code (empty = ideal; open debate OK)  
   Debate is **not** canonical law and must never be read as AuthorityEffect.

---

## Verdicts

| Verdict | Meaning |
| --- | --- |
| `MCR-PASS` | Gates pass; no OPEN residual for claimed realization |
| `MCR-PASS-WITH-RESIDUAL` | Text OK; named residuals OPEN |
| `MCR-NEEDS-REPAIR` | Theater, missing fields, or code/YAML mismatch under code-follows-YAML |
| `MCR-BLOCKED` | Cannot review (parse fail, tools down) |

Residual codes: `DEV-THEATER` · `DEV-CORPUS` · `DEV-BINDING` · `C4_URN_DRIFT` · `MATH-CODE-MISMATCH` · `MATH-COVERAGE-HOLE` · `MATH-OVERCLAIM`

---

## Quick gates (per contract)

### Mechanical
- [ ] M0 path under `math/*.contract.yaml`  
- [ ] M1 `v1_contract_gate` / corpus load  
- [ ] M3–M6 `schema_version`, `kind`, `authority_effect: none`, `customer_claim_allowed: false`

### GTLA / anti-theater
- [ ] G: `contract_id`, title, status, math.object_kind/domain/codomain, required_structures, laws, negative_tests, doctrine.summary, doctrine.non_role  
- [ ] T: no HoTT/GlobalGreen overclaim; sampled ≠ proved  
- [ ] C: relationship URNs use live `urn:omega:math:*` (not legacy `urn:math:contract:*`)

### Realization (if not DEFERRED)
- [ ] R: one YAML ↔ one file; `rust_binding` module path real; symbols exist  
- [ ] X: tests kill negative_tests; no tautologies  
- [ ] **Code implements YAML** — if mismatch, fix **code** (or math-repair YAML under review), never quiet-downgrade YAML for slop

---

## Receipt (minimal)

```text
contract_id:
path:
verdict: MCR-*
defects: [codes]
residuals_OPEN:
code_follows_yaml: true
AuthorityEffect: None
```

## Estate ladder (do not skip)

1. **Perfect math YAML** (canonical fields + open debate) — this checklist + `/rip-math-contracts` Stages 1–3.  
2. **Align Rust / Py** to reviewed YAML (ADR-007a code-follows-YAML).  
3. **Golden step: LEAN4** mechanization (separate track; not minted by debate or structural shells).

**AuthorityEffect: `None`.**
