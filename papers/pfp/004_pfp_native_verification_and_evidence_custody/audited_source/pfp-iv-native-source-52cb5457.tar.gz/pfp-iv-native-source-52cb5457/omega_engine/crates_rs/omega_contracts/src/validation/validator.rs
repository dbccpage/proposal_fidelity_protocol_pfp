use super::artifact::ValidationArtifact;
use super::violation::ValidationViolation;
use crate::kinds::{Capability, ContractEffect};
use crate::witness::evidence::ValidationWitness;

/// Validator trait for structural well-formedness checking.
///
/// Per 05_governance.yaml validator contract:
/// - Role: "Deterministic structural well-formedness checker against declared invariants"
/// - authority_effect: EvidenceOnly (validators do not emit facts, decisions, or actions)
/// - Validators check structure, they do NOT:
///   - repair/normalize targets
///   - certify or sign certificates
///   - execute or mutate state
///   - evaluate admissibility (that's Evaluator's role)
///   - terminalize
///   - authorize or license transitions
///   - define invariants from LLM output
///   - write trace directly
pub trait Validator<S> {
    type Witness: ValidationWitness;
    type Violation: ValidationViolation;

    const VALIDATOR_ID: &'static str;
    const SUBJECT_TYPE: &'static str;
    const PROPERTY: &'static str;

    /// Validate the subject and return a ValidationArtifact.
    fn validate(subject: &S) -> ValidationArtifact<Self::Witness, Self::Violation>;

    /// Returns the authority effect of this validator.
    ///
    /// Per 05_governance.yaml: Validators always emit EvidenceOnly artifacts.
    /// A CheckedValidationReport may become FactOnly only through a declared
    /// checking, replay, or certificate boundary.
    fn authority_effect() -> ContractEffect {
        ContractEffect::EvidenceOnly
    }
}

/// Canonical capabilities forbidden to validators per 05_governance.yaml.
pub const VALIDATOR_FORBIDDEN_CAPABILITIES: &[Capability] = &[
    Capability::Repair,
    Capability::CertificateSigning,
    Capability::ExecuteStateTransition,
    Capability::Evaluation,
    Capability::AdmissibilityDecision,
    Capability::RuntimeMutation,
    Capability::TerminalMapping,
    Capability::ActionLicensing,
    Capability::AuthorityPromotion,
    Capability::TraceWriting,
];
