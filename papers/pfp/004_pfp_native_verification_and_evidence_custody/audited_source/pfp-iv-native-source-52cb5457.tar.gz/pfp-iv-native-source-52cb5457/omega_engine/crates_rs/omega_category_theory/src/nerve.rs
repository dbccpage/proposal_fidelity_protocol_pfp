//! The Nerve of a Category — Simplicial Sets.
//!
//! The nerve functor N : Cat → sSet sends a small category C to a simplicial set N(C)
//! where:
//! - 0-simplices are objects of C
//! - 1-simplices are morphisms of C
//! - 2-simplices are composable pairs (commuting triangles)
//! - n-simplices are composable chains of n morphisms
//!
//! This module adapts the nerve construction to our finite `DeclaredFiniteCategory` infrastructure,
//! complete with face and degeneracy maps.

use super::finite_category::DeclaredFiniteCategory;

/// A cleaner representation for an n-simplex in our specific encoding.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub enum Simplex {
    /// A 0-simplex is an object.
    Vertex(String),
    /// An n-simplex (n > 0) is a chain of n composable morphisms.
    Chain(Vec<String>),
}

impl Simplex {
    pub fn dimension(&self) -> usize {
        match self {
            Simplex::Vertex(_) => 0,
            Simplex::Chain(morphisms) => morphisms.len(),
        }
    }
}

/// The Nerve of a finite category.
///
/// NOTE: The input `category` is assumed to be a mathematically sound category
/// (identities, associativity, proper composition). If built over an invalid
/// `DeclaredFiniteCategory`, the resulting simplicial set will not satisfy
/// the simplicial identities.
#[derive(Debug, Clone)]
pub struct DeclaredNerve<'a> {
    pub category: &'a DeclaredFiniteCategory,
}

impl<'a> DeclaredNerve<'a> {
    pub fn new(category: &'a DeclaredFiniteCategory) -> Self {
        Self { category }
    }

    /// Generate all n-simplices of the category.
    pub fn n_simplices(&self, n: usize) -> Vec<Simplex> {
        if n == 0 {
            self.category
                .objects
                .iter()
                .map(|obj| Simplex::Vertex(obj.clone()))
                .collect()
        } else {
            self.composable_chains(n)
        }
    }

    /// Helper to generate composable chains of length n > 0.
    fn composable_chains(&self, n: usize) -> Vec<Simplex> {
        if n == 0 {
            return vec![];
        }
        if n == 1 {
            return self
                .category
                .morphisms
                .keys()
                .map(|m| Simplex::Chain(vec![m.clone()]))
                .collect();
        }

        let mut chains = Vec::new();
        let prev_chains = self.composable_chains(n - 1);

        for chain in prev_chains {
            if let Simplex::Chain(morphisms) = chain {
                let last_morph_name = morphisms.last().unwrap();
                let last_morph = self.category.morphisms.get(last_morph_name).unwrap();
                let last_tgt = &last_morph.target;

                // Find all morphisms whose source is the target of the last morphism.
                for (next_name, next_morph) in &self.category.morphisms {
                    if &next_morph.source == last_tgt {
                        let mut new_chain = morphisms.clone();
                        new_chain.push(next_name.clone());
                        chains.push(Simplex::Chain(new_chain));
                    }
                }
            }
        }
        chains
    }

    /// Face map d_i : N_n(C) → N_{n-1}(C).
    /// Returns the i-th face of the simplex, or None if i > n.
    pub fn face(&self, simplex: &Simplex, i: usize) -> Option<Simplex> {
        let n = simplex.dimension();
        if i > n {
            return None;
        }

        match simplex {
            Simplex::Vertex(_) => None, // 0-simplices have no faces
            Simplex::Chain(morphisms) => {
                if n == 1 {
                    // For a 1-simplex f: A → B, d_0(f) = B, d_1(f) = A
                    let f = self.category.morphisms.get(&morphisms[0])?;
                    if i == 0 {
                        Some(Simplex::Vertex(f.target.clone()))
                    } else {
                        Some(Simplex::Vertex(f.source.clone()))
                    }
                } else {
                    // For n > 1:
                    // d_0: drop first morphism
                    // d_n: drop last morphism
                    // d_i (0 < i < n): compose i-th and (i+1)-th morphisms (0-indexed list means i-1 and i)
                    let mut new_chain = morphisms.clone();
                    if i == 0 {
                        new_chain.remove(0);
                    } else if i == n {
                        new_chain.pop();
                    } else {
                        // We need to compose morphisms at index (i-1) and index i.
                        // f = new_chain[i-1], g = new_chain[i]
                        // composition is (f, g) -> g ∘ f
                        let f = &new_chain[i - 1];
                        let g = &new_chain[i];
                        let comp_key = (f.clone(), g.clone());
                        let composed = self.category.compositions.get(&comp_key)?;

                        // Replace f and g with their composition.
                        new_chain.splice((i - 1)..=i, vec![composed.clone()]);
                    }
                    Some(Simplex::Chain(new_chain))
                }
            }
        }
    }

    /// Degeneracy map s_i : N_n(C) → N_{n+1}(C).
    /// Inserts an identity morphism at position i (0 <= i <= n).
    pub fn degeneracy(&self, simplex: &Simplex, i: usize) -> Option<Simplex> {
        let n = simplex.dimension();
        if i > n {
            return None;
        }

        match simplex {
            Simplex::Vertex(obj) => {
                // s_0 on an object A yields the identity morphism id_A.
                let id_morphism = self.category.identities.get(obj)?;
                Some(Simplex::Chain(vec![id_morphism.clone()]))
            }
            Simplex::Chain(morphisms) => {
                let mut new_chain = morphisms.clone();
                // We need to insert the identity of the object at position i.
                // The object at position i is the target of morphisms[i-1] (or source of morphisms[0] if i=0).
                let obj = if i == 0 {
                    let f = self.category.morphisms.get(&morphisms[0])?;
                    &f.source
                } else {
                    let f = self.category.morphisms.get(&morphisms[i - 1])?;
                    &f.target
                };

                let id_morphism = self.category.identities.get(obj)?;
                new_chain.insert(i, id_morphism.clone());
                Some(Simplex::Chain(new_chain))
            }
        }
    }

    /// Checks if a simplex is degenerate (contains an identity morphism).
    pub fn is_degenerate(&self, simplex: &Simplex) -> bool {
        match simplex {
            Simplex::Vertex(_) => false,
            Simplex::Chain(morphisms) => {
                // Collect all identity morphism names
                let id_names: std::collections::BTreeSet<_> =
                    self.category.identities.values().collect();
                morphisms.iter().any(|m| id_names.contains(m))
            }
        }
    }

    /// Enumerates only the non-degenerate n-simplices.
    pub fn nondegenerate_n_simplices(&self, n: usize) -> Vec<Simplex> {
        self.n_simplices(n)
            .into_iter()
            .filter(|s| !self.is_degenerate(s))
            .collect()
    }
}

// ═══════════════════════════════════════════════════════════════════════════
// Tests
// ═══════════════════════════════════════════════════════════════════════════

#[cfg(test)]
mod tests {
    use super::*;
    use crate::finite_category_builder::DeclaredFiniteCategoryBuilder;

    fn build_triangle_category() -> DeclaredFiniteCategory {
        DeclaredFiniteCategoryBuilder::new("Triangle")
            .object("A")
            .object("B")
            .object("C")
            .identity("A", "id_A")
            .identity("B", "id_B")
            .identity("C", "id_C")
            .morphism("f", "A", "B")
            .morphism("g", "B", "C")
            .morphism("h", "A", "C")
            .composition("f", "g", "h")
            .identity_compositions()
            .build()
    }

    fn build_tetrahedron_category() -> DeclaredFiniteCategory {
        DeclaredFiniteCategoryBuilder::new("Tetrahedron")
            .object("A")
            .object("B")
            .object("C")
            .object("D")
            .identity("A", "id_A")
            .identity("B", "id_B")
            .identity("C", "id_C")
            .identity("D", "id_D")
            .morphism("f", "A", "B")
            .morphism("g", "B", "C")
            .morphism("k", "C", "D")
            .morphism("fg", "A", "C")
            .morphism("gk", "B", "D")
            .morphism("fgk", "A", "D")
            .composition("f", "g", "fg")
            .composition("g", "k", "gk")
            .composition("fg", "k", "fgk")
            .composition("f", "gk", "fgk")
            .identity_compositions()
            .build()
    }

    #[test]
    fn test_n_simplices() {
        let cat = build_triangle_category();
        let nerve = DeclaredNerve::new(&cat);

        let s0 = nerve.n_simplices(0);
        assert_eq!(s0.len(), 3); // A, B, C

        let s1 = nerve.n_simplices(1);
        // id_A, id_B, id_C, f, g, h
        assert_eq!(s1.len(), 6);

        let s2 = nerve.n_simplices(2);
        // Non-degenerate: (f, g)
        // Degenerate: (id_A, f), (f, id_B), (id_B, g), (g, id_C), (id_A, h), (h, id_C),
        //             (id_A, id_A), (id_B, id_B), (id_C, id_C)
        // Total = 1 + 6 + 3 = 10
        assert_eq!(s2.len(), 10);

        let non_degen_s2 = nerve.nondegenerate_n_simplices(2);
        assert_eq!(non_degen_s2.len(), 1);
        assert_eq!(
            non_degen_s2[0],
            Simplex::Chain(vec!["f".into(), "g".into()])
        );
    }

    #[test]
    fn test_face_maps() {
        let cat = build_triangle_category();
        let nerve = DeclaredNerve::new(&cat);

        // 1-simplex face maps
        let f = Simplex::Chain(vec!["f".into()]);
        assert_eq!(nerve.face(&f, 0), Some(Simplex::Vertex("B".into())));
        assert_eq!(nerve.face(&f, 1), Some(Simplex::Vertex("A".into())));

        // 2-simplex face maps for (f, g)
        let fg = Simplex::Chain(vec!["f".into(), "g".into()]);
        assert_eq!(nerve.face(&fg, 0), Some(Simplex::Chain(vec!["g".into()]))); // drop f
        assert_eq!(nerve.face(&fg, 1), Some(Simplex::Chain(vec!["h".into()]))); // compose f,g
        assert_eq!(nerve.face(&fg, 2), Some(Simplex::Chain(vec!["f".into()]))); // drop g
    }

    #[test]
    fn test_degeneracy_maps() {
        let cat = build_triangle_category();
        let nerve = DeclaredNerve::new(&cat);

        // 0-simplex degeneracy
        let a = Simplex::Vertex("A".into());
        assert_eq!(
            nerve.degeneracy(&a, 0),
            Some(Simplex::Chain(vec!["id_A".into()]))
        );

        // 1-simplex degeneracy for f: A -> B
        let f = Simplex::Chain(vec!["f".into()]);
        assert_eq!(
            nerve.degeneracy(&f, 0),
            Some(Simplex::Chain(vec!["id_A".into(), "f".into()]))
        );
        assert_eq!(
            nerve.degeneracy(&f, 1),
            Some(Simplex::Chain(vec!["f".into(), "id_B".into()]))
        );
    }

    #[test]
    fn test_simplicial_identities() {
        let cat = build_tetrahedron_category();
        let nerve = DeclaredNerve::new(&cat);

        // 3-simplex: A -> B -> C -> D
        let fgk = Simplex::Chain(vec!["f".into(), "g".into(), "k".into()]);

        // Face identity: d_i d_j = d_{j-1} d_i for i < j
        for j in 1..=3 {
            for i in 0..j {
                let d_j = nerve.face(&fgk, j).unwrap();
                let lhs = nerve.face(&d_j, i).unwrap();

                let d_i = nerve.face(&fgk, i).unwrap();
                let rhs = nerve.face(&d_i, j - 1).unwrap();

                assert_eq!(lhs, rhs, "Face identity failed for i={}, j={}", i, j);
            }
        }

        // 2-simplex: A -> B -> C
        let fg = Simplex::Chain(vec!["f".into(), "g".into()]);

        // Degeneracy identity: s_i s_j = s_{j+1} s_i for i <= j
        for j in 0..=2 {
            for i in 0..=j {
                let s_j = nerve.degeneracy(&fg, j).unwrap();
                let lhs = nerve.degeneracy(&s_j, i).unwrap();

                let s_i = nerve.degeneracy(&fg, i).unwrap();
                let rhs = nerve.degeneracy(&s_i, j + 1).unwrap();

                assert_eq!(lhs, rhs, "Degeneracy identity failed for i={}, j={}", i, j);
            }
        }

        // Face-degeneracy identities: d_i s_j
        for j in 0..=2 {
            for i in 0..=3 {
                let s_j = nerve.degeneracy(&fg, j).unwrap();
                let d_i_s_j = nerve.face(&s_j, i).unwrap();

                if i < j {
                    let d_i = nerve.face(&fg, i).unwrap();
                    let expected = nerve.degeneracy(&d_i, j - 1).unwrap();
                    assert_eq!(
                        d_i_s_j, expected,
                        "Failed d_i s_j for i<j (i={}, j={})",
                        i, j
                    );
                } else if i == j || i == j + 1 {
                    assert_eq!(
                        d_i_s_j, fg,
                        "Failed d_i s_j for i=j or i=j+1 (i={}, j={})",
                        i, j
                    );
                } else {
                    // i > j + 1
                    let d_i_minus_1 = nerve.face(&fg, i - 1).unwrap();
                    let expected = nerve.degeneracy(&d_i_minus_1, j).unwrap();
                    assert_eq!(
                        d_i_s_j, expected,
                        "Failed d_i s_j for i>j+1 (i={}, j={})",
                        i, j
                    );
                }
            }
        }
    }
}
