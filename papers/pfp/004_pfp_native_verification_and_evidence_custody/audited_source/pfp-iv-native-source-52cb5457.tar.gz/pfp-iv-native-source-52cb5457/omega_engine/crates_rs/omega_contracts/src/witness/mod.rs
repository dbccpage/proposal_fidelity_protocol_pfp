pub mod capability;
pub mod directive;
pub mod empirical;
pub mod evidence;
pub mod law_checker;
// Renaming the inner module would break the public `witness::witness` path.
#[allow(clippy::module_inception)]
pub mod witness;

#[macro_use]
pub mod property_macros;

#[macro_use]
pub mod totality_macros;

pub use capability::*;
pub use directive::witness_properties;
pub use directive::*;
pub use empirical::*;
pub use evidence::*;
pub use law_checker::*;
