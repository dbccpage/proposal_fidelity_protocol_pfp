# Algorithm Prime 000 — triple face: `basic_matrix`

**Date:** 2026-08-01  
**AuthorityEffect:** None  
**Applicability:** `PRIME_APPLICABLE` (Workflow-C style object obligation: finite storage matrix)  
**Goal everywhere:** \(\phi = 0 + \varepsilon\) (local shape green + priced residual)  
**Law:** math and contracts are **proposals**; no face mints host auth / GlobalGreen / PROVED alone.

| Face | Path |
| --- | --- |
| YAML | `omega_contracts/.../math/basic_matrix.contract.yaml` |
| Rust | `omega_linear_algebra/src/backend/basic_matrix.rs` |
| Lean | `lean4/.../003_the_algebra/BasicMatrix.lean` |

---

## 0. Cross-face object (shared proposal)

**Object:** finite rectangular **storage** matrix \(A \in T^{m \times n}\), row-major dense, \(m,n \in \mathbb{N}_0\) (zero dims allowed).  
**Fence:** not the basis-aware linear-map object `matrix.contract.yaml`.  
**Scalar residual \(\varepsilon_{\mathrm{scalar}}\):** YAML speaks field language aspirationally; RS uses `Numeric`/semiring; Lean leaves \(\alpha\) abstract.

---

# Face A — YAML (`basic_matrix.contract.yaml`)

## Prime 000 declaration receipt (proposal)

| Step | Slot | Status | Fill |
| ---: | --- | --- | --- |
| 1 | Carrier \(K\) | DECLARED | Finite shapes \((m,n)\) + length-\(mn\) entry lists; packet profile = storage matrices over fixed scalar type \(T\) |
| 2 | PrimDiff \(\delta\) | DECLARED | \(\delta(A,B)\): shape mismatch, length mismatch, entrywise difference when shapes equal; refuse as error vs data |
| 3 | ZeroRel | DECLARED | Same shape + all entries equal (structural equality of storage); empty matrices of same shape are ZeroRel |
| 4 | Cochains \(C^\bullet\) | NOT_APPLICABLE | Storage object does not itself construct \(C^\bullet\); it **supplies** maps for homological carriers above |
| 5 | Quotient \(Q^1\) | NOT_APPLICABLE | No cochain repair image on this object alone |
| 6 | \(\Phi_1\) / \(\Gamma_2\) | DERIVED (proposal) | \(\Phi_1\): count/norm of shape-law violations (len ≠ mn, OOB, bad add/matmul). \(\Gamma_2\): closure mass N/A for pure storage; residual is **scalar-theory gap** not \(d_1\) |
| 7 | Observer \(J\) | DECLARED | Shape-only gauge: indices, lengths, op compatibility — no View-from-Nowhere continuum |
| 8 | Witnesses | DECLARED | negative_tests list; rust_binding symbols; B1 meth debate codes |
| 9 | Lifts | DEFERRED | Field/CheckedNumeric lifts above storage; linear-map object is separate YAML |
| 10 | Route \(\rho^\#\) | DECLARED | Route failures to refuse (`MatrixError`-class); successes stay ShapeOnly evidence |
| 11 | Terminal \(\tau^\#\) | **ClosedResidual** (shape) + **OpenResidual** (field) | Shape laws closed as proposal; field vs Numeric open |
| 12 | Literature | AFTER only | Deferred; ADR-007a zero-dim decision is estate law, not external auth |

### YAML packet (structure / primdiff / obstruction)

| Quartile | Content |
| --- | --- |
| **Structure** | laws: shape, length, access, add/sub, matmul, object fence, authority fence |
| **PrimDiff** | unequal shapes / bad length / entry mismatch as local cuts |
| **Cochains** | N/A (support layer for them) |
| **Obstruction** | \(\Phi_1 \approx 0\) when length/OOB/op laws hold; \(\varepsilon =\) field-language residual |
| **Terminal** | `ClosedShapeResidual` + `OpenScalarFieldResidual` |

**Proposal only.** Status `mathematical_wip`.

---

# Face B — Rust (`basic_matrix.rs`)

## Prime 000 declaration receipt (proposal)

| Step | Slot | Status | Fill |
| ---: | --- | --- | --- |
| 1 | Carrier \(K\) | DECLARED | `BasicMatrix<T> { rows, cols, data: Vec<T> }`; admits `zero(m,n)` with empty data |
| 2 | PrimDiff \(\delta\) | DECLARED | `MatrixError` variants: ShapeMismatch, IndexOutOfBounds, DimensionMismatch, … |
| 3 | ZeroRel | DECLARED | `PartialEq` on struct when shape+data equal; construction enforces length law |
| 4 | Cochains | NOT_APPLICABLE | Module docs: pure numeric backend; no topology/homology inside |
| 5 | \(Q^1\) | NOT_APPLICABLE | — |
| 6 | \(\Phi_1\) / \(\Gamma_2\) | DERIVED | \(\Phi_1\): runtime refuse rate for bad shape ops. \(\Gamma_2\): N/A. Residual: wrapping integer Numeric vs CheckedNumeric |
| 7 | Observer \(J\) | DECLARED | Fallible get/set/add/mul; nalgebra bridge is layout adapter (Prime 001 candidate) |
| 8 | Witnesses | PARTIAL | Unit tests in-file; no content-addressed law hashes |
| 9 | Lifts | DECLARED_ADAPTER | `to_nalgebra` / `from_nalgebra` (loss: row-major ↔ column-major copy) |
| 10 | Route | DECLARED | `Result<_, MatrixError>` |
| 11 | Terminal \(\tau^\#\) | **ExactShapeRepair** on construction path + **OpenResidual** on scalar safety | Shape enforced; `Numeric` docs admit wrapping i64 |
| 12 | Literature | N/A | — |

### Rust packet

| Quartile | Content |
| --- | --- |
| **Structure** | `from_row_major`, `get`/`set`, `add`, `mul`, `zero` implement YAML shape/length/access/op laws |
| **PrimDiff** | error enum = discrete cut vocabulary |
| **Cochains** | N/A (by module fence) |
| **Obstruction** | \(\Phi_1 \to 0\) when callers use `Result` honestly; \(\varepsilon =\) unchecked Numeric overflow story |
| **Terminal** | local green on shape; open residual on theorem-grade scalars |

**Proposal only.** Code demo, not PROVED.

### Face A↔B adapter residual (Prime 001 sketch)

| Protected distinction | Adapter | Loss |
| --- | --- | --- |
| Zero-dim allowed | both | MATCH after B1 |
| Field language | YAML aspirational / RS Numeric | **lossy** — ledger OPEN |
| Linear-map fence | both declare storage-only | MATCH |
| OOB wrap vs refuse | both refuse | MATCH |

**Adapter terminal (proposal):** `AdapterLossy` on scalar theory; `AdapterSound` on pure shape.

---

# Face C — Lean (`BasicMatrix.lean`)

## What we wrote

Path: `omega_engine/lean4/research_programs/100_mathematical_foundations/003_the_algebra/BasicMatrix.lean`  
Root: added to lean_lib `TheAlgebra` in `lakefile.lean`.

Mechanizes **shape/length/access/compatibility** propositions + zero-dim length lemmas + fences.  
Does **not** mechanize full field axioms, matmul algebra, or linear maps.

## Prime 000 declaration receipt (proposal)

| Step | Slot | Status | Fill |
| ---: | --- | --- | --- |
| 1 | Carrier \(K\) | DECLARED | `BasicMatrix α` + `WF` (lengthLaw) |
| 2 | PrimDiff \(\delta\) | DECLARED_ADAPTER | Propositional cuts: `¬lengthLaw`, `¬inBounds`, `¬sameShape`, `¬matmulCompatible` |
| 3 | ZeroRel | DECLARED | Extensional equality of `WF` matrices (same shape + data) as Prop equality |
| 4 | Cochains | NOT_APPLICABLE | Same fence as YAML/RS |
| 5 | \(Q^1\) | NOT_APPLICABLE | — |
| 6 | \(\Phi_1\) / \(\Gamma_2\) | DERIVED | \(\Phi_1\): Prop failure of length/inBounds/shape laws. \(\Gamma_2\) N/A. \(\varepsilon\): unproved field/matmul arithmetic |
| 7 | Observer \(J\) | DECLARED | Prop-level shape gauge only |
| 8 | Witnesses | PARTIAL | Small lemmas (`empty_product_length_zero`, lengthLaw zero row/col, not_inBounds_row) |
| 9 | Lifts | DEFERRED | Full matmul correctness, field modules → later obligations |
| 10 | Route | DECLARED | Proof obligations remain open where not lemma'd |
| 11 | Terminal \(\tau^\#\) | **`OpenScalarFieldResidual`** (declared in-module) | Shape fragment closed as local lemmas; scalar open |
| 12 | Literature | AFTER | Mathlib matrix theory not imported (Mathlib-free module) |

### Lean packet

| Quartile | Content |
| --- | --- |
| **Structure** | `BasicMatrix`, `lengthLaw`, `inBounds`, `sameShape`, `matmulCompatible` |
| **PrimDiff** | failed Props as residuals |
| **Cochains** | N/A |
| **Obstruction** | \(\Phi_1 = 0\) on proved shape lemmas; \(\varepsilon\) huge on unproved ops |
| **Terminal** | `OpenScalarFieldResidual` — honest |

**Proposal only.** Local lemmas ≠ GlobalGreen.

---

# Triple comparison — what we get from all three

```text
                    STRUCTURE          PRIM DIFF              COCHAINS     OBSTRUCTION (φ→0+ε)
YAML proposal   shape/len/access    law violations         N/A support   Φ1 shape; ε field language
RS proposal     BasicMatrix<T>      MatrixError cuts       N/A backend   Φ1 Result path; ε Numeric wrap
Lean proposal   WF + Props          failed Props           N/A           Φ1 lemmas; ε unproved arith

SHARED TERMINAL (honest):
  Closed / Exact on pure shape storage laws (when enforced/proved)
  Open residual ε_scalar  (field vs Numeric vs abstract α)
  Open residual ε_linear_map_fence (must not claim matrix V→W)
  AuthorityEffect: None on every face
```

### \(\phi = 0 + \varepsilon\) for this object

| Component | Status |
| --- | --- |
| \(\phi_{\mathrm{shape}}\) | ≈ 0 across YAML+RS; Lean partial proof cover |
| \(\varepsilon_{\mathrm{scalar}}\) | OPEN — blocks “theorem-grade field storage” claim |
| \(\varepsilon_{\mathrm{linear\_map}}\) | CLOSED by fence if observers respect it |
| Host auth | NOT minted |

### Cross-face PrimDiff (atlas-style judgment, proposal)

| Left | Right | ZeroRel? | Residual class |
| --- | --- | --- | --- |
| YAML shape laws | RS construction/get/add/mul | **yes** (after B1 zero-dim) | empty on shape |
| YAML “field” prose | RS `Numeric` | **no** | `SCALAR_THEORY_DRIFT` |
| YAML/RS storage fence | Lean storageOnlyFence | **yes** | empty |
| YAML full op suite | Lean lemmas | **no** | `LEAN_PARTIAL_COVER` |

---

## Terminals (all faces)

| Face | \(\tau^\#\) (proposal) |
| --- | --- |
| YAML | ClosedShapeResidual + OpenScalarFieldResidual |
| Rust | ExactShapeRepair (construct path) + OpenScalarFieldResidual |
| Lean | OpenScalarFieldResidual (declared) |

**None** are GlobalGreen. **None** authorize. All are **proposals** toward \(\phi=0+\varepsilon\).

---

## Recommended next (Prime 002)

CanContinue if obligation remains:

1. Price \(\varepsilon_{\mathrm{scalar}}\): either YAML demotes field language at storage layer, or RS defaults CheckedNumeric/Ratio for theorem-grade paths.  
2. Lean: prove `get`/`set` properties under `WF` + optional matmul shape theorem.  
3. Do **not** continue by claiming linear-map theorems on `BasicMatrix` (object smash / laundering).

**Stop if:** any face claims PROVED/GlobalGreen from shape alone.

---

**AuthorityEffect: None.**  
**Not PROVED. Not GlobalGreen. Not host auth.**
