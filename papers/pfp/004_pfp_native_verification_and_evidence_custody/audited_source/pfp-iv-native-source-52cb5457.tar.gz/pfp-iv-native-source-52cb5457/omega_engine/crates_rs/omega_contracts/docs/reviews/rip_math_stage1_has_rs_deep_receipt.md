# Stage-1 DEEP (HAS_RS only)

**AuthorityEffect:** None
**Stems:** 119 from `rip_math_has_rs_stems.txt`
**Pass:** stage1_deep_has_rs (YAML-aware GTLA / anti-theater / URN / overclaim)
**Apply:** False

| Metric | Count |
| --- | ---: |
| deep PASS (no residual) | 119 |
| residual stems | 0 |
| stems with new debate injects | 0 |

## Defect code histogram (deep)

| Code | Count |
| --- | ---: |

## Residual stems

| Stem | Codes |
| --- | --- |

## Scope fence

- Stage-1 deep only on HAS_RS set (not full 496 math corpus).
- Does not edit canonical law fields; debate inject only.
- Does not mint PROVED / GlobalGreen / AuthorityEffect.
- Mechanical Stage-1 residual set is subset-related; deep reduces false
  negatives on quoted `authority_effect: "none"` etc.

**AuthorityEffect: None.**
