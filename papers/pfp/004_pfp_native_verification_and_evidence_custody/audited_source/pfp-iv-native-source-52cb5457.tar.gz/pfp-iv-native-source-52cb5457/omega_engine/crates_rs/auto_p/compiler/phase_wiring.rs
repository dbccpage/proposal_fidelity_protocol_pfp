//! --- yaml
//! title: phase_wiring
//! file_name: phase_wiring.rs
//! file_location: omega_core/src/compiler/phase_wiring.rs
//! status: Diamond
//! test_coverage: comprehensive
//! invariance_level: Tier 1
//! logic_system: Topological Memory Management
//! substrate: Rust
//! content_hash: 98e234e547a6a54a6392f37ae408ef2ee1fbe8574cb532c73b8a5968724dbdd7
//! version: 1
//! ---
//! # Phase 3 to Phase 4 Wiring
//!
//! Satisfies Bounty X-008: Topological Memory Management.
//! Applies Kahn's Topological Sort to the Phase 3 VerifiedSimplicialComplex.
//! Evaluates topological tension and injects GeometricOpCode::CollapseManifold
//! the instant the mapping loops shrink continuously to zero.

use serde::{Deserialize, Serialize};
use std::collections::{HashMap, HashSet, VecDeque};

use super::symbol_table::{SymbolId, SymbolTable};

/// Represents the contractible geometry verified by Phase 3 (betti_1 == 0).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VerifiedSimplicialComplex {
    pub manifolds: HashSet<String>,
    // The dependency graph: consumer -> providers
    pub depends_on: HashMap<String, Vec<String>>,
    // The topological tension: provider -> consumers
    pub consumed_by: HashMap<String, Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum GeometricOpCode {
    InstantiateManifold(String),
    ExecuteManifold(String),
    // Replaces 'free()', 'drop()', or Garbage Collection natively
    CollapseManifold(String),
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VerifiedInstruction {
    pub opcode: GeometricOpCode,
    pub proof_hash: Option<String>,
}

/// Phase 4: Kahn's Topological Sort wired directly to Memory Contraction
pub fn wire_phase3_to_phase4(
    complex: &VerifiedSimplicialComplex,
    symbols: &mut SymbolTable,
) -> Result<Vec<VerifiedInstruction>, String> {
    let mut queue: VecDeque<SymbolId> = VecDeque::new();
    let mut instruction_tape = Vec::new();
    let mut collapsed: HashSet<SymbolId> = HashSet::new();

    // In-degrees for Kahn's sort (how many morphisms must execute before this node can)
    let mut in_degrees: HashMap<SymbolId, usize> = HashMap::new();

    // Topological tension: how many downstream morphisms still need to map this manifold.
    // This entirely replaces the concept of a "reference count".
    let mut topological_tension: HashMap<SymbolId, usize> = HashMap::new();

    // Intern all manifold names into the symbol table for O(1) lookups
    let mut sorted_res: Vec<(SymbolId, String)> = complex
        .manifolds
        .iter()
        .map(|name| (symbols.intern_user(name), name.clone()))
        .collect();
    sorted_res.sort_by_key(|(sym, _)| *sym);

    // Build SymbolId lookup maps for depends_on / consumed_by
    let depends_on_sym: HashMap<SymbolId, Vec<SymbolId>> = complex
        .depends_on
        .iter()
        .map(|(k, vs)| {
            (
                symbols.intern_user(k),
                vs.iter().map(|v| symbols.intern_user(v)).collect(),
            )
        })
        .collect();
    let consumed_by_sym: HashMap<SymbolId, Vec<SymbolId>> = complex
        .consumed_by
        .iter()
        .map(|(k, vs)| {
            (
                symbols.intern_user(k),
                vs.iter().map(|v| symbols.intern_user(v)).collect(),
            )
        })
        .collect();

    // 0. Graph Invariant Verification
    for (consumer, providers) in &complex.depends_on {
        for provider in providers {
            let error_msg = format!("H^1 Semantic Tear: Asymmetric Graph. {} depends on {}, but is missing from consumed_by", consumer, provider);
            let consumers = complex
                .consumed_by
                .get(provider)
                .ok_or_else(|| error_msg.clone())?;
            if !consumers.contains(consumer) {
                return Err(error_msg);
            }
        }
    }

    for (provider, consumers) in &complex.consumed_by {
        for consumer in consumers {
            let error_msg = format!("H^1 Semantic Tear: Asymmetric Graph. {} is consumed by {}, but is missing from depends_on", provider, consumer);
            let providers = complex
                .depends_on
                .get(consumer)
                .ok_or_else(|| error_msg.clone())?;
            if !providers.contains(provider) {
                return Err(error_msg);
            }
        }
    }

    // Helper: resolve SymbolId to String for opcode emission
    let resolve = |sym: SymbolId, symbols: &SymbolTable| -> String {
        symbols.resolve(sym).unwrap_or("?").to_string()
    };

    // 1. Initialize topological weights from the Phase 3 DAG
    for (sym, _name) in &sorted_res {
        let deps = depends_on_sym.get(sym).map(|v| v.len()).unwrap_or(0);
        in_degrees.insert(*sym, deps);

        let consumers = consumed_by_sym.get(sym).map(|v| v.len()).unwrap_or(0);
        topological_tension.insert(*sym, consumers);

        // Root geometries (no dependencies) enter the execution queue first
        if deps == 0 {
            // Queue them to be instantiated when dequeued
            queue.push_back(*sym);
        }
    }

    // 2. Kahn's Execution with Intrinsic Memory Collapse
    while let Some(node) = queue.pop_front() {
        let node_name = resolve(node, symbols);
        if in_degrees.get(&node).copied().unwrap_or(0) == 0 && !depends_on_sym.contains_key(&node) {
            instruction_tape.push(VerifiedInstruction {
                opcode: GeometricOpCode::InstantiateManifold(node_name.clone()),
                proof_hash: None,
            });
        }

        // Emit the execution instruction for the target substrate
        instruction_tape.push(VerifiedInstruction {
            opcode: GeometricOpCode::ExecuteManifold(node_name.clone()),
            proof_hash: None,
        });

        // Resolve dependencies (The "Unweaving" Phase)
        if let Some(providers) = depends_on_sym.get(&node) {
            for &provider in providers {
                let provider_name = resolve(provider, symbols);
                let tension = topological_tension.get_mut(&provider).ok_or_else(|| {
                    format!(
                        "H^1 Wiring Tear: Missing manifold '{}' during Phase 4 contraction.",
                        provider_name
                    )
                })?;
                *tension = tension.checked_sub(1).ok_or_else(|| {
                    format!(
                        "H^1 Wiring Tear: Negative topological tension on '{}'",
                        provider_name
                    )
                })?;

                // BOUNTY X-008 APPLICATION:
                // Memory deallocation executes unequivocally as an intrinsic geometry limit
                // the instant topological mapping loops shrink continuously to zero cleanly.
                if *tension == 0 && !collapsed.contains(&provider) {
                    instruction_tape.push(VerifiedInstruction {
                        opcode: GeometricOpCode::CollapseManifold(provider_name),
                        proof_hash: None,
                    });
                    collapsed.insert(provider);
                }
            }
        }

        // Unblock downstream consumers by propagating the continuous mapping
        if let Some(consumers) = consumed_by_sym.get(&node) {
            for &consumer in consumers {
                let consumer_name = resolve(consumer, symbols);
                let in_degree = in_degrees.get_mut(&consumer)
                    .ok_or_else(|| format!("H^1 Wiring Tear: Missing consumer manifold '{}' during Phase 4 contraction.", consumer_name))?;
                *in_degree = in_degree.checked_sub(1).ok_or_else(|| {
                    format!("H^1 Wiring Tear: Negative in_degree on '{}'", consumer_name)
                })?;
                if *in_degree == 0 {
                    instruction_tape.push(VerifiedInstruction {
                        opcode: GeometricOpCode::InstantiateManifold(consumer_name),
                        proof_hash: None,
                    });
                    queue.push_back(consumer);
                }
            }
        }
    }

    // Capture any remaining tension=0 boundaries that were never collapsed (i.e. roots, sinks)
    let mut sorted_keys: Vec<SymbolId> = topological_tension.keys().copied().collect();
    sorted_keys.sort();

    for sym in sorted_keys {
        if topological_tension[&sym] == 0 && !collapsed.contains(&sym) {
            let name = resolve(sym, symbols);
            instruction_tape.push(VerifiedInstruction {
                opcode: GeometricOpCode::CollapseManifold(name),
                proof_hash: None,
            });
            collapsed.insert(sym);
        }
    }

    // 3. Final Homological Verification
    // If the number of executed morphisms doesn't match the complex size,
    // a disjoint sub-manifold was somehow injected between phases.
    let executed_count = instruction_tape
        .iter()
        .filter(|op| matches!(op.opcode, GeometricOpCode::ExecuteManifold(_)))
        .count();

    if executed_count != complex.manifolds.len() {
        return Err(
            "H^1 Semantic Tear: Unreachable manifold detected during execution contraction."
                .to_string(),
        );
    }

    Ok(instruction_tape)
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;

    fn make_complex(
        manifolds: &[&str],
        depends: &[(&str, &[&str])],
        consumed: &[(&str, &[&str])],
    ) -> VerifiedSimplicialComplex {
        VerifiedSimplicialComplex {
            manifolds: manifolds.iter().map(|s| s.to_string()).collect(),
            depends_on: depends
                .iter()
                .map(|(k, v)| (k.to_string(), v.iter().map(|s| s.to_string()).collect()))
                .collect(),
            consumed_by: consumed
                .iter()
                .map(|(k, v)| (k.to_string(), v.iter().map(|s| s.to_string()).collect()))
                .collect(),
        }
    }

    fn count_opcodes(tape: &[VerifiedInstruction], pred: fn(&GeometricOpCode) -> bool) -> usize {
        tape.iter().filter(|i| pred(&i.opcode)).count()
    }

    #[test]
    fn test_single_root_manifold() {
        let complex = make_complex(&["A"], &[], &[]);
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();

        // Should instantiate, execute, then collapse A
        let instantiate = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::InstantiateManifold(_))
        });
        let execute = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::ExecuteManifold(_))
        });
        let collapse = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::CollapseManifold(_))
        });

        assert_eq!(instantiate, 1);
        assert_eq!(execute, 1);
        assert_eq!(collapse, 1);
    }

    #[test]
    fn test_linear_chain_a_to_b() {
        // A -> B: A has no deps, B depends on A.
        // A is consumed by B.
        let complex = make_complex(&["A", "B"], &[("B", &["A"])], &[("A", &["B"])]);
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();

        // Should see: InstantiateA, ExecuteA, InstantiateB, ExecuteB, CollapseA, CollapseB
        let instantiate = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::InstantiateManifold(_))
        });
        let execute = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::ExecuteManifold(_))
        });

        assert_eq!(instantiate, 2);
        assert_eq!(execute, 2);
    }

    #[test]
    fn test_two_independent_manifolds() {
        let complex = make_complex(&["X", "Y"], &[], &[]);
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();

        let execute = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::ExecuteManifold(_))
        });
        assert_eq!(execute, 2);
    }

    #[test]
    fn test_diamond_dag() {
        // Diamond: A -> B, A -> C, B -> D, C -> D
        let complex = make_complex(
            &["A", "B", "C", "D"],
            &[("B", &["A"]), ("C", &["A"]), ("D", &["B", "C"])],
            &[("A", &["B", "C"]), ("B", &["D"]), ("C", &["D"])],
        );
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();

        let execute = count_opcodes(&tape, |op| {
            matches!(op, GeometricOpCode::ExecuteManifold(_))
        });
        assert_eq!(execute, 4, "all 4 manifolds should execute");
    }

    #[test]
    fn test_all_manifolds_eventually_collapsed() {
        let complex = make_complex(
            &["A", "B", "C"],
            &[("B", &["A"]), ("C", &["B"])],
            &[("A", &["B"]), ("B", &["C"])],
        );
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();

        let collapsed: HashSet<String> = tape
            .iter()
            .filter_map(|i| {
                if let GeometricOpCode::CollapseManifold(name) = &i.opcode {
                    Some(name.clone())
                } else {
                    None
                }
            })
            .collect();

        assert!(collapsed.contains("A"), "A should be collapsed");
        assert!(collapsed.contains("B"), "B should be collapsed");
        assert!(collapsed.contains("C"), "C should be collapsed");
    }

    #[test]
    fn test_empty_complex() {
        let complex = make_complex(&[], &[], &[]);
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();
        assert!(tape.is_empty());
    }

    #[test]
    fn test_opcode_serialization() {
        // Verify opcodes can round-trip through serde
        let op = GeometricOpCode::CollapseManifold("test".to_string());
        let json = serde_json::to_string(&op).unwrap();
        let back: GeometricOpCode = serde_json::from_str(&json).unwrap();
        assert!(matches!(back, GeometricOpCode::CollapseManifold(name) if name == "test"));
    }

    #[test]
    fn test_instruction_tape_order() {
        // Verify that instantiation precedes execution for each manifold
        let complex = make_complex(&["A"], &[], &[]);
        let tape = wire_phase3_to_phase4(&complex, &mut SymbolTable::new()).unwrap();

        let mut saw_instantiate = false;
        let mut saw_execute_before_instantiate = false;

        for instr in &tape {
            match &instr.opcode {
                GeometricOpCode::InstantiateManifold(n) if n == "A" => saw_instantiate = true,
                GeometricOpCode::ExecuteManifold(n) if n == "A" => {
                    if !saw_instantiate {
                        saw_execute_before_instantiate = true;
                    }
                }
                _ => {}
            }
        }

        assert!(
            !saw_execute_before_instantiate,
            "execute should not precede instantiate"
        );
    }
}
