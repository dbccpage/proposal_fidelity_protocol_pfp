//! contract-authority observer: declared authority effect may never exceed its role pin,
//! and the row's declared role-ceiling must agree with the canonical per-role pin.
//!
//! Authority is bounded above by the role-pinned ceiling. Any row whose
//! `declared_authority_effect` ranks strictly above its `role_pinned_ceiling`
//! (per [`crate::row::authority_rank`]) is drifting authority upward past its pin.
//! Separately, the row's declared role-ceiling must be an effect admitted for
//! its role by the local mirror of `omega_contract_core::validate`.
use super::ObserverReading;
use crate::row::{authority_rank, role_admits_ceiling, ReconciliationRow};

pub use crate::row::pinned_authority_effect;

/// Deterministic contract-authority reading for a row.
pub fn check(row: &ReconciliationRow) -> ObserverReading {
    let mut findings = Vec::new();

    // Drift: declared effect ranks strictly above the row's declared role-pinned ceiling.
    if authority_rank(row.declared_authority_effect) > authority_rank(row.role_pinned_ceiling) {
        findings.push("authority-ceiling drift above role pin".to_string());
    }

    if !role_admits_ceiling(row.role, row.role_pinned_ceiling) {
        findings.push(format!(
            "contract-authority: declared role-ceiling is not admitted for {:?}",
            row.role
        ));
    }

    ObserverReading {
        observer: "contract-authority",
        findings,
    }
}
