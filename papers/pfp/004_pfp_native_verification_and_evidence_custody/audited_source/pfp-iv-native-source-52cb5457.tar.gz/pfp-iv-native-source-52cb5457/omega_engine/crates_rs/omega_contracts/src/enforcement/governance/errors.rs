//! Governance error types for Blackrod and Woland functors.
//!
//! All governance errors are defensive in nature. No error type encodes
//! offensive, retaliatory, or real-world coercive semantics.

use serde::{Deserialize, Serialize};

/// Result type alias for governance operations.
pub type GovernanceResult<T> = Result<T, GovernanceError>;

/// Governance error types.
///
/// These errors describe failures in the governance enforcement/diagnostic pipeline.
/// No error variant encodes offensive or coercive semantics.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize, thiserror::Error)]
pub enum GovernanceError {
    /// Authority boundary violation.
    #[error("authority violation: {0}")]
    AuthorityViolation(String),

    /// Evidence requirement not met.
    #[error("evidence missing: {artifact_id} requires {evidence_type}")]
    EvidenceMissing {
        artifact_id: String,
        evidence_type: String,
    },

    /// Invalid finding structure.
    #[error("invalid finding: {0}")]
    InvalidFinding(String),

    /// Trace not found.
    #[error("trace not found: {0}")]
    TraceNotFound(String),

    /// Council not found.
    #[error("council not found: {0}")]
    CouncilNotFound(String),

    /// License not found.
    #[error("license not found: {0}")]
    LicenseNotFound(String),

    /// Artifact not found.
    #[error("artifact not found: {0}")]
    ArtifactNotFound(String),

    /// Meeting not found.
    #[error("meeting not found: {0}")]
    MeetingNotFound(String),

    /// Internal governance error.
    #[error("internal error: {0}")]
    InternalError(String),
}

/// Unique identifier for a trace record.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct TraceId(pub String);

impl TraceId {
    /// Create a new trace identifier.
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }

    /// Get the trace ID as a string slice.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl From<String> for TraceId {
    fn from(s: String) -> Self {
        Self(s)
    }
}

impl From<&str> for TraceId {
    fn from(s: &str) -> Self {
        Self(s.to_string())
    }
}

/// Unique identifier for a council.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct CouncilId(pub String);

impl CouncilId {
    /// Create a new council identifier.
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }

    /// Get the council ID as a string slice.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl From<String> for CouncilId {
    fn from(s: String) -> Self {
        Self(s)
    }
}

impl From<&str> for CouncilId {
    fn from(s: &str) -> Self {
        Self(s.to_string())
    }
}

/// Unique identifier for a license.
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct LicenseId(pub String);

impl LicenseId {
    /// Create a new license identifier.
    pub fn new(id: impl Into<String>) -> Self {
        Self(id.into())
    }

    /// Get the license ID as a string slice.
    pub fn as_str(&self) -> &str {
        &self.0
    }
}

impl From<String> for LicenseId {
    fn from(s: String) -> Self {
        Self(s)
    }
}

impl From<&str> for LicenseId {
    fn from(s: &str) -> Self {
        Self(s.to_string())
    }
}

/// Artifact type classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum ArtifactType {
    /// Source code artifact.
    Code,
    /// Test artifact.
    Test,
    /// Documentation artifact.
    Documentation,
    /// Configuration artifact.
    Configuration,
    /// Trace artifact.
    Trace,
    /// Evidence artifact.
    Evidence,
    /// Certificate artifact.
    Certificate,
    /// Unknown artifact type.
    Unknown,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn trace_id_round_trip() {
        let id = TraceId::new("trace-001");
        assert_eq!(id.as_str(), "trace-001");
    }

    #[test]
    fn council_id_round_trip() {
        let id = CouncilId::new("council-alpha");
        assert_eq!(id.as_str(), "council-alpha");
    }

    #[test]
    fn license_id_round_trip() {
        let id = LicenseId::new("lic-42");
        assert_eq!(id.as_str(), "lic-42");
    }

    #[test]
    fn governance_error_display() {
        let err = GovernanceError::AuthorityViolation("test violation".into());
        assert!(err.to_string().contains("authority violation"));
    }
}
