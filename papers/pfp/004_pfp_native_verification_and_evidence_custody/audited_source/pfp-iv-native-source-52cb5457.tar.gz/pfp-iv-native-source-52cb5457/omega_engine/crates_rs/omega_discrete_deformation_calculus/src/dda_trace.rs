use num_rational::BigRational;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::fs::{create_dir_all, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DdaTraceStep {
    pub timestamp_utc: String,
    pub runner_id: String,
    pub campaign: String,
    pub run_id: String,
    pub step_id: String,
    pub letter: String,
    pub action_name: String,
    pub cochain_dim: String,
    pub coboundary_map: String,
    pub input_state: String,
    pub output_state: String,
    pub witness: String,
    pub residual_energy: BigRational,
    pub refusal_reason: Option<String>,
    pub authority_effect: String,
    pub prev_step_hash: Option<String>,
    pub step_hash: String,
}

pub struct TraceLogger {
    pub runner_id: String,
    pub campaign_name: String,
    pub trace_dir: PathBuf,
    pub run_id: String,
    pub jsonl_path: PathBuf,
    pub last_hash: Option<String>,
    pub step_counter: usize,
}

impl TraceLogger {
    pub fn new(runner_id: &str, campaign_name: Option<&str>, custom_dir: Option<&Path>) -> Self {
        let r_id = runner_id.to_string();
        let camp = campaign_name.unwrap_or(runner_id).to_string();
        let trace_dir = match custom_dir {
            Some(p) => p.to_path_buf(),
            None => {
                let current = std::env::current_dir().unwrap_or_else(|_| PathBuf::from("."));
                if current.join(".agents").exists() {
                    current.join(".agents").join("dda_traces")
                } else if current.join("omega_engine").exists() {
                    current.join(".agents").join("dda_traces")
                } else {
                    current.join("..").join(".agents").join("dda_traces")
                }
            }
        };
        let _ = create_dir_all(&trace_dir);
        let run_id = format!("{:012x}", rand_u64());
        let jsonl_path = trace_dir.join(format!("{}_{}_dda_trace.jsonl", r_id, run_id));

        Self {
            runner_id: r_id,
            campaign_name: camp,
            trace_dir,
            run_id,
            jsonl_path,
            last_hash: None,
            step_counter: 0,
        }
    }

    pub fn record_step(
        &mut self,
        letter: &str,
        action_name: &str,
        input_state: &str,
        output_state: &str,
        witness: &str,
        residual_energy: BigRational,
        refusal_reason: Option<String>,
    ) -> DdaTraceStep {
        self.step_counter += 1;
        let now = chrono_utc_now();
        let step_id = format!("DDA_STEP_{:03}", self.step_counter);

        let mut step = DdaTraceStep {
            timestamp_utc: now,
            runner_id: self.runner_id.clone(),
            campaign: self.campaign_name.clone(),
            run_id: self.run_id.clone(),
            step_id,
            letter: letter.to_string(),
            action_name: action_name.to_string(),
            cochain_dim: "C1".to_string(),
            coboundary_map: "d1".to_string(),
            input_state: input_state.to_string(),
            output_state: output_state.to_string(),
            witness: witness.to_string(),
            residual_energy,
            refusal_reason,
            authority_effect: "None".to_string(),
            prev_step_hash: self.last_hash.clone(),
            step_hash: String::new(),
        };

        step.step_hash = compute_step_hash(&step);
        self.last_hash = Some(step.step_hash.clone());

        if let Ok(json_line) = serde_json::to_string(&step) {
            if let Ok(mut file) = OpenOptions::new()
                .create(true)
                .append(true)
                .open(&self.jsonl_path)
            {
                let _ = writeln!(file, "{}", json_line);
            }
        }

        step
    }
}

fn compute_step_hash(step: &DdaTraceStep) -> String {
    let mut copy = step.clone();
    copy.step_hash.clear();
    let json_bytes = serde_json::to_vec(&copy).unwrap_or_default();
    let mut hasher = Sha256::new();
    hasher.update(&json_bytes);
    format!("{:x}", hasher.finalize())
}

fn chrono_utc_now() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let start = SystemTime::now();
    let since_the_epoch = start.duration_since(UNIX_EPOCH).unwrap_or_default();
    format!("{}s-utc", since_the_epoch.as_secs())
}

fn rand_u64() -> u64 {
    use std::time::{SystemTime, UNIX_EPOCH};
    let start = SystemTime::now();
    let since_the_epoch = start.duration_since(UNIX_EPOCH).unwrap_or_default();
    since_the_epoch.as_nanos() as u64
}

#[cfg(test)]
mod tests {
    use super::*;
    use num_traits::Zero;

    #[test]
    fn test_trace_logger() {
        let dir = std::env::temp_dir().join(format!("dda_test_{}", rand_u64()));
        let mut logger = TraceLogger::new("test_runner", None, Some(&dir));

        let s1 = logger.record_step(
            "C",
            "context_start",
            "S0",
            "S1",
            "WIT0",
            BigRational::zero(),
            None,
        );
        assert_eq!(s1.letter, "C");

        let s2 = logger.record_step(
            "E",
            "exact_repair",
            "S1",
            "S2",
            "WIT1",
            BigRational::zero(),
            None,
        );
        assert_eq!(s2.letter, "E");
        assert_eq!(s2.prev_step_hash, Some(s1.step_hash));

        let files: Vec<_> = std::fs::read_dir(&dir).unwrap().collect();
        assert_eq!(files.len(), 1);
        let _ = std::fs::remove_dir_all(&dir);
    }
}
