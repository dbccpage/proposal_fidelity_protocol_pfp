"""Meth-level canonical structural repair for Stage-1 DEEP residual HAS_RS stems.

Fills missing omega.contract.v1 structural gates only (math block, laws,
required_structures, negative_tests, doctrine.non_role/summary, authority
descriptor). Does NOT invent deep theorems. status -> mathematical_wip when
structural content was thin. Preserves nomos_debate_NOT_CANONICAL.

AuthorityEffect None. Not PROVED. Not GlobalGreen.
"""
from __future__ import annotations

import re
from copy import deepcopy
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parents[5]
MATH = REPO / "omega_engine/crates/omega_contracts/src/contract_canonical_definitions/math"
RECEIPT_IN = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_stage1_has_rs_deep_receipt.md"
RECEIPT_OUT = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_stage1_has_rs_meth_repair_receipt.md"
STEMS_HAS = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_has_rs_stems.txt"

# Residual stems from deep receipt (hardcoded fallback if receipt parse fails)
FALLBACK_RESIDUALS = [
    "algebraic_field.contract.yaml",
    "chain_complex.contract.yaml",
    "closure_defect.contract.yaml",
    "closure_regime.contract.yaml",
    "cohomology.contract.yaml",
    "contract_descriptors.contract.yaml",
    "contract_property_witnesses.contract.yaml",
    "diagnostic_vector.contract.yaml",
    "evaluation_hierarchy.contract.yaml",
    "exact_carrier.contract.yaml",
    "exact_repair.contract.yaml",
    "fiber.contract.yaml",
    "fiber_bundle.contract.yaml",
    "functional_layer_boundary.contract.yaml",
    "gamma2_closure_defect.contract.yaml",
    "gram_schmidt.contract.yaml",
    "hashes.contract.yaml",
    "higher_inductive_type.contract.yaml",
    "identity_type.contract.yaml",
    "image.contract.yaml",
    "interval.contract.yaml",
    "invariant_defect_profile.contract.yaml",
    "lefschetz_operator.contract.yaml",
    "lift_candidate.contract.yaml",
    "lift_certificate.contract.yaml",
    "lift_forget_fixed_point.contract.yaml",
    "maurer_cartan_equation.contract.yaml",
    "mub_feasibility_wall.contract.yaml",
    "observer.contract.yaml",
    "observer_comparison.contract.yaml",
    "observer_family.contract.yaml",
    "observer_quotient.contract.yaml",
    "operator_class.contract.yaml",
    "phi1.contract.yaml",
    "phi1_obstruction_mass.contract.yaml",
    "quotient_mass.contract.yaml",
    "real_algebraic_number.contract.yaml",
    "replay_hash.contract.yaml",
    "residual_projection.contract.yaml",
    "seed.contract.yaml",
    "shor_topos.contract.yaml",
    "t3_authority.contract.yaml",
    "xi_diagnostic.contract.yaml",
    "xi_tie_breaker.contract.yaml",
]


def residual_stems() -> list[str]:
    if RECEIPT_IN.is_file():
        stems = []
        for line in RECEIPT_IN.read_text(encoding="utf-8").splitlines():
            m = re.search(r"`([a-z0-9_]+\.contract\.yaml)`", line)
            if m and line.strip().startswith("|"):
                stems.append(m.group(1))
        # de-dup preserve order
        out, seen = [], set()
        for s in stems:
            if s not in seen and s.endswith(".contract.yaml"):
                seen.add(s)
                out.append(s)
        if out:
            return out
    return list(FALLBACK_RESIDUALS)


def split_debate(text: str) -> tuple[str, str]:
    key = "nomos_debate_NOT_CANONICAL:"
    if key not in text:
        empty = (
            "nomos_debate_NOT_CANONICAL:\n"
            '  banner: "NON-CANONICAL DEBATE ONLY — not contract law; not enforced; AuthorityEffect None"\n'
            "  not_part_of_contract_law: true\n"
            "  authority_effect: none\n"
            "  potential_defects: []\n"
            "  realization_delta_vs_implemented_math_file: []\n"
        )
        return text.rstrip() + "\n", empty
    i = text.index(key)
    return text[:i].rstrip() + "\n", text[i:]


def stem_slug(filename: str) -> str:
    return filename.replace(".contract.yaml", "")


def default_non_role(slug: str) -> list[str]:
    return [
        "Authority minting or GlobalGreen discharge",
        "Customer-facing claims or product guarantees",
        f"Full encyclopedia mechanization of {slug} (deferred)",
        "HoTT/Univalence theorem discharge from this contract alone",
        "Runtime enforcement as proof of mathematical truth",
    ]


def default_negative_tests(slug: str, title: str) -> list[str]:
    return [
        f"Artifact claiming {title} without required structures must be rejected",
        f"Empty or ill-typed carrier for {slug} must be rejected",
        "Artifact claiming authority or admissibility must be rejected",
        "Artifact claiming PROVED/GlobalGreen from this contract alone must be rejected",
        "Non-deterministic or external-state-dependent construction must be rejected",
    ]


def default_laws(slug: str, title: str) -> list[str]:
    return [
        f"{title} is a pure mathematical structure (AuthorityEffect none)",
        "All declared required_structures must hold for a valid instance",
        "Replay is deterministic: no external state, no randomness, no wall-clock",
        "This contract does not mint customer claims or GlobalGreen",
    ]


def default_required_structures(slug: str, title: str) -> list[str]:
    return [
        f"Carrier for {slug} must be finite/explicit where claimed",
        "Object kind and domain/codomain (or equivalent) must be declared",
        "Operations, if any, must preserve declared structure",
        "No authority effect may be self-assigned by the structure",
    ]


def ensure_descriptor(data: dict) -> None:
    desc = data.get("descriptor")
    if not isinstance(desc, dict):
        desc = {}
    desc.setdefault("authority_effect", "none")
    if str(desc.get("authority_effect", "")).lower() != "none":
        desc["authority_effect"] = "none"
    desc.setdefault("evidence_ceiling", "ShapeOnly")
    desc.setdefault("runtime_enforcement", False)
    desc["customer_claim_allowed"] = False
    desc.setdefault("dependencies", {"contracts": [], "proof_obligations": []})
    desc.setdefault("terminals", {"may_emit": [], "may_support": []})
    desc.setdefault("refusals", {"may_emit": []})
    desc.setdefault(
        "operator_classes", {"may_support": [], "must_not_self_assign": True}
    )
    data["descriptor"] = desc


def migrate_legacy(data: dict, slug: str) -> dict:
    """Lift legacy non-v1 shapes into omega.contract.v1 shell, preserving prose."""
    if data.get("schema_version") == "omega.contract.v1" and str(
        data.get("contract_id", "")
    ).startswith("urn:omega:math:"):
        return data

    title = str(data.get("title") or slug.replace("_", " ").title())
    old_id = str(data.get("contract_id") or "")
    new_id = f"urn:omega:math:{slug}:v0.1.0"
    if old_id.startswith("urn:omega:math:"):
        new_id = old_id

    # harvest description / mathematical_object prose
    summary_bits = []
    for k in ("description", "purpose", "summary"):
        v = data.get(k)
        if isinstance(v, str) and v.strip():
            summary_bits.append(v.strip())
    mo = data.get("mathematical_object")
    if isinstance(mo, dict):
        for k, v in mo.items():
            if isinstance(v, str) and v.strip():
                summary_bits.append(f"{k}: {v.strip()}")
            elif isinstance(v, list):
                summary_bits.append(f"{k}: " + "; ".join(str(x) for x in v[:8]))
    elif isinstance(mo, str) and mo.strip():
        summary_bits.append(mo.strip())

    summary = " ".join(summary_bits)[:1200] if summary_bits else (
        f"Meth-level structural shell for {title}. Human-built; not God-given; not PROVED."
    )

    req_props = data.get("required_properties") or data.get("properties") or []
    if isinstance(req_props, dict):
        req_props = [f"{k}: {v}" for k, v in req_props.items()]
    if not isinstance(req_props, list):
        req_props = []
    req_props = [str(x) for x in req_props if x][:20]

    ops = data.get("operations") or []
    if isinstance(ops, dict):
        ops = list(ops.keys())
    if not isinstance(ops, list):
        ops = []

    domain = []
    if ops:
        domain.append("operations: " + ", ".join(str(o) for o in ops[:12]))
    deps = data.get("dependencies")
    if isinstance(deps, list) and deps:
        domain.append("dependencies: " + ", ".join(str(d) for d in deps[:12]))
    elif isinstance(deps, dict) and deps:
        domain.append("dependencies: " + ", ".join(str(k) for k in list(deps)[:12]))
    if not domain:
        domain = [f"carrier: declared instance of {slug}"]

    laws = req_props[:] if req_props else default_laws(slug, title)
    if ops:
        laws = laws + [f"Declared operation present in model: {o}" for o in ops[:6]]

    new = {
        "schema_version": "omega.contract.v1",
        "contract_id": new_id,
        "title": title,
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": {},
        "math": {
            "object_kind": slug,
            "symbol": slug,
            "ascii_symbol": slug,
            "notation": slug,
            "domain": domain,
            "codomain": {
                "description": summary[:400],
            },
        },
        "requirements": {
            "required_structures": req_props
            if req_props
            else default_required_structures(slug, title),
        },
        "laws": laws if laws else default_laws(slug, title),
        "negative_tests": default_negative_tests(slug, title),
        "doctrine": {
            "summary": summary[:800],
            "non_role": default_non_role(slug),
        },
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No time-dependent data",
            ],
        },
    }
    # preserve rust_binding if present
    if isinstance(data.get("rust_binding"), dict):
        new["rust_binding"] = data["rust_binding"]
    # keep legacy_id note
    if old_id and old_id != new_id:
        new["doctrine"]["legacy_contract_id"] = old_id
        new["doctrine"]["migration_note"] = (
            "Migrated from legacy schema to omega.contract.v1 under meth-level "
            "HAS_RS repair; content is structural shell pending math re-review."
        )
    ensure_descriptor(new)
    return new


def repair_v1(data: dict, slug: str) -> tuple[dict, list[str]]:
    """Repair an already-v1 contract. Returns (data, actions)."""
    actions: list[str] = []
    data = deepcopy(data)
    title = str(data.get("title") or slug.replace("_", " ").title())

    # top-level hygiene
    if data.get("schema_version") != "omega.contract.v1":
        data["schema_version"] = "omega.contract.v1"
        actions.append("set schema_version")
    cid = str(data.get("contract_id") or "")
    if not cid.startswith("urn:omega:math:"):
        data["contract_id"] = f"urn:omega:math:{slug}:v0.1.0"
        actions.append("fix contract_id urn")
    data.setdefault("kind", "math_contract")
    data.setdefault("layer", "math")
    if not data.get("title"):
        data["title"] = title
        actions.append("set title")

    ensure_descriptor(data)
    if "descriptor" in actions or True:
        actions.append("ensure descriptor.authority_effect=none + customer_claim_allowed=false")

    # math block
    math = data.get("math")
    if not isinstance(math, dict):
        math = {}
        actions.append("create math block")
    if not math.get("object_kind"):
        math["object_kind"] = slug
        actions.append("set math.object_kind")
    math.setdefault("ascii_symbol", slug)
    math.setdefault("symbol", math.get("ascii_symbol") or slug)
    math.setdefault("notation", math.get("symbol") or slug)
    if "domain" not in math or math.get("domain") in (None, [], {}):
        math["domain"] = [f"carrier: instance of {slug}"]
        actions.append("set math.domain")
    if "codomain" not in math or not math.get("codomain"):
        math["codomain"] = {
            "description": f"Mathematical object declared by {title} (structural shell)."
        }
        actions.append("set math.codomain")
    data["math"] = math

    # requirements.required_structures
    req = data.get("requirements")
    if not isinstance(req, dict):
        # if requirements is a list, wrap
        if isinstance(req, list) and req:
            req = {"required_structures": [str(x) for x in req]}
            actions.append("wrap list requirements into required_structures")
        else:
            req = {}
            actions.append("create requirements")
    rs = req.get("required_structures")
    if not rs:
        req["required_structures"] = default_required_structures(slug, title)
        actions.append("set required_structures")
    data["requirements"] = req

    # laws
    laws = data.get("laws")
    if not laws:
        data["laws"] = default_laws(slug, title)
        actions.append("set laws")
    elif isinstance(laws, list) and len(laws) == 0:
        data["laws"] = default_laws(slug, title)
        actions.append("fill empty laws")

    # negative_tests
    nt = data.get("negative_tests")
    if not nt:
        data["negative_tests"] = default_negative_tests(slug, title)
        actions.append("set negative_tests")

    # doctrine
    doctrine = data.get("doctrine")
    if not isinstance(doctrine, dict):
        doctrine = {}
        actions.append("create doctrine")
    if not doctrine.get("summary"):
        doctrine["summary"] = (
            f"{title}: pure mathematical contract for {slug}. "
            "Human-built structural declaration; confers no authority; not PROVED; not GlobalGreen."
        )
        actions.append("set doctrine.summary")
    nr = doctrine.get("non_role")
    if nr is None or (isinstance(nr, list) and len(nr) == 0) or (
        isinstance(nr, str) and not str(nr).strip()
    ):
        doctrine["non_role"] = default_non_role(slug)
        actions.append("set doctrine.non_role (anti-theater)")
    data["doctrine"] = doctrine

    # status honesty: if we had to fill structural shells, prefer mathematical_wip
    st = str(data.get("status") or "")
    if st == "active" and any(
        a.startswith("create math")
        or a.startswith("set laws")
        or a.startswith("set required")
        or a.startswith("set negative")
        for a in actions
    ):
        data["status"] = "mathematical_wip"
        actions.append("demote status active -> mathematical_wip (structural repair)")
    elif not st:
        data["status"] = "mathematical_wip"
        actions.append("set status mathematical_wip")

    # strip legacy top-level authority keys that confuse gates
    for k in ("authority_level", "authority_effect", "customer_claim_allowed", "version"):
        if k in data and k != "version":
            # keep version only if not conflicting; remove authority*
            if k.startswith("authority") or k == "customer_claim_allowed":
                data.pop(k, None)
                actions.append(f"remove legacy top-level {k}")

    # identity_type / overclaim: add nonclaim fence in doctrine if HoTT present without fence
    canon_probe = yaml.dump(data, default_flow_style=False, allow_unicode=True)
    if re.search(r"\bHoTT\b|\bUnivalence\b|\bPROVED\b|\bGlobalGreen\b", canon_probe):
        summary = str(doctrine.get("summary") or "")
        fence = (
            " Nonclaim: this contract does not claim HoTT/Univalence discharge, "
            "PROVED status, or GlobalGreen."
        )
        if "does not claim" not in summary.lower() and "nonclaim" not in summary.lower():
            doctrine["summary"] = (summary + fence).strip()
            data["doctrine"] = doctrine
            actions.append("add overclaim nonclaim fence to doctrine.summary")

    # dedupe actions loosely
    uniq = []
    for a in actions:
        if a not in uniq:
            uniq.append(a)
    return data, uniq


def dump_canon(data: dict) -> str:
    # Prefer stable key order for readability
    preferred = [
        "schema_version",
        "contract_id",
        "title",
        "kind",
        "status",
        "layer",
        "descriptor",
        "math",
        "requirements",
        "laws",
        "replay",
        "relationships",
        "rust_binding",
        "negative_tests",
        "doctrine",
        "wip",
    ]
    ordered = {}
    for k in preferred:
        if k in data:
            ordered[k] = data[k]
    for k, v in data.items():
        if k not in ordered:
            ordered[k] = v
    return yaml.safe_dump(
        ordered,
        sort_keys=False,
        allow_unicode=True,
        default_flow_style=False,
        width=100,
    )


def annotate_debate(debate: str, actions: list[str]) -> str:
    if not actions:
        return debate
    item = (
        "  - reviewer: panepistimion-math-prof\n"
        "    role: MATH_CANONICAL_REVIEW\n"
        "    code: METH_STRUCTURAL_REPAIR\n"
        "    severity: info\n"
        '    claim_class: "[STANDARD]"\n'
        f'    detail: "Meth-level structural repair applied: {"; ".join(actions[:12])}. '
        'Not PROVED; not GlobalGreen; human re-review still required for math depth."\n'
        '    recommendation: "Continue meth re-review for object-specific laws; code follows YAML (ADR-007a)."\n'
        "    pass: stage1_meth_repair_has_rs\n"
    )
    # avoid duplicate inject
    if "METH_STRUCTURAL_REPAIR" in debate:
        return debate
    if "potential_defects: []" in debate:
        return debate.replace("potential_defects: []", "potential_defects:\n" + item.rstrip(), 1)
    marker = "  realization_delta_vs_implemented_math_file:"
    if marker in debate:
        i = debate.index(marker)
        return debate[:i] + item + debate[i:]
    if "potential_defects:" in debate:
        return debate.rstrip() + "\n" + item
    return debate.rstrip() + "\n  potential_defects:\n" + item


def main() -> None:
    stems = residual_stems()
    rows: list[tuple[str, list[str]]] = []
    for stem in stems:
        p = MATH / stem
        if not p.is_file():
            rows.append((stem, ["MISSING_FILE"]))
            continue
        text = p.read_text(encoding="utf-8")
        canon_text, debate = split_debate(text)
        try:
            data = yaml.safe_load(canon_text)
        except Exception as e:  # noqa: BLE001
            rows.append((stem, [f"PARSE_FAIL:{e}"]))
            continue
        if not isinstance(data, dict):
            rows.append((stem, ["ROOT_NOT_MAPPING"]))
            continue

        slug = stem_slug(stem)
        is_legacy = data.get("schema_version") != "omega.contract.v1" or not str(
            data.get("contract_id") or ""
        ).startswith("urn:omega:math:")

        if is_legacy:
            data = migrate_legacy(data, slug)
            actions = ["migrate_legacy_to_omega.contract.v1"]
            data, more = repair_v1(data, slug)
            actions.extend(more)
        else:
            data, actions = repair_v1(data, slug)

        new_canon = dump_canon(data)
        # re-parse dump to ensure valid
        yaml.safe_load(new_canon)
        new_debate = annotate_debate(debate, actions)
        p.write_text(new_canon.rstrip() + "\n" + new_debate, encoding="utf-8")
        # final whole-file parse
        yaml.safe_load(p.read_text(encoding="utf-8"))
        rows.append((stem, actions if actions else ["NOOP"]))

    # write receipt
    lines = [
        "# Stage-1 meth-level canonical repair (HAS_RS residuals)",
        "",
        "**AuthorityEffect:** None",
        f"**Targets:** {len(stems)} residual stems from deep Stage-1",
        "**Scope:** structural omega.contract.v1 gates only — not theorem discharge",
        "",
        "| Stem | Actions |",
        "| --- | --- |",
    ]
    for stem, acts in rows:
        lines.append(f"| `{stem}` | {'; '.join(acts)} |")
    lines += [
        "",
        "## Nonclaims",
        "",
        "- Not PROVED / not GlobalGreen / not HoTT discharge",
        "- Default laws/required_structures/negative_tests are structural shells",
        "  pending object-specific meth re-review",
        "- Debate blocks preserved; METH_STRUCTURAL_REPAIR note injected",
        "- Code-follows-YAML (ADR-007a): realization code not auto-edited",
        "",
        "**AuthorityEffect: None.**",
        "",
    ]
    RECEIPT_OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"repaired={len(rows)} receipt={RECEIPT_OUT}")


if __name__ == "__main__":
    main()
