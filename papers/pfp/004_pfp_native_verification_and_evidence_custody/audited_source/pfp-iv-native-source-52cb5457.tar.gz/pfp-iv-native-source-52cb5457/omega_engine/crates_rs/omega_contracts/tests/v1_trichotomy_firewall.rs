//! Task 15 — the floating/tolerance-claims-exact rule is CONTRACT-SPECIFIC (spec §11.5),
//! asserted here, not as a generic schema validator. The migrated trichotomy must declare
//! the `floating_firewall` law and a floating/tolerance negative test.
use omega_contracts::registry::OmegaContractV1;
use serde_yaml::Value;
use std::path::Path;

const FIREWALL: &str = "no floating heuristic may emit an exact trichotomy constructor.";

fn require_firewall(
    laws: Option<&Value>,
    negative_tests: Option<&[String]>,
) -> Result<(), &'static str> {
    // Both forms are already authored in the two corpora. Compare the complete
    // obligation, never just a keyword that a negated/forged sentence can carry.
    let matches = |text: &str| text.eq_ignore_ascii_case(FIREWALL);
    let declared = match laws {
        Some(Value::Mapping(map)) => map
            .get(Value::from("floating_firewall"))
            .and_then(Value::as_str)
            .is_some_and(matches),
        Some(Value::Sequence(items)) => items
            .iter()
            .filter_map(Value::as_str)
            .filter_map(|text| text.strip_prefix("Floating firewall: "))
            .any(matches),
        _ => false,
    };
    if !declared {
        return Err("FLOATING_FIREWALL_DECLARATION_MISSING_OR_CHANGED");
    }
    let negative = negative_tests.is_some_and(|items| {
        items.iter().any(|text| {
            text == "Tolerance mode used to emit exact trichotomy must be rejected"
                || text == "Tolerance mode used to emit exact trichotomy"
        })
    });
    if !negative {
        return Err("FLOATING_FIREWALL_NEGATIVE_FIXTURE_MISSING");
    }
    Ok(())
}

#[test]
fn trichotomy_declares_floating_firewall_and_negative_test() {
    let p = Path::new(env!("CARGO_MANIFEST_DIR")).join(
        "src/contract_canonical_definitions/math/finite_obstruction_trichotomy.contract.yaml",
    );
    let text = std::fs::read_to_string(p).expect("migrated exemplar exists");
    let c: OmegaContractV1 = serde_yaml::from_str(&text).expect("exemplar parses as v1");

    require_firewall(c.laws.as_ref(), c.negative_tests.as_deref())
        .expect("declared floating firewall and its negative fixture");
}

#[test]
fn both_authored_law_formats_require_the_complete_firewall() {
    let negative = vec!["Tolerance mode used to emit exact trichotomy".to_owned()];
    for raw in [
        "floating_firewall: No floating heuristic may emit an exact trichotomy constructor.",
        "- 'Floating firewall: no floating heuristic may emit an exact trichotomy constructor.'",
    ] {
        let laws: Value = serde_yaml::from_str(raw).unwrap();
        assert_eq!(require_firewall(Some(&laws), Some(&negative)), Ok(()));
    }
}

#[test]
fn keyword_spoofing_or_removing_the_law_is_refused() {
    let negative = vec!["Tolerance mode used to emit exact trichotomy".to_owned()];
    for raw in [
        "{}",
        "[]",
        "floating_firewall: floating heuristics MAY emit an exact trichotomy constructor.",
        "floating_firewall: null",
        "- 'Floating firewall: bypass allowed; no floating heuristic may emit an exact trichotomy constructor.'",
        "- 'Some prose mentioning the Floating firewall: no floating heuristic may emit an exact trichotomy constructor.'",
    ] {
        let laws: Value = serde_yaml::from_str(raw).unwrap();
        assert_eq!(require_firewall(Some(&laws), Some(&negative)), Err("FLOATING_FIREWALL_DECLARATION_MISSING_OR_CHANGED"));
    }
}

#[test]
fn a_valid_law_without_its_decisive_negative_fixture_is_refused() {
    let laws: Value = serde_yaml::from_str(
        "floating_firewall: No floating heuristic may emit an exact trichotomy constructor.",
    )
    .unwrap();
    for negative in [
        None,
        Some(vec![]),
        Some(vec!["floating tests all passed, trust me".to_owned()]),
    ] {
        assert_eq!(
            require_firewall(Some(&laws), negative.as_deref()),
            Err("FLOATING_FIREWALL_NEGATIVE_FIXTURE_MISSING")
        );
    }
}
