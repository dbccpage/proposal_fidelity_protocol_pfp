//! Task 14 — poison fixtures must fail closed (parse rejection or validate_v1 finding).
use omega_contracts::registry::{validate_v1, OmegaContractV1};
use std::path::Path;

fn fixture(name: &str) -> String {
    let p = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures/v1/poison")
        .join(name);
    std::fs::read_to_string(p).expect("poison fixture exists")
}

// Structural defects fail at parse (deny_unknown_fields / required field).
#[test]
fn missing_descriptor_fails_at_parse() {
    assert!(serde_yaml::from_str::<OmegaContractV1>(&fixture("missing_descriptor.yaml")).is_err());
}

#[test]
fn compact_yaml_present_fails_at_parse() {
    assert!(
        serde_yaml::from_str::<OmegaContractV1>(&fixture("compact_yaml_present.yaml")).is_err()
    );
}

// Semantic defects parse but fail validate_v1.
#[test]
fn authority_for_math_fails_validation() {
    let c: OmegaContractV1 = serde_yaml::from_str(&fixture("authority_for_math.yaml")).unwrap();
    let errs = validate_v1(&c).unwrap_err();
    assert!(errs.iter().any(|f| f.contains("authority_effect: none")));
}

#[test]
fn unknown_terminal_fails_validation() {
    let c: OmegaContractV1 = serde_yaml::from_str(&fixture("unknown_terminal.yaml")).unwrap();
    assert!(validate_v1(&c)
        .unwrap_err()
        .iter()
        .any(|f| f.contains("unknown terminal")));
}

#[test]
fn unknown_refusal_fails_validation() {
    let c: OmegaContractV1 = serde_yaml::from_str(&fixture("unknown_refusal.yaml")).unwrap();
    assert!(validate_v1(&c)
        .unwrap_err()
        .iter()
        .any(|f| f.contains("unknown refusal")));
}

#[test]
fn malformed_po_fails_validation() {
    let c: OmegaContractV1 = serde_yaml::from_str(&fixture("malformed_po.yaml")).unwrap();
    assert!(validate_v1(&c)
        .unwrap_err()
        .iter()
        .any(|f| f.contains("malformed proof obligation")));
}

// Sprint 2: a non-math kind without an explicit role fails validate_v1.
#[test]
fn nonmath_missing_role_fails_validation() {
    let c: OmegaContractV1 = serde_yaml::from_str(&fixture("nonmath_missing_role.yaml")).unwrap();
    assert!(validate_v1(&c)
        .unwrap_err()
        .iter()
        .any(|f| f.contains("role required")));
}

// Sprint 2: an unknown role enum value fails closed at deserialize.
#[test]
fn unknown_role_fails_at_parse() {
    assert!(serde_yaml::from_str::<OmegaContractV1>(&fixture("unknown_role.yaml")).is_err());
}
