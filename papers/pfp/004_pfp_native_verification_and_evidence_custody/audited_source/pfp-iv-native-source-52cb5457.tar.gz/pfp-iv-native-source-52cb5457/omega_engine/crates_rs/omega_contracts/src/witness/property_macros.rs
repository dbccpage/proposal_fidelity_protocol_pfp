/// Generates test-time lambda property checks.
///
/// This macro does not emit persisted `ValidationWitness` artifacts. Persistent
/// witness evidence belongs in `crate::witness::evidence` and
/// `crate::witness::empirical`.
#[macro_export]
macro_rules! generate_lambda_witnesses {
    ($impl_ty:ty, $contract:ty) => {
        // ─── Compile-time bound assertions ───────────────────────────────────
        const _: () = {
            // Contract must be a strict lambda contract
            fn assert_strict_lambda<C: $crate::descriptors::StrictLambdaContract>() {}
            fn assert_bound_contract<C: $crate::binding::BoundContract>() {}

            // Input and output must expose phi for phi monotonicity checks.
            fn assert_input_phi<T: $crate::witness::capability::HasPhi>() {}
            fn assert_output_phi<T: $crate::witness::capability::HasPhi>() {}

            let _ = assert_strict_lambda::<$contract>;
            let _ = assert_bound_contract::<$contract>;
            let _ = assert_input_phi::<<$contract as $crate::binding::BoundContract>::Input>;
            let _ = assert_output_phi::<<$contract as $crate::binding::BoundContract>::Output>;
        };

        #[cfg(test)]
        mod __lambda_property_witnesses {
            use super::*;
            use proptest::prelude::*;

            const _: () = {
                fn assert_input_arbitrary<T: proptest::arbitrary::Arbitrary>() {}
                fn assert_input_debug<T: core::fmt::Debug>() {}

                let _ =
                    assert_input_arbitrary::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_debug::<<$contract as $crate::binding::BoundContract>::Input>;
            };

            proptest! {
                #[test]
                fn phi_non_increasing(
                    input in any::<<$contract as $crate::binding::BoundContract>::Input>()
                ) {
                    let op = <$impl_ty>::default();

                    let output = <$impl_ty as $crate::traits::operators::LambdaOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                        <$contract as $crate::binding::BoundContract>::Output,
                    >>::apply(&op, &input)
                        .expect("contract requires total operator (lambda must not fail)");

                    let before = $crate::witness::capability::HasPhi::phi(&input);
                    let after = $crate::witness::capability::HasPhi::phi(&output);

                    prop_assert!(
                        after <= before,
                        "phi increased: before={:?}, after={:?}, input={:?}",
                        before,
                        after,
                        input
                    );
                }
            }
        }
    };
}

/// Generates test-time reducer property checks.
///
/// This macro does not emit persisted `ValidationWitness` artifacts.
#[macro_export]
macro_rules! generate_reducer_witnesses {
    ($impl_ty:ty, $contract:ty) => {
        // ─── Compile-time bound assertions ───────────────────────────────────
        const _: () = {
            fn assert_strict_reducer<C: $crate::descriptors::StrictReducerContract>() {}
            fn assert_bound_contract<C: $crate::binding::BoundContract>() {}

            let _ = assert_strict_reducer::<$contract>;
            let _ = assert_bound_contract::<$contract>;
        };

        #[cfg(test)]
        mod __reducer_property_witnesses {
            use super::*;
            use proptest::prelude::*;

            const _: () = {
                fn assert_input_arbitrary<T: proptest::arbitrary::Arbitrary>() {}
                fn assert_input_debug<T: core::fmt::Debug>() {}
                fn assert_input_eq<T: PartialEq>() {}

                let _ = assert_input_arbitrary::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_debug::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_eq::<<$contract as $crate::binding::BoundContract>::Input>;
            };

            proptest! {
                #[test]
                fn reducer_idempotence(
                    input in any::<<$contract as $crate::binding::BoundContract>::Input>()
                ) {
                    let op = <$impl_ty>::default();

                    let once = <$impl_ty as $crate::traits::operators::ReducerOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                    >>::apply(&op, &input)
                        .expect("contract requires total operator (reducer must not fail)");

                    let twice = <$impl_ty as $crate::traits::operators::ReducerOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                    >>::apply(&op, &once)
                        .expect("contract requires total operator (reducer must not fail on own output)");

                    prop_assert_eq!(
                        once,
                        twice,
                        "reducer is not idempotent: input={:?}",
                        input
                    );
                }
            }
        }
    };
}

/// Generates test-time transform determinism checks.
///
/// This macro does not emit persisted `ValidationWitness` artifacts.
#[macro_export]
macro_rules! generate_transform_determinism_witnesses {
    ($impl_ty:ty, $contract:ty) => {
        // ─── Compile-time bound assertions ───────────────────────────────────
        const _: () = {
            fn assert_strict_transform<C: $crate::descriptors::StrictTransformContract>() {}
            fn assert_bound_contract<C: $crate::binding::BoundContract>() {}

            let _ = assert_strict_transform::<$contract>;
            let _ = assert_bound_contract::<$contract>;
        };

        #[cfg(test)]
        mod __transform_property_witnesses {
            use super::*;
            use proptest::prelude::*;

            const _: () = {
                fn assert_input_arbitrary<T: proptest::arbitrary::Arbitrary>() {}
                fn assert_input_debug<T: core::fmt::Debug>() {}
                fn assert_input_eq<T: PartialEq>() {}

                let _ = assert_input_arbitrary::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_debug::<<$contract as $crate::binding::BoundContract>::Input>;
                let _ = assert_input_eq::<<$contract as $crate::binding::BoundContract>::Input>;
            };

            proptest! {
                #[test]
                fn transform_determinism(
                    input in any::<<$contract as $crate::binding::BoundContract>::Input>()
                ) {
                    let op = <$impl_ty>::default();

                    let a = <$impl_ty as $crate::traits::operators::TransformOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                    >>::apply(&op, &input)
                        .expect("contract requires total operator (transform must not fail)");

                    let b = <$impl_ty as $crate::traits::operators::TransformOp<
                        <$contract as $crate::binding::BoundContract>::Input,
                    >>::apply(&op, &input)
                        .expect("contract requires total operator (transform must not fail on repeat)");

                    prop_assert_eq!(
                        a,
                        b,
                        "transform is not deterministic: input={:?}",
                        input
                    );
                }
            }
        }
    };
}
