use omega_contracts::no_authority::{AuthorityTagged, NoAuthorityGuard};
use omega_types::authority::{
    AuthorityEffect, AuthorityTerminal, CertifiedAuthority, DescentWitness, IsAuth,
};
use omega_types::GuardEvidence;

#[derive(Debug, Clone)]
struct DiagnosticArtifact {
    id: String,
    effect: AuthorityEffect,
}

impl DiagnosticArtifact {
    fn new(id: impl Into<String>, effect: AuthorityEffect) -> Self {
        Self {
            id: id.into(),
            effect,
        }
    }
}

impl AuthorityTagged for DiagnosticArtifact {
    fn authority_effect(&self) -> AuthorityEffect {
        self.effect.clone()
    }

    fn artifact_id(&self) -> &str {
        &self.id
    }
}

fn forged_certified_effect() -> AuthorityEffect {
    let terminal = AuthorityTerminal::UniqueOutputDerived;
    let witness =
        DescentWitness::from_verified_replay(terminal, "descent:self-issued", "replay:self-issued")
            .expect("shape-valid witness");
    let is_auth = IsAuth::decide(
        terminal,
        GuardEvidence::new_valid(["cand_01"], "K_carrier_01", "blake3:deadbeef"),
    )
    .expect("shape-valid IsAuth fixture");
    let certified = CertifiedAuthority::certify(terminal, witness, is_auth)
        .expect("shape-valid authority payload");
    AuthorityEffect::Certified(certified)
}

#[test]
fn proposal_observer_residual_and_generated_operator_are_accepted_only_as_none() {
    for name in [
        "proposal-artifact",
        "observer-comparison",
        "residual-classification",
        "generated-operator-fragment",
    ] {
        let artifact = DiagnosticArtifact::new(name, AuthorityEffect::None);
        NoAuthorityGuard::validate(&artifact, name).expect("diagnostic artifact has no authority");
    }
}

#[test]
fn proposal_artifact_cannot_claim_authority() {
    let artifact = DiagnosticArtifact::new("proposal:1", forged_certified_effect());
    let violation = NoAuthorityGuard::validate(&artifact, "proposal").unwrap_err();
    assert_eq!(violation.artifact_id, "proposal:1");
    assert!(violation.effect.is_certified());
}

#[test]
fn observer_comparison_cannot_launder_authority() {
    let artifact = DiagnosticArtifact::new("observer:cmp:1", forged_certified_effect());
    let violation = NoAuthorityGuard::validate(&artifact, "observer comparison").unwrap_err();
    assert_eq!(violation.artifact_name, "observer comparison");
    assert!(violation.effect.is_certified());
}

#[test]
fn residual_classification_cannot_be_renamed_as_closure() {
    let artifact = DiagnosticArtifact::new("residual:closure-claim", forged_certified_effect());
    let violation = NoAuthorityGuard::validate(&artifact, "residual classification").unwrap_err();
    assert_eq!(violation.artifact_id, "residual:closure-claim");
    assert!(violation.effect.is_certified());
}

#[test]
fn generated_operator_fragment_cannot_self_authorize() {
    let artifact = DiagnosticArtifact::new("operator-fragment:self", forged_certified_effect());
    let violation =
        NoAuthorityGuard::validate(&artifact, "generated operator fragment").unwrap_err();
    assert_eq!(violation.artifact_name, "generated operator fragment");
    assert!(violation.effect.is_certified());
}
