//! 07_products — the 8 migrated product contracts load and pass validate_registry
//! (Certificate / CertificateApiInterface / LlmAdapter / Packetization / SymbolGame
//! validators + the validator-free interface roles).
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn products_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/07_core_products");
    let report = load_v1_dir(&dir).expect("dir readable");
    assert_eq!(report.loaded, 9, "expected 9 migrated product contracts");
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
