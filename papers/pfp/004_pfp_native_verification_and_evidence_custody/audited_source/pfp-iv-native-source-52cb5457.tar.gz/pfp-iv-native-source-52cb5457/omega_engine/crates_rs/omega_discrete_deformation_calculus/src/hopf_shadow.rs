//! --- Math Contract: Finite Hopf Shadow (degree-d clutching over the two-chart S²) ---
//!
//! Model: the base S² is presented as two charts (N, S) glued along a k-sampled
//! equator ℤ_k; a principal ℤ_k-bundle (the finite U(1) shadow) is presented by the
//! Čech transition cochain `g : ℤ_k → ℤ_k`, `g(i) = d·i mod k`, on the overlap.
//! The c₁-shadow is `d mod k`; `d = 1` is the Hopf shadow, `d ≢ 0` the lens family.
//!
//! Claims implemented (each the FINITE shadow of a bridged encyclopedia entry; no
//! continuum claim is made anywhere in this module):
//!
//! * **Section decision** — a global section exists iff `d ≡ 0 (mod k)`. In the
//!   two-chart model a chart gauge is a constant (the charts are the contractible
//!   pieces of the presentation — a DECLARED feature of the finite model), so `g` is
//!   a Čech coboundary iff `i ↦ d·i` is constant iff `d ≡ 0`. Finite shadow of the
//!   classification content bridged as ENC-1173; Lean target PL-GTOC-TUFT-1.
//! * **Verified refusal** — when `d ≢ 0` the gate returns the canonical
//!   `omega_types::authority::RefusalSource::NoLiftFound`, and it is a *verified*
//!   refusal: all k² constant gauge pairs are checked exhaustively (the same
//!   checked-not-assumed discipline as the omega_lifts Φ₁ gate).
//! * **Lift-to-total-space certificate** — on the total space E (charts × fiber)
//!   the pulled-back transition is killed by the tautological fiber-coordinate
//!   0-cochain `a(x, j) = j`: the certificate checks `a_N − a_S = π*g` pointwise
//!   over all k² points of the overlap torus. This is the DDA lift that absorbs the
//!   obstruction by adding the fiber dimension — the twisted-bundle DDA mechanism
//!   (extends the frustrated-cycle → filling-cell lift of the Simplicial Big Bang
//!   paper to bundles with nontrivial c₁-shadow).
//! * **ℤ₂×ℤ₃ factorization shadow** — pushforward along `ℤ_k → ℤ_m` (`m | k`): the
//!   reduced bundle is trivial iff `d ≡ 0 (mod m)`; the pair
//!   `(d mod 2, d mod 3) ≠ (0, 0)` blocks joint factorization. Finite shadow of the
//!   ℤ₆ non-factorability obstruction bridged as ENC-1174 (TUFT Thm 9); Lean target
//!   PL-GTOC-TUFT-2. The continuum-level caveats stay in ENC-1174; the finite
//!   statement asserts only what it checks.
//!
//! * **DDA-runtime wiring (ENC-1181)** — the mod-2 pushforward of the clutching
//!   model runs through the degree-tower runtime: the base two-chart segment
//!   diagnoses a frustrated reduced cocycle as a **StabilizedSurvivor** (a real
//!   cohomology class — Γ = 0 because two charts admit no triple overlaps), and
//!   the certified repair is the new runtime operation `CarrierLift`: pass to
//!   the total space, where the runtime's independent F₂ decision (exhaustive
//!   gauge enumeration for domains ≤ 20, Gaussian elimination above) re-verifies
//!   Exactness independently of this module's Čech arithmetic. Even `k` only —
//!   the reduction commutes with the wraparound for even `k` (for odd `k` there
//!   is no ℤ₂ quotient, and for `k ≥ 3` the carry genuinely breaks it; typed refusal
//!   `OddSampleCount` otherwise; counterexample `k = 3, d = 1` recorded there).
//!
//! Authority: none. Everything here is a diagnostic construction whose certificates
//! are finite equalities; nothing terminalizes, nothing mints. The linking-number
//! reading of `clutching_degree` is the classical interpretation recorded in the
//! bridge entries, not a computation this module claims.
//!
//! Provenance: TUFT B2 plan
//! (`papers/101_topological_unified_field_theory/00_intake_provenance_and_bridge_plan.md`
//! §B2); bridged entries ENC-1173/1174/1175; proof-ledger targets PL-GTOC-TUFT-1/2
//! (`research/encyclopedia/proof_ledgers/proof_ledger_20260716.md`).

use omega_types::authority::RefusalSource;
use serde::Serialize;

/// Errors of the finite Hopf-shadow model itself (not refusals).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum HopfShadowError {
    /// The equator must carry at least one sample (`k >= 1`).
    ZeroSampleCount,
    /// Factorization pushforward requires the modulus to divide the fiber order.
    ModulusNotDividing,
    /// The pointwise coboundary identity failed during certificate construction —
    /// unreachable by construction, kept typed so the certificate is only built
    /// when the identity actually held (no silent success).
    TrivializationIdentityFailed,
    /// The runtime bridge requires an even sample count: the mod-2 reduction
    /// commutes with the ℤ_k wraparound only when `2 | k` (the carry term `c·k`
    /// vanishes mod 2). For odd `k` the F₂ pullback-trivialization genuinely
    /// fails (counterexample `k = 3, d = 1`: summing the total-space gauge
    /// equations along the fiber over equator point `i` gives
    /// `Σa_N ⊕ Σa_S = k·g₂(i) = g₂(i)` for odd `k`; `g₂ = (0,1,0)` is
    /// non-constant, so `i = 0` vs `i = 1` forces `0 = 1` in F₂).
    OddSampleCount,
    /// The runtime bridge caps `k` (the total-space segment has `k²` rows).
    EquatorTooLarge,
    /// A degree-tower segment constructor rejected bridge-built data —
    /// unreachable by construction (dimensions are consistent by design),
    /// kept typed so no runtime rejection is silently swallowed.
    RuntimeSegmentRejected,
    /// The two mechanisms disagreed (Čech arithmetic vs the runtime's
    /// independent F₂ decision) — unreachable by the mirror theorems, kept typed as the
    /// honest cross-verifier guard.
    MechanismDisagreement,
    /// The total-space diagnosis was not Exact — unreachable for even `k` by
    /// the pullback-trivialization theorem (Lean: `pullback_trivializes`;
    /// mod-2 form requires `2 | k`), kept typed.
    LiftNotExactOnTotalSpace,
}

/// The finite degree-`d` clutching presentation of a principal ℤ_k-bundle over the
/// two-chart S². `d` is stored reduced mod `k`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct ClutchingShadow {
    k: u64,
    d: u64,
}

/// A gauge pair `(a_N, a_S)` of chart constants exhibiting `g` as a coboundary,
/// together with the exhaustive check receipt. Private fields + gated constructor:
/// a witness is only constructible by the decision procedure after verification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct SectionWitness {
    gauge_north: u64,
    gauge_south: u64,
    equator_points_checked: u64,
}

impl SectionWitness {
    pub fn gauge_north(&self) -> u64 {
        self.gauge_north
    }
    pub fn gauge_south(&self) -> u64 {
        self.gauge_south
    }
    /// Number of equator samples at which `a_N − a_S = g` was verified.
    pub fn equator_points_checked(&self) -> u64 {
        self.equator_points_checked
    }
}

/// Outcome of the flat-repair (global section / global gauge) decision.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum SectionDecision {
    /// A verified section witness (only when `d ≡ 0 mod k`).
    Found(SectionWitness),
    /// Verified refusal: no constant gauge pair trivializes `g`. Carries the
    /// canonical refusal source and the exhaustiveness receipt (`k²` pairs).
    Refused {
        source: RefusalSource,
        gauge_pairs_checked: u64,
    },
}

/// Certificate that the pulled-back transition trivializes on the total space:
/// `a_N(i, j) − a_S(i, j) ≡ π*g(i) (mod k)` at every point of the overlap torus.
/// Private fields + gated constructor: only the exhaustive verifier builds one.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct PullbackTrivialization {
    total_points_checked: u64,
}

impl PullbackTrivialization {
    /// Number of `(i, j)` points of the overlap torus at which the coboundary
    /// identity was verified (`k²`).
    pub fn total_points_checked(&self) -> u64 {
        self.total_points_checked
    }
}

/// The ℤ₆ = ℤ₂ × ℤ₃ factorization shadow: the reduced obstruction pair and the
/// joint-factorization verdict.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct Z6Shadow {
    obstruction_mod2: u64,
    obstruction_mod3: u64,
    joint_factorization_blocked: bool,
}

impl Z6Shadow {
    pub fn obstruction_mod2(&self) -> u64 {
        self.obstruction_mod2
    }
    pub fn obstruction_mod3(&self) -> u64 {
        self.obstruction_mod3
    }
    /// `true` iff `(d mod 2, d mod 3) ≠ (0, 0)` — joint factorization blocked.
    pub fn joint_factorization_blocked(&self) -> bool {
        self.joint_factorization_blocked
    }
}

fn gcd(mut a: u64, mut b: u64) -> u64 {
    while b != 0 {
        let t = a % b;
        a = b;
        b = t;
    }
    a
}

impl ClutchingShadow {
    /// Build the degree-`d` clutching shadow over a `k`-sampled equator.
    pub fn new(k: u64, d: u64) -> Result<Self, HopfShadowError> {
        match k {
            0 => Err(HopfShadowError::ZeroSampleCount),
            _ => Ok(Self { k, d: d % k }),
        }
    }

    pub fn fiber_order(&self) -> u64 {
        self.k
    }

    /// The c₁-shadow: the clutching degree reduced mod `k`. The classical
    /// linking-number reading of this quantity lives in the bridge entries
    /// (ENC-1173/1174), not in this module's claims.
    pub fn clutching_degree(&self) -> u64 {
        self.d
    }

    /// The Čech transition cochain on the overlap: `g(i) = d·i mod k`.
    /// Computed in `u128` so the product is exact for every `k` — a `u64`
    /// `wrapping_mul` silently returns wrong residues once `k > 2^32`.
    pub fn transition(&self, i: u64) -> u64 {
        ((u128::from(self.d) * u128::from(i % self.k)) % u128::from(self.k)) as u64
    }

    /// Decide flat repair: does a global section (equivalently, a constant gauge
    /// pair trivializing `g`) exist? Exhaustive over all `k²` constant gauge pairs,
    /// so the refusal is verified, never assumed.
    pub fn decide_section(&self) -> SectionDecision {
        let k = self.k;
        let mut pairs_checked: u64 = 0;
        for a_n in 0..k {
            for a_s in 0..k {
                pairs_checked += 1;
                let delta = ((u128::from(a_n) + u128::from(k - a_s)) % u128::from(k)) as u64;
                let trivializes = (0..k).all(|i| delta == self.transition(i));
                if trivializes {
                    return SectionDecision::Found(SectionWitness {
                        gauge_north: a_n,
                        gauge_south: a_s,
                        equator_points_checked: k,
                    });
                }
            }
        }
        SectionDecision::Refused {
            source: RefusalSource::NoLiftFound,
            gauge_pairs_checked: pairs_checked,
        }
    }

    /// The DDA lift: pass to the total space and verify that the pulled-back
    /// transition is the coboundary of the tautological fiber coordinate,
    /// `a_N(i, j) = j`, `a_S(i, j) = j − d·i`, checked at all `k²` overlap points.
    pub fn lift_to_total_space(&self) -> Result<PullbackTrivialization, HopfShadowError> {
        let k = self.k;
        let mut checked: u64 = 0;
        for i in 0..k {
            for j in 0..k {
                let a_north = j;
                let pullback_transition = self.transition(i);
                let a_south =
                    ((u128::from(j) + u128::from(k - pullback_transition)) % u128::from(k)) as u64;
                if ((u128::from(a_north) + u128::from(k - a_south)) % u128::from(k)) as u64
                    != pullback_transition
                {
                    // Unreachable by construction; kept as an honest guard so the
                    // certificate is only built when the identity actually held.
                    return Err(HopfShadowError::TrivializationIdentityFailed);
                }
                checked += 1;
            }
        }
        Ok(PullbackTrivialization {
            total_points_checked: checked,
        })
    }

    /// Pushforward along `ℤ_k → ℤ_m` for `m | k`: the reduced bundle is trivial iff
    /// `d ≡ 0 (mod m)`.
    pub fn factors_through(&self, m: u64) -> Result<bool, HopfShadowError> {
        match (m, self.k % m.max(1)) {
            (0, _) => Err(HopfShadowError::ModulusNotDividing),
            (_, 0) => Ok(self.d.is_multiple_of(m)),
            _ => Err(HopfShadowError::ModulusNotDividing),
        }
    }

    /// The ℤ₆ shadow (requires `6 | k`): the reduced obstruction pair
    /// `(d mod 2, d mod 3)` and the joint-factorization verdict.
    pub fn z6_shadow(&self) -> Result<Z6Shadow, HopfShadowError> {
        match self.k % 6 {
            0 => {
                let o2 = self.d % 2;
                let o3 = self.d % 3;
                Ok(Z6Shadow {
                    obstruction_mod2: o2,
                    obstruction_mod3: o3,
                    joint_factorization_blocked: (o2, o3) != (0, 0),
                })
            }
            _ => Err(HopfShadowError::ModulusNotDividing),
        }
    }

    /// `m | gcd(d, k)` — the divisor-collapse form of `factors_through` (they agree
    /// for every `m | k`; tested).
    pub fn divides_reduction_locus(&self, m: u64) -> bool {
        m != 0 && gcd(self.d, self.k).is_multiple_of(m)
    }
}

// --- DDA-runtime wiring (ENC-1181 bridge) -------------------------------------
//
// The degree-tower runtime (`degree_tower.rs`, ENC-1181) works over F₂. The F₂
// face of the clutching model is its mod-2 pushforward — the ℤ₂ factor of the
// ℤ₆ shadow (Lean: `reduced_section_iff_dvd` at m = 2). Load-bearing caveat:
// the reduction commutes with the ℤ_k wraparound ONLY for even k (the carry
// term c·k vanishes mod 2); the bridge therefore refuses odd k with a typed
// error rather than producing a silently-wrong F₂ model.
//
// The base two-chart Čech segment has NO next-degree cells (two charts ⇒ no
// triple overlaps ⇒ C² = 0), so a frustrated reduced cocycle diagnoses as
// **StabilizedSurvivor** (Φ > 0, Γ = 0) — a genuine cohomology class, exactly
// the case `DetectThenRepairPacket` cannot repair (its update stays inside the
// carrier). The twisted lift is the new runtime operation: `CarrierLift` — the
// repair passes to the total space, where the runtime's independent F₂
// decision (exhaustive gauge enumeration for domains ≤ 20, Gaussian
// elimination above) re-verifies that the pulled-back class is Exact.
// Two independent verifiers, one verdict: Čech arithmetic here, linear algebra
// in the runtime.

use crate::degree_tower::{
    BinaryCochainSegment, BinaryLinearMap, DdaOperationKind, DegreeDiagnostic, DegreeTowerError,
    DegreeTrichotomy,
};

/// Cap for the runtime bridge (`k²` rows in the total-space segment).
pub const RUNTIME_BRIDGE_MAX_K: u64 = 32;

/// Sealed packet certifying one twisted-bundle lift through the DDA runtime:
/// base survivor detected (and cross-checked against the ℤ_k refusal), total
/// space Exact per the runtime's independent F₂ decision. Private fields + gated
/// constructor (`verify_twisted_lift`), `Serialize` without `Deserialize`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct TwistedLiftPacket {
    base: DegreeDiagnostic,
    total: DegreeDiagnostic,
    refusal_at_base: RefusalSource,
    base_residual_dim: usize,
    total_residual_dim: usize,
    operations: [DdaOperationKind; 2],
}

impl TwistedLiftPacket {
    pub fn base(&self) -> &DegreeDiagnostic {
        &self.base
    }
    pub fn total(&self) -> &DegreeDiagnostic {
        &self.total
    }
    pub fn refusal_at_base(&self) -> RefusalSource {
        self.refusal_at_base
    }
    pub fn base_residual_dim(&self) -> usize {
        self.base_residual_dim
    }
    pub fn total_residual_dim(&self) -> usize {
        self.total_residual_dim
    }
    pub fn operations(&self) -> [DdaOperationKind; 2] {
        self.operations
    }
}

/// Outcome of running the clutching shadow through the DDA runtime at mod 2.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub enum TwistedLiftOutcome {
    /// The reduced (mod-2) transition is already a coboundary — `d` even; a
    /// flat F₂ gauge exists and no lift is needed at this reduction.
    FlatMod2GaugeExists { base: DegreeDiagnostic },
    /// The reduced transition is a genuine survivor at the base; the carrier
    /// lift absorbed it on the total space. Certified packet enclosed.
    Lifted(TwistedLiftPacket),
}

impl ClutchingShadow {
    fn require_bridge_k(&self) -> Result<usize, HopfShadowError> {
        if !self.k.is_multiple_of(2) {
            return Err(HopfShadowError::OddSampleCount);
        }
        if self.k > RUNTIME_BRIDGE_MAX_K {
            return Err(HopfShadowError::EquatorTooLarge);
        }
        Ok(self.k as usize)
    }

    /// The base two-chart Čech segment over F₂: `δ⁰ : F₂² → F₂^k` sends the
    /// chart-constant pair `(a_N, a_S)` to the constant vector `a_N ⊕ a_S`;
    /// there is no next degree (two charts ⇒ no triple overlaps ⇒ C² = 0).
    pub fn base_mod2_segment(&self) -> Result<BinaryCochainSegment, HopfShadowError> {
        let k = self.require_bridge_k()?;
        let rows = vec![vec![true, true]; k];
        let previous = BinaryLinearMap::from_rows(2, rows)
            .map_err(|_| HopfShadowError::RuntimeSegmentRejected)?;
        let next = BinaryLinearMap::zero(k, 0);
        BinaryCochainSegment::new(1, previous, next)
            .map_err(|_| HopfShadowError::RuntimeSegmentRejected)
    }

    /// The reduced (mod-2) transition cocycle on the equator.
    pub fn reduced_mod2_residual(&self) -> Result<Vec<bool>, HopfShadowError> {
        let k = self.require_bridge_k()?;
        Ok((0..k).map(|i| self.transition(i as u64) % 2 == 1).collect())
    }

    /// The total-space Čech segment over F₂: charts of E are the `2k` fiber
    /// components; `δ⁰_E : F₂^{2k} → F₂^{k²}` evaluates, at overlap point
    /// (degree numbering follows the crate's residual-cell-dimension
    /// convention: base = k arcs (1-cells, degree 1), total = k² torus
    /// patches (2-cells, degree 2), matching `simplex_boundary_segment`);
    /// `(i, j)`, the N-component gauge at `j` XOR the S-component gauge at
    /// `(j − d·i) mod k`.
    pub fn total_space_mod2_segment(&self) -> Result<BinaryCochainSegment, HopfShadowError> {
        let k = self.require_bridge_k()?;
        let mut rows = Vec::with_capacity(k * k);
        for i in 0..k {
            let g = self.transition(i as u64) as usize;
            for j in 0..k {
                let mut row = vec![false; 2 * k];
                row[j] = true;
                row[k + ((j + k - g) % k)] = true;
                rows.push(row);
            }
        }
        let previous = BinaryLinearMap::from_rows(2 * k, rows)
            .map_err(|_| HopfShadowError::RuntimeSegmentRejected)?;
        let next = BinaryLinearMap::zero(k * k, 0);
        BinaryCochainSegment::new(2, previous, next)
            .map_err(|_| HopfShadowError::RuntimeSegmentRejected)
    }

    /// The pulled-back reduced cocycle on the total space: value at `(i, j)`
    /// is `g₂(i)` (constant along the fiber coordinate).
    pub fn pulled_back_mod2_residual(&self) -> Result<Vec<bool>, HopfShadowError> {
        let k = self.require_bridge_k()?;
        let mut out = Vec::with_capacity(k * k);
        for i in 0..k {
            let bit = self.transition(i as u64) % 2 == 1;
            out.extend(std::iter::repeat_n(bit, k));
        }
        Ok(out)
    }

    /// Run the clutching shadow through the DDA runtime at mod 2: diagnose the
    /// base (the runtime's independent F₂ decision), cross-check against this module's
    /// own decisions (`factors_through(2)`, `decide_section`), and — when the
    /// base is a survivor — certify the `CarrierLift` on the total space.
    pub fn verify_twisted_lift(&self) -> Result<TwistedLiftOutcome, HopfShadowError> {
        let base_segment = self.base_mod2_segment()?;
        let base_residual = self.reduced_mod2_residual()?;
        let base = base_segment
            .diagnose(&base_residual)
            .map_err(|_| HopfShadowError::RuntimeSegmentRejected)?;

        let mod2_factors = self
            .factors_through(2)
            .map_err(|_| HopfShadowError::RuntimeSegmentRejected)?;

        match base.classification {
            DegreeTrichotomy::Exact => {
                // Runtime says flat gauge exists ⟺ our arithmetic says 2 | d.
                match mod2_factors {
                    true => Ok(TwistedLiftOutcome::FlatMod2GaugeExists { base }),
                    false => Err(HopfShadowError::MechanismDisagreement),
                }
            }
            DegreeTrichotomy::StabilizedSurvivor => {
                // A genuine base class: our arithmetic must agree (d odd), and
                // the full Z_k decision must refuse (odd d ⇒ d ≢ 0 mod even k).
                let observed_source = match self.decide_section() {
                    SectionDecision::Refused { source, .. } => Some(source),
                    SectionDecision::Found(_) => None,
                };
                let Some(observed_source) = observed_source else {
                    return Err(HopfShadowError::MechanismDisagreement);
                };
                if mod2_factors {
                    return Err(HopfShadowError::MechanismDisagreement);
                }
                let total_segment = self.total_space_mod2_segment()?;
                let total_residual = self.pulled_back_mod2_residual()?;
                let total = total_segment
                    .diagnose(&total_residual)
                    .map_err(|e| match e {
                        // At 2k > MAX_EXHAUSTIVE_DOMAIN_DIM this arises only when
                        // the residual is NOT in the image (the in-image fast path
                        // returns 0) — i.e. exactly a non-Exact total space.
                        DegreeTowerError::ExhaustiveSearchTooLarge { .. } => {
                            HopfShadowError::LiftNotExactOnTotalSpace
                        }
                        _ => HopfShadowError::RuntimeSegmentRejected,
                    })?;
                if total.classification != DegreeTrichotomy::Exact || total.phi != 0 {
                    return Err(HopfShadowError::LiftNotExactOnTotalSpace);
                }
                Ok(TwistedLiftOutcome::Lifted(TwistedLiftPacket {
                    base,
                    total,
                    refusal_at_base: observed_source,
                    base_residual_dim: base_segment.residual_dim(),
                    total_residual_dim: total_segment.residual_dim(),
                    operations: [
                        DdaOperationKind::SuccessorProbe,
                        DdaOperationKind::CarrierLift,
                    ],
                }))
            }
            DegreeTrichotomy::Open => {
                // Impossible: the base segment has no next degree, so Γ = 0
                // always — Open (Γ > 0) cannot occur. Typed, not asserted.
                Err(HopfShadowError::MechanismDisagreement)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Section exists iff d ≡ 0 (mod k) — exhaustive over k ≤ 12, all d.
    /// Both branches inspect payloads: the witness must verify the gauge equation
    /// receipt, the refusal must be the canonical NoLiftFound with the full k²
    /// exhaustiveness receipt.
    #[test]
    fn section_iff_degree_zero_exhaustive() {
        for k in 1..=12u64 {
            for d in 0..k {
                let shadow = ClutchingShadow::new(k, d).expect("k >= 1 fixture");
                match (d, shadow.decide_section()) {
                    (0, SectionDecision::Found(w)) => {
                        assert_eq!(w.equator_points_checked(), k, "k={k}");
                        // The found gauge really trivializes g: re-verify externally.
                        let (an, as_) = (w.gauge_north(), w.gauge_south());
                        assert!(
                            (0..k).all(|i| (an + k - as_) % k == shadow.transition(i)),
                            "witness gauge fails externally at k={k}"
                        );
                    }
                    (0, other) => panic!("d=0 must yield a section at k={k}, got {other:?}"),
                    (
                        _,
                        SectionDecision::Refused {
                            source,
                            gauge_pairs_checked,
                        },
                    ) => {
                        assert_eq!(source, RefusalSource::NoLiftFound, "k={k} d={d}");
                        assert_eq!(gauge_pairs_checked, k * k, "k={k} d={d}");
                    }
                    (_, SectionDecision::Found(w)) => {
                        panic!("d={d} k={k} must refuse, found spurious witness {w:?}")
                    }
                }
            }
        }
    }

    /// The Hopf shadow (d = 1): flat repair refused, and the DDA lift to the total
    /// space absorbs the obstruction with a full k² certificate.
    #[test]
    fn hopf_d1_refused_then_lift_absorbs() {
        let shadow = ClutchingShadow::new(12, 1).expect("fixture");
        match shadow.decide_section() {
            SectionDecision::Refused {
                source,
                gauge_pairs_checked,
            } => {
                assert_eq!(source, RefusalSource::NoLiftFound);
                assert_eq!(gauge_pairs_checked, 144);
            }
            SectionDecision::Found(w) => panic!("Hopf shadow must refuse flat repair: {w:?}"),
        }
        let cert = shadow
            .lift_to_total_space()
            .expect("pullback must trivialize");
        assert_eq!(cert.total_points_checked(), 144);
    }

    /// The pullback ALWAYS trivializes on the total space — for every (k, d).
    #[test]
    fn pullback_trivializes_for_all_small_models() {
        for k in 1..=8u64 {
            for d in 0..k {
                let shadow = ClutchingShadow::new(k, d).expect("fixture");
                let cert = shadow
                    .lift_to_total_space()
                    .unwrap_or_else(|e| panic!("lift failed at k={k} d={d}: {e:?}"));
                assert_eq!(cert.total_points_checked(), k * k, "k={k} d={d}");
            }
        }
    }

    /// The ℤ₆ shadow blocks joint factorization exactly when (d mod 2, d mod 3) ≠ (0,0).
    #[test]
    fn z6_shadow_blocking_table() {
        let expect = [
            (0u64, (0u64, 0u64), false),
            (1, (1, 1), true),
            (2, (0, 2), true),
            (3, (1, 0), true),
            (4, (0, 1), true),
            (5, (1, 2), true),
        ];
        for (d, (o2, o3), blocked) in expect {
            let shadow = ClutchingShadow::new(6, d).expect("fixture");
            let z6 = shadow.z6_shadow().expect("6 | 6");
            assert_eq!(
                (z6.obstruction_mod2(), z6.obstruction_mod3()),
                (o2, o3),
                "d={d}"
            );
            assert_eq!(z6.joint_factorization_blocked(), blocked, "d={d}");
        }
    }

    /// factors_through(m) agrees with the divisor form m | gcd(d, k) for all m | k,
    /// and the reduced bundle is trivial exactly when m | d.
    #[test]
    fn factorization_agrees_with_gcd_form() {
        let k = 12u64;
        for d in 0..k {
            let shadow = ClutchingShadow::new(k, d).expect("fixture");
            for m in [1u64, 2, 3, 4, 6, 12] {
                let through = shadow.factors_through(m).expect("m | k fixture");
                assert_eq!(through, d % m == 0, "k={k} d={d} m={m}");
                assert_eq!(
                    through,
                    shadow.divides_reduction_locus(m),
                    "k={k} d={d} m={m}"
                );
            }
        }
    }

    /// Model-level cross-check: factors_through's arithmetic (d ≡ 0 mod m)
    /// agrees with an exhaustive constant-gauge search over the REDUCED model —
    /// the ℤ_m-valued transition ḡ(i) = g(i) mod m over the same k-sampled equator.
    #[test]
    fn factorization_matches_reduced_model_search() {
        for k in 1..=12u64 {
            for d in 0..k {
                let shadow = ClutchingShadow::new(k, d).expect("fixture");
                for m in (1..=k).filter(|m| k % m == 0) {
                    let claimed = shadow.factors_through(m).expect("m | k");
                    let searched = (0..m).any(|a_n| {
                        (0..m).any(|a_s| {
                            (0..k).all(|i| (a_n + m - a_s) % m == shadow.transition(i) % m)
                        })
                    });
                    assert_eq!(claimed, searched, "k={k} d={d} m={m}");
                }
            }
        }
    }

    /// Failure paths: k = 0 is rejected; non-dividing moduli are rejected with the
    /// exact error variant (never a silent false).
    #[test]
    fn failure_paths_are_typed() {
        assert_eq!(
            ClutchingShadow::new(0, 3).unwrap_err(),
            HopfShadowError::ZeroSampleCount
        );
        let shadow = ClutchingShadow::new(10, 3).expect("fixture");
        assert_eq!(
            shadow.factors_through(4).unwrap_err(),
            HopfShadowError::ModulusNotDividing
        );
        assert_eq!(
            shadow.factors_through(0).unwrap_err(),
            HopfShadowError::ModulusNotDividing
        );
        assert_eq!(
            shadow.z6_shadow().unwrap_err(),
            HopfShadowError::ModulusNotDividing
        );
    }

    /// Runtime bridge, Hopf instance (k = 6, d = 1): the base diagnoses as a
    /// StabilizedSurvivor with the exact Φ = k/2 (the runtime's independent
    /// F₂ decision), the outcome is a certified CarrierLift, and the total
    /// space is Exact with Φ = 0 over all k² points.
    #[test]
    fn runtime_bridge_hopf_k6_d1_survivor_then_carrier_lift() {
        let shadow = ClutchingShadow::new(6, 1).expect("fixture");
        match shadow.verify_twisted_lift().expect("bridge runs") {
            TwistedLiftOutcome::Lifted(packet) => {
                assert_eq!(
                    packet.base().classification,
                    DegreeTrichotomy::StabilizedSurvivor
                );
                assert_eq!(packet.base().phi, 3, "Φ = k/2 for odd d");
                assert_eq!(packet.base().gamma, 0, "two charts ⇒ no next degree");
                assert_eq!(packet.total().classification, DegreeTrichotomy::Exact);
                assert_eq!(packet.total().phi, 0);
                assert_eq!(packet.refusal_at_base(), RefusalSource::NoLiftFound);
                assert_eq!(packet.base_residual_dim(), 6);
                assert_eq!(packet.total_residual_dim(), 36);
                assert_eq!(
                    packet.operations(),
                    [
                        DdaOperationKind::SuccessorProbe,
                        DdaOperationKind::CarrierLift
                    ]
                );
            }
            other => panic!("Hopf shadow must lift, got {other:?}"),
        }
    }

    /// Runtime bridge, even degrees: the reduced transition is already a
    /// coboundary — flat F₂ gauge, no lift, base Exact.
    #[test]
    fn runtime_bridge_even_degree_flat_gauge() {
        for d in [0u64, 2, 4] {
            let shadow = ClutchingShadow::new(6, d).expect("fixture");
            match shadow.verify_twisted_lift().expect("bridge runs") {
                TwistedLiftOutcome::FlatMod2GaugeExists { base } => {
                    assert_eq!(base.classification, DegreeTrichotomy::Exact, "d={d}");
                    assert_eq!(base.phi, 0, "d={d}");
                }
                other => panic!("even d={d} must be flat at mod 2, got {other:?}"),
            }
        }
    }

    /// Cross-mechanism agreement sweep: for all even k ≤ 8 and all d, the
    /// runtime outcome is Lifted ⟺ this module's factors_through(2) is false
    /// ⟺ d is odd; every lift's total space is Exact. Two independent
    /// verifiers (Čech arithmetic vs the runtime's F₂ decision), one verdict.
    #[test]
    fn runtime_bridge_agreement_sweep() {
        for k in [2u64, 4, 6, 8] {
            for d in 0..k {
                let shadow = ClutchingShadow::new(k, d).expect("fixture");
                let outcome = shadow.verify_twisted_lift().expect("bridge runs");
                let mod2_ok = shadow.factors_through(2).expect("2 | k");
                match (outcome, mod2_ok, d % 2) {
                    (TwistedLiftOutcome::FlatMod2GaugeExists { .. }, true, 0) => {}
                    (TwistedLiftOutcome::Lifted(p), false, 1) => {
                        assert_eq!(p.total().classification, DegreeTrichotomy::Exact, "k={k} d={d}");
                        assert_eq!(p.base().phi as u64, k / 2, "k={k} d={d}");
                    }
                    (outcome, mod2_ok, parity) => panic!(
                        "mechanism disagreement at k={k} d={d}: {outcome:?} vs factors_through(2)={mod2_ok}, parity={parity}"
                    ),
                }
            }
        }
    }

    /// Cap-regime coverage (k = 32: total domain 64 > MAX_EXHAUSTIVE_DOMAIN_DIM,
    /// so Exactness rides the in-image Gaussian-elimination fast path): the
    /// Hopf-parity lift still certifies, and the even case stays flat.
    #[test]
    fn runtime_bridge_cap_regime_k32() {
        let shadow = ClutchingShadow::new(32, 1).expect("fixture");
        match shadow
            .verify_twisted_lift()
            .expect("bridge runs at the cap")
        {
            TwistedLiftOutcome::Lifted(packet) => {
                assert_eq!(packet.base().phi, 16, "Φ = k/2 at k = 32");
                assert_eq!(packet.total().classification, DegreeTrichotomy::Exact);
                assert_eq!(packet.total().phi, 0);
                assert_eq!(packet.total_residual_dim(), 1024);
            }
            other => panic!("k=32 d=1 must lift, got {other:?}"),
        }
        let even = ClutchingShadow::new(32, 2).expect("fixture");
        assert!(matches!(
            even.verify_twisted_lift().expect("bridge runs"),
            TwistedLiftOutcome::FlatMod2GaugeExists { .. }
        ));
    }

    /// The bridge refuses odd k with the typed carry-failure error (the mod-2
    /// reduction does not commute with the wraparound; k = 3, d = 1 is the
    /// recorded counterexample) and oversized k with the cap error.
    #[test]
    fn runtime_bridge_failure_paths_are_typed() {
        for k in [1u64, 3, 5, 7] {
            let shadow = ClutchingShadow::new(k, 1 % k.max(1)).expect("fixture");
            assert_eq!(
                shadow.verify_twisted_lift().unwrap_err(),
                HopfShadowError::OddSampleCount,
                "k={k}"
            );
        }
        let shadow = ClutchingShadow::new(34, 1).expect("fixture");
        assert_eq!(
            shadow.verify_twisted_lift().unwrap_err(),
            HopfShadowError::EquatorTooLarge
        );
    }

    /// Degree normalization: d is stored mod k, so d = k behaves as the trivial
    /// bundle (section found), matching the classification.
    #[test]
    fn degree_normalizes_mod_k() {
        let shadow = ClutchingShadow::new(7, 7).expect("fixture");
        assert_eq!(shadow.clutching_degree(), 0);
        assert!(matches!(shadow.decide_section(), SectionDecision::Found(_)));
    }
}
