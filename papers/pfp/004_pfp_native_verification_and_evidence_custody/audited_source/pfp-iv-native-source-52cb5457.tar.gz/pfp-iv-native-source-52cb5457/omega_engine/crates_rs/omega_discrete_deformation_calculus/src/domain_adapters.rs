//! Built-in Algorithm Prime 000 domain adapters.
//!
//! Each adapter fills declaration slots for one programme surface and is run
//! through [`crate::oeprmalg0::run_oeprmalg0`] so every domain emits the same
//! DDA letter-tape work product (H-O1).
//!
//! Step-9 lift candidates carry nine bits + `PaperER003.LicensedLiftCertificate`
//! materials; admission is gated by H-O3 [`crate::licensed_lift_gate`].

use crate::cp2_shadow::{Cp2ShellOutcome, Cp2TransitionFamily};
use crate::degree_tower::DegreeDiagnostic;
use crate::licensed_lift_gate::{
    certificate_from_labels, NineUpLiftBits, PaperEr003LiftCertificate,
};
use crate::oeprmalg0::{
    CochainWindow, DeclarationFill, DefectBranch, DomainAdapter, EvidenceProvenance, LiftProposal,
    PrimeDomain,
};

/// Fully licensed nine-bit packet (all true, authority preserved).
fn licensed_nine() -> NineUpLiftBits {
    NineUpLiftBits::all_true()
}

/// Certificate labels for a residual → resolve_* operator lift.
fn resolve_cert(residual: &str, operator: &str) -> PaperEr003LiftCertificate {
    certificate_from_labels(
        residual,
        &format!("mss1:{residual}"),
        operator,
        true,  // residual_reduced
        true,  // replay_checked
        true,  // closure_preserved
        false, // policy_violation
    )
}

/// Generic MSS-0 genesis: one witnessed δ₀, justified path-graph cochain, Φ₁>0 Γ₂=0.
pub struct GenericMss0Adapter;

impl DomainAdapter for GenericMss0Adapter {
    fn domain(&self) -> PrimeDomain {
        PrimeDomain::Generic
    }

    fn declaration(&self) -> DeclarationFill {
        DeclarationFill {
            carrier: Some("finite_token_set:{delta_0}".into()),
            primitive_difference: Some("delta_0".into()),
            zero_rel: Some("exact_collapse_of_declared_sameness_only".into()),
            observer: Some("unit_weight_l1_profile".into()),
            witnesses: vec!["replay:exhaust_trace".into(), "hash:toy".into()],
        }
    }

    fn justify_cochain(&self) -> bool {
        true
    }

    fn cochain_window(&self) -> Option<CochainWindow> {
        Some(CochainWindow {
            dim_c0: 2,
            dim_c1: 1,
            dim_c2: 0,
            square_zero: true,
            l1_defect_mass: 0,
        })
    }

    fn residual_masses(&self) -> (u64, u64) {
        (1, 0)
    }

    fn lift_proposal(&self, branch: DefectBranch) -> LiftProposal {
        match branch {
            DefectBranch::StabilizedSurvivor => LiftProposal::Candidate {
                generators: vec!["resolve_delta_0".into()],
                nine_bits: licensed_nine(),
                certificate: resolve_cert("delta_0", "resolve_delta_0"),
            },
            DefectBranch::Open => LiftProposal::SameLevelRepair,
            _ => LiftProposal::SkipClosed,
        }
    }

    fn literature_note(&self) -> Option<String> {
        Some("FOC Anomalon boundary; GOMC LGGR; MSS reconstruction spine".into())
    }

    fn residual_family_label(&self) -> String {
        "generic:anomalon_delta0".into()
    }
}

/// MUB wall scaffold — open residual; no finite licensed lift.
pub struct MubWallAdapter;

impl DomainAdapter for MubWallAdapter {
    fn domain(&self) -> PrimeDomain {
        PrimeDomain::Mub
    }

    fn declaration(&self) -> DeclarationFill {
        DeclarationFill {
            carrier: Some(
                "Declared finite product triple + candidate fourth vector search in C^d".into(),
            ),
            primitive_difference: Some(
                "Non-sameness of exact MU ZeroRel vs candidate stationarity residual".into(),
            ),
            zero_rel: Some(
                "Exact |<e_i,v>|^2 = 1/d for fixed vectors (not float tolerance as theorem)".into(),
            ),
            observer: Some("Declared wall functional / chart — not View-from-Nowhere".into()),
            witnesses: vec![
                "crates/mub share packs".into(),
                "public-export receipts".into(),
            ],
        }
    }

    fn justify_cochain(&self) -> bool {
        false
    }

    fn cochain_window(&self) -> Option<CochainWindow> {
        None
    }

    fn residual_masses(&self) -> (u64, u64) {
        (1, 0)
    }

    fn lift_proposal(&self, _: DefectBranch) -> LiftProposal {
        LiftProposal::OracleGap {
            note: "Global MUB(6)=3 remains OPEN; no finite lift admitted".into(),
        }
    }

    fn literature_note(&self) -> Option<String> {
        Some("ONLY after terminal — Zauner/Renes etc. do not mint theorem".into())
    }

    fn residual_family_label(&self) -> String {
        "mub:wall_open_mub6".into()
    }
}

/// FSP Channel A scaffold.
pub struct FspChannelAAdapter;

impl DomainAdapter for FspChannelAAdapter {
    fn domain(&self) -> PrimeDomain {
        PrimeDomain::Fsp
    }

    fn declaration(&self) -> DeclarationFill {
        DeclarationFill {
            carrier: Some("Channel A parity: F2^V, F2^E, F2^F finite graph".into()),
            primitive_difference: Some(
                "Packet-local delta on declared finite sign configurations".into(),
            ),
            zero_rel: Some("LocalRepairRel / CochainZeroRel as declared in Paper 042".into()),
            observer: Some("Declared observer O with typed readout".into()),
            witnesses: vec![
                "Lean PaperQF partial kernels".into(),
                "replay commands".into(),
            ],
        }
    }

    fn justify_cochain(&self) -> bool {
        true
    }

    fn cochain_window(&self) -> Option<CochainWindow> {
        Some(CochainWindow {
            dim_c0: 3,
            dim_c1: 3,
            dim_c2: 1,
            square_zero: true,
            l1_defect_mass: 0,
        })
    }

    fn residual_masses(&self) -> (u64, u64) {
        (1, 1)
    }

    fn lift_proposal(&self, branch: DefectBranch) -> LiftProposal {
        match branch {
            DefectBranch::Open => LiftProposal::SameLevelRepair,
            DefectBranch::StabilizedSurvivor => LiftProposal::OracleGap {
                note: "general FSP not solved".into(),
            },
            _ => LiftProposal::SkipClosed,
        }
    }

    fn literature_note(&self) -> Option<String> {
        Some("ONLY after terminal — Troyer-Wiese 2005 NP-hardness remains".into())
    }

    fn residual_family_label(&self) -> String {
        "fsp:channel_a_sign_class".into()
    }
}

/// CODA residual-firewall adapter.
pub struct CodaResidualAdapter;

impl DomainAdapter for CodaResidualAdapter {
    fn domain(&self) -> PrimeDomain {
        PrimeDomain::Coda
    }

    fn declaration(&self) -> DeclarationFill {
        DeclarationFill {
            carrier: Some("GTOC finite cover packet / residual ledger host".into()),
            primitive_difference: Some(
                "carrier-Structure vs residual-Structure non-sameness".into(),
            ),
            zero_rel: Some("declared exact residual collapse under FOC repair class".into()),
            observer: Some("declared GTOC ℓ¹ unit-weight observer".into()),
            witnesses: vec![
                "PaperER003 residual terminalizer contracts".into(),
                "encyclopedia residual ledgers".into(),
            ],
        }
    }

    fn justify_cochain(&self) -> bool {
        true
    }

    fn cochain_window(&self) -> Option<CochainWindow> {
        Some(CochainWindow {
            dim_c0: 2,
            dim_c1: 1,
            dim_c2: 0,
            square_zero: true,
            l1_defect_mass: 0,
        })
    }

    fn residual_masses(&self) -> (u64, u64) {
        (1, 0)
    }

    fn lift_proposal(&self, branch: DefectBranch) -> LiftProposal {
        match branch {
            DefectBranch::StabilizedSurvivor => LiftProposal::Candidate {
                generators: vec!["coda_residual_refine".into()],
                nine_bits: licensed_nine(),
                certificate: resolve_cert("coda_q1", "coda_residual_refine"),
            },
            DefectBranch::Open => LiftProposal::SameLevelRepair,
            _ => LiftProposal::SkipClosed,
        }
    }

    fn literature_note(&self) -> Option<String> {
        Some("CODA carrier/residual firewall; Q quarantine non-promotion".into())
    }

    fn residual_family_label(&self) -> String {
        "coda:q1_residual_firewall".into()
    }
}

/// Symbol Game expressivity obstruction adapter.
#[derive(Debug, Clone)]
pub struct SymbolGameExpressivityAdapter {
    pub phi1: u64,
    pub gamma2: u64,
    pub square_zero: bool,
    pub problem_label: String,
}

impl Default for SymbolGameExpressivityAdapter {
    fn default() -> Self {
        Self {
            phi1: 3,
            gamma2: 0,
            square_zero: true,
            problem_label: "expressivity_obstructed_default".into(),
        }
    }
}

impl DomainAdapter for SymbolGameExpressivityAdapter {
    fn domain(&self) -> PrimeDomain {
        PrimeDomain::SymbolGame
    }

    fn declaration(&self) -> DeclarationFill {
        DeclarationFill {
            carrier: Some(format!("symbol_game::expressivity:{}", self.problem_label)),
            primitive_difference: Some(
                "local patch naming non-sameness on overlap discrepancies".into(),
            ),
            zero_rel: Some("ContextuallyGlueable (o_n = 0 in im d0)".into()),
            observer: Some("expressivity_norm_face / unit ℓ¹ diagnostic".into()),
            witnesses: vec![
                "omega_symbol_game::expressivity".into(),
                "omega_functional exact Phi1/Gamma2 rails".into(),
            ],
        }
    }

    fn justify_cochain(&self) -> bool {
        true
    }

    fn cochain_window(&self) -> Option<CochainWindow> {
        Some(CochainWindow {
            dim_c0: 3,
            dim_c1: 3,
            dim_c2: 0,
            square_zero: self.square_zero,
            l1_defect_mass: if self.square_zero { 0 } else { 1 },
        })
    }

    fn residual_masses(&self) -> (u64, u64) {
        (self.phi1, self.gamma2)
    }

    fn lift_proposal(&self, branch: DefectBranch) -> LiftProposal {
        match branch {
            DefectBranch::StabilizedSurvivor if self.phi1 > 0 => LiftProposal::Candidate {
                generators: vec!["expressivity_meta_norm".into()],
                nine_bits: licensed_nine(),
                certificate: resolve_cert(&self.problem_label, "expressivity_meta_norm"),
            },
            DefectBranch::Open => LiftProposal::SameLevelRepair,
            DefectBranch::Closed => LiftProposal::SkipClosed,
            _ => LiftProposal::OracleGap {
                note: "expressivity obstruction unresolved".into(),
            },
        }
    }

    fn literature_note(&self) -> Option<String> {
        Some("Symbol Game math spine; FOC Čech gate; ENC-0891 no Phi1 authority".into())
    }

    fn residual_family_label(&self) -> String {
        format!("symbol_game:{}", self.problem_label)
    }
}

/// All built-in adapters as a fixed roster for Rosetta multi-domain runs.
pub fn builtin_adapter_roster() -> Vec<Box<dyn DomainAdapter>> {
    vec![
        Box::new(GenericMss0Adapter),
        Box::new(MubWallAdapter),
        Box::new(FspChannelAAdapter),
        Box::new(CodaResidualAdapter),
        Box::new(SymbolGameExpressivityAdapter::default()),
    ]
}

/// CP² shadow — the one adapter whose masses are **computed, not declared**.
///
/// Every other adapter in this file returns constants: `residual_masses` is a
/// literal, `justify_cochain` is a literal, and the lift proposal carries
/// `NineUpLiftBits::all_true()` with a certificate whose "hashes" are prefixed
/// label strings. That is legitimate for a structural demo and is exactly why the
/// Rosetta report is stamped [`EvidenceProvenance::FixtureDrivenStructuralDemo`].
///
/// This adapter closes that gap for one domain. It builds a real
/// [`Cp2TransitionFamily`], reduces it mod 2, and asks the degree-tower runtime to
/// diagnose it; Φ₁ and Γ₂ come back from that diagnosis rather than from a literal.
/// The distinction is observable: perturbing the family changes the reported
/// masses, which is untrue of every other adapter here.
///
/// It reports [`EvidenceProvenance::VerifierProduced`] — the only adapter entitled to.
///
/// **Scope of the claim.** The masses are computed *over F₂*. Per `cp2_shadow`'s own
/// note, the reduction `Z_k → Z_2` has kernel `2Z_k`, so an integral defect lying in
/// `2Z_k` is invisible to this runtime and Γ = 0 certifies nothing about the
/// integral family. "Computed" here means computed at the reduction, not integrally.
pub struct Cp2ShadowAdapter {
    family: Cp2TransitionFamily,
    label: String,
}

impl Cp2ShadowAdapter {
    /// The standard degree-`d` family on a `k`-sample equator.
    ///
    /// Returns `None` when the constructor refuses (`k = 0`, or `k` over
    /// `CP2_MAX_K`), so a caller cannot silently get a fixture instead.
    pub fn standard(k: u64, d: u64) -> Option<Self> {
        Cp2TransitionFamily::standard_degree(k, d)
            .ok()
            .map(|family| Self {
                family,
                label: format!("cp2:standard_k{k}_d{d}"),
            })
    }

    /// The diagnosis this adapter's masses are read from, or `None` if the
    /// runtime refused the family (odd `k`, over the bridge cap, not a cocycle).
    fn diagnosis(&self) -> Option<DegreeDiagnostic> {
        match self.family.verify_shell_lift().ok()? {
            Cp2ShellOutcome::NotABundle { base, .. } => Some(base),
            Cp2ShellOutcome::FlatMod2GaugeExists { base } => Some(base),
            Cp2ShellOutcome::Lifted(packet) => Some(packet.base().clone()),
        }
    }
}

impl DomainAdapter for Cp2ShadowAdapter {
    fn domain(&self) -> PrimeDomain {
        PrimeDomain::Cp2
    }

    fn declaration(&self) -> DeclarationFill {
        DeclarationFill {
            carrier: Some(format!(
                "Three-chart CP² presentation, {}-sample overlap circles",
                self.family.sample_count()
            )),
            primitive_difference: Some(
                "Non-sameness of the transition family and a chart-constant gauge".into(),
            ),
            zero_rel: Some("(δ¹g)(a,b) = 0 on every triple overlap, exactly in Z_k".into()),
            observer: Some("F₂ degree-tower runtime, reduction Z_k → Z_2".into()),
            witnesses: vec![
                "cp2_shadow::Cp2TransitionFamily::cocycle_defect".into(),
                "degree_tower::BinaryCochainSegment::diagnose".into(),
            ],
        }
    }

    /// Justified exactly when the runtime accepts the family — not by assertion.
    fn justify_cochain(&self) -> bool {
        self.diagnosis().is_some()
    }

    fn cochain_window(&self) -> Option<CochainWindow> {
        let k = self.family.sample_count() as usize;
        let d = self.diagnosis()?;
        Some(CochainWindow {
            dim_c0: 3 * k,
            dim_c1: 3 * k,
            dim_c2: 3 * k * k,
            // δ¹δ⁰ = 0 holds by construction of the segment; the runtime re-checks it
            // and would have refused above if it did not.
            square_zero: true,
            l1_defect_mass: d.gamma as u64,
        })
    }

    /// Read off the runtime's diagnosis. Perturb the family and these move.
    fn residual_masses(&self) -> (u64, u64) {
        match self.diagnosis() {
            Some(d) => (d.phi as u64, d.gamma as u64),
            // The runtime refused, so there is no measurement. Reporting (0, 0)
            // would read as "closed" — the one answer that must not be inferred
            // from an absent diagnosis.
            None => (1, 1),
        }
    }

    fn lift_proposal(&self, _: DefectBranch) -> LiftProposal {
        // No fabricated nine-bit packet. Whether a lift exists here is decided by
        // the runtime, and when the base is not already flat the honest report is
        // an oracle gap rather than an all-true certificate.
        match self.diagnosis() {
            Some(d) if d.phi == 0 => LiftProposal::SkipClosed,
            Some(d) => LiftProposal::OracleGap {
                note: format!(
                    "F₂ base carries Φ={}, Γ={}; integral lift undecided at this reduction",
                    d.phi, d.gamma
                ),
            },
            None => LiftProposal::OracleGap {
                note: "runtime refused the family; no diagnosis to lift from".into(),
            },
        }
    }

    fn literature_note(&self) -> Option<String> {
        Some("ONLY after terminal — CP² Chern/Hopf literature does not mint this".into())
    }

    fn evidence_provenance(&self) -> EvidenceProvenance {
        EvidenceProvenance::VerifierProduced
    }

    fn residual_family_label(&self) -> String {
        self.label.clone()
    }
}
