use omega_atlas_reconciliation::terminalize::{
    terminalize, ObstructionStatus, TerminalizerRefusal,
};

#[test]
fn exact_repair_only_when_both_zero() {
    assert_eq!(terminalize(0, 0), Ok(ObstructionStatus::ExactRepair));
}

#[test]
fn phi_zero_with_positive_gamma_is_refused() {
    // FOC-T3: phi == 0 && gamma > 0 is an inconsistent witness, not an exact repair.
    assert_eq!(
        terminalize(0, 9),
        Err(TerminalizerRefusal::InconsistentWitness)
    );
}

#[test]
fn survivor_when_phi_pos_gamma_zero() {
    assert_eq!(terminalize(3, 0), Ok(ObstructionStatus::StabilizedSurvivor));
}

#[test]
fn open_when_both_positive() {
    assert_eq!(terminalize(3, 2), Ok(ObstructionStatus::OpenObstruction));
}

#[test]
fn total_and_exclusive() {
    for p in 0..3u64 {
        for g in 0..3u64 {
            let s = terminalize(p, g);
            if p == 0 && g > 0 {
                assert_eq!(s, Err(TerminalizerRefusal::InconsistentWitness));
            } else if p == 0 {
                assert_eq!(s, Ok(ObstructionStatus::ExactRepair));
            } else if g == 0 {
                assert_eq!(s, Ok(ObstructionStatus::StabilizedSurvivor));
            } else {
                assert_eq!(s, Ok(ObstructionStatus::OpenObstruction));
            }
        }
    }
}
