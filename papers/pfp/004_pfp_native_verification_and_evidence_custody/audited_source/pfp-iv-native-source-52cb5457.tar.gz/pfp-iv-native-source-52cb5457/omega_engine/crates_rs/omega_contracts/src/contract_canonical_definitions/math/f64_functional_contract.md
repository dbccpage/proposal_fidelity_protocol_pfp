F64 FUNCTIONAL CONTRACT
=======================

==============================================================================
==============================================================================

#

Contract for floating-point functionals in the finite obstruction calculus.
===========================================================================

Unlike rational arithmetic, f64 functionals use approximate IEEE 754 arithmetic
===============================================================================

with specified tolerance bounds and numerical stability guarantees.
===================================================================

#

==============================================================================
==============================================================================

contract_id: "urn:math:contract:F64Functional:v0.1.0"
title: "F64 Functional Contract"
version: "0.1.0"
status: "mathematical_wip"
authority_level: "implementation_contract"
kind: "numerical-functional"

MATHEMATICAL OBJECT
-------------------

mathematical_object:
  kind: "approximate_functional"
  carrier:
    description: "Functionals Φ₁, Γ₂, Ξ computed over f64 scalar field"
    components:
      scalar_type: "f64 (IEEE 754 double precision)"
      precision: "53-bit mantissa (≈15.95 decimal digits)"
      tolerance: "user-specified ε (typically 1e-10 to 1e-15)"
      operations: "approximate (subject to rounding)"

  notation: "(ℝ_float, +, *, 0.0, 1.0, ε)"

NUMERICAL PROPERTIES
--------------------

numerical_properties:

  * id: "finite_precision"
    statement: "All computations use IEEE 754 double precision (53-bit mantissa)"
    enforcement: "hardware"

  * id: "approximate_arithmetic"
    statement: "Operations may introduce rounding errors ≤ machine epsilon"
    machine_epsilon: "2.220446049250313e-16"
    enforcement: "acknowledged"

  * id: "tolerance_based_equality"
    statement: "Zero-comparison uses user-specified tolerance ε"
    default_tolerance: "1e-10"
    enforcement: "runtime"

  * id: "catastrophic_cancellation_aware"
    statement: "Subtraction of nearly-equal values may lose precision"
    mitigation: "Use alternative formulations when possible"
    enforcement: "algorithm_design"

  * id: "overflow_detection"
    statement: "Detect and reject NaN, ±∞ results"
    enforcement: "runtime_check"

BACKEND SPECIFICATION
---------------------

backend:
  name: "F64FunctionalBackend"
  scalar_type: "f64"
  properties:

    * "IEEE 754 double precision arithmetic"
    * "Hardware-accelerated SIMD operations (nalgebra)"
    * "Tolerance-based zero comparison"
    * "NaN/infinity detection and rejection"
    * "Deterministic rounding mode (round-to-nearest-even)"

  error_conditions:

    * "NonFiniteValue (NaN or ±∞)"
    * "ToleranceViolation (computed value below tolerance threshold)"
    * "NumericalInstability (condition number too large)"

FUNCTIONALS
-----------

functionals:
  phi1:
    name: "Φ₁ (Obstruction Mass)"
    definition: "Φ₁([ω]) = min_α ‖ω - d₀α‖₁"
    computation: "ℓ¹ minimization via linear programming or iterative methods"
    numerical_stability: "Stable (ℓ¹ norm is well-conditioned)"
    tolerance_usage: "Zero-check: |Φ₁| < ε implies exact repair"
    error_bound: "Relative error ≤ ε_mach × condition_number × n"

  gamma2:
    name: "Γ₂ (Closure Defect)"
    definition: "Γ₂([h]) = ‖d₁h‖₁"
    computation: "Matrix-vector multiplication followed by ℓ¹ norm"
    numerical_stability: "Stable (ℓ¹ norm, well-conditioned matrix)"
    tolerance_usage: "Zero-check: |Γ₂| < ε implies closed cycle"
    error_bound: "Relative error ≤ ε_mach × ‖d₁‖ × ‖h‖"

  xi:
    name: "Ξ (Primal-Dual Density Tie-Breaker)"
    definition: "Ξ = ‖ρ(h₁*) - ρ(φ*)‖_tr"
    computation: "Density lift via square root + trace norm"
    numerical_stability: "Moderate (square root may amplify errors)"
    tolerance_usage: "Zero-check: |Ξ| < ε implies aligned densities"
    error_bound: "Relative error ≤ ε_mach^(1/2) × √n (square root amplification)"

VALIDATION
----------

validators:

  * name: "finite_value_validator"
    order: 1
    purpose: "Reject NaN and ±∞ results"
    test_cases:

      * "0.0 / 0.0 → Error (NaN)"
      * "1.0 / 0.0 → Error (∞)"
      * "f64::MAX * 2.0 → Error (∞)"

  * name: "tolerance_validator"
    order: 2
    purpose: "Verify tolerance-based zero-checks"
    test_cases:

      * "1e-11 < 1e-10 → is_zero = true"
      * "1e-9 < 1e-10 → is_zero = false"

  * name: "numerical_stability_validator"
    order: 3
    purpose: "Verify stable computation for well-conditioned inputs"
    test_cases:

      * "‖d₁h‖₁ for identity matrix → exact (no rounding error)"
      * "‖d₁h‖₁ for orthogonal matrix → near-exact (minimal error)"

OPERATIONS
----------

operations:
  l1_norm:
    name: "l1_norm"
    signature: "fn l1_norm(v: &DVector<f64>) -> f64"
    description: "Compute ℓ¹ norm: Σ|vᵢ|"
    stability: "Stable (no cancellation)"
    error_bound: "≤ n × ε_mach × max|vᵢ|"

  matrix_vector_multiply:
    name: "matrix_vector_multiply"
    signature: "fn matvec(A: &DMatrix<f64>, v: &DVector<f64>) -> DVector<f64>"
    description: "Compute Av"
    stability: "Stable for well-conditioned A"
    error_bound: "≤ ε_mach × ‖A‖ × ‖v‖ × √n"

  is_zero:
    name: "is_zero"
    signature: "fn is_zero(x: f64, tolerance: f64) -> bool"
    description: "Check if |x| ≤ tolerance"
    stability: "Exact (no rounding)"
    deterministic: true

  is_non_worsening:
    name: "is_non_worsening"
    signature: "fn is_non_worsening(before: f64, after: f64, tolerance: f64) -> bool"
    description: "Check if after ≤ before + tolerance"
    stability: "Exact (no rounding)"
    deterministic: true

ERROR TAXONOMY
--------------

errors:

  * error_type: "NonFiniteValue"
    condition: "Result is NaN or ±∞"
    recovery: "Check input validity, avoid division by zero"

  * error_type: "ToleranceViolation"
    condition: "Computed value below tolerance threshold"
    recovery: "Increase tolerance or use exact arithmetic"

  * error_type: "NumericalInstability"
    condition: "Condition number too large (>1e12)"
    recovery: "Regularize problem or use higher precision"

TESTS
-----

tests:
  required:

    * "phi1_zero_observation_is_exact"
    * "gamma2_zero_residual_is_closed"
    * "xi_zero_when_phi1_zero"
    * "l1_norm_positive_definite"
    * "tolerance_based_equality_symmetric"
    * "non_finite_detection"

  unit_tests:

    * name: "phi1_zero_observation_is_exact"
      input: "ω = [0.0, 0.0, 0.0]"
      expected: "Φ₁ < 1e-10 and is_exact = true"

    * name: "gamma2_zero_residual_is_closed"
      input: "h = [0.0, 0.0, 0.0]"
      expected: "Γ₂ < 1e-10 and is_closed = true"

    * name: "xi_zero_when_phi1_zero"
      input: "Φ₁ = 0.0"
      expected: "Ξ = 0.0 (conditional definition)"

    * name: "non_finite_detection"
      input: "NaN, +∞, -∞"
      expected: "Error(NonFiniteValue)"

COMPARISON WITH RATIONAL BACKEND
--------------------------------

comparison:
  exact_vs_approximate:
    rational: "Exact arithmetic (no rounding errors within bounds)"
    f64: "Approximate arithmetic (rounding errors bounded by ε_mach)"

  overflow_behavior:
    rational: "Detected overflow → Error"
    f64: "Overflow → ±∞ → Detected → Error"

  performance:
    rational: "Slower (arbitrary precision)"
    f64: "Faster (hardware SIMD)"

  determinism:
    rational: "Fully deterministic"
    f64: "Deterministic (IEEE 754 round-to-nearest-even)"

  use_cases:
    rational: "Theorem-grade proofs, exact verification"
    f64: "Fast prototyping, approximate optimization"

IMPLEMENTATION NOTES
--------------------

notes:
  tolerance_selection: >
    Default tolerance 1e-10 balances numerical precision with practical
    zero-detection. For condition numbers >1e6, increase tolerance to 1e-8.
    For condition numbers <1e3, can decrease to 1e-12.

  catastrophic_cancellation: >
    Subtraction of nearly-equal values (|a-b| << |a|, |b|) loses precision.
    The Φ₁ functional uses ℓ¹ norm (sum of absolute values) which avoids
    cancellation. The Ξ functional uses square roots which amplify errors
    by √ε_mach but remain stable for well-separated densities.

  matrix_conditioning: >
    The coboundary operators d₀, d₁ are typically sparse and well-conditioned
    (condition number <1e6). For ill-conditioned matrices, consider
    regularization or switching to rational backend.

  simd_optimization: >
    nalgebra uses SIMD instructions when available, providing 2-4× speedup
    for large vectors. This is deterministic across platforms using IEEE 754.

FUTURE EXTENSIONS
-----------------

future:

  * "Mixed-precision: f64 for speed, rational for verification"
  * "Adaptive tolerance: adjust ε based on condition number"
  * "Error bounds: compute rigorous error bounds using interval arithmetic"
  * "Compensated summation: use Kahan summation for ℓ¹ norms"
