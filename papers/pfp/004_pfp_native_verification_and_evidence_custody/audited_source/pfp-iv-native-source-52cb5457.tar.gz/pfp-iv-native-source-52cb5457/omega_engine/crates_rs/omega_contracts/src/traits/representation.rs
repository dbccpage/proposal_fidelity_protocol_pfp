use super::identity::{ContractBound, NamedComponent};
use crate::kinds::BaseType;

pub trait Adapter<S, T: BaseType>: NamedComponent + ContractBound {
    type Error;
    fn adapt(&self, input: &S) -> Result<T, Self::Error>;
}

pub trait Encoder<S: BaseType, T: BaseType>: NamedComponent + ContractBound {
    type Error;
    fn encode(&self, input: &S) -> Result<T, Self::Error>;
}

pub trait Decoder<S: BaseType, T: BaseType>: NamedComponent + ContractBound {
    type Error;
    fn decode(&self, input: &S) -> Result<T, Self::Error>;
}

/// Representation projection only.
/// This is not automatically fixed-layer OperatorClass::R.
pub trait Projector<S: BaseType, T: BaseType>: NamedComponent + ContractBound {
    type Error;
    fn project(&self, input: &S) -> Result<T, Self::Error>;
}

/// Representation reflection only.
/// This does not authorize a lift or equivalence claim.
pub trait Reflector<S: BaseType, T: BaseType>: NamedComponent + ContractBound {
    type Error;
    fn reflect(&self, input: &S) -> Result<T, Self::Error>;
}
