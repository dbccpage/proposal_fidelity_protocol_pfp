//! --- yaml
//! title: catkit_emitter
//! file_name: emitter.rs
//! file_location: omega_core/src/compiler/emitter.rs
//! status: Diamond
//! invariance_level: Tier 1
//! logic_system: Functorial Intermediate Representation (FIR)
//! substrate: Rust
//! description: >
//!   AST-to-Catkit Emitter. Phase 5 of the AutoP (.atp) compiler.
//!   Transforms a verified Topological AST into a self-contained Rust program
//!   string that utilizes the `omega_core::catkit` execution substrate.
//!   Only runs after Phase 3 boundary check produces Diamond or SovereignParadox.
//!   Maps: manifold -> FiniteCategory::add_object,
//!         morphism -> FiniteCategory::add_morphism + set_composition,
//!         adjunction -> types::category::adjunction::verify_adjunction_roundtrip,
//!         orbit -> operational event loop,
//!         tensor -> async parallel execution,
//!         sheaf -> module struct.
//! content_hash: 7bd6776853a290b820d4e3116a7a1ea3309693d84f851f4b7f93e63374e0ddbe
//! version: 2
//! ---

use super::parser::{
    AdjunctionDecl, AtpModule, BinOpKind, CategoryDecl, CohomologyDecl, Declaration, Expr,
    FunctorDecl, ManifoldDecl, MorphismDecl, NaturalTransformationDecl, OrbitDecl, SheafDecl,
    TensorDecl, TypeExpr,
};
use std::collections::HashSet;

// ============================================================
// Helpers
// ============================================================

/// Sanitize an identifier for safe use in generated Rust code.
/// Only allows alphanumeric characters and underscores.
/// Prefixes with `_` if the result starts with a digit or is empty.
fn sanitize_ident(name: &str) -> String {
    let mut cleaned = String::with_capacity(name.len() * 2);
    for c in name.chars() {
        if c.is_ascii_alphanumeric() || c == '_' {
            cleaned.push(c);
        } else if c == '-' {
            cleaned.push_str("_dash_");
        } else if c == '.' {
            cleaned.push_str("_dot_");
        } else if c == '*' {
            cleaned.push_str("_star_");
        } else if c == '+' {
            cleaned.push_str("_plus_");
        } else {
            cleaned.push_str(&format!("_u{:04x}_", c as u32));
        }
    }

    let keywords = [
        "fn", "match", "let", "mut", "if", "else", "while", "for", "loop", "return", "type",
        "struct", "enum", "trait", "impl", "use", "pub", "mod", "const", "static", "box", "ref",
        "in", "as", "move", "break", "continue",
    ];
    if keywords.contains(&cleaned.as_str()) {
        cleaned.push_str("_kw");
    }

    if cleaned.is_empty() {
        "_unnamed".to_string()
    } else if cleaned.starts_with(|c: char| c.is_ascii_digit()) {
        format!("_{}", cleaned)
    } else {
        cleaned
    }
}

/// Render a TypeExpr as a flat string (for comments and object names).
/// Arrow types become "A_to_B", product types become "A_x_B".
fn render_type(ty: &TypeExpr) -> String {
    match ty {
        TypeExpr::Arrow(left, right) => {
            format!("arrow_{}_to_{}", render_type(left), render_type(right))
        }
        TypeExpr::Product(factors) => {
            let inner_strs: Vec<String> = factors.iter().map(render_type).collect();
            format!("prod_{}", inner_strs.join("_"))
        }
        TypeExpr::Named(name) => sanitize_ident(name),
        TypeExpr::Parameterized(name, params) => {
            let params: Vec<String> = params.iter().map(render_type).collect();
            format!("{}_{}", sanitize_ident(name), params.join("_"))
        }
    }
}

/// Collect leaf type names from a TypeExpr (for object registration).
fn collect_leaf_names(ty: &TypeExpr) -> Vec<String> {
    match ty {
        TypeExpr::Arrow(left, right) => {
            let mut leaves = collect_leaf_names(left);
            leaves.extend(collect_leaf_names(right));
            leaves
        }
        TypeExpr::Product(factors) => factors.iter().flat_map(collect_leaf_names).collect(),
        TypeExpr::Named(name) => vec![sanitize_ident(name)],
        TypeExpr::Parameterized(name, params) => {
            let mut leaves = vec![sanitize_ident(name)];
            for p in params {
                leaves.extend(collect_leaf_names(p));
            }
            leaves
        }
    }
}

/// Render an expression tree as a human-readable string.
fn render_expr(e: &Expr) -> String {
    match e {
        Expr::Var(s) => s.clone(),
        Expr::Int(n) => n.to_string(),
        Expr::App(name, args) => {
            let arg_strs: Vec<String> = args.iter().map(render_expr).collect();
            format!("{}({})", name, arg_strs.join(", "))
        }
        Expr::Tuple(elems) => {
            let elem_strs: Vec<String> = elems.iter().map(render_expr).collect();
            format!("({})", elem_strs.join(", "))
        }
        Expr::Compose(lhs, rhs) => format!("{} >>> {}", render_expr(lhs), render_expr(rhs)),
        Expr::BinOp(lhs, op, rhs) => {
            let op_str = match op {
                BinOpKind::Add => "+",
                BinOpKind::Sub => "-",
                BinOpKind::Mul => "*",
                BinOpKind::Div => "/",
                BinOpKind::Pow => "^",
            };
            format!("({} {} {})", render_expr(lhs), op_str, render_expr(rhs))
        }
        Expr::Neg(inner) => format!("(-{})", render_expr(inner)),
    }
}

// ============================================================
// Catkit Emitter
// ============================================================

/// Emits a standalone Rust program string from a verified AtpModule.
///
/// The generated code builds a `FiniteCategory` at runtime, registers
/// all manifolds as objects and morphisms as arrows, then executes
/// orbits as event loops and tensors as async parallel tasks.
pub struct CatkitEmitter {
    code: String,
    indent: usize,
    objects: HashSet<String>,
}

impl CatkitEmitter {
    pub fn new() -> Self {
        Self {
            code: String::new(),
            indent: 0,
            objects: HashSet::new(),
        }
    }

    /// Push a line with current indentation.
    fn line(&mut self, s: &str) {
        for _ in 0..self.indent {
            self.code.push_str("    ");
        }
        self.code.push_str(s);
        self.code.push('\n');
    }

    /// Push an empty line.
    fn blank(&mut self) {
        self.code.push('\n');
    }

    /// Ensure an object is registered exactly once, and emit its identity morphism.
    fn ensure_object(&mut self, name: &str) {
        if self.objects.insert(name.to_string()) {
            self.line(&format!("cat.add_object(\"{}\");", name));
            self.line(&format!(
                "cat.add_morphism(\"id_{}\", \"{}\", \"{}\");",
                name, name, name
            ));
        }
    }

    /// Emit the full Rust source file as a string.
    pub fn emit_module(&mut self, module: &AtpModule) -> String {
        // Header
        self.line("//! AUTO-GENERATED BY AUTOP COMPILER");
        self.line("//! Logic System: Self-Repair Cohomology");
        self.line("//! Do not edit — regenerate from .atp source.");
        self.blank();
        self.line("use omega_core::ascent::lambdas::l161_structcat::FiniteCategory;");
        self.line("use omega_core::ascent::lambdas::l161_structcat::MorphismMeta;");
        self.line("use omega_core::ascent::lambdas::l161_structcat::MorphismKind;");
        self.blank();

        // Main function
        self.line("fn main() -> Result<(), Box<dyn std::error::Error>> {");
        self.indent += 1;
        self.line("let mut cat = FiniteCategory::default();");
        self.blank();

        // Pass 1: Register all objects (manifolds, sheaf names, implicit types)
        for decl in &module.declarations {
            match decl {
                Declaration::Manifold(m) => self.emit_manifold(m),
                Declaration::Sheaf(s) => self.emit_sheaf(s),
                Declaration::Category(c) => self.emit_category(c),
                _ => {}
            }
        }

        self.blank();

        // Pass 2: Register morphisms, adjunctions, tensors, orbits, functors, cohomology
        for decl in &module.declarations {
            match decl {
                Declaration::Morphism(m) => self.emit_morphism(m),
                Declaration::Adjunction(a) => self.emit_adjunction(a),
                Declaration::Tensor(t) => self.emit_tensor(t),
                Declaration::Orbit(o) => self.emit_orbit(o),
                Declaration::Functor(f) => self.emit_functor(f),
                Declaration::NaturalTransformation(nt) => self.emit_natural(nt),
                Declaration::Cohomology(ch) => self.emit_cohomology(ch),
                _ => {}
            }
        }

        self.blank();
        self.line("println!(\"Topology executed successfully. Objects: {}, Morphisms: {}\",");
        self.line("    cat.num_objects(), cat.num_morphisms());");
        self.line("Ok(())");
        self.indent -= 1;
        self.line("}");

        self.code.clone()
    }

    /// Lowers a 0-simplex (Manifold) into a category Object + identity.
    fn emit_manifold(&mut self, decl: &ManifoldDecl) {
        let name = sanitize_ident(&decl.name);
        self.line(&format!("// Manifold: {} : Dim({})", name, decl.dim_bound));
        self.ensure_object(&name);

        // Emit sections as comments (they define the manifold's local structure)
        for section in &decl.sections {
            let sec_name = sanitize_ident(&section.name);
            let type_str = render_type(&section.type_sig);
            self.line(&format!("// section {}: {}", sec_name, type_str));
        }
    }

    /// Lowers a 1-simplex (Morphism) into a category Arrow.
    /// Uses rendered type names to preserve product structure (A*B → A_x_B).
    fn emit_morphism(&mut self, decl: &MorphismDecl) {
        let name = sanitize_ident(&decl.name);
        let src_str = render_type(&decl.source);
        let tgt_str = render_type(&decl.target);

        self.line(&format!(
            "// Morphism: {} : {} -> {}",
            name, src_str, tgt_str
        ));

        // Ensure source and target objects exist (using rendered composite names)
        self.ensure_object(&src_str);
        self.ensure_object(&tgt_str);

        // Register the morphism using rendered type names
        self.line(&format!(
            "cat.add_morphism(\"{}\", \"{}\", \"{}\");",
            name, src_str, tgt_str
        ));

        // Wire composition: id_src ; f = f, f ; id_tgt = f
        self.line(&format!(
            "cat.set_composition(\"id_{}\", \"{}\", \"{}\");",
            src_str, name, name
        ));
        self.line(&format!(
            "cat.set_composition(\"{}\", \"id_{}\", \"{}\");",
            name, tgt_str, name
        ));

        // Emit equations with rendered expressions
        for eq in &decl.equations {
            self.line(&format!(
                "// equation: {} = {}",
                render_expr(&eq.lhs),
                render_expr(&eq.rhs)
            ));
        }
    }

    /// Lowers a Category into object and identity morphism registrations.
    fn emit_category(&mut self, decl: &CategoryDecl) {
        let name = sanitize_ident(&decl.name);
        self.line(&format!("// Category: {}", name));
        for obj in &decl.objects {
            let obj_name = sanitize_ident(obj);
            self.ensure_object(&obj_name);
        }
    }

    /// Lowers a Functor into object/morphism mapping comments and morphisms.
    fn emit_functor(&mut self, decl: &FunctorDecl) {
        let name = sanitize_ident(&decl.name);
        let src = sanitize_ident(&decl.source_cat);
        let tgt = sanitize_ident(&decl.target_cat);
        self.line(&format!("// Functor: {} : {} -> {}", name, src, tgt));

        for (s, t) in &decl.object_map {
            let s_name = sanitize_ident(s);
            let t_name = sanitize_ident(t);
            self.ensure_object(&s_name);
            self.ensure_object(&t_name);
            self.line(&format!(
                "cat.add_morphism(\"{}_{}\", \"{}\", \"{}\");",
                name, s_name, s_name, t_name
            ));
        }

        for (s, t) in &decl.morphism_map {
            self.line(&format!("// morphism map: {} -> {}", s, t));
        }
    }

    /// Lowers a NaturalTransformation into component morphisms.
    fn emit_natural(&mut self, decl: &NaturalTransformationDecl) {
        let name = sanitize_ident(&decl.name);
        self.line(&format!(
            "// NaturalTransformation: {} : {} => {}",
            name, decl.source_functor, decl.target_functor
        ));
        for comp in &decl.components {
            let comp_name = sanitize_ident(&comp.name);
            let type_str = render_type(&comp.type_sig);
            self.line(&format!("// component {}: {}", comp_name, type_str));
        }
    }

    /// Lowers a Cohomology into a morphism (source -> target) with equations.
    fn emit_cohomology(&mut self, decl: &CohomologyDecl) {
        let name = sanitize_ident(&decl.name);
        let src_str = render_type(&decl.source);
        let tgt_str = render_type(&decl.target);

        self.line(&format!(
            "// Cohomology: {} : {} -> {}",
            name, src_str, tgt_str
        ));
        self.ensure_object(&src_str);
        self.ensure_object(&tgt_str);
        self.line(&format!(
            "cat.add_morphism(\"{}\", \"{}\", \"{}\");",
            name, src_str, tgt_str
        ));

        for eq in &decl.equations {
            self.line(&format!(
                "// equation: {} = {}",
                render_expr(&eq.lhs),
                render_expr(&eq.rhs)
            ));
        }
    }

    /// Lowers a Sheaf into a module struct.
    fn emit_sheaf(&mut self, decl: &SheafDecl) {
        let name = sanitize_ident(&decl.name);
        self.line(&format!("// Sheaf: {}", name));
        self.ensure_object(&name);

        // Register sections that have arrow types as morphisms
        for section in &decl.sections {
            if let TypeExpr::Arrow(ref src, ref tgt) = section.type_sig {
                let sec_name = sanitize_ident(&section.name);
                let src_str = render_type(src);
                let tgt_str = render_type(tgt);
                self.ensure_object(&src_str);
                self.ensure_object(&tgt_str);
                self.line(&format!(
                    "cat.add_morphism(\"{}\", \"{}\", \"{}\");",
                    sec_name, src_str, tgt_str
                ));
            }
        }
    }

    /// Lowers an Adjunction (F ⊣ G) into paired functor registration.
    /// Wires both triangle identities: G∘F → id_A and F∘G → id_B.
    fn emit_adjunction(&mut self, decl: &AdjunctionDecl) {
        let name = sanitize_ident(&decl.name);
        let left_name = sanitize_ident(&decl.left.name);
        let right_name = sanitize_ident(&decl.right.name);

        let left_src = render_type(&decl.left.source);
        let left_tgt = render_type(&decl.left.target);
        let right_src = render_type(&decl.right.source);
        let right_tgt = render_type(&decl.right.target);

        self.line(&format!(
            "// Adjunction: {} ({}  ⊣  {})",
            name, left_name, right_name
        ));

        // Ensure all endpoint objects exist (deduplicated)
        self.ensure_object(&left_src);
        self.ensure_object(&left_tgt);
        self.ensure_object(&right_src);
        self.ensure_object(&right_tgt);

        // Register left and right adjoint as morphisms
        self.line(&format!(
            "cat.add_morphism(\"{}\", \"{}\", \"{}\");",
            left_name, left_src, left_tgt
        ));
        self.line(&format!(
            "cat.add_morphism(\"{}\", \"{}\", \"{}\");",
            right_name, right_src, right_tgt
        ));

        // Wire both triangle identities:
        // Triangle 1: right ∘ left = id_A  (unit)
        self.line(&format!(
            "cat.set_composition(\"{}\", \"{}\", \"id_{}\");",
            right_name, left_name, left_src
        ));
        // Triangle 2: left ∘ right = id_B  (counit)
        self.line(&format!(
            "cat.set_composition(\"{}\", \"{}\", \"id_{}\");",
            left_name, right_name, left_tgt
        ));

        // Emit unit/counit as metadata comments
        self.line(&format!("// unit: {}", decl.unit.statement));
        self.line(&format!("// counit: {}", decl.counit.statement));
    }

    /// Lowers a Tensor into an async parallel execution block.
    fn emit_tensor(&mut self, decl: &TensorDecl) {
        let name = sanitize_ident(&decl.name);
        self.line(&format!("// Tensor: {} — parallel execution", name));
        self.line(&format!(
            "// disjointness: {}",
            decl.disjointness_proof.statement
        ));
        self.line(&format!("// execute: {}", decl.execute_expr.join(" || ")));

        // Each tensor component gets registered as an object (deduplicated)
        for param in &decl.params {
            let p = sanitize_ident(param);
            self.ensure_object(&p);
        }
    }

    /// Lowers a blessed cycle (Orbit) into an operational event loop.
    fn emit_orbit(&mut self, decl: &OrbitDecl) {
        let name = sanitize_ident(&decl.name);
        let src_str = render_type(&decl.source);
        let tgt_str = render_type(&decl.target);

        self.line(&format!(
            "// Orbit (blessed cycle): {} : {} -> {}",
            name, src_str, tgt_str
        ));

        // Register the orbit morphisms for all combinations of leaves
        let src_leaves = collect_leaf_names(&decl.source);
        let tgt_leaves = collect_leaf_names(&decl.target);
        for src in &src_leaves {
            for tgt in &tgt_leaves {
                self.ensure_object(src);
                self.ensure_object(tgt);
                self.line(&format!(
                    "cat.add_morphism(\"{}_{}_{}\", \"{}\", \"{}\");",
                    name, src, tgt, src, tgt
                ));
            }
        }

        // Emit the orbit body as a loop comment block
        self.line("// OPERATIONAL: This orbit generates a runtime event loop.");
        self.line(&format!(
            "// loop {{ match {}.execute() {{ Ok(_) => continue, Err(e) => break }} }}",
            name
        ));
    }
}

impl Default for CatkitEmitter {
    fn default() -> Self {
        Self::new()
    }
}

/// Convenience function: emit a module to a catkit Rust string.
pub fn generate_catkit(module: &AtpModule) -> String {
    let mut emitter = CatkitEmitter::new();
    emitter.emit_module(module)
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compiler::lexer::tokenize;
    use crate::compiler::parser::parse;

    /// Helper: lex -> parse -> emit catkit.
    fn emit_source(source: &str) -> String {
        let tokens = tokenize(source);
        let module = parse(&tokens).expect("parse failed");
        generate_catkit(&module)
    }

    #[test]
    fn test_empty_module_generates_header() {
        let code = emit_source("");
        assert!(code.contains("AUTO-GENERATED BY AUTOP COMPILER"));
        assert!(code.contains("use omega_core::ascent::lambdas::l161_structcat::FiniteCategory;"));
        assert!(code.contains("fn main()"));
    }

    #[test]
    fn test_manifold_registers_object() {
        let code = emit_source(
            "manifold Natural : Dim(1) where\n  section zero : Natural\n  proof p : ok",
        );
        assert!(code.contains("cat.add_object(\"Natural\");"));
        assert!(code.contains("cat.add_morphism(\"id_Natural\", \"Natural\", \"Natural\");"));
        assert!(code.contains("Manifold: Natural : Dim(1)"));
    }

    #[test]
    fn test_morphism_registers_arrow() {
        let code = emit_source("morphism inc : A -> B where\n  inc(x) = succ(x)\n  proof p : ok");
        assert!(code.contains("cat.add_morphism(\"inc\", \"A\", \"B\");"));
        assert!(code.contains("cat.add_morphism(\"id_A\", \"A\", \"A\");"));
        assert!(code.contains("cat.add_morphism(\"id_B\", \"B\", \"B\");"));
        assert!(code.contains("cat.set_composition(\"id_A\", \"inc\", \"inc\");"));
        assert!(code.contains("cat.set_composition(\"inc\", \"id_B\", \"inc\");"));
    }

    #[test]
    fn test_adjunction_registers_both_arms() {
        let code = emit_source(
            "adjunction FileIO where\n  \
             left open_file : Path -> FileHandle\n  \
             right close_file : FileHandle -> Path\n  \
             unit : forall p, close_file(open_file(p)) = p\n  \
             counit : forall h, open_file(close_file(h)) = h",
        );
        assert!(code.contains("cat.add_morphism(\"open_file\", \"Path\", \"FileHandle\");"));
        assert!(code.contains("cat.add_morphism(\"close_file\", \"FileHandle\", \"Path\");"));
        assert!(code.contains("cat.set_composition(\"close_file\", \"open_file\", \"id_Path\");"));
        assert!(
            code.contains("cat.set_composition(\"open_file\", \"close_file\", \"id_FileHandle\");")
        );
        assert!(code.contains("Adjunction: FileIO"));
    }

    #[test]
    fn test_orbit_registers_blessed_cycle() {
        let code = emit_source(
            "orbit event_loop : State -> State where\n  step(s) = next(s)\n  proof p : ok",
        );
        assert!(code.contains("Orbit (blessed cycle): event_loop"));
        assert!(
            code.contains("cat.add_morphism(\"event_loop_State_State\", \"State\", \"State\");")
        );
    }

    #[test]
    fn test_tensor_registers_parallel_components() {
        let code = emit_source(
            "tensor parallel(a, b) where\n  \
             disjoint : a intersect b = empty\n  \
             execute : a || b",
        );
        assert!(code.contains("Tensor: parallel"));
        assert!(code.contains("cat.add_object(\"a\");"));
        assert!(code.contains("cat.add_object(\"b\");"));
    }

    #[test]
    fn test_sheaf_registers_object_and_sections() {
        let code = emit_source(
            "sheaf Stack(T) where\n  \
             section empty : Stack(T)\n  \
             section push : T * Stack(T) -> Stack(T)\n  \
             proof p : ok",
        );
        assert!(code.contains("cat.add_object(\"Stack\");"));
        assert!(code.contains("Sheaf: Stack"));
    }

    #[test]
    fn test_full_natural_atp() {
        let source = r#"manifold Natural : Dim(1) where
  section zero : Natural
  section succ : Natural -> Natural
  proof bounded : forall n, dim(n) = 1

morphism add : Natural * Natural -> Natural where
  add(zero, n) = n
  add(succ(m), n) = succ(add(m, n))
  proof total : forall m n, exists k, add(m, n) = k

sheaf Stack(T) where
  section empty : Stack(T)
  section push : T * Stack(T) -> Stack(T)
  section pop : Stack(T) -> T * Stack(T)
  proof inverse : forall t s, pop(push(t, s)) = (t, s)

adjunction FileIO where
  left open_file : Path -> FileHandle
  right close_file : FileHandle -> Path
  unit : forall p, close_file(open_file(p)) = p
  counit : forall h, open_file(close_file(h)) = h

tensor parallel(a, b) where
  disjoint : a intersect b = empty
  execute : a || b"#;

        let code = emit_source(source);
        // All 6 declaration types should be present
        assert!(code.contains("cat.add_object(\"Natural\");"));
        assert!(code.contains("cat.add_morphism(\"add\""));
        assert!(code.contains("cat.add_object(\"Stack\");"));
        assert!(code.contains("Adjunction: FileIO"));
        assert!(code.contains("Tensor: parallel"));
        assert!(code.contains("fn main()"));
        assert!(code.contains("Ok(())"));
    }

    #[test]
    fn test_sanitize_ident() {
        assert_eq!(sanitize_ident("hello"), "hello");
        assert_eq!(sanitize_ident("3abc"), "_3abc");
        assert_eq!(sanitize_ident(""), "_unnamed");
        assert_eq!(sanitize_ident("a-b.c"), "a_dash_b_dot_c");
        assert_eq!(sanitize_ident("match"), "match_kw");
    }

    #[test]
    fn test_render_type_arrow() {
        let ty = TypeExpr::Arrow(
            Box::new(TypeExpr::Named("A".to_string())),
            Box::new(TypeExpr::Named("B".to_string())),
        );
        assert_eq!(render_type(&ty), "arrow_A_to_B");
    }

    #[test]
    fn test_render_type_product() {
        let ty = TypeExpr::Product(vec![
            TypeExpr::Named("X".to_string()),
            TypeExpr::Named("Y".to_string()),
        ]);
        assert_eq!(render_type(&ty), "prod_X_Y");
    }
}
