use omega_types::authority::AuthorityEffect;

pub trait AuthorityTagged {
    fn authority_effect(&self) -> AuthorityEffect;
    fn artifact_id(&self) -> &str;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AuthorityViolation {
    pub artifact_id: String,
    pub artifact_name: String,
    pub effect: AuthorityEffect,
}

pub struct NoAuthorityGuard;

impl NoAuthorityGuard {
    pub fn validate<T: AuthorityTagged>(
        artifact: &T,
        artifact_name: impl Into<String>,
    ) -> Result<(), AuthorityViolation> {
        let effect = artifact.authority_effect();
        if effect.is_none() {
            Ok(())
        } else {
            Err(AuthorityViolation {
                artifact_id: artifact.artifact_id().to_string(),
                artifact_name: artifact_name.into(),
                effect,
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::{AuthorityTagged, NoAuthorityGuard};
    use omega_types::authority::{
        AuthorityEffect, AuthorityTerminal, CertifiedAuthority, DescentWitness, IsAuth,
    };
    use omega_types::GuardEvidence;

    struct DiagnosticArtifact {
        id: String,
        authority_effect: AuthorityEffect,
    }

    impl AuthorityTagged for DiagnosticArtifact {
        fn authority_effect(&self) -> AuthorityEffect {
            self.authority_effect.clone()
        }

        fn artifact_id(&self) -> &str {
            &self.id
        }
    }

    #[test]
    fn no_authority_guard_accepts_none() {
        let artifact = DiagnosticArtifact {
            id: "probe:1".into(),
            authority_effect: AuthorityEffect::None,
        };
        assert!(NoAuthorityGuard::validate(&artifact, "probe").is_ok());
    }

    #[test]
    fn no_authority_guard_rejects_claimed_authority() {
        // There is no bare `AuthorityEffect::Certified`; to tag an artifact as
        // certified you must present the dependent pair (terminal + descent
        // witness). The guard still rejects any non-`None` effect.
        let terminal = AuthorityTerminal::ExactRuleDerived;
        let witness =
            DescentWitness::from_verified_replay(terminal, "descent:proposal-1", "blake3:cafe")
                .unwrap();
        let is_auth = IsAuth::decide(
            terminal,
            GuardEvidence::new_valid(["cand_01"], "K_carrier_01", "blake3:deadbeef"),
        )
        .unwrap();
        let certified = CertifiedAuthority::certify(terminal, witness, is_auth).unwrap();
        let artifact = DiagnosticArtifact {
            id: "proposal:1".into(),
            authority_effect: AuthorityEffect::Certified(certified),
        };
        let violation = NoAuthorityGuard::validate(&artifact, "proposal").unwrap_err();
        assert_eq!(violation.artifact_id, "proposal:1");
        assert!(violation.effect.is_certified());
    }
}
