/// Whether `source` satisfies a file-contract required substring.
///
/// Three historical pins name `std::ops` impls. The calculus source spells
/// those operations as `impl ... for FaceLambda`. Both lexical gates use this
/// so those pins are not recorded as missing when the impl is present.
pub fn source_satisfies_file_contract_substring(source: &str, required: &str) -> bool {
    if source.contains(required) {
        return true;
    }
    match required {
        "std::ops::Add for FaceLambda" => {
            source.contains("impl<F: PartialEq> Add for FaceLambda<F>")
        }
        "std::ops::Neg for FaceLambda" => source.contains("impl<F> Neg for FaceLambda<F>"),
        "std::ops::Mul<i64> for FaceLambda" => {
            source.contains("impl<F> Mul<i64> for FaceLambda<F>")
        }
        _ => false,
    }
}
