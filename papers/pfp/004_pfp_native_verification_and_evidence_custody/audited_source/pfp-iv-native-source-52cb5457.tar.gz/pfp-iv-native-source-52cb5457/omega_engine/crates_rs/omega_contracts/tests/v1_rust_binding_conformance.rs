//! AST declaration checks for each explicitly named Rust module.
//!
//! This is static binding evidence, not type checking, cfg/feature execution,
//! macro expansion, dependency resolution or behavior. Named public re-export
//! syntax is recorded; its target must still be checked by compilation.
//! Malformed/unsupported contracts fail, and recognized non-v1 documents remain
//! explicitly accounted without v1 or operational credit. Current unresolved
//! bindings are pinned as an exact finding baseline, not claimed complete.
//! AuthorityEffect: None.

use omega_contract_core::registry::v1_loader::{classify_contract_document, DocumentSchema};
use omega_contracts::registry::OmegaContractV1;
use std::collections::BTreeSet;
use std::path::{Path, PathBuf};
use syn::{Item, UseTree, Visibility};

fn use_names(tree: &UseTree, symbol: &str) -> bool {
    match tree {
        UseTree::Path(path) => use_names(&path.tree, symbol),
        UseTree::Name(name) => name.ident == symbol && symbol != "self",
        UseTree::Rename(rename) => rename.rename == symbol && symbol != "_",
        UseTree::Group(group) => group.items.iter().any(|tree| use_names(tree, symbol)),
        // A glob cannot identify a binding without independent target resolution.
        UseTree::Glob(_) => false,
    }
}

fn items_declare(items: &[Item], symbol: &str) -> bool {
    items.iter().any(|item| match item {
        Item::Const(item) => item.ident == symbol,
        Item::Enum(item) => item.ident == symbol,
        Item::Fn(item) => item.sig.ident == symbol,
        Item::Mod(item) => item.ident == symbol,
        Item::Static(item) => item.ident == symbol,
        Item::Struct(item) => item.ident == symbol,
        Item::Trait(item) => item.ident == symbol,
        Item::TraitAlias(item) => item.ident == symbol,
        Item::Type(item) => item.ident == symbol,
        Item::Union(item) => item.ident == symbol,
        Item::Use(item) if matches!(item.vis, Visibility::Public(_)) => {
            use_names(&item.tree, symbol)
        }
        _ => false,
    })
}

fn declares_symbol(src: &str, symbol: &str) -> Result<bool, String> {
    if symbol.is_empty() {
        return Err("RUST_SYMBOL_EMPTY".into());
    }
    let file = syn::parse_file(src).map_err(|error| format!("RUST_PARSE_FAILED: {error}"))?;
    Ok(items_declare(&file.items, symbol))
}

fn identifier(value: &str) -> bool {
    let mut chars = value.chars();
    chars
        .next()
        .is_some_and(|c| c.is_ascii_alphabetic() || c == '_')
        && chars.all(|c| c.is_ascii_alphanumeric() || c == '_')
}

fn read_module(path: &Path) -> Result<Vec<Item>, String> {
    let source = std::fs::read_to_string(path).map_err(|_| "RUST_MODULE_UNREADABLE".to_owned())?;
    syn::parse_file(&source)
        .map(|file| file.items)
        .map_err(|_| "RUST_PARSE_FAILED".to_owned())
}

/// Follow declarations from the actual crate library root, not orphan files
/// or an arbitrary identically named symbol elsewhere in the crate. Custom
/// path/cfg module declarations require explicit feature/path review.
fn bound_module_items(crates_root: &Path, krate: &str, module: &str) -> Result<Vec<Item>, String> {
    if !identifier(krate) || module.split("::").any(|part| !identifier(part)) {
        return Err("RUST_BINDING_PATH_INVALID".into());
    }
    let mut directory = crates_root.join(krate).join("src");
    let mut items =
        read_module(&directory.join("lib.rs")).map_err(|error| format!("{error}: {krate}::lib"))?;
    if module == "lib" {
        return Ok(items);
    }
    for part in module.split("::") {
        let declarations: Vec<_> = items
            .iter()
            .filter_map(|item| match item {
                Item::Mod(item) if item.ident == part => Some(item),
                _ => None,
            })
            .collect();
        if declarations.len() != 1 {
            return Err(format!(
                "RUST_MODULE_DECLARATION_MISSING_OR_AMBIGUOUS: {krate}::{module}"
            ));
        }
        let declaration = declarations[0];
        if declaration.attrs.iter().any(|attr| {
            attr.path().is_ident("path")
                || attr.path().is_ident("cfg")
                || attr.path().is_ident("cfg_attr")
        }) {
            return Err(format!(
                "RUST_MODULE_CONFIGURATION_UNREVIEWED: {krate}::{module}"
            ));
        }
        if let Some((_, inline)) = &declaration.content {
            let nested = inline.clone();
            directory = directory.join(part);
            items = nested;
        } else {
            let candidates = [
                directory.join(format!("{part}.rs")),
                directory.join(part).join("mod.rs"),
            ];
            let present: Vec<_> = candidates.iter().filter(|path| path.is_file()).collect();
            if present.len() != 1 {
                return Err(format!(
                    "RUST_MODULE_FILE_MISSING_OR_AMBIGUOUS: {krate}::{module}"
                ));
            }
            items =
                read_module(present[0]).map_err(|error| format!("{error}: {krate}::{module}"))?;
            directory = directory.join(part);
        }
    }
    Ok(items)
}

fn binding_declares(
    crates_root: &Path,
    krate: &str,
    module: &str,
    symbol: &str,
) -> Result<bool, String> {
    if !identifier(symbol) {
        return Err("RUST_SYMBOL_INVALID".into());
    }
    Ok(items_declare(
        &bound_module_items(crates_root, krate, module)?,
        symbol,
    ))
}

fn collect_contracts(dir: &Path, out: &mut Vec<PathBuf>) -> Result<(), String> {
    let entries = std::fs::read_dir(dir)
        .map_err(|error| format!("CONTRACT_DIRECTORY_UNREADABLE: {}: {error}", dir.display()))?;
    for entry in entries {
        let entry = entry.map_err(|error| format!("CONTRACT_ENTRY_UNREADABLE: {error}"))?;
        let kind = entry
            .file_type()
            .map_err(|error| format!("CONTRACT_ENTRY_TYPE_UNREADABLE: {error}"))?;
        let path = entry.path();
        if kind.is_symlink() {
            return Err(format!("CONTRACT_SYMLINK_UNREVIEWED: {}", path.display()));
        }
        if kind.is_dir() {
            collect_contracts(&path, out)?;
        } else if path
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n.ends_with(".contract.yaml"))
        {
            out.push(path);
        }
    }
    out.sort();
    Ok(())
}

fn parse_document(text: &str) -> Result<Option<OmegaContractV1>, String> {
    let (schema, _) = classify_contract_document(text)?;
    if schema != DocumentSchema::DescriptorV1 {
        return Ok(None);
    }
    serde_yaml::from_str(text)
        .map(Some)
        .map_err(|error| format!("CONTRACT_V1_INVALID: {error}"))
}

#[test]
fn declares_real_item_at_a_boundary() {
    for (source, symbol) in [
        (
            "pub struct InvariantDefectProfile {}",
            "InvariantDefectProfile",
        ),
        ("pub enum StepEffect { None }", "StepEffect"),
        ("pub fn judge() {}", "judge"),
    ] {
        assert!(declares_symbol(source, symbol).unwrap());
    }
}

#[test]
fn rejects_longer_identifiers_and_syntactically_invalid_declarations() {
    assert!(!declares_symbol("pub struct ProfileExtra {}", "Profile").unwrap());
    assert!(declares_symbol("superstruct Profile {}", "Profile")
        .unwrap_err()
        .starts_with("RUST_PARSE_FAILED"));
    assert!(declares_symbol("pub struct Profile {", "Profile").is_err());
}

#[test]
fn comments_strings_and_nested_modules_are_not_top_level_bindings() {
    for source in [
        "// struct Profile\nfn f() {}",
        "/*\nstruct Profile {}\n*/ fn f() {}",
        "const NOTE: &str = \"pub struct Profile {}\";",
        "const NOTE: &str = r###\"pub struct Profile {}\"###;",
        "mod unrelated { pub struct Profile {} }",
        "fn f() { struct Profile; }",
    ] {
        assert!(!declares_symbol(source, "Profile").unwrap(), "{source}");
    }
}

#[test]
fn public_reexports_match_only_the_exported_name() {
    assert!(declares_symbol("pub use foo::{Other, Profile};", "Profile").unwrap());
    assert!(declares_symbol("pub use foo::Original as Profile;", "Profile").unwrap());
    assert!(!declares_symbol("pub use foo::Original as Profile;", "Original").unwrap());
    assert!(!declares_symbol("pub use Profile::Other;", "Profile").unwrap());
    assert!(!declares_symbol("pub use foo::*;", "Profile").unwrap());
    assert!(!declares_symbol("use foo::Profile;", "Profile").unwrap());
    assert!(!declares_symbol("pub use foo::Other; // Profile", "Profile").unwrap());
}

#[test]
fn the_gate_has_teeth_a_missing_symbol_does_not_resolve() {
    let crates_root = Path::new(env!("CARGO_MANIFEST_DIR")).parent().unwrap();
    // This actual canonical binding is the positive, not the absent
    // omega_operator_algebra::InvariantDefectProfile declaration.
    assert!(binding_declares(
        crates_root,
        "omega_certifiers",
        "certificate_boundary",
        "AuthorityVerdict"
    )
    .unwrap());
    assert!(!binding_declares(
        crates_root,
        "omega_certifiers",
        "certificate_boundary",
        "GhostSymbolThatDoesNotExist999"
    )
    .unwrap());
    assert!(!binding_declares(
        crates_root,
        "omega_certifiers",
        "checked_packet",
        "AuthorityVerdict"
    )
    .unwrap());
    assert!(binding_declares(
        crates_root,
        "omega_operator_algebra",
        "invariant_defect_profile",
        "InvariantDefectProfile"
    )
    .is_err());
    assert!(binding_declares(
        crates_root,
        "../omega_certifiers",
        "certificate_boundary",
        "AuthorityVerdict"
    )
    .is_err());
    assert!(binding_declares(
        crates_root,
        "omega_certifiers",
        "ghost_module",
        "AuthorityVerdict"
    )
    .is_err());
}

#[test]
fn malformed_unknown_and_duplicate_contract_fields_cannot_be_silently_skipped() {
    for text in [
        "[not-a-contract",
        "schema_version: omega.contract.v99\ncontract_id: x",
        "schema_version: omega.contract.v1\ncontract_id: x\ncontract_id: y",
        "schema_version: omega.contract.v1\ncontract_id: x",
    ] {
        assert!(parse_document(text).is_err(), "{text}");
    }
    assert!(
        parse_document("schema_version: omega.file_contract.v1\ncontract_id: x")
            .unwrap()
            .is_none()
    );
}

#[test]
fn v1_rust_binding_findings_match_the_recorded_baseline() {
    let manifest = Path::new(env!("CARGO_MANIFEST_DIR"));
    let corpus = manifest.join("src/contract_canonical_definitions");
    let crates_root = manifest.parent().unwrap();
    let mut paths = Vec::new();
    collect_contracts(&corpus, &mut paths).expect("complete contract tree must be readable");
    assert!(!paths.is_empty(), "CONTRACT_POPULATION_EMPTY");
    let total = paths.len();
    let mut seen_ids = BTreeSet::new();
    let mut findings = Vec::new();
    let mut non_v1 = Vec::new();
    let (mut v1, mut invalid, mut checked) = (0, 0, 0);
    for path in paths {
        let text = std::fs::read_to_string(&path).expect("enumerated document must be readable");
        let contract = match parse_document(&text) {
            Ok(Some(contract)) => {
                v1 += 1;
                contract
            }
            Ok(None) => {
                non_v1.push(path);
                continue;
            }
            Err(error) => {
                invalid += 1;
                findings.push(format!("{}: {error}", path.display()));
                continue;
            }
        };
        if !seen_ids.insert(contract.contract_id.clone()) {
            findings.push(format!("CONTRACT_ID_DUPLICATE: {}", contract.contract_id));
        }
        let Some(binding) = &contract.rust_binding else {
            continue;
        };
        if binding.symbols.is_empty() {
            findings.push(format!(
                "RUST_BINDING_SYMBOLS_EMPTY: {}",
                contract.contract_id
            ));
        }
        for symbol in &binding.symbols {
            checked += 1;
            match binding_declares(crates_root, &binding.krate, &binding.module, symbol) {
                Ok(true) => {}
                Ok(false) => findings.push(format!(
                    "RUST_SYMBOL_UNRESOLVED: {}: {}::{}::{symbol}",
                    contract.contract_id, binding.krate, binding.module
                )),
                Err(error) => findings.push(format!("{}: {error}", contract.contract_id)),
            }
        }
    }
    assert_eq!(
        v1 + invalid + non_v1.len(),
        total,
        "CONTRACT_ACCOUNTING_MISMATCH"
    );
    assert!(checked > 0, "RUST_BINDING_POPULATION_EMPTY");
    findings.sort();
    findings.dedup();
    let expected: Vec<String> = include_str!("v1_rust_binding_findings_baseline.txt")
        .lines()
        .filter(|line| !line.trim().is_empty())
        .map(str::to_owned)
        .collect();
    assert!(!expected.is_empty(), "RUST_BINDING_BASELINE_EMPTY");
    assert_eq!(
        findings, expected,
        "static binding findings drifted ({v1} v1, {} non-v1 not validated); repair bindings or update the explicit baseline",
        non_v1.len()
    );
}
