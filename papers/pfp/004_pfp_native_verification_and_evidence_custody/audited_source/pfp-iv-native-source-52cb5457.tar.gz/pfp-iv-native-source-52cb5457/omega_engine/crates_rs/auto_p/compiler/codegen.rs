//! --- yaml
//! title: codegen
//! file_name: codegen.rs
//! file_location: ~/anomalon/anomalon_kernel/omega_core/src/compiler/codegen.rs
//! status: Diamond
//! invariance_level: Tier 1
//! logic_system: Self-Repair Cohomology
//! substrate: Rust
//! description: >
//!   Phase 6 / Backend of the AutoP compiler.
//!   Pipeline: 1-lexer, 2-parser, 3-boundary_check, 4-lifetime_check, 5-PTIR, 6-codegen.
//!   Translates a verified Topological AST (AtpModule) into executable Python code.
//!   Also generates Quantum IR (QIR) targeting Majorana topological modes.
//!   All identifiers are sanitized to prevent injection.
//! content_hash: dd2662c7b76af846b72575b1babcbec52e73ed6ec41bf0e5c862790d11b3ce2f
//! version: 2
//! ---

use super::parser::{AtpModule, BinOpKind, Declaration, Expr, TypeExpr};
use crate::omega_engine_os::types::{
    BoundaryType, CliffordCorrection, MeasurementBasis, TQCInstruction, TQCProgram,
};

/// Render a TypeExpr as a human-readable string for codegen output.
fn render_type_expr(ty: &TypeExpr) -> String {
    match ty {
        TypeExpr::Named(s) => sanitize_ident(s),
        TypeExpr::Arrow(a, b) => format!("{} -> {}", render_type_expr(a), render_type_expr(b)),
        TypeExpr::Product(parts) => {
            let strs: Vec<String> = parts.iter().map(render_type_expr).collect();
            format!("({})", strs.join(", "))
        }
        TypeExpr::Parameterized(name, args) => {
            let arg_strs: Vec<String> = args.iter().map(render_type_expr).collect();
            format!("{}({})", sanitize_ident(name), arg_strs.join(", "))
        }
    }
}

/// Sanitize an identifier for safe use in generated Python code.
/// Only allows alphanumeric characters and underscores. Strips everything else.
/// Prefixes with `_` if the result starts with a digit or is empty.
/// Appends `_` if the identifier matches a Python keyword.
fn sanitize_ident(name: &str) -> String {
    // Python reserved keywords
    const PY_KEYWORDS: &[&str] = &[
        "and", "as", "assert", "async", "await", "break", "case", "class", "continue", "def",
        "del", "elif", "else", "except", "False", "finally", "for", "from", "global", "if",
        "import", "in", "is", "lambda", "match", "None", "nonlocal", "not", "or", "pass", "raise",
        "return", "True", "try", "while", "with", "yield",
    ];

    let cleaned: String = name
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_')
        .collect();
    let mut result = if cleaned.is_empty() {
        "_unnamed".to_string()
    } else if cleaned.starts_with(|c: char| c.is_ascii_digit()) {
        format!("_{}", cleaned)
    } else {
        cleaned
    };

    // Check for Python keyword collision
    if PY_KEYWORDS.contains(&result.as_str()) {
        result.push('_');
    }

    result
}

/// Render an expression tree as a Python expression string.
fn render_expr_py(e: &Expr) -> String {
    match e {
        Expr::Var(s) => sanitize_ident(s),
        Expr::Int(n) => n.to_string(),
        Expr::App(name, args) => {
            let arg_strs: Vec<String> = args.iter().map(render_expr_py).collect();
            format!("{}({})", sanitize_ident(name), arg_strs.join(", "))
        }
        Expr::Tuple(elems) => {
            let elem_strs: Vec<String> = elems.iter().map(render_expr_py).collect();
            if elems.len() == 1 {
                format!("({},)", elem_strs[0])
            } else {
                format!("({})", elem_strs.join(", "))
            }
        }
        Expr::Compose(lhs, rhs) => {
            format!("compose({}, {})", render_expr_py(lhs), render_expr_py(rhs))
        }
        Expr::BinOp(lhs, op, rhs) => {
            let op_str = match op {
                BinOpKind::Add => "+",
                BinOpKind::Sub => "-",
                BinOpKind::Mul => "*",
                BinOpKind::Div => "/",
                BinOpKind::Pow => "**",
            };
            format!(
                "({} {} {})",
                render_expr_py(lhs),
                op_str,
                render_expr_py(rhs)
            )
        }
        Expr::Neg(inner) => format!("(-{})", render_expr_py(inner)),
    }
}

/// Entry point for code generation.
/// Takes a verified AtpModule and emits Python code.
///
/// All declaration names are sanitized before emission.
/// The generated code uses asyncio for tensor/orbit constructs
/// and context managers for adjunctions.
pub fn generate_python(module: &AtpModule) -> String {
    let mut out = String::new();

    // Core imports for the generated python file.
    out.push_str("# --- AutoP Generated Source ---\n");
    out.push_str("# Logic System: Self-Repair Cohomology\n");
    out.push_str("import asyncio\n");
    out.push_str("from anomalon.quantum import VaultGate, apply_unitary, qalloc, qfree\n");
    out.push_str("from anomalon.topological import compose\n\n");

    let mut symbol_registry: std::collections::HashSet<String> = std::collections::HashSet::new();

    let mut declare_symbol = |raw: &str| -> String {
        let base = sanitize_ident(raw);
        let mut unique = base.clone();
        let mut counter = 1;
        while !symbol_registry.insert(unique.clone()) {
            unique = format!("{}_{}", base, counter);
            counter += 1;
        }
        unique
    };

    for decl in &module.declarations {
        match decl {
            Declaration::Manifold(m) => {
                let name = declare_symbol(&m.name);
                out.push_str(&format!("class {}:\n", name));
                out.push_str(&format!(
                    "    \"\"\"Manifold: Dim({bound})\"\"\"\n",
                    bound = m.dim_bound
                ));
                out.push_str(&format!("    _DIM_BOUND = {}\n\n", m.dim_bound));
            }
            Declaration::Morphism(m) => {
                let name = declare_symbol(&m.name);
                out.push_str(&format!("def {}(*args):\n", name));
                out.push_str("    \"\"\"Topological Morphism\"\"\"\n");
                out.push_str("    # The boundary checker verified safety. Executing.\n");
                if m.equations.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str("    raise NotImplementedError('Equation to python logic mapping pending')\n\n");
                }
            }
            Declaration::Adjunction(a) => {
                let name = declare_symbol(&a.name);
                let left_name = declare_symbol(&a.left.name);
                let right_name = declare_symbol(&a.right.name);
                out.push_str(&format!("class {}_Context:\n", name));
                out.push_str("    \"\"\"Categorical Adjunction (F -| G)\"\"\"\n");
                out.push_str("    def __init__(self, target):\n");
                out.push_str("        self.target = target\n");
                out.push_str("    def __enter__(self):\n");
                out.push_str(&format!("        # Execute left adjoint: {}\n", left_name));
                out.push_str("        return self.target\n");
                out.push_str("    def __exit__(self, exc_type, exc_val, exc_tb):\n");
                out.push_str(&format!(
                    "        # Execute right adjoint: {}\n",
                    right_name
                ));
                out.push_str("        pass\n\n");
            }
            Declaration::Tensor(t) => {
                let name = sanitize_ident(&t.name);
                out.push_str(&format!("async def run_tensor_{}():\n", name));
                out.push_str("    \"\"\"Parallel Tensor Execution\"\"\"\n");
                out.push_str("    # The disjointness proof guarantees no quantum crosstalk.\n");
                out.push_str("    tasks = [\n");
                for exec in &t.execute_expr {
                    let exec_name = declare_symbol(exec);
                    out.push_str(&format!("        asyncio.create_task({}()),\n", exec_name));
                }
                out.push_str("    ]\n");
                out.push_str("    try:\n");
                out.push_str("        await asyncio.gather(*tasks, return_exceptions=True)\n");
                out.push_str("    except Exception:\n");
                out.push_str("        for t in tasks:\n");
                out.push_str("            t.cancel()\n");
                out.push_str("        raise\n\n");
            }
            Declaration::Sheaf(s) => {
                let name = declare_symbol(&s.name);
                out.push_str(&format!("class {}:\n", name));
                out.push_str("    \"\"\"Sheaf Definition\"\"\"\n");
                out.push_str("    pass\n\n");
            }
            Declaration::Orbit(o) => {
                let name = sanitize_ident(&o.name);
                out.push_str(&format!(
                    "async def orbit_{}(state, max_iterations=None):\n",
                    name
                ));
                out.push_str("    \"\"\"Blessed Event Loop (topological orbit)\"\"\"\n");
                out.push_str("    _iter = 0\n");
                out.push_str("    while max_iterations is None or _iter < max_iterations:\n");
                out.push_str("        state = await step(state)\n");
                out.push_str("        _iter += 1\n");
                out.push_str("        # Yield control to prevent blocking\n");
                out.push_str("        await asyncio.sleep(0)\n");
                out.push_str("    return state\n\n");
            }
            Declaration::Functor(f) => {
                let name = declare_symbol(&f.name);
                let src = declare_symbol(&f.source_cat);
                let tgt = declare_symbol(&f.target_cat);
                out.push_str(&format!("class {}:\n", name));
                out.push_str(&format!("    \"\"\"Functor: {} -> {}\"\"\"\n", src, tgt));
                out.push_str(&format!("    _SOURCE = '{}'\n", src));
                out.push_str(&format!("    _TARGET = '{}'\n", tgt));
                if f.object_map.is_empty() && f.morphism_map.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str("    OBJECT_MAP = {\n");
                    for (s, t) in &f.object_map {
                        out.push_str(&format!(
                            "        '{}': '{}',\n",
                            declare_symbol(s),
                            declare_symbol(t)
                        ));
                    }
                    out.push_str("    }\n");
                    out.push_str("    MORPHISM_MAP = {\n");
                    for (s, t) in &f.morphism_map {
                        out.push_str(&format!(
                            "        '{}': '{}',\n",
                            declare_symbol(s),
                            declare_symbol(t)
                        ));
                    }
                    out.push_str("    }\n\n");
                }
            }
            Declaration::Category(c) => {
                let name = declare_symbol(&c.name);
                out.push_str(&format!("class {}:\n", name));
                out.push_str("    \"\"\"Category Definition\"\"\"\n");
                if c.objects.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str(&format!(
                        "    OBJECTS = [{}]\n\n",
                        c.objects
                            .iter()
                            .map(|o| format!("'{}'", declare_symbol(o)))
                            .collect::<Vec<_>>()
                            .join(", ")
                    ));
                }
            }
            Declaration::Cohomology(ch) => {
                let name = declare_symbol(&ch.name);
                out.push_str(&format!("def {}(*args):\n", name));
                out.push_str("    \"\"\"Cohomology Operator\"\"\"\n");
                if ch.equations.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    for eq in &ch.equations {
                        out.push_str(&format!(
                            "    # {} = {}\n",
                            render_expr_py(&eq.lhs),
                            render_expr_py(&eq.rhs)
                        ));
                    }
                    out.push_str("    raise NotImplementedError('Equation to python logic mapping pending')\n\n");
                }
            }
            Declaration::NaturalTransformation(nt) => {
                let name = sanitize_ident(&nt.name);
                let src = sanitize_ident(&nt.source_functor);
                let tgt = sanitize_ident(&nt.target_functor);
                out.push_str(&format!("class {}:\n", name));
                out.push_str(&format!(
                    "    \"\"\"Natural Transformation: {} ⟹ {}\"\"\"\n",
                    src, tgt
                ));
                out.push_str(&format!("    _SOURCE_FUNCTOR = '{}'\n", src));
                out.push_str(&format!("    _TARGET_FUNCTOR = '{}'\n", tgt));
                if nt.components.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str("    COMPONENTS = {\n");
                    for comp in &nt.components {
                        out.push_str(&format!(
                            "        '{}': '{}',\n",
                            sanitize_ident(&comp.name),
                            render_type_expr(&comp.type_sig)
                        ));
                    }
                    out.push_str("    }\n\n");
                }
            }
            Declaration::Operad(op) => {
                let name = sanitize_ident(&op.name);
                out.push_str(&format!("class {}:\n", name));
                out.push_str("    \"\"\"Operad: n-ary multi-category composition\"\"\"\n");
                if op.sections.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str("    SECTIONS = [\n");
                    for sec in &op.sections {
                        out.push_str(&format!(
                            "        ('{}', '{}'),\n",
                            sanitize_ident(&sec.name),
                            render_type_expr(&sec.type_sig)
                        ));
                    }
                    out.push_str("    ]\n");
                    out.push_str("    @staticmethod\n");
                    out.push_str("    def compose(*args):\n");
                    out.push_str("        \"\"\"Operadic composition\"\"\"\n");
                    out.push_str(
                        "        raise NotImplementedError('Operadic composition pending')\n\n",
                    );
                }
            }
            Declaration::Bundle(b) => {
                let name = sanitize_ident(&b.name);
                let fiber = render_type_expr(&b.fiber);
                let base = render_type_expr(&b.base);
                out.push_str(&format!("class {}:\n", name));
                out.push_str(&format!(
                    "    \"\"\"Fiber Bundle: {} → {}\"\"\"\n",
                    fiber, base
                ));
                out.push_str(&format!("    _FIBER = '{}'\n", fiber));
                out.push_str(&format!("    _BASE = '{}'\n", base));
                if b.sections.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str("    SECTIONS = [\n");
                    for sec in &b.sections {
                        out.push_str(&format!(
                            "        ('{}', '{}'),\n",
                            sanitize_ident(&sec.name),
                            render_type_expr(&sec.type_sig)
                        ));
                    }
                    out.push_str("    ]\n\n");
                }
            }
            Declaration::Topos(t) => {
                let name = sanitize_ident(&t.name);
                out.push_str(&format!("class {}:\n", name));
                out.push_str(
                    "    \"\"\"Topos: Cartesian closed category with subobject classifier\"\"\"\n",
                );
                if t.objects.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str(&format!(
                        "    OBJECTS = [{}]\n",
                        t.objects
                            .iter()
                            .map(|o| format!("'{}'", sanitize_ident(o)))
                            .collect::<Vec<_>>()
                            .join(", ")
                    ));
                    out.push_str(&format!("    _MORPHISM_COUNT = {}\n\n", t.morphisms.len()));
                }
            }
            Declaration::Presheaf(p) => {
                let name = sanitize_ident(&p.name);
                out.push_str(&format!("class {}:\n", name));
                out.push_str("    \"\"\"Presheaf Definition\"\"\"\n");
                if !p.type_params.is_empty() {
                    out.push_str(&format!(
                        "    _TYPE_PARAMS = [{}]\n",
                        p.type_params
                            .iter()
                            .map(|t| format!("'{}'", sanitize_ident(t)))
                            .collect::<Vec<_>>()
                            .join(", ")
                    ));
                }
                if p.sections.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    out.push_str("    SECTIONS = [\n");
                    for sec in &p.sections {
                        out.push_str(&format!(
                            "        ('{}', '{}'),\n",
                            sanitize_ident(&sec.name),
                            render_type_expr(&sec.type_sig)
                        ));
                    }
                    out.push_str("    ]\n\n");
                }
            }
            Declaration::Operator(op) => {
                let name = sanitize_ident(&op.name);
                out.push_str(&format!("def {}(*args):\n", name));
                out.push_str("    \"\"\"Operator\"\"\"\n");
                if op.equations.is_empty() {
                    out.push_str("    pass\n\n");
                } else {
                    for eq in &op.equations {
                        out.push_str(&format!(
                            "    # {} = {}\n",
                            render_expr_py(&eq.lhs),
                            render_expr_py(&eq.rhs)
                        ));
                    }
                    out.push_str(
                        "    raise NotImplementedError('Operator equation mapping pending')\n\n",
                    );
                }
            }
            Declaration::Network(n) => {
                let name = sanitize_ident(&n.name);
                out.push_str(&format!("# Network topology: {}\n", name));
                for node in &n.nodes {
                    let node_name = sanitize_ident(node);
                    out.push_str(&format!("# - node: {}\n", node_name));
                }
                out.push('\n');
            }
            Declaration::Deploy(d) => {
                let morph = sanitize_ident(&d.morphism);
                let target = sanitize_ident(&d.target_node);
                out.push_str(&format!("# deploy {} on {}\n\n", morph, target));
            }
        }
    }

    out
}

/// Entry point for Quantum Intermediate Representation (QIR) generation.
/// Translates the verified topological AST into Microsoft's LLVM-based QIR format.
/// Emits specific type definitions for Majorana topological modes alongside
/// standard Qubit types, bypassing standard VQE bloat for pure topological compilation.
pub fn generate_qir(module: &AtpModule) -> String {
    let mut out = String::new();

    // QIR / LLVM IR Header
    out.push_str("; ModuleID = 'anomalon_topological_qir'\n");
    out.push_str("source_filename = \"anomalon_kernel\"\n\n");

    // LLVM Module Flags
    out.push_str("!llvm.module.flags = !{!0, !1, !2}\n");
    out.push_str("!0 = !{i32 1, !\"qir_major_version\", i32 1}\n");
    out.push_str("!1 = !{i32 7, !\"qir_minor_version\", i32 0}\n");
    out.push_str("!2 = !{i32 1, !\"dynamic_qubit_management\", i1 false}\n\n");

    // QIR Standard Types
    out.push_str("%Array = type opaque\n");
    out.push_str("%Callable = type opaque\n");
    out.push_str("%Qubit = type opaque\n");
    out.push_str("%Result = type opaque\n");

    // Microsoft / Topological Custom Extensions
    out.push_str("%MajoranaMode = type opaque\n\n");

    // Declare external topological gate implementations intrinsically provided by the QPU hardware
    out.push_str("declare void @__quantum__qis__braid__body(%MajoranaMode*, %MajoranaMode*)\n");
    out.push_str(
        "declare %Result* @__quantum__qis__measure__body(%MajoranaMode*, %MajoranaMode*)\n",
    );
    out.push_str("declare void @llvm.sideeffect()\n\n");

    for decl in &module.declarations {
        match decl {
            Declaration::Manifold(m) => {
                let name = sanitize_ident(&m.name);
                out.push_str(&format!("; Manifold definition: {}\n", name));
                out.push_str(&format!("@{} = global i64 {}\n\n", name, m.dim_bound));
            }
            Declaration::Morphism(m) => {
                let name = sanitize_ident(&m.name);
                out.push_str(&format!(
                    "define void @{}(%MajoranaMode* %src, %MajoranaMode* %tgt) {{\n",
                    name
                ));
                out.push_str("entry:\n");
                out.push_str("  ; Execute Topological Morphism via braiding\n");
                out.push_str("  call void @__quantum__qis__braid__body(%MajoranaMode* %src, %MajoranaMode* %tgt)\n");
                out.push_str("  ret void\n");
                out.push_str("}\n\n");
            }
            Declaration::Adjunction(a) => {
                let left_name = sanitize_ident(&a.left.name);
                let right_name = sanitize_ident(&a.right.name);
                out.push_str(&format!(
                    "; Adjunction verified algebraically: f -| g => {} -| {}\n\n",
                    left_name, right_name
                ));
            }
            Declaration::Tensor(t) => {
                let name = sanitize_ident(&t.name);
                out.push_str(&format!("define void @tensor_{}() {{\n", name));
                out.push_str("entry:\n");
                out.push_str("  ; Tensor parallel execution (No crosstalk guaranteed)\n");
                if !t.execute_expr.is_empty() {
                    out.push_str("  %tmp = alloca %MajoranaMode\n");
                }
                for exec in &t.execute_expr {
                    let exec_name = sanitize_ident(exec);
                    out.push_str(&format!(
                        "  call void @{}(%MajoranaMode* %tmp, %MajoranaMode* %tmp)\n",
                        exec_name
                    ));
                }
                out.push_str("  ret void\n");
                out.push_str("}\n\n");
            }
            Declaration::Sheaf(_) => {
                out.push_str("; Sheaf (skipped in QIR direct emitting)\n\n");
            }
            Declaration::Orbit(o) => {
                let name = sanitize_ident(&o.name);
                out.push_str(&format!("define void @orbit_{}() {{\n", name));
                out.push_str("entry:\n");
                out.push_str("  br label %loop\n");
                out.push_str("loop:\n");
                out.push_str(&format!("  ; Evaluate orbit {}\n", name));
                out.push_str("  call void @llvm.sideeffect()\n");
                out.push_str("  br label %loop\n");
                out.push_str("}\n\n");
            }
            Declaration::Functor(f) => {
                let name = sanitize_ident(&f.name);
                out.push_str(&format!(
                    "; Functor: {} : {} -> {}\n",
                    name,
                    sanitize_ident(&f.source_cat),
                    sanitize_ident(&f.target_cat)
                ));
                for (s, t) in &f.object_map {
                    out.push_str(&format!(
                        ";   {} -> {}\n",
                        sanitize_ident(s),
                        sanitize_ident(t)
                    ));
                }
                out.push('\n');
            }
            Declaration::Category(c) => {
                let name = sanitize_ident(&c.name);
                out.push_str(&format!(
                    "; Category: {} ({} objects)\n\n",
                    name,
                    c.objects.len()
                ));
            }
            Declaration::Cohomology(ch) => {
                let name = sanitize_ident(&ch.name);
                out.push_str(&format!(
                    "define void @{}(%MajoranaMode* %src, %MajoranaMode* %tgt) {{\n",
                    name
                ));
                out.push_str("entry:\n");
                out.push_str("  ; Execute Cohomology Operator via braiding\n");
                out.push_str("  call void @__quantum__qis__braid__body(%MajoranaMode* %src, %MajoranaMode* %tgt)\n");
                out.push_str("  ret void\n");
                out.push_str("}\n\n");
            }
            Declaration::NaturalTransformation(nt) => {
                let name = sanitize_ident(&nt.name);
                out.push_str(&format!(
                    "; NaturalTransformation: {} : {} ⟹ {}\n",
                    name,
                    sanitize_ident(&nt.source_functor),
                    sanitize_ident(&nt.target_functor)
                ));
                for comp in &nt.components {
                    out.push_str(&format!(
                        ";   component {}: {}\n",
                        sanitize_ident(&comp.name),
                        render_type_expr(&comp.type_sig)
                    ));
                }
                out.push('\n');
            }
            Declaration::Operad(op) => {
                let name = sanitize_ident(&op.name);
                out.push_str(&format!("define void @operad_{}() {{\n", name));
                out.push_str("entry:\n");
                out.push_str("  ; Operadic composition via topological braiding\n");
                if op.sections.len() > 1 {
                    out.push_str("  %tmp = alloca %MajoranaMode\n");
                }
                for (i, sec) in op.sections.iter().enumerate() {
                    if i + 1 < op.sections.len() {
                        out.push_str(&format!(
                            "  ; braid {} ⊗ {}\n",
                            sanitize_ident(&sec.name),
                            sanitize_ident(&op.sections[i + 1].name)
                        ));
                        out.push_str(
                            "  call void @__quantum__qis__braid__body(%MajoranaMode* %tmp, %MajoranaMode* %tmp)\n"
                        );
                    }
                }
                out.push_str("  ret void\n");
                out.push_str("}\n\n");
            }
            Declaration::Bundle(b) => {
                let name = sanitize_ident(&b.name);
                out.push_str(&format!(
                    "; Bundle: {} : {} → {}\n",
                    name,
                    render_type_expr(&b.fiber),
                    render_type_expr(&b.base)
                ));
                for sec in &b.sections {
                    out.push_str(&format!(
                        ";   section {}: {}\n",
                        sanitize_ident(&sec.name),
                        render_type_expr(&sec.type_sig)
                    ));
                }
                out.push('\n');
            }
            Declaration::Topos(t) => {
                let name = sanitize_ident(&t.name);
                out.push_str(&format!(
                    "; Topos: {} ({} objects, {} morphisms)\n\n",
                    name,
                    t.objects.len(),
                    t.morphisms.len()
                ));
            }
            Declaration::Presheaf(p) => {
                let name = sanitize_ident(&p.name);
                out.push_str(&format!(
                    "; Presheaf: {} ({} sections)\n",
                    name,
                    p.sections.len()
                ));
                for sec in &p.sections {
                    out.push_str(&format!(
                        ";   {}: {}\n",
                        sanitize_ident(&sec.name),
                        render_type_expr(&sec.type_sig)
                    ));
                }
                out.push('\n');
            }
            Declaration::Operator(op) => {
                let name = sanitize_ident(&op.name);
                out.push_str(&format!(
                    "define void @{}(%MajoranaMode* %src, %MajoranaMode* %tgt) {{\n",
                    name
                ));
                out.push_str("entry:\n");
                out.push_str("  ; Execute Operator via braiding\n");
                out.push_str("  call void @__quantum__qis__braid__body(%MajoranaMode* %src, %MajoranaMode* %tgt)\n");
                out.push_str("  ret void\n");
                out.push_str("}\n\n");
            }
            Declaration::Network(n) => {
                let name = sanitize_ident(&n.name);
                out.push_str(&format!("; Network topology: {}\n", name));
                for node in &n.nodes {
                    out.push_str(&format!(";   node: {}\n", sanitize_ident(node)));
                }
                out.push('\n');
            }
            Declaration::Deploy(d) => {
                out.push_str(&format!(
                    "; deploy {} on {}\n\n",
                    sanitize_ident(&d.morphism),
                    sanitize_ident(&d.target_node)
                ));
            }
        }
    }

    out
}

/// Generate TQC-specific QIR from a compiled topological quantum program.
///
/// Emits LLVM IR with TQC-specific intrinsics:
/// - `@__tqc__braid` for topological braid operations
/// - `@__tqc__prepare_magic` for magic state distillation
/// - `@__tqc__gate_teleport` for gate teleportation
/// - `@__tqc__measure` for measurement
/// - `@__tqc__regime_boundary` for regime boundary markers
/// - `@__tqc__entangle` for measurement-based entanglement
///
/// Each regime boundary is annotated with its l1 error contribution.
pub fn generate_tqc_qir(program: &TQCProgram) -> String {
    let mut out = String::new();

    // QIR / LLVM IR Header
    out.push_str("; ModuleID = 'anomalon_tqc_compiled'\n");
    out.push_str("source_filename = \"anomalon_kernel_tqc\"\n\n");

    // Type definitions
    out.push_str("%MajoranaMode = type opaque\n");
    out.push_str("%Result = type opaque\n\n");

    // TQC-specific external declarations
    out.push_str("; TQC Intrinsics\n");
    out.push_str("declare void @__tqc__braid(%MajoranaMode*, %MajoranaMode*, i32, i1)\n");
    out.push_str("declare void @__tqc__prepare_magic(%MajoranaMode*, i32)\n");
    out.push_str("declare void @__tqc__gate_teleport(%MajoranaMode*, %MajoranaMode*)\n");
    out.push_str("declare i1 @__tqc__measure(%MajoranaMode*)\n");
    out.push_str("declare void @__tqc__regime_boundary(i32)\n");
    out.push_str("declare void @__tqc__entangle(%MajoranaMode*, %MajoranaMode*)\n");
    out.push_str("declare void @__tqc__correction(%MajoranaMode*, i32)\n\n");

    // Program metadata
    out.push_str(&format!(
        "; TQC Program: {} qubits, {} ancillas, T-count = {}\n",
        program.n_qubits, program.n_ancillas, program.t_count
    ));
    out.push_str(&format!("; l1 error budget = {:.6e}\n", program.l1_budget));
    out.push_str(&format!(
        "; regime boundaries = {}\n\n",
        program.regime_boundaries.len()
    ));

    // Main function
    out.push_str("define void @tqc_main() {\n");
    out.push_str("entry:\n");

    // Allocate qubits and ancillas
    for q in 0..(program.n_qubits + program.n_ancillas) {
        out.push_str(&format!("  %q{} = alloca %MajoranaMode\n", q));
    }
    out.push('\n');

    // Track boundary index for annotation
    let mut boundary_idx = 0usize;

    // Emit instructions
    for (i, instr) in program.instructions.iter().enumerate() {
        // Check if this instruction is at a regime boundary
        while boundary_idx < program.regime_boundaries.len()
            && program.regime_boundaries[boundary_idx].instruction_index == i
        {
            let boundary = &program.regime_boundaries[boundary_idx];
            let direction = match boundary.boundary_type {
                BoundaryType::TopologicalToExposed => "topo->exposed",
                BoundaryType::ExposedToTopological => "exposed->topo",
            };
            out.push_str(&format!(
                "  ; REGIME BOUNDARY {}: {} (l1 += {:.6e})\n",
                boundary_idx, direction, boundary.error_contribution
            ));
            out.push_str(&format!(
                "  call void @__tqc__regime_boundary(i32 {})\n",
                boundary_idx
            ));
            boundary_idx += 1;
        }

        match instr {
            TQCInstruction::Braid { qubit, word } => {
                out.push_str(&format!(
                    "  ; Braid on qubit {} ({} generators)\n",
                    qubit,
                    word.generators.len()
                ));
                for gen in &word.generators {
                    out.push_str(&format!(
                        "  call void @__tqc__braid(%MajoranaMode* %q{}, %MajoranaMode* %q{}, i32 {}, i1 {})\n",
                        qubit, qubit,
                        gen.strand_index,
                        if gen.inverse { "true" } else { "false" }
                    ));
                }
            }
            TQCInstruction::PrepareMagicState { ancilla, rounds } => {
                out.push_str(&format!(
                    "  ; Magic state distillation: {} rounds on ancilla {}\n",
                    rounds, ancilla
                ));
                out.push_str(&format!(
                    "  call void @__tqc__prepare_magic(%MajoranaMode* %q{}, i32 {})\n",
                    ancilla, rounds
                ));
            }
            TQCInstruction::CNOT {
                control: target,
                target: ancilla,
            } => {
                out.push_str(&format!(
                    "  ; Gate teleportation: target={}, ancilla={}\n",
                    target, ancilla
                ));
                out.push_str(&format!(
                    "  call void @__tqc__gate_teleport(%MajoranaMode* %q{}, %MajoranaMode* %q{})\n",
                    target, ancilla
                ));
            }
            TQCInstruction::Measure { qubit, basis } => {
                let basis_str = match basis {
                    MeasurementBasis::Computational => "Z",
                    MeasurementBasis::Hadamard => "X",
                };
                out.push_str(&format!(
                    "  ; Measure qubit {} in {} basis\n",
                    qubit, basis_str
                ));
                out.push_str(&format!(
                    "  %m{} = call i1 @__tqc__measure(%MajoranaMode* %q{})\n",
                    i, qubit
                ));
                out.push_str(&format!(
                    "  call void @__tqc__regime_boundary(i32 %m{})\n", // Pin the measurement to a boundary
                    i
                ));
            }
            TQCInstruction::ConditionalCorrection {
                target_qubit: qubit,
                correction,
                ..
            } => {
                let corr_code = match correction {
                    CliffordCorrection::None => 0,
                    CliffordCorrection::SGate => 1,
                    CliffordCorrection::PauliZ => 2,
                };
                out.push_str(&format!(
                    "  ; Classical correction on qubit {} (code={})\n",
                    qubit, corr_code
                ));
                out.push_str(&format!(
                    "  call void @__tqc__correction(%MajoranaMode* %q{}, i32 {})\n",
                    qubit, corr_code
                ));
            }
            TQCInstruction::MeasurementEntangle { control, target } => {
                out.push_str(&format!(
                    "  ; Measurement-based entanglement: control={}, target={}\n",
                    control, target
                ));
                out.push_str(&format!(
                    "  call void @__tqc__entangle(%MajoranaMode* %q{}, %MajoranaMode* %q{})\n",
                    control, target
                ));
            }
        }
    }

    out.push_str("  ret void\n");
    out.push_str("}\n");

    out
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compiler::lexer::tokenize;
    use crate::compiler::parser::parse;

    /// Helper: lex -> parse -> codegen.
    fn codegen_source(source: &str) -> String {
        let tokens = tokenize(source);
        let module = parse(&tokens).expect("parse failed");
        generate_python(&module)
    }

    #[test]
    fn test_empty_module_generates_header() {
        let code = codegen_source("");
        assert!(code.contains("# --- AutoP Generated Source ---"));
        assert!(code.contains("import asyncio"));
    }

    #[test]
    fn test_manifold_generates_class() {
        let code = codegen_source(
            "manifold Natural : Dim(1) where\n  section zero : Natural\n  proof p : ok",
        );
        assert!(code.contains("class Natural:"));
        assert!(code.contains("_DIM_BOUND = 1"));
    }

    #[test]
    fn test_morphism_generates_function() {
        let code =
            codegen_source("morphism inc : A -> B where\n  inc(x) = succ(x)\n  proof p : ok");
        assert!(code.contains("def inc(*args):"));
        assert!(code.contains("NotImplementedError"));
    }

    #[test]
    fn test_morphism_no_equations_generates_pass() {
        let code = codegen_source("morphism noop : A -> B where\n  proof p : ok");
        assert!(code.contains("def noop(*args):"));
        assert!(code.contains("    pass"));
    }

    #[test]
    fn test_adjunction_generates_context_manager() {
        let code = codegen_source(
            "adjunction FileIO where\n  \
             left open_file : Path -> FileHandle\n  \
             right close_file : FileHandle -> Path\n  \
             unit : forall p, close_file(open_file(p)) = p\n  \
             counit : forall h, open_file(close_file(h)) = h",
        );
        assert!(code.contains("class FileIO_Context:"));
        assert!(code.contains("__enter__"));
        assert!(code.contains("__exit__"));
        assert!(code.contains("left adjoint: open_file"));
        assert!(code.contains("right adjoint: close_file"));
    }

    #[test]
    fn test_tensor_generates_async() {
        let code = codegen_source(
            "tensor parallel(a, b) where\n  \
             disjoint : a intersect b = empty\n  \
             execute : a || b",
        );
        assert!(code.contains("async def run_tensor_parallel():"));
        assert!(code.contains("asyncio.create_task(a()),"));
        assert!(code.contains("asyncio.create_task(b()),"));
        assert!(code.contains("await asyncio.gather(*tasks, return_exceptions=True)"));
    }

    #[test]
    fn test_sheaf_generates_class() {
        let code =
            codegen_source("sheaf Stack(T) where\n  section empty : Stack(T)\n  proof p : ok");
        assert!(code.contains("class Stack:"));
        assert!(code.contains("Sheaf Definition"));
    }

    #[test]
    fn test_orbit_generates_event_loop() {
        let code = codegen_source(
            "orbit event_loop : State -> State where\n  step(s) = next(s)\n  proof p : ok",
        );
        assert!(code.contains("async def orbit_event_loop(state, max_iterations=None):"));
        assert!(code.contains("while max_iterations is None or _iter < max_iterations:"));
        assert!(code.contains("return state"));
        assert!(code.contains("await asyncio.sleep(0)"));
    }

    #[test]
    fn test_full_module_codegen() {
        let code = codegen_source(
            r#"manifold M : Dim(2) where
  section x : M
  proof p : ok

morphism f : M -> M where
  f(x) = x
  proof pf : ok

sheaf S(T) where
  section val : S(T)
  proof ps : ok"#,
        );
        assert!(code.contains("class M:"));
        assert!(code.contains("def f(*args):"));
        assert!(code.contains("class S:"));
    }

    #[test]
    fn test_sanitize_ident_normal() {
        assert_eq!(sanitize_ident("hello"), "hello");
        assert_eq!(sanitize_ident("my_var"), "my_var");
        assert_eq!(sanitize_ident("x1"), "x1");
    }

    #[test]
    fn test_sanitize_ident_digit_prefix() {
        assert_eq!(sanitize_ident("3abc"), "_3abc");
    }

    #[test]
    fn test_sanitize_ident_empty() {
        assert_eq!(sanitize_ident(""), "_unnamed");
    }

    #[test]
    fn test_sanitize_ident_special_chars() {
        assert_eq!(sanitize_ident("a-b.c"), "abc");
        assert_eq!(sanitize_ident("!@#"), "_unnamed");
    }

    #[test]
    fn test_dim_bound_values() {
        // Verify various dim bounds are correctly passed through
        for dim in [1, 2, 3, 5, 11, 26] {
            let source = format!(
                "manifold M : Dim({}) where\n  section x : M\n  proof p : ok",
                dim
            );
            let code = codegen_source(&source);
            assert!(
                code.contains(&format!("_DIM_BOUND = {}", dim)),
                "missing dim bound {} in output",
                dim
            );
        }
    }

    /// Helper: lex -> parse -> qir.
    fn codegen_qir_source(source: &str) -> String {
        let tokens = tokenize(source);
        let module = parse(&tokens).expect("parse failed");
        generate_qir(&module)
    }

    #[test]
    fn test_qir_generation() {
        let source = r#"
        morphism teleport : A -> B where
          teleport(x) = y
          proof p : ok
        "#;
        let qir_code = codegen_qir_source(source);
        assert!(qir_code.contains("; ModuleID = 'anomalon_topological_qir'"));
        assert!(qir_code.contains("%Qubit = type opaque"));
        assert!(qir_code.contains("%MajoranaMode = type opaque"));
        assert!(
            qir_code.contains("define void @teleport(%MajoranaMode* %src, %MajoranaMode* %tgt)")
        );
        assert!(qir_code.contains(
            "call void @__quantum__qis__braid__body(%MajoranaMode* %src, %MajoranaMode* %tgt)"
        ));
    }

    #[test]
    fn test_nat_trans_generates_class() {
        let code = codegen_source(
            r#"natural eta : F => G where
  component eta_A : A
"#,
        );
        assert!(
            code.contains("class eta:"),
            "should generate class for NatTrans. Got:\n{}",
            code
        );
        assert!(
            code.contains("_SOURCE_FUNCTOR = 'F'"),
            "should have source functor"
        );
        assert!(
            code.contains("_TARGET_FUNCTOR = 'G'"),
            "should have target functor"
        );
    }

    #[test]
    fn test_operad_generates_class() {
        let code = codegen_source(
            r#"operad Compose where
  section mu : A
  section nu : B
  proof assoc : ok
"#,
        );
        assert!(
            code.contains("class Compose:"),
            "should generate class for Operad"
        );
        assert!(code.contains("SECTIONS"), "should have SECTIONS list");
        assert!(code.contains("def compose"), "should have compose method");
    }

    #[test]
    fn test_bundle_generates_class() {
        let code = codegen_source(
            r#"bundle TangentBundle : R3 -> M where
  section v : R3
  proof p : ok
"#,
        );
        assert!(
            code.contains("class TangentBundle:"),
            "should generate class for Bundle"
        );
        assert!(code.contains("_FIBER = 'R3'"), "should have fiber type");
        assert!(code.contains("_BASE = 'M'"), "should have base type");
    }

    #[test]
    fn test_topos_generates_class() {
        let code = codegen_source(
            r#"topos SetTopos where
  object A
  object B
  proof p : ok
"#,
        );
        assert!(
            code.contains("class SetTopos:"),
            "should generate class for Topos"
        );
        assert!(code.contains("OBJECTS"), "should have OBJECTS list");
    }

    #[test]
    fn test_tqc_qir_generation() {
        use crate::omega_engine_os::engine::tqc_compiler::compile;
        use crate::omega_engine_os::types::{NoiseParameters, QuantumCircuit, QuantumGate};

        let noise = NoiseParameters {
            bulk_gap_mev: 0.1,
            temperature_kelvin: 0.020,
            physical_gate_fidelity: 0.999,
            quasiparticle_rate_hz: 1e3,
            braid_time_ns: 10.0,
            measurement_time_ns: 100.0,
        };

        let mut circuit = QuantumCircuit::new(2);
        circuit.push(QuantumGate::Hadamard(0));
        circuit.push(QuantumGate::TGate(0));
        circuit.push(QuantumGate::CNOT(0, 1));

        let program = compile(&circuit, &noise).unwrap();
        let qir = generate_tqc_qir(&program);

        assert!(qir.contains("; ModuleID = 'anomalon_tqc_compiled'"));
        assert!(qir.contains("%MajoranaMode = type opaque"));
        assert!(qir.contains("@__tqc__braid"));
        assert!(qir.contains("@__tqc__prepare_magic"));
        assert!(qir.contains("@__tqc__regime_boundary"));
        assert!(qir.contains("REGIME BOUNDARY"));
        assert!(qir.contains("l1 error budget"));
        assert!(qir.contains("T-count = 1"));
    }

    #[test]
    fn test_tqc_qir_regime_boundary_markers() {
        use crate::omega_engine_os::engine::tqc_compiler::compile;
        use crate::omega_engine_os::types::{NoiseParameters, QuantumCircuit, QuantumGate};

        let noise = NoiseParameters {
            bulk_gap_mev: 0.1,
            temperature_kelvin: 0.020,
            physical_gate_fidelity: 0.999,
            quasiparticle_rate_hz: 1e3,
            braid_time_ns: 10.0,
            measurement_time_ns: 100.0,
        };

        let mut circuit = QuantumCircuit::new(1);
        circuit.push(QuantumGate::Hadamard(0));
        circuit.push(QuantumGate::TGate(0));
        circuit.push(QuantumGate::SGate(0));

        let program = compile(&circuit, &noise).unwrap();
        let qir = generate_tqc_qir(&program);

        // Should have at least topo->exposed and exposed->topo boundaries
        assert!(
            qir.contains("topo->exposed"),
            "Should contain topo->exposed boundary"
        );
    }
}
