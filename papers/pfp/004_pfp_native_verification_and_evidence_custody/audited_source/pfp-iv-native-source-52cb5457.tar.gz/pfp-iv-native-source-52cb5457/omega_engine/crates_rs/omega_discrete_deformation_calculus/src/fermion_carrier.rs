use std::collections::HashSet;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum SignVerdict {
    ExactGaugeRepair,
    ClosedResidual,
    ExactCancellation,
    OpenSignResidual,
    DeclarationRefused,
}

/// Channel A: Sign-parity obstruction over F_2
#[derive(Debug, Clone)]
pub struct ParityChannel {
    pub v_dim: usize,            // |V|
    pub e_dim: usize,            // |E|
    pub f_dim: usize,            // |F|
    pub d0_matrix: Vec<Vec<u8>>, // |E| x |V| matrix over F_2
    pub d1_matrix: Vec<Vec<u8>>, // |F| x |E| matrix over F_2
    pub sign_cochain: Vec<u8>,   // Element of C^1
}

/// Channel B: Signed-contribution cancellation over Q
#[derive(Debug, Clone)]
pub struct CancellationChannel {
    pub active_sector: HashSet<usize>,
    pub weights: Vec<f64>,                // W(x) >= 0
    pub signs: Vec<i8>,                   // s(x) in {-1, +1}
    pub involution_m: Option<Vec<usize>>, // M: X_act -> X_act
}

#[derive(Debug, Clone)]
pub struct ExactFiniteCarrier {
    pub channel_a: Option<ParityChannel>,
    pub channel_b: Option<CancellationChannel>,
}

impl ExactFiniteCarrier {
    pub fn new(channel_a: Option<ParityChannel>, channel_b: Option<CancellationChannel>) -> Self {
        Self {
            channel_a,
            channel_b,
        }
    }

    /// Evaluates the terminal SignVerdict for the declared finite packet.
    pub fn terminalize(&self) -> SignVerdict {
        let a = match &self.channel_a {
            Some(a) => a,
            None => return SignVerdict::DeclarationRefused,
        };

        // Check d1 * d0 = 0 (mod 2)
        if !self.verify_d1_d0_zero(a) {
            return SignVerdict::DeclarationRefused;
        }

        // Compute d1(q)
        let d1_q = self.compute_d1_q(a);
        let mut is_closed = true;
        for val in d1_q {
            if val != 0 {
                is_closed = false;
                break;
            }
        }

        if !is_closed {
            return SignVerdict::OpenSignResidual;
        }

        // It is closed. Check if q in im(d0) (ExactRepair)
        let in_im_d0 = self.is_in_im_d0(a);
        if in_im_d0 {
            return SignVerdict::ExactGaugeRepair;
        }

        // ClosedResidual. Now check Channel B for ExactCancellation
        if let Some(b) = &self.channel_b {
            if self.verify_involution(b) {
                return SignVerdict::ExactCancellation;
            }
        }

        SignVerdict::ClosedResidual
    }

    fn verify_d1_d0_zero(&self, a: &ParityChannel) -> bool {
        if a.d1_matrix.is_empty() || a.d0_matrix.is_empty() {
            return true;
        }
        let f_len = a.d1_matrix.len();
        let e_len = a.d0_matrix.len();
        let v_len = a.d0_matrix[0].len();

        for i in 0..f_len {
            for j in 0..v_len {
                let mut sum = 0;
                for k in 0..e_len {
                    sum ^= a.d1_matrix[i][k] & a.d0_matrix[k][j];
                }
                if sum != 0 {
                    return false;
                }
            }
        }
        true
    }

    fn compute_d1_q(&self, a: &ParityChannel) -> Vec<u8> {
        let mut res = vec![0; a.f_dim];
        for (i, r) in res.iter_mut().enumerate() {
            let mut sum = 0;
            for j in 0..a.e_dim {
                sum ^= a.d1_matrix[i][j] & a.sign_cochain[j];
            }
            *r = sum;
        }
        res
    }

    // GF(2) Gaussian elimination with pivot selection: the index loops ARE the
    // algorithm (row/column co-indexing across two rows of `mat`); iterator
    // rewrites need split_at_mut contortions that obscure the elimination.
    #[allow(clippy::needless_range_loop)]
    fn is_in_im_d0(&self, a: &ParityChannel) -> bool {
        // Gaussian elimination to check if sign_cochain is in the column space of d0_matrix
        let mut mat = a.d0_matrix.clone();
        let mut target = a.sign_cochain.clone();
        let rows = a.e_dim;
        let cols = a.v_dim;

        let mut pivot_row = 0;
        for c in 0..cols {
            if pivot_row >= rows {
                break;
            }
            let mut found = false;
            for r in pivot_row..rows {
                if mat[r][c] == 1 {
                    mat.swap(pivot_row, r);
                    target.swap(pivot_row, r);
                    found = true;
                    break;
                }
            }
            if found {
                for r in (pivot_row + 1)..rows {
                    if mat[r][c] == 1 {
                        for k in c..cols {
                            mat[r][k] ^= mat[pivot_row][k];
                        }
                        target[r] ^= target[pivot_row];
                    }
                }
                pivot_row += 1;
            }
        }

        // Check if remaining target elements are 0
        for r in pivot_row..rows {
            if target[r] != 0 {
                return false;
            }
        }
        true
    }

    fn verify_involution(&self, b: &CancellationChannel) -> bool {
        let m = match &b.involution_m {
            Some(m) => m,
            None => return false,
        };

        for &x in &b.active_sector {
            let mx = m[x];
            // Must map active to active
            if !b.active_sector.contains(&mx) {
                return false;
            }
            // Fixed-point free
            if mx == x {
                return false;
            }
            // Involutive
            if m[mx] != x {
                return false;
            }
            // Weight preserving
            if (b.weights[mx] - b.weights[x]).abs() > 1e-9 {
                return false;
            }
            // Sign reversing
            if b.signs[mx] != -b.signs[x] {
                return false;
            }
        }
        true
    }
}
