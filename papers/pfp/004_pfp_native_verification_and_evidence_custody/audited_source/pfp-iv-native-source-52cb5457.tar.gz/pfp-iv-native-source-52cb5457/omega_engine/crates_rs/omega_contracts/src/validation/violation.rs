pub trait ValidationViolation:
    core::fmt::Debug + Send + Sync + erased_serde::Serialize + 'static
{
    fn code(&self) -> &'static str;
}

erased_serde::serialize_trait_object!(ValidationViolation);
