//! 00_constitution — the 9 migrated constitution-layer contracts load and validate
//! (role Constitution: no operational validator, only validate_common).
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn constitution_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/00_core_constitution");
    let report = load_v1_dir(&dir).expect("dir readable");
    assert_eq!(
        report.loaded, 9,
        "expected 9 migrated constitution contracts"
    );
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
