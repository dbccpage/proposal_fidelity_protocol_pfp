//! AutoP compiler — crate root (EPIC AP-0 build wiring).
//!
//! The real compiler lives under [`compiler`] (formerly the Cargo-invisible
//! `.compiler/` directory — renamed for AP-0). It was extracted from
//! `omega_core/src/compiler/`, so its internal references use the
//! `crate::compiler::*` namespace; exposing `pub mod compiler;` here preserves
//! that namespace exactly.
//!
//! The extracted tree still references three sibling subsystems of the old
//! `omega_core` crate — `topos`, `omega_engine_os`, `omega_engine` — that were
//! **deleted**. They are reconstructed below as MINIMAL, CLEARLY-LABELED
//! "subsystem removed" stubs (see `stubs/`) so the whole tree compiles and its
//! ~323 unit tests build and run. The stubs are scaffolding, **not** the real
//! engines: code paths that exercise stubbed behavior (the boundary checker's
//! advisory augmentations, the Lean bridge, the TQC compiler, ℓ¹ stable-norm /
//! sheaf-spectral / predual-norm analysis) return trivial placeholders, so any
//! test asserting on that behavior fails honestly rather than silently passing.
//!
//! See `omega_engine/.product_development/product_autop.md` (EPIC AP-0).

pub mod compiler;

// ---------------------------------------------------------------------------
// Deleted-subsystem stubs — scaffolding for AP-0 build wiring ONLY.
// NOT the real engines. See each file's header.
// ---------------------------------------------------------------------------
#[path = "stubs/topos.rs"]
pub mod topos;

#[path = "stubs/omega_engine_os.rs"]
pub mod omega_engine_os;

#[path = "stubs/omega_engine.rs"]
pub mod omega_engine;
