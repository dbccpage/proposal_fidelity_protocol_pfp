use std::collections::HashMap;

/// AutoP Core Syntax Types
/// This file defines the programmatic AST memory structs for the AutoP language,
/// mapping computation purely to Category Theory primitives.

#[derive(Clone, Debug, PartialEq)]
pub enum ASTNode {
    Manifold(ManifoldDef),
    Sheaf(SheafDef),
    Morphism(MorphismDef),
    Tensor(TensorDef),
    Adjunction(AdjunctionDef),
    Orbit(OrbitDef),
}

/// A `manifold` defines a topological space with dimensionality and sections.
#[derive(Clone, Debug, PartialEq)]
pub struct ManifoldDef {
    pub name: String,
    pub dimension: usize,
    pub sections: Vec<String>,
    pub proofs: HashMap<String, String>, // Name -> Logic
}

/// A `sheaf` defines local fractional descent or data mappings.
#[derive(Clone, Debug, PartialEq)]
pub struct SheafDef {
    pub name: String,
    pub dimension_bound: String,
    pub operators: HashMap<String, String>,
}

/// A `morphism` defines a directed transformation between manifolds.
#[derive(Clone, Debug, PartialEq)]
pub struct MorphismDef {
    pub name: String,
    pub source: String, // Manifold name
    pub target: String, // Manifold name
    pub equations: Vec<String>,
    pub proofs: HashMap<String, String>,
}

/// A `tensor` defines concurrent or composed execution paths, enforcing disjoint memory.
#[derive(Clone, Debug, PartialEq)]
pub struct TensorDef {
    pub name: String,
    pub inputs: Vec<String>,
    pub disjoint_checks: Vec<String>,
    pub execute_commands: Vec<String>,
}

/// An `adjunction` defines structural equivalence (left/right adjoints, unit/counit).
#[derive(Clone, Debug, PartialEq)]
pub struct AdjunctionDef {
    pub name: String,
    pub left_adjoint: String, // Morphism/Functor definition
    pub right_adjoint: String,
    pub unit: String,
    pub counit: String,
}

/// An `orbit` defines temporal, recursive, or state-looping operations with liveness proofs.
#[derive(Clone, Debug, PartialEq)]
pub struct OrbitDef {
    pub name: String,
    pub source: String,
    pub target: String,
    pub step_function: String,
    pub proofs: HashMap<String, String>,
}

/// Structural root representing an entire parsed AutoP module/program.
#[derive(Clone, Debug, Default, PartialEq)]
pub struct AutoPModule {
    pub elements: Vec<ASTNode>,
}

impl AutoPModule {
    pub fn new() -> Self {
        Self {
            elements: Vec::new(),
        }
    }

    pub fn add(&mut self, node: ASTNode) {
        self.elements.push(node);
    }
}
