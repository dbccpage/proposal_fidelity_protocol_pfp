//! Invariant (III) — identity witness / Borges-tiger.
//!
//! Mirrors PaperAF005.L029_04_PrimitiveDifferenceRoleEPK in
//! omega_engine/lean4/007_authority_firewall/PaperAF005/L029_04_PrimitiveDifferenceRoleEPK.lean:
//! classification cannot factor through an identity-erasing quotient. An object keeps its
//! identity across every edge of axis Y; aliasing the same object under many names across
//! layers is conservation (allowed), but collapsing two distinct identities into one is
//! impersonation (refused). Slogan: "compression allowed, impersonation not."
use serde::{Deserialize, Serialize};

/// Witness that one object's identity is conserved (or lost) across the reconciliation edges.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IdentityWitness {
    pub object_id: String,
    pub object_kind: String,
    pub canonical_name: String,
    pub aliases: Vec<String>,
    pub conserved_across_edges: bool,
    pub identity_loss_risk: bool,
    pub note: String,
}

impl IdentityWitness {
    /// The Borges tiger: one identity aliased across layers (animal / predator / symbol /
    /// Q-level object). Conserved, no identity loss.
    pub fn tiger() -> Self {
        Self {
            object_id: "tiger".to_string(),
            object_kind: "exemplar".to_string(),
            canonical_name: "the tiger".to_string(),
            aliases: vec![
                "animal".to_string(),
                "predator".to_string(),
                "symbol".to_string(),
                "Q-level object".to_string(),
            ],
            conserved_across_edges: true,
            identity_loss_risk: false,
            note: "One tiger, many names across layers — compression allowed, impersonation not."
                .to_string(),
        }
    }

    /// The bar: one business identity aliased across layers (business / venue / inventory
    /// system / liability surface / cash-flow engine). Conserved, no identity loss.
    pub fn bar() -> Self {
        Self {
            object_id: "bar".to_string(),
            object_kind: "exemplar".to_string(),
            canonical_name: "the bar".to_string(),
            aliases: vec![
                "business".to_string(),
                "venue".to_string(),
                "inventory system".to_string(),
                "liability surface".to_string(),
                "cash-flow engine".to_string(),
            ],
            conserved_across_edges: true,
            identity_loss_risk: false,
            note: "One bar, many names across layers — compression allowed, impersonation not."
                .to_string(),
        }
    }
}

/// Classification preserves identity iff the object is conserved across edges and carries no
/// identity-loss risk. A reconciliation that would erase identity is refused.
pub fn classification_preserves_identity(iw: &IdentityWitness) -> bool {
    iw.conserved_across_edges && !iw.identity_loss_risk
}
