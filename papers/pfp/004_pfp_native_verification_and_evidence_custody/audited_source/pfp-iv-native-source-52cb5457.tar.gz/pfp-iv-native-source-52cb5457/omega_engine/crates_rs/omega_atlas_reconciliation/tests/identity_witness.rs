use omega_atlas_reconciliation::identity_witness::*;
#[test]
fn conserved_identity_factors() {
    assert!(classification_preserves_identity(&IdentityWitness::tiger()));
}
#[test]
fn identity_erasure_is_refused() {
    let mut iw = IdentityWitness::tiger();
    iw.identity_loss_risk = true;
    assert!(!classification_preserves_identity(&iw));
}
#[test]
fn bar_is_one_bar_across_layers() {
    let bar = IdentityWitness::bar();
    assert!(bar.conserved_across_edges && !bar.identity_loss_risk);
    assert!(bar.aliases.len() >= 4);
}
