//! --- yaml
//! title: cubical_trace
//! file_name: cubical_trace.rs
//! file_location: omega_core/src/compiler/cubical_trace.rs
//! status: Diamond
//! invariance_level: Tier 1
//! logic_system: Algebraic Topology
//! substrate: Rust
//! content_hash: 7763566fd1c828af0628c172b60f09c8802b5e4c01db5fb8c64dc945c430e1fa
//! version: 2
//! ---
//!
//! # Cubical Trace Topology
//!
//! Extracts concurrency structures straight from the categorical String Diagram IR.
//!
//! Independent components (parallel wires) natively define commuting tensors.
//! We generate a geometric Cubical Complex over GF(2).
//!
//! - Nodes (morphisms)       -> 1-cells (edges)
//! - Commuting Pairs         -> 2-cells (squares)
//! - Commuting Triples       -> 3-cells (cubes)
//!
//! By computing the boundary matrices d_1, d_2, d_3, we can extract Homology:
//! - H^1: Cycles in the graph (dependency loops or abstract operational boundaries).
//! - H^2: Missing squares (independent operations trying to compose illegally = race conditions).
//! - H^3: Missing cubes (concurrency deadlocks).

use super::string_diagram::{Diagram, NodeId};
use std::collections::HashMap;

/// An unweighted GF(2) boundary matrix representing linear combinations of cells.
/// Rows = N-cells, Output Cols = (N-1)-cells
pub struct Gf2BoundaryMatrix {
    pub rows: usize,
    pub cols: usize,
    pub matrix: Vec<Vec<bool>>,
}

impl Gf2BoundaryMatrix {
    pub fn new(rows: usize, cols: usize) -> Self {
        Self {
            rows,
            cols,
            matrix: vec![vec![false; cols]; rows],
        }
    }

    pub fn set(&mut self, row: usize, col: usize) {
        self.matrix[row][col] = true;
    }

    /// Compute the GF(2) rank using Gaussian elimination
    pub fn rank(&self) -> usize {
        let mut row_vectors = self.matrix.clone();
        let mut pivot_row = 0;
        for col in 0..self.cols {
            let mut found = None;
            for r in pivot_row..self.rows {
                if row_vectors[r][col] {
                    found = Some(r);
                    break;
                }
            }

            if let Some(r) = found {
                row_vectors.swap(pivot_row, r);
                for i in (pivot_row + 1)..self.rows {
                    if row_vectors[i][col] {
                        for c in col..self.cols {
                            row_vectors[i][c] ^= row_vectors[pivot_row][c];
                        }
                    }
                }
                pivot_row += 1;
            }
        }
        pivot_row
    }
}

pub struct CubicalComplex {
    // Topologically, we map the elements from to 0-indexed vectors for matrices
    pub vertices: usize,    // Represents the distinct program states
    pub edges: Vec<NodeId>, // The 1-cells (morphisms)
    pub edge_boundaries: HashMap<NodeId, (usize, usize)>, // Tracks source and target states
    pub squares: Vec<(NodeId, NodeId)>, // The 2-cells (independent pairs)
    pub cubes: Vec<(NodeId, NodeId, NodeId)>, // The 3-cells (independent triples)
}

impl CubicalComplex {
    /// Extracts the Cubical Topology directly from the String Diagram.
    pub fn build(diagram: &Diagram) -> Self {
        let mut edges = Vec::new();
        // Since sequence defines a string, wires themselves don't form the vertices directly.
        // Instead, the nodes are the edges (transitions).
        // Wires are simply the typed domains. For homology, we track boundaries of nodes.
        let mut vertex_map: HashMap<Vec<usize>, usize> = HashMap::new();
        let mut next_vertex = 0;

        let mut get_v = |sig: Vec<usize>| -> usize {
            *vertex_map.entry(sig).or_insert_with(|| {
                let v = next_vertex;
                next_vertex += 1;
                v
            })
        };

        let mut edge_mapping: HashMap<NodeId, (usize, usize)> = HashMap::new();

        // 1. Build Vertices & Edges (1-cells)
        let mut sorted_nodes: Vec<_> = diagram.nodes.values().collect();
        sorted_nodes.sort_unstable_by_key(|n| n.id);
        for node in &sorted_nodes {
            edges.push(node.id);
            let in_sig = node.inputs.to_vec();
            let out_sig = node.outputs.to_vec();
            // Removed in_sig.sort() and out_sig.sort() to preserve physical wire order

            let v_in = get_v(in_sig);
            let v_out = get_v(out_sig);
            edge_mapping.insert(node.id, (v_in, v_out));
        }

        // 2. Build Squares (2-cells)
        // Two independent nodes naturally form a commuting square.
        let squares = diagram.commuting_pairs();

        // 3. Build Cubes (3-cells)
        let cubes = diagram.commuting_triples();

        Self {
            vertices: next_vertex,
            edges,
            edge_boundaries: edge_mapping,
            squares,
            cubes,
        }
    }

    /// Computes Betti_1, Betti_2, Betti_3. Requires the boundary matrices.
    /// H_1 = Betti_1 = dim(ker_1) - dim(im_2)
    /// H_2 = Betti_2 = dim(ker_2) - dim(im_3)
    pub fn compute_homology(&self) -> (usize, usize, usize) {
        let mut d1 = Gf2BoundaryMatrix::new(self.edges.len(), self.vertices);
        for (idx, e) in self.edges.iter().enumerate() {
            if let Some(&(v_in, v_out)) = self.edge_boundaries.get(e) {
                d1.set(idx, v_in);
                d1.set(idx, v_out);
            }
        }
        let rank_d1 = d1.rank();

        let edge_idx_map: HashMap<NodeId, usize> = self
            .edges
            .iter()
            .enumerate()
            .map(|(i, &e)| (e, i))
            .collect();

        // Compute D2 (Squares -> Edges)
        let mut d2 = Gf2BoundaryMatrix::new(self.squares.len(), self.edges.len());
        for (idx, &(n1, n2)) in self.squares.iter().enumerate() {
            // A square conceptually bounds 4 oriented edges, or structurally 2 generators over GF(2) projection
            if let Some(&idx1) = edge_idx_map.get(&n1) {
                d2.set(idx, idx1);
            }
            if let Some(&idx2) = edge_idx_map.get(&n2) {
                d2.set(idx, idx2);
            }
        }
        let rank_d2 = d2.rank();

        let square_idx_map: HashMap<(NodeId, NodeId), usize> = self
            .squares
            .iter()
            .enumerate()
            .map(|(i, &s)| (s, i))
            .collect();

        // Compute D3 (Cubes -> Squares)
        let mut d3 = Gf2BoundaryMatrix::new(self.cubes.len(), self.squares.len());
        for (idx, &(n1, n2, n3)) in self.cubes.iter().enumerate() {
            // A cube bounds 6 geometric faces (squares) -> structurally maps to pairs
            let mut add_square = |a: NodeId, b: NodeId| {
                let pair = (a.min(b), a.max(b));
                if let Some(&s_idx) = square_idx_map.get(&pair) {
                    d3.set(idx, s_idx);
                }
            };
            add_square(n1, n2);
            add_square(n2, n3);
            add_square(n1, n3);
            // Include all 6 faces conceptually (though `set` makes it idempotent here)
            add_square(n1, n2);
            add_square(n2, n3);
            add_square(n1, n3);
        }
        let rank_d3 = d3.rank();

        // Approximate homological ranks using standard Chain complex identity
        // Betti_N = dim(Ker_N) - dim(Im_{N+1})
        // Ker_N = cols_N - rank(d_N)
        // Im_{N} = rank(d_N)

        // H_1:
        let dim_ker_1 = self.edges.len().saturating_sub(rank_d1); // edges - rank_d1
        let betti_1 = dim_ker_1.saturating_sub(rank_d2); // - Im(D2)

        // H_2:
        let dim_ker_2 = self.squares.len().saturating_sub(rank_d2); // squares - rank_d2
        let betti_2 = dim_ker_2.saturating_sub(rank_d3); // - Im(D3)

        // H_3
        let dim_ker_3 = self.cubes.len().saturating_sub(rank_d3);
        let betti_3 = dim_ker_3; // No D4 to mod out

        (betti_1, betti_2, betti_3)
    }
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tensor_h2_closed() {
        // A tensor of two independent operations on disjoint wires forms a
        // closed commuting square (a 2-cell), so there is no H^2 race
        // condition (Betti_2 = 0) and no H^3 deadlock (Betti_3 = 0).
        let mut d = Diagram::new();
        let a = d.add_wire("A");
        let b = d.add_wire("B");
        d.add_node("f", vec![a], vec![a]);
        d.add_node("g", vec![b], vec![b]);

        let complex = CubicalComplex::build(&d);
        assert_eq!(
            complex.squares.len(),
            1,
            "Two independent tensor factors form exactly one commuting square"
        );
        let (_h1, h2, h3) = complex.compute_homology();
        assert_eq!(h2, 0, "Closed tensor square: no H^2 race condition");
        assert_eq!(h3, 0, "No commuting triples: no H^3 deadlock");
    }

    // ---- GF(2) Boundary Matrix arithmetic ----

    #[test]
    fn test_gf2_rank_empty_matrix() {
        let m = Gf2BoundaryMatrix::new(0, 0);
        assert_eq!(m.rank(), 0, "Empty matrix has rank 0");
    }

    #[test]
    fn test_gf2_rank_single_nonzero_row() {
        let mut m = Gf2BoundaryMatrix::new(1, 3);
        m.set(0, 0);
        m.set(0, 2);
        assert_eq!(m.rank(), 1, "Single nonzero row has rank 1");
    }

    #[test]
    fn test_gf2_rank_two_independent_rows() {
        let mut m = Gf2BoundaryMatrix::new(2, 3);
        m.set(0, 0); // Row 0: [1, 0, 0]
        m.set(1, 1); // Row 1: [0, 1, 0]
        assert_eq!(m.rank(), 2, "Two linearly independent rows have rank 2");
    }

    #[test]
    fn test_gf2_rank_dependent_rows_cancel() {
        // Over GF(2), two identical rows XOR to zero → rank 1
        let mut m = Gf2BoundaryMatrix::new(2, 2);
        m.set(0, 0);
        m.set(0, 1); // Row 0: [1, 1]
        m.set(1, 0);
        m.set(1, 1); // Row 1: [1, 1]
        assert_eq!(m.rank(), 1, "Identical GF(2) rows reduce to rank 1");
    }

    #[test]
    fn test_gf2_set_idempotent() {
        let mut m = Gf2BoundaryMatrix::new(1, 2);
        m.set(0, 0);
        m.set(0, 0); // Setting same position twice must not duplicate
        assert_eq!(
            m.matrix[0].iter().filter(|&&b| b).count(),
            1,
            "set() is idempotent"
        );
        assert_eq!(m.rank(), 1);
    }

    #[test]
    fn test_gf2_rank_3x3_known() {
        // Matrix over GF(2): [[1,1,0],[1,0,1],[0,1,1]]
        // Row 2 = Row 0 XOR Row 1, so rank = 2
        let mut m = Gf2BoundaryMatrix::new(3, 3);
        m.set(0, 0);
        m.set(0, 1);
        m.set(1, 0);
        m.set(1, 2);
        m.set(2, 1);
        m.set(2, 2);
        assert_eq!(
            m.rank(),
            2,
            "3x3 matrix with dependent third row has rank 2"
        );
    }

    // ---- Diagram-level homology ----

    #[test]
    fn test_empty_diagram_all_betti_zero() {
        let d = Diagram::new();
        let complex = CubicalComplex::build(&d);
        assert_eq!(complex.edges.len(), 0);
        assert_eq!(complex.squares.len(), 0);
        assert_eq!(complex.cubes.len(), 0);
        let (h1, h2, h3) = complex.compute_homology();
        assert_eq!(h1, 0, "Empty diagram: Betti_1 = 0");
        assert_eq!(h2, 0, "Empty diagram: Betti_2 = 0");
        assert_eq!(h3, 0, "Empty diagram: Betti_3 = 0");
    }

    #[test]
    fn test_single_node_no_higher_cells() {
        let mut d = Diagram::new();
        let w = d.add_wire("A");
        d.add_node("f", vec![w], vec![w]);
        let complex = CubicalComplex::build(&d);
        assert_eq!(complex.edges.len(), 1, "Single node produces 1 edge");
        assert_eq!(
            complex.squares.len(),
            0,
            "Single node has no commuting pairs"
        );
        assert_eq!(
            complex.cubes.len(),
            0,
            "Single node has no commuting triples"
        );
        let (_, h2, h3) = complex.compute_homology();
        assert_eq!(h2, 0, "Single node: no race conditions");
        assert_eq!(h3, 0, "Single node: no deadlocks");
    }
}
