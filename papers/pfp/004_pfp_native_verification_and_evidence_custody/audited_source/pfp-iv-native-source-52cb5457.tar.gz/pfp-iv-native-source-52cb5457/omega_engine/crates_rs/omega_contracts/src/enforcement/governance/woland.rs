//! Woland adversarial diagnostic functor.
//!
//! Woland is adversarial diagnosis, NOT final enforcement.
//! Woland may recommend Blackrod action but CANNOT enforce.
//!
//! # Safety Invariant
//!
//! Woland can only diagnose and recommend. Enforcement authority is
//! exclusively held by Blackrod. This separation ensures that diagnostic
//! findings must pass through an enforcement gate before action is taken.

use super::errors::{ArtifactType, CouncilId, GovernanceError, GovernanceResult, TraceId};
use serde::{Deserialize, Serialize};

// ============================================================================
// Diagnostic Functor Trait
// ============================================================================

/// Diagnostic functor trait.
///
/// Inspects artifacts for obstruction findings. Woland diagnoses but
/// does NOT enforce. Enforcement authority is held by Blackrod.
pub trait DiagnosticFunctor {
    /// Artifact type being inspected.
    type Artifact;
    /// Finding type produced by inspection.
    type Finding;

    /// Inspect an artifact for obstruction findings.
    ///
    /// Returns a list of findings. Woland diagnoses but does NOT enforce.
    fn inspect(&self, artifact: &Self::Artifact) -> Vec<Self::Finding>;
}

// ============================================================================
// Obstruction Findings
// ============================================================================

/// Obstruction findings that Woland can detect.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ObstructionFinding {
    /// Hidden contradiction detected.
    HiddenContradiction { location: String, details: String },

    /// Fake certainty - claim without sufficient evidence.
    FakeCertainty { claim: String, evidence_gap: String },

    /// Fake evidence detected.
    FakeEvidence { artifact_id: String, reason: String },

    /// Weak or inadequate tests.
    WeakTests {
        test_ids: Vec<String>,
        weakness: String,
    },

    /// Unrouted power - authority exercised without proper routing.
    UnroutedPower {
        actor: String,
        power_description: String,
    },

    /// Self-certification detected.
    SelfCertification { actor: String, artifact_id: String },

    /// Architecture drift from declared structure.
    ArchitectureDrift { expected: String, actual: String },

    /// Unlicensed claim made.
    UnlicensedClaim { actor: String, claim: String },
}

// ============================================================================
// Woland Recommendations
// ============================================================================

/// Urgency level for recommendations.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum Urgency {
    /// Low urgency - can be addressed in normal flow.
    Low,
    /// Medium urgency - should be addressed soon.
    Medium,
    /// High urgency - requires prompt attention.
    High,
    /// Critical urgency - immediate action required.
    Critical,
}

/// Woland can only recommend, never enforce.
///
/// All recommendations are advisory. Enforcement authority is held by Blackrod.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum WolandRecommendation {
    /// Refer finding to Blackrod for enforcement consideration.
    ReferToBlackrod {
        finding: ObstructionFinding,
        urgency: Urgency,
    },

    /// Flag finding for council review.
    FlagForCouncilReview {
        finding: ObstructionFinding,
        council_id: CouncilId,
    },

    /// Request additional evidence.
    RequestEvidence {
        artifact_id: String,
        evidence_needed: String,
    },

    /// Annotate artifact with diagnostic finding.
    AnnotateArtifact {
        artifact_id: String,
        annotation: String,
    },
}

// ============================================================================
// Diagnostic Artifact
// ============================================================================

/// Artifact submitted for diagnostic inspection.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DiagnosticArtifact {
    /// Unique identifier.
    pub id: String,
    /// Artifact type.
    pub kind: ArtifactType,
    /// Content hash for integrity.
    pub content_hash: String,
    /// Additional metadata.
    pub metadata: std::collections::HashMap<String, String>,
}

impl DiagnosticArtifact {
    /// Create a new diagnostic artifact.
    pub fn new(id: impl Into<String>, kind: ArtifactType, content_hash: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            kind,
            content_hash: content_hash.into(),
            metadata: std::collections::HashMap::new(),
        }
    }

    /// Add metadata to the artifact.
    pub fn with_metadata(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.metadata.insert(key.into(), value.into());
        self
    }
}

// ============================================================================
// Diagnostic Record
// ============================================================================

/// Record of a diagnostic inspection.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DiagnosticRecord {
    /// Unique identifier for this record.
    pub id: String,
    /// Artifact that was inspected.
    pub artifact_inspected: String,
    /// Findings from inspection.
    pub findings: Vec<ObstructionFinding>,
    /// Recommendations based on findings.
    pub recommendations: Vec<WolandRecommendation>,
    /// Timestamp of inspection.
    pub timestamp: String,
    /// Trace identifier for audit.
    pub trace_id: TraceId,
}

// ============================================================================
// Woland
// ============================================================================

/// Woland adversarial diagnostic entity.
///
/// Woland inspects artifacts for obstruction findings and recommends actions.
/// Woland CANNOT enforce - enforcement authority is held by Blackrod.
#[derive(Debug, Clone, Default)]
pub struct Woland {
    /// Unique identifier.
    pub id: String,
    /// Log of diagnostic inspections.
    pub findings_log: Vec<DiagnosticRecord>,
}

impl DiagnosticFunctor for Woland {
    type Artifact = DiagnosticArtifact;
    type Finding = ObstructionFinding;

    fn inspect(&self, _artifact: &Self::Artifact) -> Vec<Self::Finding> {
        // Inspects artifact for obstruction findings.
        // Woland diagnoses but does NOT enforce.
        // TODO: Implement inspection logic based on artifact type and content.
        Vec::new()
    }
}

impl Woland {
    /// Create a new Woland instance.
    pub fn new(id: impl Into<String>) -> Self {
        Self {
            id: id.into(),
            findings_log: Vec::new(),
        }
    }

    /// Recommend Blackrod action for a finding.
    ///
    /// Woland may recommend Blackrod action but cannot enforce.
    pub fn recommend(&self, finding: ObstructionFinding, urgency: Urgency) -> WolandRecommendation {
        WolandRecommendation::ReferToBlackrod { finding, urgency }
    }

    /// Recommend council review for a finding.
    pub fn recommend_council_review(
        &self,
        finding: ObstructionFinding,
        council_id: CouncilId,
    ) -> WolandRecommendation {
        WolandRecommendation::FlagForCouncilReview {
            finding,
            council_id,
        }
    }

    /// Request additional evidence for an artifact.
    pub fn request_evidence(
        &self,
        artifact_id: impl Into<String>,
        evidence_needed: impl Into<String>,
    ) -> WolandRecommendation {
        WolandRecommendation::RequestEvidence {
            artifact_id: artifact_id.into(),
            evidence_needed: evidence_needed.into(),
        }
    }

    /// Annotate an artifact with a diagnostic finding.
    pub fn annotate(
        &self,
        artifact_id: impl Into<String>,
        annotation: impl Into<String>,
    ) -> WolandRecommendation {
        WolandRecommendation::AnnotateArtifact {
            artifact_id: artifact_id.into(),
            annotation: annotation.into(),
        }
    }

    /// Woland CANNOT enforce - this must always fail.
    ///
    /// Enforcement authority is exclusively held by Blackrod.
    /// Woland diagnoses but does NOT enforce.
    pub fn enforce(&self) -> GovernanceResult<()> {
        Err(GovernanceError::AuthorityViolation(
            "Woland diagnoses but cannot enforce. Refer to Blackrod.".into(),
        ))
    }

    /// Perform diagnostic inspection and log results.
    pub fn diagnose(&mut self, artifact: &DiagnosticArtifact) -> DiagnosticRecord {
        let findings = self.inspect(artifact);
        let recommendations: Vec<WolandRecommendation> = findings
            .iter()
            .map(|f| self.recommend(f.clone(), Urgency::Medium))
            .collect();

        let record = DiagnosticRecord {
            id: format!("diag:{}", self.findings_log.len()),
            artifact_inspected: artifact.id.clone(),
            findings: findings.clone(),
            recommendations,
            timestamp: "TODO:timestamp".to_string(),
            trace_id: TraceId::new("trace:diagnostic"),
        };

        self.findings_log.push(record.clone());
        record
    }

    /// Check if an artifact exhibits self-certification.
    ///
    /// Self-certification is when an actor certifies their own work.
    pub fn check_self_certification(
        &self,
        artifact: &DiagnosticArtifact,
        author: &str,
        certifier: &str,
    ) -> Option<ObstructionFinding> {
        if author == certifier {
            Some(ObstructionFinding::SelfCertification {
                actor: author.to_string(),
                artifact_id: artifact.id.clone(),
            })
        } else {
            None
        }
    }

    /// Check for fake certainty - claims without sufficient evidence.
    pub fn check_fake_certainty(
        &self,
        claim: &str,
        evidence_refs: &[String],
        required_evidence_count: usize,
    ) -> Option<ObstructionFinding> {
        if evidence_refs.len() < required_evidence_count {
            Some(ObstructionFinding::FakeCertainty {
                claim: claim.to_string(),
                evidence_gap: format!(
                    "requires {} evidence items, found {}",
                    required_evidence_count,
                    evidence_refs.len()
                ),
            })
        } else {
            None
        }
    }

    /// Check for weak tests.
    pub fn check_weak_tests(
        &self,
        test_ids: &[String],
        assertion_counts: &[usize],
        min_assertions: usize,
    ) -> Option<ObstructionFinding> {
        let weak_tests: Vec<String> = test_ids
            .iter()
            .zip(assertion_counts.iter())
            .filter(|(_, &count)| count < min_assertions)
            .map(|(id, _)| id.clone())
            .collect();

        if weak_tests.is_empty() {
            None
        } else {
            Some(ObstructionFinding::WeakTests {
                test_ids: weak_tests,
                weakness: format!("fewer than {} assertions", min_assertions),
            })
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn woland_cannot_enforce() {
        let woland = Woland::new("woland-001");
        assert!(woland.enforce().is_err());
    }

    #[test]
    fn woland_can_recommend_blackrod_action() {
        let woland = Woland::new("woland-001");
        let finding = ObstructionFinding::FakeCertainty {
            claim: "claim-001".into(),
            evidence_gap: "missing proof".into(),
        };

        let recommendation = woland.recommend(finding.clone(), Urgency::High);
        assert!(matches!(
            recommendation,
            WolandRecommendation::ReferToBlackrod { .. }
        ));
    }

    #[test]
    fn woland_detects_self_certification() {
        let woland = Woland::new("woland-001");
        let artifact = DiagnosticArtifact::new("art-001", ArtifactType::Code, "hash123");

        let finding = woland.check_self_certification(&artifact, "alice", "alice");
        assert!(finding.is_some());
        assert!(matches!(
            finding.unwrap(),
            ObstructionFinding::SelfCertification { .. }
        ));
    }

    #[test]
    fn woland_no_self_certification_when_different_actors() {
        let woland = Woland::new("woland-001");
        let artifact = DiagnosticArtifact::new("art-001", ArtifactType::Code, "hash123");

        let finding = woland.check_self_certification(&artifact, "alice", "bob");
        assert!(finding.is_none());
    }

    #[test]
    fn woland_detects_fake_certainty() {
        let woland = Woland::new("woland-001");
        let finding = woland.check_fake_certainty("strong claim", &["evidence-1".into()], 3);

        assert!(finding.is_some());
        assert!(matches!(
            finding.unwrap(),
            ObstructionFinding::FakeCertainty { .. }
        ));
    }

    #[test]
    fn woland_no_fake_certainty_with_sufficient_evidence() {
        let woland = Woland::new("woland-001");
        let evidence = vec!["ev1".into(), "ev2".into(), "ev3".into()];
        let finding = woland.check_fake_certainty("strong claim", &evidence, 3);

        assert!(finding.is_none());
    }

    #[test]
    fn woland_detects_weak_tests() {
        let woland = Woland::new("woland-001");
        let test_ids = vec!["test1".into(), "test2".into(), "test3".into()];
        let assertion_counts = vec![1, 5, 2];

        let finding = woland.check_weak_tests(&test_ids, &assertion_counts, 3);
        assert!(finding.is_some());

        if let Some(ObstructionFinding::WeakTests { test_ids, .. }) = finding {
            assert!(test_ids.contains(&"test1".to_string()));
            assert!(test_ids.contains(&"test3".to_string()));
            assert!(!test_ids.contains(&"test2".to_string()));
        } else {
            panic!("expected WeakTests finding");
        }
    }

    #[test]
    fn woland_diagnose_creates_record() {
        let mut woland = Woland::new("woland-001");
        let artifact = DiagnosticArtifact::new("art-001", ArtifactType::Code, "hash123");

        let record = woland.diagnose(&artifact);
        assert_eq!(record.artifact_inspected, "art-001");
        assert_eq!(woland.findings_log.len(), 1);
    }
}
