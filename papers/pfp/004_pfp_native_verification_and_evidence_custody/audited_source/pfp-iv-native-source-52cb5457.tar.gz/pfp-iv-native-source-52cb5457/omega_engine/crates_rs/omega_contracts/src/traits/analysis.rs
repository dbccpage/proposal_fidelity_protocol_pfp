use crate::kinds::ContractEffect;

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct AnalysisId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct DiagnosticReportId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct FunctionalId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct MetaJudgmentId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct SubjectHash(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct CertificateId(pub String);

pub trait AnalysisArtifact {
    fn artifact_id(&self) -> AnalysisId;
    fn subject_hash(&self) -> SubjectHash;
    fn authority_effect(&self) -> ContractEffect;
}

#[derive(Debug, Clone)]
pub struct AnalysisEnvelope<A> {
    pub analysis_id: AnalysisId,
    pub subject_hash: SubjectHash,
    pub artifact: A,
    pub certificate_refs: Vec<CertificateId>,
    pub authority_effect: ContractEffect,
}

impl<A> AnalysisEnvelope<A> {
    pub const DEFAULT_AUTHORITY_EFFECT: ContractEffect = ContractEffect::EvidenceOnly;

    pub fn new(
        analysis_id: AnalysisId,
        subject_hash: SubjectHash,
        artifact: A,
        certificate_refs: Vec<CertificateId>,
    ) -> Self {
        Self {
            analysis_id,
            subject_hash,
            artifact,
            certificate_refs,
            authority_effect: Self::DEFAULT_AUTHORITY_EFFECT,
        }
    }
}

/// Analysis extracts structured reports or summaries.
///
/// It does not judge admissibility, terminalize, mutate, execute, or license.
/// Checked facts require a declared checker, verifier, or replay boundary.
pub trait AnalysisKernel<Input> {
    type Artifact: AnalysisArtifact;
    type Error;

    fn analyze(&self, input: &Input) -> Result<AnalysisEnvelope<Self::Artifact>, Self::Error>;
}

/// Diagnostics classify observed problems relative to declared checks.
/// They produce reports, not decisions.
pub trait DiagnosticKernel<Input> {
    type Report;
    type Error;

    fn diagnose(&self, input: &Input) -> Result<DiagnosticEnvelope<Self::Report>, Self::Error>;
}

#[derive(Debug, Clone)]
pub struct DiagnosticEnvelope<R> {
    pub diagnostic_id: DiagnosticReportId,
    pub subject_hash: SubjectHash,
    pub report: R,
    pub certificate_refs: Vec<CertificateId>,
    pub authority_effect: ContractEffect,
}

impl<R> DiagnosticEnvelope<R> {
    pub const DEFAULT_AUTHORITY_EFFECT: ContractEffect = ContractEffect::EvidenceOnly;

    pub fn new(
        diagnostic_id: DiagnosticReportId,
        subject_hash: SubjectHash,
        report: R,
        certificate_refs: Vec<CertificateId>,
    ) -> Self {
        Self {
            diagnostic_id,
            subject_hash,
            report,
            certificate_refs,
            authority_effect: Self::DEFAULT_AUTHORITY_EFFECT,
        }
    }
}

/// Functional computes a declared numerical/symbolic quantity.
///
/// It produces evidence-bearing output. It does not authorize action or decide
/// admissibility without a separate governance boundary.
pub trait FunctionalKernel<Input> {
    type Output;
    type Error;

    fn functional_id(&self) -> FunctionalId;

    fn compute_functional(
        &self,
        input: &Input,
    ) -> Result<FunctionalEnvelope<Self::Output>, Self::Error>;
}

#[derive(Debug, Clone)]
pub struct FunctionalEnvelope<O> {
    pub functional_id: FunctionalId,
    pub subject_hash: SubjectHash,
    pub output: O,
    pub certificate_refs: Vec<CertificateId>,
    pub authority_effect: ContractEffect,
}

impl<O> FunctionalEnvelope<O> {
    pub const DEFAULT_AUTHORITY_EFFECT: ContractEffect = ContractEffect::EvidenceOnly;

    pub fn new(
        functional_id: FunctionalId,
        subject_hash: SubjectHash,
        output: O,
        certificate_refs: Vec<CertificateId>,
    ) -> Self {
        Self {
            functional_id,
            subject_hash,
            output,
            certificate_refs,
            authority_effect: Self::DEFAULT_AUTHORITY_EFFECT,
        }
    }
}

/// Meta judgment may recommend or classify meta-level conditions,
/// but must not execute lift or terminalize.
pub trait MetaJudgmentKernel<Input> {
    type Judgment;
    type Error;

    fn judge_meta(
        &self,
        input: &Input,
    ) -> Result<MetaJudgmentEnvelope<Self::Judgment>, Self::Error>;
}

#[derive(Debug, Clone)]
pub struct MetaJudgmentEnvelope<J> {
    pub judgment_id: MetaJudgmentId,
    pub subject_hash: SubjectHash,
    pub judgment: J,
    pub certificate_refs: Vec<CertificateId>,
    pub authority_effect: ContractEffect,
}

impl<J> MetaJudgmentEnvelope<J> {
    pub const DEFAULT_AUTHORITY_EFFECT: ContractEffect = ContractEffect::RequestsDecision;

    pub fn new(
        judgment_id: MetaJudgmentId,
        subject_hash: SubjectHash,
        judgment: J,
        certificate_refs: Vec<CertificateId>,
    ) -> Self {
        Self {
            judgment_id,
            subject_hash,
            judgment,
            certificate_refs,
            authority_effect: Self::DEFAULT_AUTHORITY_EFFECT,
        }
    }
}

/*
================================================================================
# FORBIDDEN BOUNDARY LAW
Analysis, Diagnostic, and Functional kernels produce evidence-bearing reports.
They do not decide admissibility, prescribe repair, terminalize, execute, mutate state, or license lifts.
Checked facts require a declared checker/verifier/replay boundary.

MetaJudgment may request or recommend a higher-authority decision.
It may not apply the decision.

Forbidden tokens:
- execute
- terminalize
- apply_lift
- apply_operator
- rollback
- sign_certificate
- save_certificate
- ALLOW_OUTPUT
- BLOCK_OUTPUT

For DiagnosticKernel, also forbid:
- repair
- policy_decision
- engine_decision
================================================================================
*/

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn analysis_diagnostic_and_functional_default_to_evidence_only() {
        let analysis = AnalysisEnvelope::new(
            AnalysisId("analysis:1".to_string()),
            SubjectHash("subject:1".to_string()),
            "artifact",
            Vec::new(),
        );
        assert_eq!(analysis.authority_effect, ContractEffect::EvidenceOnly);

        let diagnostic = DiagnosticEnvelope::new(
            DiagnosticReportId("diagnostic:1".to_string()),
            SubjectHash("subject:1".to_string()),
            "report",
            Vec::new(),
        );
        assert_eq!(diagnostic.authority_effect, ContractEffect::EvidenceOnly);

        let functional = FunctionalEnvelope::new(
            FunctionalId("functional:1".to_string()),
            SubjectHash("subject:1".to_string()),
            1usize,
            Vec::new(),
        );
        assert_eq!(functional.authority_effect, ContractEffect::EvidenceOnly);
    }

    #[test]
    fn meta_judgment_may_request_decision() {
        let judgment = MetaJudgmentEnvelope::new(
            MetaJudgmentId("judgment:1".to_string()),
            SubjectHash("subject:1".to_string()),
            "judgment",
            Vec::new(),
        );
        assert_eq!(judgment.authority_effect, ContractEffect::RequestsDecision);
    }
}
