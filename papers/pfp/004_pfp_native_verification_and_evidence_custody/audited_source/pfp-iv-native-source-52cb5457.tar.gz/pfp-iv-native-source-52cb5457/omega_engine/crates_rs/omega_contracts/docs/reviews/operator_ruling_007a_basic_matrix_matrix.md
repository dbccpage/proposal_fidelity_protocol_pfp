# Operator ruling note — basic_matrix vs matrix (007a)

**Date:** 2026-07-31  
**AuthorityEffect:** `None`  
**ADR:** `adr-007a-one-yaml-per-math-file-and-code-follows-yaml.md`

## Ruling (plain)

1. **C applies:** `basic_matrix` and `matrix` are **different** objects → **two YAMLs**, two future/current code homes.  
2. **One YAML per math file** — no sharing, no doubles.  
3. **Code always follows YAML** — never rewrite YAML to match LLM/human slop.  
4. YAML change allowed only when **math re-review** says the contract was wrong as mathematics.

## Immediate consequence for zero-dim

- Contract text today: reject `rows=0` / `cols=0`.  
- Code today: allows 0-dim; **homology/cochain** legitimately uses `zero(0, n)` empty maps.  
- **Do not** implement hard refuse yet without either:  
  - **math-repair** of `basic_matrix` YAML (0-rank free modules / empty maps are math, not slop), or  
  - a **second object + file + YAML** for empty-capable maps (still one YAML per file).  
- Blind “code follows YAML” refuse **without** that decision **breaks** `omega_homological`.

## Field story (storage)

- Scalar domain identity for `BasicMatrix<T>` = **type parameter `T`** (compile-time).  
- Full field+basis linear-map story lives on **`matrix`**, not storage.

## Status

| Object | YAML | Code | Next |
| --- | --- | --- | --- |
| basic_matrix | keep | `backend/basic_matrix.rs` | meth re-review zero-dim law **or** split empty-capable type |
| matrix | keep (WIP) | not `BasicMatrix` alone | implement only under its own YAML when ready |

**AuthorityEffect: `None`.**
