use super::file_audit::{FileAuditSubject, FilePart};
use crate::kinds::{ContractEffect, SchemaHash};

/// Sample validation manifest.
///
/// This is placeholder/test data until contract code generation owns the
/// manifest and emits workspace-specific subjects.
pub static FILE_AUDIT_MANIFEST: &[FileAuditSubject] = &[FileAuditSubject {
    contract_id: "sample.base_type_contract",
    path: "src/types/foo.rs",
    declared_kind: "BaseType",
    schema_hash: SchemaHash([0x12; 32]),
    authority_effect: ContractEffect::EvidenceOnly,
    parts: &[
        FilePart {
            name: "BaseType impl",
            required: true,
            kind: "trait_impl",
        },
        FilePart {
            name: "contract binding",
            required: true,
            kind: "contract",
        },
        FilePart {
            name: "validation unit",
            required: true,
            kind: "validator",
        },
    ],
}];
