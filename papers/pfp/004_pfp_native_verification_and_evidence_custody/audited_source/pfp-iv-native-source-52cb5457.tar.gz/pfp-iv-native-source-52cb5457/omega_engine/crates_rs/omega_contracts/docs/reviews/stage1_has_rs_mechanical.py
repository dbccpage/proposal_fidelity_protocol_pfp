"""Stage-1 mechanical GTLA gates on HAS_RS math contracts only. AuthorityEffect None."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]  # omega_engine? 
# file at omega_engine/crates/omega_contracts/docs/reviews/stage1...
# parents[0]=reviews,1=docs,2=omega_contracts,3=crates,4=omega_engine,5=repo
REPO = Path(__file__).resolve().parents[5]
MATH = REPO / "omega_engine/crates/omega_contracts/src/contract_canonical_definitions/math"
STEMS = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_has_rs_stems.txt"

CHECKS = [
    ("G_AUTHORITY_NONE", re.compile(r"authority_effect:\s*none", re.I)),
    ("G_CUSTOMER_FALSE", re.compile(r"customer_claim_allowed:\s*false", re.I)),
    ("G_MATH_BLOCK", re.compile(r"(?m)^math:\s*$")),
    ("G_NON_ROLE", re.compile(r"non_role:")),
    ("G_REQUIRED_STRUCTURES", re.compile(r"required_structures:")),
    ("G_LAWS_OR_REQUIREMENTS", re.compile(r"(?m)^(laws:|requirements:)")),
    ("G_NEGATIVE_TESTS", re.compile(r"negative_tests:")),
]


def split_debate(text: str) -> tuple[str, str]:
    key = "nomos_debate_NOT_CANONICAL:"
    if key not in text:
        empty = (
            "nomos_debate_NOT_CANONICAL:\n"
            '  banner: "NON-CANONICAL DEBATE ONLY — not contract law; not enforced; AuthorityEffect None"\n'
            "  not_part_of_contract_law: true\n"
            "  authority_effect: none\n"
            "  potential_defects: []\n"
            "  realization_delta_vs_implemented_math_file: []\n"
        )
        return text.rstrip() + "\n", empty
    i = text.index(key)
    return text[:i].rstrip() + "\n", text[i:]


def inject_defects(debate: str, items: list[str]) -> str:
    block = "".join(items).rstrip() + "\n"
    if "potential_defects: []" in debate:
        return debate.replace("potential_defects: []", "potential_defects:\n" + block, 1)
    if "potential_defects:" in debate:
        return debate.replace("potential_defects:", "potential_defects:\n" + block, 1)
    # insert after authority_effect: none in debate
    return debate.rstrip() + "\n  potential_defects:\n" + block


def defect_item(code: str, detail: str, severity: str = "medium") -> str:
    return (
        "  - reviewer: panepistimion-math-prof\n"
        "    role: MATH_CANONICAL_REVIEW\n"
        f"    code: {code}\n"
        f"    severity: {severity}\n"
        '    claim_class: "[STANDARD]"\n'
        f'    detail: "{detail}"\n'
        '    recommendation: "Repair under meth-level math re-review (ADR-007); not GlobalGreen."\n'
    )


def main() -> None:
    stems = [s.strip() for s in STEMS.read_text(encoding="utf-8").splitlines() if s.strip()]
    pass_n = 0
    fail_n = 0
    for stem in stems:
        p = MATH / stem
        if not p.is_file():
            continue
        text = p.read_text(encoding="utf-8")
        canon, debate = split_debate(text)
        findings: list[tuple[str, str, str]] = []
        for code, pat in CHECKS:
            if not pat.search(canon):
                findings.append((code, f"Missing or not detected field gate {code}", "medium"))
        if re.search(r"non_role:\s*\[\s*\]", canon):
            findings.append(("DEV-THEATER", "non_role is empty list", "high"))
        # HoTT overclaim heuristic: word present without nonclaim nearby in doctrine
        if re.search(r"\bHoTT\b|\bUnivalence\b", canon) and not re.search(
            r"not\s+claim|nonclaim|does_not_claim|non_role:.*HoTT", canon, re.I | re.S
        ):
            findings.append(
                (
                    "MATH-OVERCLAIM",
                    "HoTT/Univalence language without explicit nonclaim fence in sample",
                    "low",
                )
            )

        if not findings:
            if "STAGE1_MECHANICAL_PASS" not in debate:
                items = [
                    defect_item(
                        "STAGE1_MECHANICAL_PASS",
                        "Mechanical GTLA field gates passed (authority/math/non_role/structures/laws-or-requirements/negative_tests). Not PROVED.",
                        "info",
                    )
                ]
                debate = inject_defects(debate, items)
                p.write_text(canon.rstrip() + "\n" + debate, encoding="utf-8")
            pass_n += 1
            continue

        items = [defect_item(c, d, s) for c, d, s in findings]
        # avoid duplicate spam if already present
        if all(c in debate for c, _, _ in findings):
            fail_n += 1
            continue
        debate = inject_defects(debate, items)
        p.write_text(canon.rstrip() + "\n" + debate, encoding="utf-8")
        fail_n += 1

    receipt = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_stage1_has_rs_receipt.md"
    receipt.write_text(
        f"""# Stage-1 mechanical (HAS_RS only)

**AuthorityEffect:** None  
**Stems:** {len(stems)} from `rip_math_has_rs_stems.txt`

| Metric | Count |
| --- | ---: |
| mechanical PASS (or already tagged) | {pass_n} |
| defects injected / residual | {fail_n} |

Scope: Stage-1 mechanical field gates only on contracts with Stage-2 realization notes.  
Not PROVED · Not GlobalGreen · Not full semantic math re-review.

**AuthorityEffect: None.**
""",
        encoding="utf-8",
    )
    print("stems", len(stems), "pass", pass_n, "fail", fail_n)


if __name__ == "__main__":
    main()
