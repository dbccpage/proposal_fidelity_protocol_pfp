use omega_contracts::validation::{
    InvariantAtlasEntry, InvariantAtlasStore, SchemaGate, SchemaGateViolationKind,
    ValidationResult, ValidationStatus, ValidationViolation, Validator,
};
use omega_types::{InvariantLayer, InvariantPacket, Refusable, RefusalSource};

fn atlas_store() -> InvariantAtlasStore {
    InvariantAtlasStore::from_entries([(
        "Phi1",
        InvariantAtlasEntry::new(
            InvariantLayer::GTFOC,
            "finite cochain carrier",
            "primal-dual replay certificate",
        )
        .expect("test atlas entry is non-empty"),
    )])
    .expect("test atlas ids are unique")
}

fn packet(
    invariant_id: &str,
    layer: InvariantLayer,
    carrier_type: &str,
    witness_protocol_id: &str,
) -> InvariantPacket {
    InvariantPacket::new(
        layer,
        carrier_type,
        "value.weighted_quotient_norm",
        invariant_id,
        "law.exact_repair_preserves_value",
        "operators.e_i_r_c_m_profile",
        witness_protocol_id,
        true,
        "refusal.phi1_certificate_missing",
    )
    .expect("test packet fields are non-empty")
}

fn well_formed_packet() -> InvariantPacket {
    packet(
        "Phi1",
        InvariantLayer::GTFOC,
        "finite cochain carrier",
        "primal-dual replay certificate",
    )
}

#[test]
fn well_formed_invariant_packet_passes_schema_gate() {
    let gate = SchemaGate::new(atlas_store());
    let packet = well_formed_packet();

    let artifact = gate.validate_packet(&packet);

    assert_eq!(artifact.status, ValidationStatus::Valid);
    assert!(matches!(artifact.result, ValidationResult::Valid(_)));
    assert!(matches!(gate.admit_packet(&packet), Refusable::Value(_)));
}

#[test]
fn default_schema_gate_validator_accepts_well_formed_packet() {
    let packet = well_formed_packet();

    let artifact = SchemaGate::validate(&packet);

    assert_eq!(artifact.status, ValidationStatus::Valid);
}

#[test]
fn well_formed_invariant_transition_passes_schema_gate() {
    let gate = SchemaGate::new(atlas_store());
    let before = well_formed_packet();
    let after = well_formed_packet();

    let artifact = gate.validate_transition(&before, &after);

    assert_eq!(artifact.status, ValidationStatus::Valid);
    let ValidationResult::Valid(witnesses) = &artifact.result else {
        panic!("well-formed transition should be valid");
    };
    assert!(witnesses[0]
        .checked_fields
        .contains(&"certificate_required"));
    assert!(matches!(
        gate.admit_transition(&before, &after),
        Refusable::Value(_)
    ));
}

#[test]
fn unregistered_invariant_packet_returns_refusal() {
    let gate = SchemaGate::new(atlas_store());
    let packet = packet(
        "UnknownInvariant",
        InvariantLayer::GTFOC,
        "finite cochain carrier",
        "primal-dual replay certificate",
    );

    let artifact = gate.validate_packet(&packet);

    assert_eq!(artifact.status, ValidationStatus::Invalid);
    let ValidationResult::Invalid(violations) = artifact.result else {
        panic!("unregistered invariant should be invalid");
    };
    assert!(violations
        .iter()
        .any(|v| v.kind == SchemaGateViolationKind::UnregisteredInvariant));
    assert_eq!(
        gate.admit_packet(&packet),
        Refusable::Refused(RefusalSource::Refusal)
    );
}

#[test]
fn corrupted_invariant_transition_returns_refusal() {
    let gate = SchemaGate::new(atlas_store());
    let before = well_formed_packet();
    let after = packet(
        "Phi1",
        InvariantLayer::GTFOC,
        "mutated cochain carrier",
        "primal-dual replay certificate",
    );

    let artifact = gate.validate_transition(&before, &after);

    assert_eq!(artifact.status, ValidationStatus::Invalid);
    let ValidationResult::Invalid(violations) = artifact.result else {
        panic!("carrier mutation should be invalid");
    };
    assert!(violations
        .iter()
        .any(|v| v.kind == SchemaGateViolationKind::CarrierTypeMismatch
            && v.code() == "InvariantCarrierTypeMismatch"));
    assert_eq!(
        gate.admit_transition(&before, &after),
        Refusable::Refused(RefusalSource::Refusal)
    );
}

#[test]
fn semantic_invariant_transition_mutation_returns_refusal() {
    let gate = SchemaGate::new(atlas_store());
    let before = well_formed_packet();
    let after = InvariantPacket::new(
        InvariantLayer::GTFOC,
        "finite cochain carrier",
        "value.weighted_quotient_norm",
        "Phi1",
        "law.exact_repair_preserves_value",
        "operators.e_i_r_c_m_profile",
        "primal-dual replay certificate",
        false,
        "refusal.phi1_certificate_missing",
    )
    .expect("test packet fields are non-empty");

    let artifact = gate.validate_transition(&before, &after);

    assert_eq!(artifact.status, ValidationStatus::Invalid);
    let ValidationResult::Invalid(violations) = artifact.result else {
        panic!("semantic packet mutation should be invalid");
    };
    assert!(violations.iter().any(|v| {
        v.kind == SchemaGateViolationKind::PacketFieldMutation
            && v.field == "certificate_required"
            && v.code() == "InvariantPacketFieldMutation"
    }));
    assert_eq!(
        gate.admit_transition(&before, &after),
        Refusable::Refused(RefusalSource::Refusal)
    );
}

#[test]
fn invariant_id_mutation_returns_refusal() {
    let gate = SchemaGate::new(atlas_store());
    let before = well_formed_packet();
    let after = packet(
        "Gamma2",
        InvariantLayer::GTFOC,
        "finite cochain carrier",
        "primal-dual replay certificate",
    );

    let artifact = gate.validate_transition(&before, &after);

    assert_eq!(artifact.status, ValidationStatus::Invalid);
    let ValidationResult::Invalid(violations) = artifact.result else {
        panic!("invariant id mutation should be invalid");
    };
    assert!(violations
        .iter()
        .any(|v| v.kind == SchemaGateViolationKind::InvariantIdMutation));
    assert_eq!(
        gate.admit_transition(&before, &after),
        Refusable::Refused(RefusalSource::Refusal)
    );
}
