"""Add doctrine nonclaim fences for HAS_RS MATH-OVERCLAIM residuals."""
from __future__ import annotations

import re
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parents[5]
MATH = REPO / "omega_engine/crates/omega_contracts/src/contract_canonical_definitions/math"
STEMS = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_has_rs_stems.txt"


def split_debate(text: str) -> tuple[str, str]:
    key = "nomos_debate_NOT_CANONICAL:"
    if key not in text:
        return text, ""
    i = text.index(key)
    return text[:i], text[i:]


def main() -> None:
    stems = [s.strip() for s in STEMS.read_text(encoding="utf-8").splitlines() if s.strip()]
    fixed: list[str] = []
    for stem in stems:
        p = MATH / stem
        text = p.read_text(encoding="utf-8")
        canon, debate = split_debate(text)
        if not re.search(r"\bHoTT\b|\bUnivalence\b|\bPROVED\b|\bGlobalGreen\b", canon):
            continue
        if re.search(
            r"not\s+PROVED|not\s+GlobalGreen|does not claim|nonclaim",
            canon,
            re.I,
        ):
            continue
        data = yaml.safe_load(canon)
        if not isinstance(data, dict):
            continue
        doctrine = data.get("doctrine") if isinstance(data.get("doctrine"), dict) else {}
        summary = str(doctrine.get("summary") or "")
        fence = (
            " Nonclaim: this contract does not claim HoTT/Univalence discharge, "
            "PROVED status, or GlobalGreen."
        )
        doctrine["summary"] = (summary + fence).strip()
        nr = doctrine.get("non_role")
        if not isinstance(nr, list):
            nr = []
        extra = "HoTT/Univalence/PROVED/GlobalGreen discharge from this YAML alone"
        if extra not in nr:
            nr = list(nr) + [extra]
        doctrine["non_role"] = nr
        data["doctrine"] = doctrine

        preferred = [
            "schema_version",
            "contract_id",
            "title",
            "kind",
            "status",
            "layer",
            "descriptor",
            "math",
            "requirements",
            "laws",
            "replay",
            "relationships",
            "rust_binding",
            "negative_tests",
            "doctrine",
            "wip",
        ]
        ordered = {k: data[k] for k in preferred if k in data}
        for k, v in data.items():
            if k not in ordered:
                ordered[k] = v
        new_canon = yaml.safe_dump(
            ordered,
            sort_keys=False,
            allow_unicode=True,
            default_flow_style=False,
            width=100,
        )
        note = (
            "  - reviewer: panepistimion-math-prof\n"
            "    role: MATH_CANONICAL_REVIEW\n"
            "    code: METH_OVERCLAIM_FENCE\n"
            "    severity: info\n"
            '    claim_class: "[SCOPE FENCE]"\n'
            '    detail: "Added doctrine nonclaim fence for HoTT/Univalence/PROVED/GlobalGreen language."\n'
            '    recommendation: "Keep vocabulary; never mint proof status from contract text alone."\n'
            "    pass: stage1_meth_repair_has_rs\n"
        )
        if "METH_OVERCLAIM_FENCE" not in debate:
            if "potential_defects: []" in debate:
                debate = debate.replace(
                    "potential_defects: []",
                    "potential_defects:\n" + note.rstrip(),
                    1,
                )
            elif "  realization_delta_vs_implemented_math_file:" in debate:
                i = debate.index("  realization_delta_vs_implemented_math_file:")
                debate = debate[:i] + note + debate[i:]
            else:
                debate = debate.rstrip() + "\n" + note
        p.write_text(new_canon.rstrip() + "\n" + debate, encoding="utf-8")
        yaml.safe_load(p.read_text(encoding="utf-8"))
        fixed.append(stem)
    print("fenced", len(fixed))
    for s in fixed:
        print(" ", s)


if __name__ == "__main__":
    main()
