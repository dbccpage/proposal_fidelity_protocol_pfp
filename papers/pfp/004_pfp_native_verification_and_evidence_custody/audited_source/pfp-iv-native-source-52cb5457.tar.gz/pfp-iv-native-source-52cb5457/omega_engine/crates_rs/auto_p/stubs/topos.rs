//! STUB — `topos` subsystem (DELETED from omega_core). Scaffolding for AP-0
//! build wiring ONLY. These types reproduce just the surface referenced by the
//! extracted AutoP compiler; they are NOT the real topos engine. Behavior is
//! trivial/placeholder and is labeled as such at each site.

pub mod meta {
    pub mod meta_10 {
        pub mod anomalon {
            /// Boundary-check verdict. A real, self-contained data type (the
            /// stubbing here is only that it used to live in the `topos` tree):
            /// `Diamond` = closed surface, `Coal` = tears detected,
            /// `SovereignParadox` = self-referential obstruction.
            #[derive(Debug, Clone, Copy, PartialEq, Eq, serde::Serialize, serde::Deserialize)]
            pub enum OmegaVerdict {
                Diamond,
                Coal,
                SovereignParadox,
            }

            impl OmegaVerdict {
                /// `true` iff the verdict permits lowering/execution — only a
                /// closed surface (`Diamond`). `Coal` (tears) and
                /// `SovereignParadox` are non-executable.
                pub fn is_executable(&self) -> bool {
                    matches!(self, OmegaVerdict::Diamond)
                }
            }
        }
    }
}

pub mod operators {
    pub mod chain_complex_typed {
        /// STUB typed simplicial complex. The real `chain_complex()` builds a
        /// typed boundary chain and verifies ∂² = 0; here it returns a trivial
        /// chain whose check assumes well-formed input (so the in-tree H₁/H₂
        /// computation — which is local to `boundary_check` — still runs).
        pub struct SimplicialComplex {
            pub vertices: Vec<String>,
            pub edges: Vec<(usize, usize)>,
            pub triangles: Vec<(usize, usize, usize)>,
        }

        pub struct ChainComplex;

        impl ChainComplex {
            /// STUB: real ∂² = 0 verification removed; assumes well-formedness.
            pub fn verify_d_squared_zero(&self) -> bool {
                true
            }
        }

        impl SimplicialComplex {
            pub fn chain_complex(&self) -> ChainComplex {
                ChainComplex
            }
        }
    }

    pub mod infinity_groupoid {
        pub struct Site;
        pub struct SignSheaf;
        pub struct Poset;
        pub struct InfinityTopos;

        impl InfinityTopos {
            pub fn sheaves(_site: &Site) -> InfinityTopos {
                InfinityTopos
            }
        }

        /// Trivial Čech cohomology class (real computation removed).
        pub struct CechClass {
            pub trivial: bool,
        }

        pub struct CechCohomology;

        impl CechCohomology {
            /// STUB: returns the trivial class (real Čech computation removed).
            pub fn compute(_poset: &Poset, _sheaf: &SignSheaf, _scale: usize) -> CechClass {
                CechClass { trivial: true }
            }
        }

        pub struct GlobalSection {
            pub is_contractible: bool,
        }

        pub struct GlobalSectionSpace;

        impl GlobalSectionSpace {
            /// STUB: echoes the requested contractibility (real ∞-topos global
            /// section existence test removed).
            pub fn mock_constructor_task(is_contractible: bool, _b: bool) -> GlobalSection {
                GlobalSection { is_contractible }
            }
        }
    }
}

pub mod base_types {
    pub mod violation_presheaf {
        use std::collections::HashMap;

        /// STUB module-dependency graph. The real type backed a topological
        /// refactoring-advice engine (now removed); here it only records edges.
        #[derive(Default)]
        pub struct ModuleDependencyGraph {
            imports: HashMap<String, Vec<String>>,
        }

        impl ModuleDependencyGraph {
            pub fn new() -> Self {
                Self::default()
            }

            pub fn add_import(&mut self, from: &str, to: &str) {
                self.imports
                    .entry(from.to_string())
                    .or_default()
                    .push(to.to_string());
            }
        }
    }
}
