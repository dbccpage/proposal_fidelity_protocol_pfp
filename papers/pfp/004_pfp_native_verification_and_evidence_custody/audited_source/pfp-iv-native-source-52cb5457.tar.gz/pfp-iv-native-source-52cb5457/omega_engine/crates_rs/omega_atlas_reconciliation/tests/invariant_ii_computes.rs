//! Invariant II computes from the carried F2 matrices (provisional carrier model, doctrine v000).
//!
//! These tests pin the "compute, don't trust" contract: the validator must derive d₁∘d₀ from the
//! row's carried `d0`/`d1` matrices and flag a declared `d1_d0_zero` that disagrees with them.
use omega_atlas_reconciliation::cochain_validity::TriState;
use omega_atlas_reconciliation::row::*;
use omega_atlas_reconciliation::validator::validate_row;

#[test]
fn declared_true_but_matrices_false_is_flagged() {
    let mut r = ReconciliationRow::sample_good();
    r.cochain_validity.d1 = vec![vec![1u8, 0u8]]; // now computes False
    r.cochain_validity.d1_d0_zero = TriState::True; // but still declares True
    let f = validate_row(&r);
    assert!(f.iter().any(|x| x.contains("invariant-II")));
}

#[test]
fn correctly_terminalized_malformed_row_passes_invariant_ii() {
    let mut r = ReconciliationRow::sample_good();
    r.cochain_validity.d1 = vec![vec![1u8, 0u8]]; // computes False
    r.cochain_validity.d1_d0_zero = TriState::False; // declared matches computed
    r.terminal_status.status = TerminalStatus::RepresentationMalformed;
    r.terminal_status.reason = "correction emits an unclosed proof-defect".into();
    r.cochain_validity.failure_reason = "d1∘d0 != 0".into();
    // must NOT contain an invariant-II finding (correctly terminalized)
    assert!(!validate_row(&r).iter().any(|x| x.contains("invariant-II")));
}
