use linear_algebra::linear_algebra::incidence_matrix::{
    incidence_matrix, incidence_matrix_dmatrix,
};
use nalgebra::{DMatrix, DVector};
use omega_homology::finite_directed_graph::FiniteDirectedGraph;

/// Orthonormal basis of harmonic 1-cochains, `ker(Bᵀ) ⊆ R^|E|`.
///
/// `B` is the edge-node incidence (`|E| × |V|`). The matrix factored here is
/// `Bᵀ`, with zero rows added until it has at least as many rows as columns.
/// Thin SVD of a wide matrix omits kernel directions of `V`.
pub fn compute_harmonic_basis(topology: &FiniteDirectedGraph) -> Result<Vec<DVector<f64>>, String> {
    let n_nodes = topology.num_nodes();
    let edges = topology.edges();
    if edges.is_empty() {
        return Ok(vec![]);
    }

    let incidence = incidence_matrix_dmatrix(n_nodes, edges).map_err(|e| format!("{:?}", e))?;
    let n_edges = edges.len();
    let mut coboundary = DMatrix::<f64>::zeros(n_edges.max(n_nodes), n_edges);
    for edge in 0..n_edges {
        for node in 0..n_nodes {
            coboundary[(node, edge)] = incidence[(edge, node)] as f64;
        }
    }

    let svd = coboundary.svd(false, true);
    let v_t = svd.v_t.ok_or("SVD failed to produce V_t")?;
    if v_t.ncols() != n_edges || v_t.nrows() != svd.singular_values.len() {
        return Err(format!(
            "SVD V_t is {}x{} with {} singular values; expected {n_edges} columns and one value per row",
            v_t.nrows(),
            v_t.ncols(),
            svd.singular_values.len()
        ));
    }

    let mut basis = Vec::new();
    for i in 0..v_t.nrows() {
        let singular = svd.singular_values[i];
        if singular < 1e-10 {
            let mut vec = DVector::zeros(n_edges);
            for j in 0..n_edges {
                vec[j] = v_t[(i, j)];
            }
            basis.push(vec);
        }
    }

    Ok(basis)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_harmonic_basis_is_orthogonal_to_incidence() {
        let edges = vec![(0, 1), (1, 2), (2, 0)];
        let topology = FiniteDirectedGraph::from_pairs(
            &edges,
            omega_homology::finite_directed_graph::TheoremProvenance {
                verification_source: "test".to_string(),
            },
        )
        .unwrap();
        let basis = compute_harmonic_basis(&topology).unwrap();

        let basic_b = incidence_matrix(3, &edges).unwrap();
        let b = DMatrix::from_fn(3, 3, |r, c| basic_b.get(r, c).unwrap() as f64);

        for v in basis {
            let res = b.transpose() * &v;
            assert!(
                res.norm() < 1e-10,
                "basis vector not in ker(B^T): norm = {}",
                res.norm()
            );
        }
    }

    #[test]
    fn two_triangles_sharing_a_vertex_have_a_two_dimensional_cycle_space() {
        let edges = vec![(0, 1), (1, 2), (2, 0), (2, 3), (3, 4), (4, 2)];
        let topology = FiniteDirectedGraph::from_pairs(
            &edges,
            omega_homology::finite_directed_graph::TheoremProvenance {
                verification_source: "test".to_string(),
            },
        )
        .unwrap();
        let basis = compute_harmonic_basis(&topology).unwrap();
        assert_eq!(basis.len(), 2);
        assert!(basis.iter().all(|vector| vector.len() == edges.len()));

        let basic_b = incidence_matrix(5, &edges).unwrap();
        let b = DMatrix::from_fn(edges.len(), 5, |r, c| basic_b.get(r, c).unwrap() as f64);
        for vector in &basis {
            let residual = b.transpose() * vector;
            assert!(residual.norm() < 1e-8, "norm = {}", residual.norm());
        }
        let dot = basis[0].dot(&basis[1]);
        assert!(dot.abs() < 1e-8, "dot = {dot}");
    }

    #[test]
    fn test_harmonic_basis_is_orthonormal() {
        let edges = vec![(0, 1), (1, 2), (2, 0)];
        let topology = FiniteDirectedGraph::from_pairs(
            &edges,
            omega_homology::finite_directed_graph::TheoremProvenance {
                verification_source: "test".to_string(),
            },
        )
        .unwrap();
        let basis = compute_harmonic_basis(&topology).unwrap();

        for (i, v1) in basis.iter().enumerate() {
            for (j, v2) in basis.iter().enumerate() {
                let dot = v1.dot(v2);
                if i == j {
                    assert!(
                        (dot - 1.0).abs() < 1e-10,
                        "basis vector not normalized: dot = {}",
                        dot
                    );
                } else {
                    assert!(
                        dot.abs() < 1e-10,
                        "basis vectors not orthogonal: dot = {}",
                        dot
                    );
                }
            }
        }
    }
}
