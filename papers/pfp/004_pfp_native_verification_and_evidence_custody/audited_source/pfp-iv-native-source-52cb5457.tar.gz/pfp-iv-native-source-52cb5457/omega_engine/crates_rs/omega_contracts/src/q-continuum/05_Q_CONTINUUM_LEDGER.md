Q-Continuum Ledger
==================

Purpose
-------

The ledger is an append-only in-memory record of Q ideas, probes, finite descent attempts, authority traces, and residuals. It is serializable through serde because `omega_types` already uses serde.

Schema
------

Each `ObstructionLedgerEntry` records:

* idea ID,
* claim ID,
* probe ID,
* source/provenance,
* finite projection,
* descent obligation,
* witness,
* obstruction,
* residual,
* terminal status,
* authority update,
* sequence number,
* links to code/docs/tests when available.

The first implementation stores these fields in memory. Durable persistence is DESIGN_ONLY.

Ledger Collections
------------------

`QContinuumLedger` stores:

* `ideas`,
* `claims`,
* `probes`,
* `projections`,
* `obligations`,
* `descent_results`,
* `entries`,
* `authority_traces`,
* `sequence`.

Supported Operations
--------------------

Implemented operations:

* add idea,
* add claim,
* add probe,
* add projection,
* add descent obligation,
* add descent result,
* query residuals,
* query authority trace,
* query unsupported claims,
* query terminal claims,
* query speculative claims.

Invariants
----------

* A ledger row is not proof.
* A witness can strengthen authority only inside scope.
* A failed descent creates a visible residual.
* Repeated obstruction creates repeated rows.
* Unsupported claims remain unsupported until finite support exists.

Serialization
-------------

The ledger and its records derive `Serialize` and `Deserialize`. The repository can later choose a durable store, but this slice does not add a database dependency.
