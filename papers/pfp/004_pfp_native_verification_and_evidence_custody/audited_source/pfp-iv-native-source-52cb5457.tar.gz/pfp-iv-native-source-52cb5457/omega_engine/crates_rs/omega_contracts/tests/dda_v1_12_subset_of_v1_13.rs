use std::collections::BTreeSet;
use std::fs;
use std::path::PathBuf;

const V1_12_REQUIRED_SUBSTRINGS: &[&str] = &[
    "pub struct FaceLambda",
    "pub struct OrientedTriangle",
    "pub struct FiniteWindow",
    "pub struct FiniteWindowScan",
    "pub struct Boundary1",
    "pub struct Cochain0",
    "pub type Cochain1",
    "pub struct FiniteDiagnostic",
    "pub struct NonDestructiveExtensionCertificate",
    "pub struct FiniteLambdaStepCertificate",
    "pub struct QuotientIrreducibilityCertificate",
    "pub struct BornNormalizationCertificate",
    "pub struct ObserverPassivityCertificate",
    "pub struct CrossTermObstructionCertificate",
    "pub struct NormalizedL1Weight",
    "pub struct OperatorProposal",
    "pub struct ProofCarryingAiProposal",
    "pub enum DegreeTwoSupport",
    "pub struct XiTiePrecondition",
    "pub struct XiTieBreakCertificate",
    "pub enum RealizationBoundary",
    "pub enum TerminalStatus",
    "pub struct ClaimPacket",
    "PAPER000C_CLAIM_PACKET_EVIDENCE_ID",
    "pub fn checked_boundary",
    "pub fn checked_primitive_difference",
    "pub fn checked_scan",
    "pub fn checked_scan_c1",
    "pub fn checked_closure_defect",
    "pub fn checked_gamma2",
    "pub fn checked_l1_tension",
    "pub fn require_irreducible",
    "pub fn checked_from_quotient_certificate",
    "pub fn checked_diagnostic_from_quotient",
    "pub fn checked_from_l1_weights",
    "pub fn born_probability_from_squared_norm",
    "pub fn preserves_diagnostic",
    "pub fn require_passive",
    "pub fn observed_diagnostic",
    "pub fn require_typed_obstruction",
    "pub fn diagnostic",
    "pub fn require_tie_breaker",
    "pub fn require_lambda_license",
    "pub fn require_non_destructive",
    "pub fn require_valid",
    "pub fn require_proof_carrying",
    "pub fn accepted_diagnostic",
    "pub fn after_tension",
    "pub fn descends_to_real0",
    "pub fn is_terminalized",
    "pub fn has_authority",
    "pub fn require_terminalized",
    "pub fn require_authority",
    "std::ops::Add for FaceLambda",
    "std::ops::Neg for FaceLambda",
    "std::ops::Mul<i64> for FaceLambda",
];

#[test]
fn test_dda_v1_12_substrings_survive_in_v1_13() {
    assert_eq!(
        V1_12_REQUIRED_SUBSTRINGS.len(),
        56,
        "the non-destruction witness must enumerate the complete v1.12 surface"
    );

    let path = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(
        "src/contract_canonical_definitions/rust/omega_discrete_deformation_algebra/discrete_deformation_algebra.contract.yaml",
    );
    let source = fs::read_to_string(&path).expect("DDA contract is readable");
    let contract: serde_yaml::Value =
        serde_yaml::from_str(&source).expect("DDA contract is valid YAML");

    assert_eq!(
        contract["contract_id"].as_str(),
        Some("urn:omega:rust:omega_discrete_deformation_algebra:discrete_deformation_algebra:v1.13.0")
    );

    let required = contract["required_substrings"]
        .as_sequence()
        .expect("required_substrings is a sequence");
    let current = required
        .iter()
        .map(|value| value.as_str().expect("required substring is text"))
        .collect::<BTreeSet<_>>();

    for pin in V1_12_REQUIRED_SUBSTRINGS {
        assert!(
            current.contains(pin),
            "v1.13 dropped the v1.12 required substring {pin:?}"
        );
    }

    for ledger_pin in [
        "pub struct FiniteLambdaLedger",
        "impl FiniteLambdaLedger",
        "pub fn require_chained",
    ] {
        assert!(
            current.contains(ledger_pin),
            "v1.13 is missing additive ledger pin {ledger_pin:?}"
        );
    }
}
