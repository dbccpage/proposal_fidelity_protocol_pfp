pub mod artifact_policy;
pub mod authorization_basis;
pub mod binding;
pub mod contract_images;
pub mod contracts_contract;
pub mod descriptors;
pub mod enforcement;
pub mod file_contract_substring;
/// Canonical improvement / maintenance contract family (V1).
pub mod improvement;
pub mod kinds;
pub mod mub_domain_ownership;
pub mod published_corpus;
pub mod registry;
pub mod runtime;
pub mod schema;
pub mod sealed;
pub mod traits;
pub mod validate;
pub mod validation;
pub mod witness;
pub use binding::*;
pub use contracts_contract::*;
pub use enforcement::*;
pub use file_contract_substring::source_satisfies_file_contract_substring;
pub use kinds::*;
pub use runtime::*;
pub use schema::{ArtifactFamily, EffectLawDecl, PhiLawDecl, StructureLawDecl};
pub use sealed::Sealed;
pub use validate::*;
pub use witness::*;

// ── Migrated from obstruction_calculus (Wave 6) ─────────────────────────────
pub mod certificate_promotion;
pub mod no_authority;
pub mod operator_gauge;

pub use certificate_promotion::*;
pub use operator_gauge::*;

#[cfg(test)]
mod contract_property_witnesses;
