# Dual-face library spine perfection ledger

**Status:** ACTIVE — library-epic preflight  
**Date:** 2026-08-01  
**AuthorityEffect:** `None`  

---

## Controlling graph (operator law)

```text
YAML (math object law)
   → LEAN4 (mechanization / invariants)
   → RUST (PROD face)  |  PYTHON (prototype / dual face)
```

| Layer | Role | Mints authority? |
| --- | --- | --- |
| Math YAML | Object law + debate | **No** |
| LEAN4 | Mechanized invariants, nonclaims, quotient discipline | **No** (proof ≠ host authority) |
| Rust | PROD computation / carriers | **No** |
| Python | Dual-face / prototype / tooling | **No** |

**Together** they must be **consistent enough** that CODA **proposal → eval → auth** can run under host rules:

- **PrimDiff** (primitive difference)  
- **Zero-rel** (zero-difference relation)  
- **Finite quotient** residual  

Authority remains **host-gated** under CODA (PrimDiff / zero-rel / finite quotient), never ambiently minted by a single surface.

---

## Dual-face spines (this epic’s RS|PY perfection set)

| # | Math role | Rust crate | Python package | Lean anchors (examples) |
| --- | ---: | --- | --- | --- |
| S0 | PrimDiff / zero-rel / finite quotient | `omega_homotopy_type_theory` (`primitive_difference.rs`, …) + `omega_types` (`primitive_difference.rs`) | `omega_homotopy_type_theory` + `omega_types/primitive_difference.py` | `OmegaCore.PrimitiveDifference`, `CODA_FOC_EPK_PrimitiveDifference`, GTFOC EPK |
| S1 | Judgment rows LIB↔skeleton↔ENC | `omega_atlas_reconciliation` (row, validator, identity_witness, ledger) | `omega_atlas_reconciliation` | AF005 / EPK primitive-difference roles |
| S2 | Carriers, d, Čech, cohomology | `omega_homological` (cech_gate, cochain, coboundary, …) | `omega_homological` | FOC / cochain / exactness suites |
| S3 | Φ₁, Γ₂, Ξ, observers | `omega_functional` | `omega_functional` | FOC residual / observer packets |
| S4 | Sheaf sections / restrictions | `omega_sheaf_theory` | `omega_sheaf_theory` | Sheaf / Čech bridges |
| S5 | Art_(≤ 2) records | `omega_higher_category_theory` | `omega_higher_category_theory` | 2-cell / bicategory records |

**Not in this table (upstream YAML work continues):** other math contracts (B-families). Dual-face perfection **consumes** settled YAML + Lean, not the reverse.

---

## Module-stem census (2026-08-01, heuristic)

Counts are **file stems** under `crates/<name>/src` vs `omega_engine_py/<name>` (excluding `lib.rs`/`mod.rs`/`__init__.py`; tests partially included on PY). This is a **parity radar**, not a proof of behavioral identity.

| Spine | RS stems | PY stems | only_rs (sample) | only_py (sample) | Radar |
| --- | ---: | ---: | --- | --- | --- |
| S0 HoTT | 10 | 13 | higher_inductive_type, hott_contract_alignment | quotient_identity, hott_boundary | **Split**: theory in HoTT; judgment record also in `omega_types` |
| S0 types | 77 | 22 | large RS type estate | smaller PY subset | **PY lag** on shared types |
| S1 atlas | 20 | 9 | ledger, reconciler, math_proof, product_claim, … | thin | **PY lag** on judgment machinery |
| S2 homological | 53 | 63 | homological_contract_alignment | cohomology_h1, discrete_derham, exact_solve, … | Near stem-parity; **semantic** parity unproven |
| S3 functional | 21 | 41 | — | born_probabilities, density_*, dual_verification, … | PY **wider**; risk of PY-only authority cosplay |
| S4 sheaf | 10 | 12 | sheaf_contract_alignment | cech_gate (PY) | Near parity; align Čech ownership vs homological |
| S5 higher-cat | 11 | 16 | higher_category_contract_alignment | fibration, higher_category_boundary, transport_cone | PY extras need fence |

---

## Critical semantic gap (blocks library epic)

### PrimDiff math YAML is still the wrong object

`math/primitive_difference.contract.yaml` currently speaks **added/removed/modified primitives** (set-diff of “primitives”).

Live RS/Lean/CODA speak:

- `δ : A → A → B`  
- `Zero : B → Prop`  
- `ZeroRel x y := Zero(δ x y)`  
- finite carrier + quotient classes  
- observables **factor through** residual quotient  

Until that YAML is meth-repaired to the CODA PrimDiff object, the chain

```text
YAML → LEAN4 → RS|PY
```

is **broken at the root** for S0–S1.  
B1/B2/B3 YAML work does **not** close this.

**First dual-face perfection gate:** meth-repair `primitive_difference` YAML to PrimDiff/zero-rel/finite quotient, then re-bind RS/PY/Lean faces.

---

## Perfection criteria (per spine)

A spine is **dual-face ready for library epic** only if all hold:

1. **YAML** — object_kind, laws, negative_tests, non_role match the **intended CODA object** (not shell / not overclaim).  
2. **LEAN4** — cited modules build; sorry-scan known; no claim of host AuthorityEffect.  
3. **Rust PROD** — implements YAML laws; refuse paths kill negative_tests; no ambient authority mint.  
4. **Python dual** — same public invariants as Rust for the **shared surface** (types + pure functions); prototype-only extras fenced.  
5. **Parity tests** — at least one cross-face invariant test (or documented intentional PY-only / RS-only).  
6. **Atlas rows** (S1) — every material drift is a PrimitiveDifference judgment row, not silent rewrite.

**None of 1–5 mint proposal/eval/auth.** They only make the **substrate honest** so CODA host rules can.

---

## Ordered work program (do not reorder)

| Wave | Work | Why |
| --- | --- | --- |
| **W0** | Meth-repair `primitive_difference` YAML → PrimDiff/zero-rel/finite quotient | Root object law |
| **W1** | S0 dual-face: `omega_types` judgment + `omega_homotopy_type_theory` theory (RS↔PY API table) | Foundation for all judgment |
| **W2** | S1 atlas rows/validator/ledger dual-face | LIB↔skeleton↔ENC for library epic |
| **W3** | S2 homological dual-face (carriers, d, Čech, cohomology) — consume B2 YAML | Math spine for papers |
| **W4** | S3 functional Φ₁/Γ₂/Ξ observers dual-face | Residual channels |
| **W5** | S4 sheaf dual-face | Sections / restrictions |
| **W6** | S5 Art_(≤2) dual-face | Higher cells |
| **W7** | Library epic consumes only **dual-face ready** spines | No epic on soft ground |

---

## CODA proposal / eval / auth (reminder)

| Stage | Substrate | Gate |
| --- | --- | --- |
| Proposal | rows + PrimDiff judgments | no ambient authority |
| Eval | finite quotients, residuals, Φ₁/Γ₂/Ξ | evidence ceilings |
| Auth | host / sealed roles only | never RS/PY/YAML alone |

---

## Next action (recommended)

**Execute W0 + W1 slice 1:**  

1. Meth-repair `urn:omega:math:primitive_difference:v0.1.0` to CODA PrimDiff.  
2. Publish RS↔PY API table for `PrimitiveDifference` / `ZeroRel` / finite carrier / quotient class.  
3. Close one behavioral parity test: zero-rel reflexivity/symmetry/transitivity refuse + factors-through invariant (RS + PY).  

Then library epic can stand on S0.

---

**AuthorityEffect: None.**  
**Not PROVED. Not GlobalGreen. Not LEAN4 discharge by this ledger alone.**
