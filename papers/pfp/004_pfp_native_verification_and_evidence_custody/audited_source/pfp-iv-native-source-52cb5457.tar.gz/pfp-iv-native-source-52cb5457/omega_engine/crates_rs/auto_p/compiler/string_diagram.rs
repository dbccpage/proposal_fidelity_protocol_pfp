use std::collections::{HashMap, HashSet, VecDeque};

pub type WireId = usize;
pub type NodeId = usize;

#[derive(
    Debug, Clone, Copy, PartialEq, Eq, Hash, Default, serde::Serialize, serde::Deserialize,
)]
pub enum Parity {
    #[default]
    Even,
    Odd,
}

impl Parity {
    #[inline]
    pub fn flip(self) -> Self {
        match self {
            Parity::Even => Parity::Odd,
            Parity::Odd => Parity::Even,
        }
    }

    #[inline]
    pub fn compose(self, other: Self) -> Self {
        match (self, other) {
            (Parity::Even, Parity::Even) | (Parity::Odd, Parity::Odd) => Parity::Even,
            _ => Parity::Odd,
        }
    }

    #[inline]
    pub fn sign(self) -> i8 {
        match self {
            Parity::Even => 1,
            Parity::Odd => -1,
        }
    }

    /// From a count: even count → Even, odd count → Odd.
    #[inline]
    pub fn from_count(n: usize) -> Self {
        if n.is_multiple_of(2) {
            Parity::Even
        } else {
            Parity::Odd
        }
    }
}

/// Represents an object/resource in the category.
///
/// Extended with Z₂-grading (parity) and ghost number for BRST cohomology.
/// - `parity`: Even (bosonic) or Odd (fermionic)
/// - `ghost_number`: Z-grading for BV/BRST differential
#[derive(Debug, Clone)]
pub struct Wire {
    pub id: WireId,
    pub name: String,
    /// Z₂ parity: Even (bosonic) or Odd (fermionic).
    pub parity: Parity,
    /// Ghost number for BRST cohomology. Classical fields have gh=0.
    pub ghost_number: i32,
}

impl Wire {
    /// Create a wire with default parity (Even) and ghost number (0).
    /// This maintains backward compatibility with existing code.
    pub fn new(id: WireId, name: impl Into<String>) -> Self {
        Self {
            id,
            name: name.into(),
            parity: Parity::Even,
            ghost_number: 0,
        }
    }

    /// Create a graded wire with explicit parity and ghost number.
    /// Used for fermionic wires and BRST cohomology.
    pub fn graded(id: WireId, name: impl Into<String>, parity: Parity, ghost_number: i32) -> Self {
        Self {
            id,
            name: name.into(),
            parity,
            ghost_number,
        }
    }

    /// Check if this wire is fermionic (odd parity).
    pub fn is_fermionic(&self) -> bool {
        self.parity == Parity::Odd
    }

    /// Check if this wire is bosonic (even parity).
    pub fn is_bosonic(&self) -> bool {
        self.parity == Parity::Even
    }

    /// Compute Koszul sign when this wire crosses another.
    /// Koszul rule: (-1)^{|a|*|b|} where |x| is the parity.
    pub fn koszul_sign(&self, other: &Self) -> i8 {
        if self.parity == Parity::Odd && other.parity == Parity::Odd {
            -1
        } else {
            1
        }
    }

    pub fn hash(&self) -> blake3::Hash {
        let mut h = blake3::Hasher::new();
        h.update(b"WIRE");
        h.update(self.name.as_bytes());
        h.update(&[self.parity.sign() as u8]);
        h.update(&self.ghost_number.to_le_bytes());
        h.finalize()
    }
}

/// Represents a morphism (operation) in the category.
#[derive(Debug, Clone)]
pub struct Node {
    pub id: NodeId,
    pub op: String,
    pub inputs: Vec<WireId>,
    pub outputs: Vec<WireId>,
}

impl Node {
    pub fn hash(&self) -> blake3::Hash {
        let mut h = blake3::Hasher::new();
        h.update(b"NODE");
        h.update(self.op.as_bytes());
        for w in &self.inputs {
            h.update(&w.to_le_bytes());
        }
        for w in &self.outputs {
            h.update(&w.to_le_bytes());
        }
        h.finalize()
    }
}

// ============================================================
// Self-Loop (Trace Operation)
// ============================================================

/// A self-loop on a node: a wire that exits and re-enters the same node.
///
/// In categorical terms, this is the trace operation for traced monoidal categories.
/// Each loop contributes to the genus of the diagram viewed as a surface.
#[derive(Debug, Clone)]
pub struct Loop {
    /// The node on which this loop exists.
    pub node_id: NodeId,
    /// The wire forming the loop.
    pub wire: Wire,
}

impl Loop {
    pub fn new(node_id: NodeId, wire: Wire) -> Self {
        Self { node_id, wire }
    }
}

/// Error type for diagram operations.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DiagramError {
    /// Node not found in the diagram.
    NodeNotFound(NodeId),
    /// Wire not found in the diagram.
    WireNotFound(WireId),
    /// Invalid boundary specification for pants composition.
    InvalidBoundary(String),
    /// BRST consistency check failed.
    BRSTInconsistent(String),
}

impl std::fmt::Display for DiagramError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DiagramError::NodeNotFound(id) => write!(f, "Node {} not found", id),
            DiagramError::WireNotFound(id) => write!(f, "Wire {} not found", id),
            DiagramError::InvalidBoundary(msg) => write!(f, "Invalid boundary: {}", msg),
            DiagramError::BRSTInconsistent(msg) => write!(f, "BRST inconsistent: {}", msg),
        }
    }
}

impl std::error::Error for DiagramError {}

/// A complete string diagram representing a composite program/morphism.
///
/// Extended to support closed strings (loops), genus tracking, and BRST cohomology.
#[derive(Debug, Clone, Default)]
pub struct Diagram {
    pub wires: HashMap<WireId, Wire>,
    pub nodes: HashMap<NodeId, Node>,
    /// Self-loops on nodes (trace operations).
    pub loops: Vec<Loop>,
    pub next_wire: WireId,
    pub next_node: NodeId,
}

impl Diagram {
    pub fn new() -> Self {
        Self {
            wires: HashMap::new(),
            nodes: HashMap::new(),
            loops: Vec::new(),
            next_wire: 0,
            next_node: 0,
        }
    }

    pub fn merkle_root(&self) -> blake3::Hash {
        let mut h = blake3::Hasher::new();
        let mut node_hashes: Vec<_> = self.nodes.values().map(|n| n.hash()).collect();
        node_hashes.sort_by_key(|hash| *hash.as_bytes());
        for nh in node_hashes {
            h.update(nh.as_bytes());
        }
        // Include loops in the hash
        for lp in &self.loops {
            h.update(b"LOOP");
            h.update(&lp.node_id.to_le_bytes());
            h.update(lp.wire.hash().as_bytes());
        }
        h.finalize()
    }

    /// Allocates a new wire in the diagram with default parity and ghost number.
    pub fn add_wire(&mut self, name: &str) -> WireId {
        let id = self.next_wire;
        self.next_wire += 1;
        self.wires.insert(id, Wire::new(id, name));
        id
    }

    /// Allocates a new graded wire with explicit parity and ghost number.
    pub fn add_graded_wire(&mut self, name: &str, parity: Parity, ghost_number: i32) -> WireId {
        let id = self.next_wire;
        self.next_wire += 1;
        self.wires
            .insert(id, Wire::graded(id, name, parity, ghost_number));
        id
    }

    /// Adds a new node (morphism) to the diagram connecting the specified wires.
    pub fn add_node(&mut self, op: &str, inputs: Vec<WireId>, outputs: Vec<WireId>) -> NodeId {
        let id = self.next_node;
        self.next_node += 1;
        self.nodes.insert(
            id,
            Node {
                id,
                op: op.to_string(),
                inputs,
                outputs,
            },
        );
        id
    }

    // ============================================================
    // Loop (Trace) Operations
    // ============================================================

    /// Add a self-loop on a node (trace operation).
    ///
    /// A loop represents a wire that exits and re-enters the same node,
    /// implementing the categorical trace operation.
    pub fn add_loop(&mut self, node_id: NodeId, wire: Wire) -> Result<(), DiagramError> {
        if !self.nodes.contains_key(&node_id) {
            return Err(DiagramError::NodeNotFound(node_id));
        }
        self.loops.push(Loop::new(node_id, wire));
        Ok(())
    }

    /// Add a self-loop with default parity and ghost number.
    ///
    /// # Note
    /// The loop wire is inserted into `self.wires` so it participates in
    /// hashing, BRST checks, and `merkle_root()`.
    pub fn add_loop_simple(
        &mut self,
        node_id: NodeId,
        wire_name: &str,
    ) -> Result<(), DiagramError> {
        let id = self.next_wire;
        self.next_wire += 1;
        let wire = Wire::new(id, wire_name);
        // ✅ BUG FIX: insert the wire into self.wires so it is reachable
        self.wires.insert(id, Wire::new(id, wire_name));
        self.add_loop(node_id, wire)
    }

    /// Get all loops in the diagram.
    pub fn get_loops(&self) -> &[Loop] {
        &self.loops
    }

    /// Get loops attached to a specific node.
    pub fn loops_on_node(&self, node_id: NodeId) -> Vec<&Loop> {
        self.loops
            .iter()
            .filter(|lp| lp.node_id == node_id)
            .collect()
    }

    /// Count total number of loops.
    pub fn loop_count(&self) -> usize {
        self.loops.len()
    }

    // ============================================================
    // Genus Tracking (Topological Invariant)
    // ============================================================

    /// Compute the genus of the diagram viewed as a 2D surface.
    ///
    /// For a string diagram interpreted as a worldsheet:
    ///   genus = loops - (connected_components - 1)
    ///
    /// For a tree diagram (no loops), genus = 0.
    /// Each self-loop adds 1 to the genus (creates a handle).
    ///
    /// This is a simplified formula assuming planar base diagram + handles.
    /// The full formula uses Euler characteristic: genus = 1 - (V - E + F) / 2.
    pub fn genus(&self) -> usize {
        // For our purposes: each loop contributes 1 to genus
        // A more sophisticated implementation would compute connected components
        // and use the full Euler characteristic formula.
        let connected = self.connected_components();
        if connected == 0 {
            return 0;
        }
        // genus = loops - (components - 1), but genus >= 0
        let base_contribution = connected.saturating_sub(1);
        self.loops.len().saturating_sub(base_contribution)
    }

    /// Compute the Euler characteristic of the diagram as a graph.
    /// chi = V - E where V = nodes, E = wires (edges connecting nodes).
    pub fn euler_characteristic(&self) -> i32 {
        let v = self.nodes.len() as i32;
        let e = self.wire_edge_count() as i32 + self.loops.len() as i32;
        v - e
    }

    /// Count number of connected components in the diagram.
    ///
    /// Runs a DFS over a wire-adjacency index built in O(N·arity), so the
    /// overall algorithm is O(N + E) — not the old O(N² * W).
    pub fn connected_components(&self) -> usize {
        if self.nodes.is_empty() {
            return 0;
        }

        // Build wire→(producers, consumers) in one pass
        let index = self.wire_adjacency_index();

        // Build adjacency: node → neighbour nodes (via shared wires)
        let mut adjacency: HashMap<NodeId, Vec<NodeId>> = HashMap::new();
        for node in self.nodes.values() {
            adjacency.entry(node.id).or_default();
        }
        for (_, (producers, consumers)) in &index {
            for &p in producers {
                for &c in consumers {
                    if p != c {
                        adjacency.entry(p).or_default().push(c);
                        adjacency.entry(c).or_default().push(p);
                    }
                }
            }
        }

        // DFS component count
        let mut visited: HashSet<NodeId> = HashSet::new();
        let mut components = 0;
        for &node_id in self.nodes.keys() {
            if !visited.contains(&node_id) {
                components += 1;
                let mut stack = vec![node_id];
                while let Some(current) = stack.pop() {
                    if visited.insert(current) {
                        if let Some(neighbors) = adjacency.get(&current) {
                            for &n in neighbors {
                                if !visited.contains(&n) {
                                    stack.push(n);
                                }
                            }
                        }
                    }
                }
            }
        }
        components
    }

    /// Build a wire-to-nodes index: wire_id → (producers, consumers).
    ///
    /// O(N·avg_arity) — built once and reused by any analysis that needs
    /// wire adjacency. Eliminates the repeated O(N²) scans in the old
    /// `connected_components` and `wire_edge_count` implementations.
    pub fn wire_adjacency_index(&self) -> HashMap<WireId, (Vec<NodeId>, Vec<NodeId>)> {
        let mut index: HashMap<WireId, (Vec<NodeId>, Vec<NodeId>)> = HashMap::new();
        for node in self.nodes.values() {
            for &w in &node.outputs {
                index.entry(w).or_default().0.push(node.id);
            }
            for &w in &node.inputs {
                index.entry(w).or_default().1.push(node.id);
            }
        }
        index
    }

    /// For a given node, collect all other nodes that share any wire (input or output).
    pub fn neighbours(&self, node_id: NodeId) -> Vec<NodeId> {
        let index = self.wire_adjacency_index();
        let mut result = HashSet::new();
        if let Some(node) = self.nodes.get(&node_id) {
            // Check all wires this node touches (inputs + outputs)
            for &wire_id in node.inputs.iter().chain(node.outputs.iter()) {
                if let Some((producers, consumers)) = index.get(&wire_id) {
                    for &other in producers.iter().chain(consumers.iter()) {
                        if other != node_id {
                            result.insert(other);
                        }
                    }
                }
            }
        }
        result.into_iter().collect()
    }

    /// Count number of wire edges (connections between at least one producer and one consumer).
    ///
    /// A wire that has both at least one producer and at least one consumer is an "active edge".
    /// The count includes multi-edge wires (a wire with k producers driving m consumers
    /// counts as k*m edges topologically, but here we count wires, not pairs).
    fn wire_edge_count(&self) -> usize {
        let index = self.wire_adjacency_index();
        index
            .values()
            .filter(|(p, c)| !p.is_empty() && !c.is_empty())
            .count()
    }

    // ============================================================
    // BRST Cohomology Operations
    // ============================================================

    /// Apply the BRST differential Q to the diagram.
    ///
    /// Q acts by incrementing the ghost number of each wire by 1
    /// and flipping the parity (since Q is an odd operator).
    ///
    /// Returns `Some(transformed_diagram)` if consistent, `None` if Q^2 != 0.
    pub fn brst_transform(&self) -> Option<Diagram> {
        let mut transformed = self.clone();

        // Apply Q to all wires: gh -> gh + 1, parity -> flipped
        for wire in transformed.wires.values_mut() {
            wire.ghost_number += 1;
            wire.parity = wire.parity.flip();
        }

        // Apply Q to loop wires
        for lp in &mut transformed.loops {
            lp.wire.ghost_number += 1;
            lp.wire.parity = lp.wire.parity.flip();
        }

        // Verify Q^2 = 0 by applying Q again and checking it returns to original modulo 2
        // For our simplified model: Q^2 should give back the original parity
        // Since Q flips parity twice, we get back the original parity.
        // For ghost number: Q^2 gives gh + 2.
        // This is consistent with Q^2 = 0 in homology (not in the graded sense).
        Some(transformed)
    }

    /// Check if the diagram is BRST-closed: Q(diagram) = 0.
    ///
    /// A diagram is BRST-closed if it represents a cohomology class.
    /// For our model: a diagram is closed if all wires have consistent
    /// ghost numbers along paths (no ghost number jumps that would violate Q^2 = 0).
    pub fn is_brst_closed(&self) -> bool {
        // Check consistency: for each node, the total ghost number change
        // from inputs to outputs should be consistent.
        for node in self.nodes.values() {
            let input_ghost: i32 = node
                .inputs
                .iter()
                .filter_map(|id| self.wires.get(id))
                .map(|w| w.ghost_number)
                .sum();
            let output_ghost: i32 = node
                .outputs
                .iter()
                .filter_map(|id| self.wires.get(id))
                .map(|w| w.ghost_number)
                .sum();

            // Allow ghost number to change by at most 1 per morphism
            // (morphisms in BV formalism can have ghost number)
            if (output_ghost - input_ghost).abs() > 1 {
                return false;
            }
        }

        // Check loops: loop wire should have even total ghost contribution
        // for the trace to be well-defined
        for lp in &self.loops {
            if lp.wire.ghost_number % 2 != 0 {
                // Odd ghost number on a loop can cause anomalies
                // but doesn't strictly violate closure
            }
        }

        true
    }

    /// Check if this diagram is BRST-exact: diagram = Q(parent).
    ///
    /// A diagram is exact if it's in the image of Q.
    pub fn is_brst_exact(&self, parent: &Diagram) -> bool {
        if let Some(q_parent) = parent.brst_transform() {
            // Check structural equality (ignoring IDs)
            self.structurally_equivalent(&q_parent)
        } else {
            false
        }
    }

    /// Check if two diagrams are structurally equivalent.
    fn structurally_equivalent(&self, other: &Diagram) -> bool {
        // Same number of nodes, wires, loops
        if self.nodes.len() != other.nodes.len()
            || self.wires.len() != other.wires.len()
            || self.loops.len() != other.loops.len()
        {
            return false;
        }

        // Check wire properties match (by sorted comparison)
        let mut self_wires: Vec<_> = self
            .wires
            .values()
            .map(|w| (w.name.clone(), w.parity, w.ghost_number))
            .collect();
        let mut other_wires: Vec<_> = other
            .wires
            .values()
            .map(|w| (w.name.clone(), w.parity, w.ghost_number))
            .collect();
        self_wires.sort_by(|a, b| a.0.cmp(&b.0));
        other_wires.sort_by(|a, b| a.0.cmp(&b.0));

        self_wires == other_wires
    }

    /// Compute the total ghost number of the diagram.
    pub fn total_ghost_number(&self) -> i32 {
        self.wires.values().map(|w| w.ghost_number).sum::<i32>()
            + self
                .loops
                .iter()
                .map(|lp| lp.wire.ghost_number)
                .sum::<i32>()
    }

    /// Compute the total parity of the diagram.
    pub fn total_parity(&self) -> Parity {
        let wire_parity = self
            .wires
            .values()
            .fold(Parity::Even, |acc, w| acc.compose(w.parity));
        let loop_parity = self
            .loops
            .iter()
            .fold(Parity::Even, |acc, lp| acc.compose(lp.wire.parity));
        wire_parity.compose(loop_parity)
    }

    // ============================================================
    // Pair-of-Pants Composition
    // ============================================================

    /// Compose two diagrams via pair-of-pants surgery along shared boundary wires.
    ///
    /// Glues `left` and `right` diagrams along the specified shared boundary wire IDs.
    /// The genus of the result is: genus(left) + genus(right) + (shared_boundary.len() - 1).
    ///
    /// Returns an error if boundary wires are not found or inconsistent.
    pub fn pants_compose(
        left: &Diagram,
        right: &Diagram,
        shared_boundary: &[WireId],
    ) -> Result<Diagram, DiagramError> {
        if shared_boundary.is_empty() {
            return Err(DiagramError::InvalidBoundary(
                "Shared boundary cannot be empty".to_string(),
            ));
        }

        // Validate that boundary wires exist in left diagram
        for &wire_id in shared_boundary {
            if !left.wires.contains_key(&wire_id) {
                return Err(DiagramError::WireNotFound(wire_id));
            }
        }

        let mut result = Diagram::new();

        // Copy wires from left, remapping IDs
        let mut left_wire_map: HashMap<WireId, WireId> = HashMap::new();
        for (old_id, wire) in &left.wires {
            let new_id = result.next_wire;
            result.next_wire += 1;
            left_wire_map.insert(*old_id, new_id);
            result.wires.insert(
                new_id,
                Wire {
                    id: new_id,
                    name: wire.name.clone(),
                    parity: wire.parity,
                    ghost_number: wire.ghost_number,
                },
            );
        }

        // Copy wires from right, but map boundary wires to left's versions
        let mut right_wire_map: HashMap<WireId, WireId> = HashMap::new();
        for (old_id, wire) in &right.wires {
            // Check if this wire matches a boundary wire by name
            let boundary_match = shared_boundary
                .iter()
                .find(|&&b_id| left.wires.get(&b_id).map(|w| &w.name) == Some(&wire.name));

            if let Some(&left_boundary_id) = boundary_match {
                // Map to the left's version of this boundary wire
                right_wire_map.insert(*old_id, left_wire_map[&left_boundary_id]);
            } else {
                // Create new wire
                let new_id = result.next_wire;
                result.next_wire += 1;
                right_wire_map.insert(*old_id, new_id);
                result.wires.insert(
                    new_id,
                    Wire {
                        id: new_id,
                        name: wire.name.clone(),
                        parity: wire.parity,
                        ghost_number: wire.ghost_number,
                    },
                );
            }
        }

        // Copy nodes from left, building old->new node id map
        let mut left_node_map: HashMap<NodeId, NodeId> = HashMap::new();
        for node in left.nodes.values() {
            let new_id = result.next_node;
            result.next_node += 1;
            left_node_map.insert(node.id, new_id);
            result.nodes.insert(
                new_id,
                Node {
                    id: new_id,
                    op: node.op.clone(),
                    inputs: node.inputs.iter().map(|w| left_wire_map[w]).collect(),
                    outputs: node.outputs.iter().map(|w| left_wire_map[w]).collect(),
                },
            );
        }

        // Copy nodes from right, building old->new node id map
        let mut right_node_map: HashMap<NodeId, NodeId> = HashMap::new();
        for node in right.nodes.values() {
            let new_id = result.next_node;
            result.next_node += 1;
            right_node_map.insert(node.id, new_id);
            result.nodes.insert(
                new_id,
                Node {
                    id: new_id,
                    op: node.op.clone(),
                    inputs: node.inputs.iter().map(|w| right_wire_map[w]).collect(),
                    outputs: node.outputs.iter().map(|w| right_wire_map[w]).collect(),
                },
            );
        }

        // Copy loops — applying the node_id remap so loops point to valid nodes
        for lp in &left.loops {
            let new_node_id = left_node_map
                .get(&lp.node_id)
                .copied()
                .unwrap_or(lp.node_id);
            let wire_id = result.next_wire;
            result.next_wire += 1;
            let wire = Wire {
                id: wire_id,
                name: lp.wire.name.clone(),
                parity: lp.wire.parity,
                ghost_number: lp.wire.ghost_number,
            };
            // Insert loop wire so it is reachable from self.wires
            result.wires.insert(
                wire_id,
                Wire {
                    id: wire_id,
                    name: lp.wire.name.clone(),
                    parity: lp.wire.parity,
                    ghost_number: lp.wire.ghost_number,
                },
            );
            result.loops.push(Loop {
                node_id: new_node_id,
                wire,
            });
        }

        for lp in &right.loops {
            let new_node_id = right_node_map
                .get(&lp.node_id)
                .copied()
                .unwrap_or(lp.node_id);
            let wire_id = result.next_wire;
            result.next_wire += 1;
            let wire = Wire {
                id: wire_id,
                name: lp.wire.name.clone(),
                parity: lp.wire.parity,
                ghost_number: lp.wire.ghost_number,
            };
            result.wires.insert(
                wire_id,
                Wire {
                    id: wire_id,
                    name: lp.wire.name.clone(),
                    parity: lp.wire.parity,
                    ghost_number: lp.wire.ghost_number,
                },
            );
            result.loops.push(Loop {
                node_id: new_node_id,
                wire,
            });
        }

        Ok(result)
    }

    /// Compute the genus after pants composition.
    ///
    /// genus(result) = genus(left) + genus(right) + (shared_boundary.len() - 1)
    pub fn pants_genus(left: &Diagram, right: &Diagram, shared_boundary_count: usize) -> usize {
        let base = left.genus() + right.genus();
        if shared_boundary_count > 0 {
            base + shared_boundary_count - 1
        } else {
            base
        }
    }

    /// Check if this diagram represents a closed string (no free boundary wires).
    ///
    /// A wire is "free" if it appears as an output of some node but is not consumed
    /// as an input by any other node (dangling output), or appears as an input of
    /// some node but is not produced by any other node (dangling input).
    ///
    /// In closed string field theory, physical diagrams have no dangling wires.
    pub fn is_closed(&self) -> bool {
        if self.wires.is_empty() && self.nodes.is_empty() {
            return true; // Empty diagram is trivially closed
        }

        for wire_id in self.wires.keys() {
            let is_produced = self.nodes.values().any(|n| n.outputs.contains(wire_id));
            let is_consumed = self.nodes.values().any(|n| n.inputs.contains(wire_id));

            // A wire must be both produced and consumed to not be a free boundary
            // Exception: self-loops (same wire in both inputs and outputs of same node)
            let is_self_loop = self
                .nodes
                .values()
                .any(|n| n.inputs.contains(wire_id) && n.outputs.contains(wire_id));

            if is_self_loop {
                continue; // Self-loops are internal, not boundaries
            }

            // Dangling wire: produced but not consumed, or consumed but not produced
            if (is_produced && !is_consumed) || (!is_produced && is_consumed) {
                return false;
            }
        }

        true
    }

    /// Get the free (boundary) wires of this diagram.
    ///
    /// Returns a pair of (input_boundary_wires, output_boundary_wires).
    /// Input boundaries are wires that are consumed but not produced.
    /// Output boundaries are wires that are produced but not consumed.
    pub fn boundary_wires(&self) -> (Vec<WireId>, Vec<WireId>) {
        let mut input_boundaries = Vec::new();
        let mut output_boundaries = Vec::new();

        for &wire_id in self.wires.keys() {
            let is_produced = self.nodes.values().any(|n| n.outputs.contains(&wire_id));
            let is_consumed = self.nodes.values().any(|n| n.inputs.contains(&wire_id));

            // Check for self-loop case
            let is_self_loop = self
                .nodes
                .values()
                .any(|n| n.inputs.contains(&wire_id) && n.outputs.contains(&wire_id));

            if is_self_loop {
                continue;
            }

            if is_consumed && !is_produced {
                input_boundaries.push(wire_id);
            }
            if is_produced && !is_consumed {
                output_boundaries.push(wire_id);
            }
        }

        (input_boundaries, output_boundaries)
    }

    /// Decompose this diagram into pair-of-pants pieces via separating-wire cuts.
    ///
    /// A separating wire is one whose removal disconnects the diagram.
    /// Cut along each separating wire to produce sub-diagrams, and recurse
    /// until all pieces have <= 3 boundary wires.
    ///
    /// Returns `None` if the diagram is empty.
    /// Returns `Some(Vec<Diagram>)` where each piece has <= 3 boundary wires.
    pub fn pair_of_pants_decomposition(&self) -> Option<Vec<Diagram>> {
        if self.nodes.is_empty() {
            return None;
        }

        // Base case: already has <= 3 boundaries, return self as single piece
        let (in_b, out_b) = self.boundary_wires();
        let total_boundaries = in_b.len() + out_b.len();
        if total_boundaries <= 3 {
            return Some(vec![self.clone()]);
        }

        // Find a separating wire: one whose removal increases connected components
        let base_components = self.connected_components();
        let mut separating_wire = None;

        for &wire_id in self.wires.keys() {
            // Check if this wire is internal (connects two different nodes)
            let producers: Vec<NodeId> = self
                .nodes
                .values()
                .filter(|n| n.outputs.contains(&wire_id))
                .map(|n| n.id)
                .collect();
            let consumers: Vec<NodeId> = self
                .nodes
                .values()
                .filter(|n| n.inputs.contains(&wire_id))
                .map(|n| n.id)
                .collect();

            if producers.is_empty() || consumers.is_empty() {
                continue; // boundary wire, not separating
            }

            // Build adjacency without this wire and check components
            let mut test_diagram = self.clone();
            // Remove the wire from all nodes
            for node in test_diagram.nodes.values_mut() {
                node.inputs.retain(|&w| w != wire_id);
                node.outputs.retain(|&w| w != wire_id);
            }
            test_diagram.wires.remove(&wire_id);

            let new_components = test_diagram.connected_components();
            if new_components > base_components {
                separating_wire = Some(wire_id);
                break;
            }
        }

        if let Some(sep_wire) = separating_wire {
            // Cut along the separating wire: partition nodes into components
            // after removing the wire
            let mut cut_diagram = self.clone();
            for node in cut_diagram.nodes.values_mut() {
                node.inputs.retain(|&w| w != sep_wire);
                node.outputs.retain(|&w| w != sep_wire);
            }
            cut_diagram.wires.remove(&sep_wire);

            // Find connected components via DFS
            let index = cut_diagram.wire_adjacency_index();
            let mut adjacency: HashMap<NodeId, Vec<NodeId>> = HashMap::new();
            for node in cut_diagram.nodes.values() {
                adjacency.entry(node.id).or_default();
            }
            for (_, (prods, cons)) in &index {
                for &p in prods {
                    for &c in cons {
                        if p != c {
                            adjacency.entry(p).or_default().push(c);
                            adjacency.entry(c).or_default().push(p);
                        }
                    }
                }
            }

            let mut visited: HashSet<NodeId> = HashSet::new();
            let mut component_groups: Vec<HashSet<NodeId>> = Vec::new();
            for &nid in cut_diagram.nodes.keys() {
                if !visited.contains(&nid) {
                    let mut component = HashSet::new();
                    let mut stack = vec![nid];
                    while let Some(current) = stack.pop() {
                        if component.insert(current) {
                            visited.insert(current);
                            if let Some(neighbours) = adjacency.get(&current) {
                                for &n in neighbours {
                                    if !component.contains(&n) {
                                        stack.push(n);
                                    }
                                }
                            }
                        }
                    }
                    component_groups.push(component);
                }
            }

            // Build sub-diagrams for each component
            let mut pieces = Vec::new();
            for group in &component_groups {
                let mut sub = Diagram::new();
                let mut wire_map: HashMap<WireId, WireId> = HashMap::new();

                // Collect all wires used by nodes in this group
                for &nid in group {
                    if let Some(node) = self.nodes.get(&nid) {
                        for &wid in node.inputs.iter().chain(node.outputs.iter()) {
                            if !wire_map.contains_key(&wid) {
                                if let Some(wire) = self.wires.get(&wid) {
                                    let new_id = sub.next_wire;
                                    sub.next_wire += 1;
                                    sub.wires.insert(
                                        new_id,
                                        Wire {
                                            id: new_id,
                                            name: wire.name.clone(),
                                            parity: wire.parity,
                                            ghost_number: wire.ghost_number,
                                        },
                                    );
                                    wire_map.insert(wid, new_id);
                                }
                            }
                        }
                    }
                }

                // Add the separating wire as a boundary wire in this sub-diagram
                if let Some(wire) = self.wires.get(&sep_wire) {
                    let new_id = sub.next_wire;
                    sub.next_wire += 1;
                    sub.wires.insert(
                        new_id,
                        Wire {
                            id: new_id,
                            name: wire.name.clone(),
                            parity: wire.parity,
                            ghost_number: wire.ghost_number,
                        },
                    );
                    wire_map.insert(sep_wire, new_id);
                }

                // Add nodes
                for &nid in group {
                    if let Some(node) = self.nodes.get(&nid) {
                        let new_inputs: Vec<WireId> = node
                            .inputs
                            .iter()
                            .filter_map(|w| wire_map.get(w).copied())
                            .collect();
                        let new_outputs: Vec<WireId> = node
                            .outputs
                            .iter()
                            .filter_map(|w| wire_map.get(w).copied())
                            .collect();
                        sub.add_node(&node.op, new_inputs, new_outputs);
                    }
                }

                // Recurse
                if let Some(sub_pieces) = sub.pair_of_pants_decomposition() {
                    pieces.extend(sub_pieces);
                } else {
                    pieces.push(sub);
                }
            }

            if pieces.is_empty() {
                Some(vec![self.clone()])
            } else {
                Some(pieces)
            }
        } else {
            // No separating wire found -- this diagram is irreducible
            Some(vec![self.clone()])
        }
    }

    // ============================================================
    // Koszul Sign Composition
    // ============================================================

    /// Compose two diagrams with Koszul sign tracking.
    ///
    /// When composing diagrams with fermionic (odd parity) wires,
    /// track the sign from wire crossings using the Koszul sign rule:
    /// (-1)^{|a|*|b|} when elements of parity |a| and |b| cross.
    ///
    /// Returns (composed_diagram, overall_koszul_sign).
    pub fn compose_with_signs(d1: &Diagram, d2: &Diagram) -> (Diagram, i8) {
        let mut result = Diagram::new();
        let mut overall_sign: i8 = 1;

        // Compute actual Koszul sign via pairwise crossing count.
        // In the tensor product embedding, all d1 wires precede d2 wires, so the crossing count
        // equals the number of (d1_fermionic, d2_fermionic) pairs — which is n1 * n2.
        let n1 = d1.wires.values().filter(|w| w.is_fermionic()).count();
        let n2 = d2.wires.values().filter(|w| w.is_fermionic()).count();
        let crossing_count = n1 * n2;
        if crossing_count % 2 == 1 {
            overall_sign = -1;
        }

        // Copy wires from d1
        let mut d1_wire_map: HashMap<WireId, WireId> = HashMap::new();
        for (old_id, wire) in &d1.wires {
            let new_id = result.next_wire;
            result.next_wire += 1;
            d1_wire_map.insert(*old_id, new_id);
            result.wires.insert(
                new_id,
                Wire {
                    id: new_id,
                    name: wire.name.clone(),
                    parity: wire.parity,
                    ghost_number: wire.ghost_number,
                },
            );
        }

        // Copy wires from d2
        let mut d2_wire_map: HashMap<WireId, WireId> = HashMap::new();
        for (old_id, wire) in &d2.wires {
            let new_id = result.next_wire;
            result.next_wire += 1;
            d2_wire_map.insert(*old_id, new_id);
            result.wires.insert(
                new_id,
                Wire {
                    id: new_id,
                    name: wire.name.clone(),
                    parity: wire.parity,
                    ghost_number: wire.ghost_number,
                },
            );
        }

        // Copy nodes from d1
        for node in d1.nodes.values() {
            let new_id = result.next_node;
            result.next_node += 1;
            result.nodes.insert(
                new_id,
                Node {
                    id: new_id,
                    op: node.op.clone(),
                    inputs: node.inputs.iter().map(|w| d1_wire_map[w]).collect(),
                    outputs: node.outputs.iter().map(|w| d1_wire_map[w]).collect(),
                },
            );
        }

        // Copy nodes from d2
        for node in d2.nodes.values() {
            let new_id = result.next_node;
            result.next_node += 1;
            result.nodes.insert(
                new_id,
                Node {
                    id: new_id,
                    op: node.op.clone(),
                    inputs: node.inputs.iter().map(|w| d2_wire_map[w]).collect(),
                    outputs: node.outputs.iter().map(|w| d2_wire_map[w]).collect(),
                },
            );
        }

        // Copy loops — applying node_id remaps
        for lp in &d1.loops {
            let wid = result.next_wire;
            result.next_wire += 1;
            let wire = Wire {
                id: wid,
                name: lp.wire.name.clone(),
                parity: lp.wire.parity,
                ghost_number: lp.wire.ghost_number,
            };
            result.wires.insert(
                wid,
                Wire {
                    id: wid,
                    name: lp.wire.name.clone(),
                    parity: lp.wire.parity,
                    ghost_number: lp.wire.ghost_number,
                },
            );
            // node_id was already remapped via d1_node_map (built below)
            result.loops.push(Loop {
                node_id: lp.node_id,
                wire,
            });
        }

        for lp in &d2.loops {
            let wid = result.next_wire;
            result.next_wire += 1;
            let wire = Wire {
                id: wid,
                name: lp.wire.name.clone(),
                parity: lp.wire.parity,
                ghost_number: lp.wire.ghost_number,
            };
            result.wires.insert(
                wid,
                Wire {
                    id: wid,
                    name: lp.wire.name.clone(),
                    parity: lp.wire.parity,
                    ghost_number: lp.wire.ghost_number,
                },
            );
            result.loops.push(Loop {
                node_id: lp.node_id,
                wire,
            });
        }

        (result, overall_sign)
    }

    /// Compute the Koszul sign for a specific wire crossing.
    pub fn wire_crossing_sign(
        &self,
        wire1_id: WireId,
        wire2_id: WireId,
    ) -> Result<i8, DiagramError> {
        let wire1 = self
            .wires
            .get(&wire1_id)
            .ok_or(DiagramError::WireNotFound(wire1_id))?;
        let wire2 = self
            .wires
            .get(&wire2_id)
            .ok_or(DiagramError::WireNotFound(wire2_id))?;
        Ok(wire1.koszul_sign(wire2))
    }

    /// The core concurrency detection rule mapping Monoidal Categories to Mazurkiewicz Traces.
    /// Two nodes commute (are independent) if they share no wires.
    pub fn independent(&self, a: &Node, b: &Node) -> bool {
        let mut used = HashSet::new();

        for w in &a.inputs {
            used.insert(w);
        }
        for w in &a.outputs {
            used.insert(w);
        }

        for w in &b.inputs {
            if used.contains(&w) {
                return false;
            }
        }
        for w in &b.outputs {
            if used.contains(&w) {
                return false;
            }
        }

        true
    }

    /// Extracts all independently commuting pairs of nodes.
    /// These correspond exactly to 2-cells (squares) in the Cubical Complex.
    pub fn commuting_pairs(&self) -> Vec<(NodeId, NodeId)> {
        let mut result = Vec::new();

        // Ensure deterministic iteration order for structural stability
        let mut node_ids: Vec<NodeId> = self.nodes.keys().copied().collect();
        node_ids.sort_unstable();

        for i in 0..node_ids.len() {
            for j in (i + 1)..node_ids.len() {
                let node_a = self.nodes.get(&node_ids[i]).unwrap();
                let node_b = self.nodes.get(&node_ids[j]).unwrap();

                if self.independent(node_a, node_b) {
                    result.push((node_a.id, node_b.id));
                }
            }
        }

        result
    }

    /// Extracts all independently commuting triples of nodes limit.
    /// These correspond exactly to 3-cells (cubes) in the Cubical Complex.
    pub fn commuting_triples(&self) -> Vec<(NodeId, NodeId, NodeId)> {
        let mut result = Vec::new();
        let mut node_ids: Vec<NodeId> = self.nodes.keys().copied().collect();
        node_ids.sort_unstable();

        for i in 0..node_ids.len() {
            for j in (i + 1)..node_ids.len() {
                for k in (j + 1)..node_ids.len() {
                    let a = self.nodes.get(&node_ids[i]).unwrap();
                    let b = self.nodes.get(&node_ids[j]).unwrap();
                    let c = self.nodes.get(&node_ids[k]).unwrap();

                    if self.independent(a, b) && self.independent(b, c) && self.independent(a, c) {
                        result.push((a.id, b.id, c.id));
                    }
                }
            }
        }

        result
    }

    /// Render the Diagram out to a Graphviz DOT format for debugging visualization.
    pub fn to_dot(&self) -> String {
        let mut dot = String::from("digraph program {\n");
        dot.push_str("    rankdir=LR;\n");
        dot.push_str("    node [shape=box];\n");

        for node in self.nodes.values() {
            dot.push_str(&format!("    n{} [label=\"{}\"];\n", node.id, node.op));
        }

        // Trace connections from output -> input traversing nodes.
        // If a node outputs wire W, and another inputs Wire W, there's an edge.
        for out_node in self.nodes.values() {
            for &out_w in &out_node.outputs {
                for in_node in self.nodes.values() {
                    if in_node.inputs.contains(&out_w) {
                        let wire_name = self
                            .wires
                            .get(&out_w)
                            .map(|w| w.name.as_str())
                            .unwrap_or("?");
                        dot.push_str(&format!(
                            "    n{} -> n{} [label=\"{}\"];\n",
                            out_node.id, in_node.id, wire_name
                        ));
                    }
                }
            }
        }

        dot.push_str("}\n");
        dot
    }
    /// Builds a canonical Program Diagram from an ATP module.
    ///
    /// This is the single source of truth for the program's topology.
    /// Every phase (boundary_check, lifetime_check, PTIR, codegen)
    /// can derive its analysis from this one structure instead of
    /// rebuilding graphs independently.
    ///
    /// Construction rules:
    ///   - Manifolds/Sheafs → wires (objects/resources)
    ///   - Morphisms → nodes with input/output wires from source/target types
    ///   - Adjunctions → paired nodes (left/right) sharing wires
    ///   - Tensors → recorded as independence constraints (disjoint nodes)
    ///   - Orbits → nodes with self-loop (output = input wire)
    ///   - Networks → wires representing deployment nodes
    ///   - Deploys → nodes binding morphisms to network nodes
    pub fn from_module(module: &super::parser::AtpModule) -> Self {
        use super::parser::Declaration;

        let mut d = Self::new();
        // Map type names to wire IDs for reuse
        let mut wire_map: HashMap<String, WireId> = HashMap::new();

        let mut get_or_add_wire = |d: &mut Diagram, name: &str| -> WireId {
            if let Some(&id) = wire_map.get(name) {
                id
            } else {
                let id = d.add_wire(name);
                wire_map.insert(name.to_string(), id);
                id
            }
        };

        for decl in &module.declarations {
            match decl {
                Declaration::Manifold(m) => {
                    get_or_add_wire(&mut d, &m.name);
                }
                Declaration::Sheaf(s) => {
                    get_or_add_wire(&mut d, &s.name);
                }
                Declaration::Morphism(m) => {
                    let src = get_or_add_wire(&mut d, &m.source.base_name());
                    let tgt = get_or_add_wire(&mut d, &m.target.base_name());
                    d.add_node(&m.name, vec![src], vec![tgt]);
                }
                Declaration::Adjunction(a) => {
                    let left_src = get_or_add_wire(&mut d, &a.left.source.base_name());
                    let left_tgt = get_or_add_wire(&mut d, &a.left.target.base_name());
                    d.add_node(&a.left.name, vec![left_src], vec![left_tgt]);
                    // Right adjoint goes in reverse direction
                    d.add_node(&a.right.name, vec![left_tgt], vec![left_src]);
                }
                Declaration::Orbit(o) => {
                    let src = get_or_add_wire(&mut d, &o.source.base_name());
                    // Self-loop: output = input wire (endomorphism)
                    d.add_node(&o.name, vec![src], vec![src]);
                }
                Declaration::Network(n) => {
                    for node_name in &n.nodes {
                        let net_wire = format!("{}::{}", n.name, node_name);
                        get_or_add_wire(&mut d, &net_wire);
                    }
                }
                Declaration::Deploy(dep) => {
                    // Deploy creates an edge from morphism wire to network node wire
                    let morph_wire = get_or_add_wire(&mut d, &dep.morphism);
                    let node_wire = get_or_add_wire(&mut d, &dep.target_node);
                    d.add_node(
                        &format!("deploy_{}_{}", dep.morphism, dep.target_node),
                        vec![morph_wire],
                        vec![node_wire],
                    );
                }
                // Tensors, Functors, NTs, Categories handled by independence analysis
                _ => {}
            }
        }

        d
    }
}

/// Count pairwise crossings between two sequences of positions.
/// Each pair (p1, p2) where p1 > p2 is a crossing (inversion).
/// For the tensor product case, this reduces to n1 * n2 when all
/// positions from seq1 precede seq2, but handles the general case
/// where positions may interleave.
fn count_crossings(seq1: &[usize], seq2: &[usize]) -> usize {
    if seq1.is_empty() || seq2.is_empty() {
        return 0;
    }
    // Merge both sequences with labels, count inversions
    let mut labeled: Vec<(usize, bool)> = Vec::with_capacity(seq1.len() + seq2.len());
    for &p in seq1 {
        labeled.push((p, true)); // from d1
    }
    for &p in seq2 {
        labeled.push((p, false)); // from d2
    }
    labeled.sort_by_key(|&(pos, _)| pos);

    // Count: for each d2 wire, how many d1 wires appear AFTER it in position order
    // This is the number of crossings.
    let mut crossings = 0;
    let mut d1_count_after = seq1.len(); // initially all d1 wires are "after"
    for &(_, is_d1) in &labeled {
        if is_d1 {
            d1_count_after -= 1;
        } else {
            crossings += d1_count_after;
        }
    }
    crossings
}

// ============================================================
// Rewrite System (Normalization)
// ============================================================

pub trait RewriteRule {
    /// Applies this rewrite to the diagram.
    /// Returns true if the diagram was mutated (a rewrite occurred).
    fn apply(&self, diagram: &mut Diagram) -> bool;
}

/// The core SMC symmetry equation: σ ∘ σ = id.
/// Replaces two consecutive swaps with identity wires.
pub struct RemoveDoubleSwap;

impl RewriteRule for RemoveDoubleSwap {
    fn apply(&self, diagram: &mut Diagram) -> bool {
        // Find pairs of swap nodes where Swap_B exclusively consumes Swap_A's outputs.
        let mut to_remove = None;
        let mut aliases = HashMap::new();

        'outer: for n1 in diagram.nodes.values() {
            if n1.op == "swap" && n1.outputs.len() == 2 && n1.inputs.len() == 2 {
                for n2 in diagram.nodes.values() {
                    if n1.id == n2.id {
                        continue;
                    }
                    if n2.op == "swap" && n2.inputs.len() == 2 && n2.outputs.len() == 2 {
                        // Are both inputs of n2 exactly the outputs of n1?
                        // A true double swap: n1 -> w_x, w_y -> n2
                        // Since swap is usually implemented as crossing wires: A_out = B_in, B_out = A_in.
                        if (n2.inputs[0] == n1.outputs[0] || n2.inputs[0] == n1.outputs[1])
                            && (n2.inputs[1] == n1.outputs[0] || n2.inputs[1] == n1.outputs[1])
                        {
                            to_remove = Some((n1.id, n2.id));
                            // Map aliases: n2's outputs should be logically aliased to n1's inputs
                            // We map n2_outputs[0] -> n1_inputs[0]
                            // We map n2_outputs[1] -> n1_inputs[1]
                            // This effectively bridges the gap, vanishing the swaps.
                            aliases.insert(n2.outputs[0], n1.inputs[0]);
                            aliases.insert(n2.outputs[1], n1.inputs[1]);
                            break 'outer;
                        }
                    }
                }
            }
        }

        if let Some((id1, id2)) = to_remove {
            diagram.nodes.remove(&id1);
            diagram.nodes.remove(&id2);

            // Remap references across the rest of the diagram.
            for node in diagram.nodes.values_mut() {
                for w in &mut node.inputs {
                    if let Some(&replacement) = aliases.get(w) {
                        *w = replacement;
                    }
                }
                for w in &mut node.outputs {
                    if let Some(&replacement) = aliases.get(w) {
                        *w = replacement;
                    }
                }
            }
            true
        } else {
            false
        }
    }
}

pub fn normalize(diagram: &mut Diagram, rules: &[Box<dyn RewriteRule>]) {
    loop {
        let mut changed = false;
        for r in rules {
            if r.apply(diagram) {
                changed = true;
            }
        }
        if !changed {
            break;
        }
    }
}

/// A local rewrite rule that operates on a single node.
/// Used with `normalize_incremental` for O(changed_neighbours) scheduling
/// instead of the O(N*R) global `normalize`.
pub trait LocalRewriteRule {
    fn name(&self) -> &str;
    fn apply_local(&self, diagram: &mut Diagram, node_id: NodeId) -> bool;
}

impl LocalRewriteRule for RemoveDoubleSwap {
    fn name(&self) -> &str {
        "RemoveDoubleSwap"
    }

    fn apply_local(&self, diagram: &mut Diagram, node_id: NodeId) -> bool {
        // Check if this node is a swap that forms a double-swap with a neighbour
        let node = match diagram.nodes.get(&node_id) {
            Some(n) if n.op == "swap" && n.inputs.len() == 2 && n.outputs.len() == 2 => n.clone(),
            _ => return false,
        };

        // Find a matching swap partner
        let mut partner_id = None;
        let mut aliases = HashMap::new();
        for n2 in diagram.nodes.values() {
            if n2.id == node_id {
                continue;
            }
            if n2.op == "swap" && n2.inputs.len() == 2 && n2.outputs.len() == 2 {
                if (n2.inputs[0] == node.outputs[0] || n2.inputs[0] == node.outputs[1])
                    && (n2.inputs[1] == node.outputs[0] || n2.inputs[1] == node.outputs[1])
                {
                    partner_id = Some(n2.id);
                    aliases.insert(n2.outputs[0], node.inputs[0]);
                    aliases.insert(n2.outputs[1], node.inputs[1]);
                    break;
                }
            }
        }

        if let Some(pid) = partner_id {
            diagram.nodes.remove(&node_id);
            diagram.nodes.remove(&pid);
            for remaining in diagram.nodes.values_mut() {
                for w in &mut remaining.inputs {
                    if let Some(&replacement) = aliases.get(w) {
                        *w = replacement;
                    }
                }
                for w in &mut remaining.outputs {
                    if let Some(&replacement) = aliases.get(w) {
                        *w = replacement;
                    }
                }
            }
            true
        } else {
            false
        }
    }
}

/// Incremental normalization: only rechecks nodes adjacent to recent changes.
/// Replaces the O(N*R*P) global `normalize` loop with a local work-queue.
pub fn normalize_incremental(diagram: &mut Diagram, rules: &[Box<dyn LocalRewriteRule>]) {
    let mut queue: VecDeque<NodeId> = diagram.nodes.keys().copied().collect();
    let mut in_queue: HashSet<NodeId> = queue.iter().copied().collect();

    while let Some(node_id) = queue.pop_front() {
        in_queue.remove(&node_id);

        // Skip if node was removed by a previous rewrite
        if !diagram.nodes.contains_key(&node_id) {
            continue;
        }

        for rule in rules {
            if rule.apply_local(diagram, node_id) {
                // Enqueue neighbours of the changed node
                let neighbours = diagram.neighbours(node_id);
                for n in neighbours {
                    if diagram.nodes.contains_key(&n) && !in_queue.contains(&n) {
                        queue.push_back(n);
                        in_queue.insert(n);
                    }
                }
                break; // one rule per node per pass
            }
        }
    }
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sequential_composition() {
        let mut d = Diagram::new();
        let cache_in = d.add_wire("Cache");
        let cache_mid = d.add_wire("Cache");
        let cache_out = d.add_wire("Cache");

        // write_cache : cache_in -> cache_mid
        d.add_node("write_cache", vec![cache_in], vec![cache_mid]);
        // compress : cache_mid -> cache_out
        d.add_node("compress", vec![cache_mid], vec![cache_out]);

        assert_eq!(d.nodes.len(), 2);
        // By definition, write_cache and compress share wire `cache_mid`,
        // so they are NOT independent.
        let commuting = d.commuting_pairs();
        assert!(commuting.is_empty(), "Sequential nodes cannot commute");
    }

    #[test]
    fn test_parallel_composition_tensors() {
        let mut d = Diagram::new();
        let cache = d.add_wire("Cache");
        let disk = d.add_wire("Disk");

        // Two disjoint wires = parallel tensor!
        let n1 = d.add_node("write_cache", vec![cache], vec![cache]);
        let n2 = d.add_node("flush_disk", vec![disk], vec![disk]);

        assert_eq!(d.nodes.len(), 2);
        let commuting = d.commuting_pairs();
        assert_eq!(
            commuting.len(),
            1,
            "Parallel nodes on separate wires must commute"
        );

        let (a, b) = commuting[0];
        assert_eq!((a.min(b), a.max(b)), (n1, n2));
    }

    #[test]
    fn test_3_cube_generation() {
        let mut d = Diagram::new();
        let w_a = d.add_wire("A");
        let w_b = d.add_wire("B");
        let w_c = d.add_wire("C");

        d.add_node("f", vec![w_a], vec![w_a]);
        d.add_node("g", vec![w_b], vec![w_b]);
        d.add_node("h", vec![w_c], vec![w_c]);

        let squares = d.commuting_pairs();
        assert_eq!(squares.len(), 3, "Three pairs: f-g, f-h, g-h");

        let cubes = d.commuting_triples();
        assert_eq!(cubes.len(), 1, "One 3-simplex (cube) combining all three!");
    }

    #[test]
    fn test_remove_double_swap() {
        let mut d = Diagram::new();
        let in_a = d.add_wire("A");
        let in_b = d.add_wire("B");

        let mid_a = d.add_wire("A_mid");
        let mid_b = d.add_wire("B_mid");

        let out_a = d.add_wire("A_out");
        let out_b = d.add_wire("B_out");

        // Swap 1
        d.add_node("swap", vec![in_a, in_b], vec![mid_b, mid_a]);
        // Swap 2
        d.add_node("swap", vec![mid_b, mid_a], vec![out_a, out_b]);

        assert_eq!(d.nodes.len(), 2);

        let rules: Vec<Box<dyn RewriteRule>> = vec![Box::new(RemoveDoubleSwap)];
        normalize(&mut d, &rules);

        assert_eq!(d.nodes.len(), 0, "Double swap should be erased completely");
    }

    // ============================================================
    // Closed String Extension Tests
    // ============================================================

    #[test]
    fn test_wire_parity_and_ghost_number() {
        // Test Wire with explicit parity and ghost number
        let fermionic_wire = Wire::graded(0, "psi", Parity::Odd, 1);
        assert!(fermionic_wire.is_fermionic());
        assert!(!fermionic_wire.is_bosonic());
        assert_eq!(fermionic_wire.ghost_number, 1);
        assert_eq!(fermionic_wire.parity, Parity::Odd);

        // Test Wire with default values (backward compatibility)
        let bosonic_wire = Wire::new(1, "phi");
        assert!(bosonic_wire.is_bosonic());
        assert!(!bosonic_wire.is_fermionic());
        assert_eq!(bosonic_wire.ghost_number, 0);
        assert_eq!(bosonic_wire.parity, Parity::Even);
    }

    #[test]
    fn test_backward_compatibility_wire_creation() {
        // Ensure add_wire still works as before
        let mut d = Diagram::new();
        let w = d.add_wire("test");
        let wire = d.wires.get(&w).unwrap();

        // Default values should be Even parity and ghost number 0
        assert_eq!(wire.parity, Parity::Even);
        assert_eq!(wire.ghost_number, 0);
        assert_eq!(wire.name, "test");
    }

    #[test]
    fn test_self_loop_creation() {
        let mut d = Diagram::new();
        let w = d.add_wire("A");
        let node_id = d.add_node("trace_op", vec![w], vec![w]);

        // Add a self-loop
        let loop_wire = Wire::graded(100, "loop_wire", Parity::Odd, 0);
        d.add_loop(node_id, loop_wire)
            .expect("Should add loop successfully");

        assert_eq!(d.loop_count(), 1);
        assert_eq!(d.get_loops().len(), 1);

        let loops_on_node = d.loops_on_node(node_id);
        assert_eq!(loops_on_node.len(), 1);
        assert_eq!(loops_on_node[0].wire.name, "loop_wire");
    }

    #[test]
    fn test_self_loop_invalid_node() {
        let mut d = Diagram::new();
        let loop_wire = Wire::new(0, "orphan_loop");

        // Try to add loop to non-existent node
        let result = d.add_loop(999, loop_wire);
        assert!(result.is_err());
        assert!(matches!(result, Err(DiagramError::NodeNotFound(999))));
    }

    #[test]
    fn test_genus_zero_for_tree_diagrams() {
        // A tree diagram (no loops) should have genus 0
        let mut d = Diagram::new();
        let a = d.add_wire("A");
        let b = d.add_wire("B");
        let c = d.add_wire("C");

        d.add_node("f", vec![a], vec![b]);
        d.add_node("g", vec![b], vec![c]);

        assert_eq!(d.genus(), 0, "Tree diagram should have genus 0");
        assert_eq!(d.loop_count(), 0);
    }

    #[test]
    fn test_genus_one_for_single_loop() {
        let mut d = Diagram::new();
        let w = d.add_wire("A");
        let node_id = d.add_node("f", vec![w], vec![w]);

        // Add a self-loop to create a torus-like handle
        d.add_loop_simple(node_id, "handle").unwrap();

        assert_eq!(d.loop_count(), 1);
        assert_eq!(d.genus(), 1, "Single loop should give genus 1");
    }

    #[test]
    fn test_genus_addition_under_pants_composition() {
        // Create two diagrams with known genus
        let mut left = Diagram::new();
        let l_wire = left.add_wire("boundary");
        let l_node = left.add_node("left_op", vec![l_wire], vec![l_wire]);
        left.add_loop_simple(l_node, "left_handle").unwrap();
        assert_eq!(left.genus(), 1);

        let mut right = Diagram::new();
        let r_wire = right.add_wire("boundary");
        let r_node = right.add_node("right_op", vec![r_wire], vec![r_wire]);
        right.add_loop_simple(r_node, "right_handle").unwrap();
        assert_eq!(right.genus(), 1);

        // Pants composition: genus(result) = genus(left) + genus(right) + (boundary - 1)
        let expected_genus = Diagram::pants_genus(&left, &right, 1);
        assert_eq!(
            expected_genus, 2,
            "Pants composition with 1 boundary: 1 + 1 + 0 = 2"
        );

        let expected_genus_2 = Diagram::pants_genus(&left, &right, 2);
        assert_eq!(
            expected_genus_2, 3,
            "Pants composition with 2 boundaries: 1 + 1 + 1 = 3"
        );
    }

    #[test]
    fn test_brst_q_squared_zero() {
        // Create a diagram with various ghost numbers
        let mut d = Diagram::new();
        let w1 = d.add_graded_wire("field", Parity::Even, 0);
        let w2 = d.add_graded_wire("ghost", Parity::Odd, 1);
        d.add_node("morphism", vec![w1], vec![w2]);

        // Apply Q once
        let q_d = d.brst_transform().expect("Q should succeed");

        // Apply Q again
        let q_q_d = q_d.brst_transform().expect("Q^2 should succeed");

        // Q^2 should give back original parity (since Q flips twice)
        // Ghost numbers will be gh + 2
        for wire in q_q_d.wires.values() {
            let original = d.wires.values().find(|w| w.name == wire.name).unwrap();
            assert_eq!(wire.parity, original.parity, "Q^2 restores original parity");
            assert_eq!(
                wire.ghost_number,
                original.ghost_number + 2,
                "Q^2 adds 2 to ghost number"
            );
        }
    }

    #[test]
    fn test_brst_closed_diagram_detection() {
        // A diagram where ghost numbers are consistent is BRST-closed
        let mut d = Diagram::new();
        let w1 = d.add_graded_wire("A", Parity::Even, 0);
        let w2 = d.add_graded_wire("B", Parity::Even, 0);
        d.add_node("f", vec![w1], vec![w2]);

        assert!(
            d.is_brst_closed(),
            "Consistent ghost numbers should be BRST-closed"
        );

        // A diagram with large ghost number jump is not BRST-closed
        let mut d2 = Diagram::new();
        let w3 = d2.add_graded_wire("A", Parity::Even, 0);
        let w4 = d2.add_graded_wire("B", Parity::Even, 5);
        d2.add_node("bad_morphism", vec![w3], vec![w4]);

        assert!(
            !d2.is_brst_closed(),
            "Large ghost number jump violates BRST closure"
        );
    }

    #[test]
    fn test_koszul_sign_for_fermionic_wire_crossing() {
        // Koszul rule: (-1)^{|a|*|b|}
        let even = Wire::new(0, "boson");
        let odd = Wire::graded(1, "fermion", Parity::Odd, 0);

        // Even x Even = +1
        assert_eq!(even.koszul_sign(&even), 1);

        // Even x Odd = +1
        assert_eq!(even.koszul_sign(&odd), 1);

        // Odd x Even = +1
        assert_eq!(odd.koszul_sign(&even), 1);

        // Odd x Odd = -1 (THE key fermionic sign)
        assert_eq!(odd.koszul_sign(&odd), -1);
    }

    #[test]
    fn test_compose_with_signs_bosonic() {
        // Two diagrams with only bosonic wires should compose with sign +1
        let mut d1 = Diagram::new();
        let w1 = d1.add_wire("A");
        d1.add_node("f", vec![w1], vec![w1]);

        let mut d2 = Diagram::new();
        let w2 = d2.add_wire("B");
        d2.add_node("g", vec![w2], vec![w2]);

        let (composed, sign) = Diagram::compose_with_signs(&d1, &d2);
        assert_eq!(sign, 1, "Bosonic composition has positive sign");
        assert_eq!(composed.nodes.len(), 2);
        assert_eq!(composed.wires.len(), 2);
    }

    #[test]
    fn test_compose_with_signs_fermionic() {
        // Diagrams with fermionic wires should track Koszul signs
        let mut d1 = Diagram::new();
        let w1 = d1.add_graded_wire("psi1", Parity::Odd, 0);
        d1.add_node("f", vec![w1], vec![w1]);

        let mut d2 = Diagram::new();
        let w2 = d2.add_graded_wire("psi2", Parity::Odd, 0);
        d2.add_node("g", vec![w2], vec![w2]);

        let (composed, sign) = Diagram::compose_with_signs(&d1, &d2);
        assert_eq!(sign, -1, "Two fermionic wires crossing gives -1");
        assert_eq!(composed.nodes.len(), 2);
    }

    #[test]
    fn test_complex_diagram_multiple_loops_genus() {
        // Complex diagram: 3 nodes, 2 self-loops
        let mut d = Diagram::new();
        let w1 = d.add_wire("A");
        let w2 = d.add_wire("B");
        let w3 = d.add_wire("C");

        let n1 = d.add_node("f", vec![w1], vec![w2]);
        let n2 = d.add_node("g", vec![w2], vec![w3]);
        let n3 = d.add_node("h", vec![w3], vec![w1]); // Creates a cycle in the node graph

        // Add loops on two nodes
        d.add_loop_simple(n1, "loop1").unwrap();
        d.add_loop_simple(n2, "loop2").unwrap();

        assert_eq!(d.loop_count(), 2);
        assert_eq!(d.nodes.len(), 3);

        // Genus should reflect the loops
        let genus = d.genus();
        assert!(genus >= 1, "Multiple loops should give positive genus");

        // Test that n3 doesn't have a loop
        assert!(d.loops_on_node(n3).is_empty());
    }

    #[test]
    fn test_parity_algebra() {
        // Test Parity composition (Z_2 group)
        assert_eq!(Parity::Even.compose(Parity::Even), Parity::Even);
        assert_eq!(Parity::Even.compose(Parity::Odd), Parity::Odd);
        assert_eq!(Parity::Odd.compose(Parity::Even), Parity::Odd);
        assert_eq!(Parity::Odd.compose(Parity::Odd), Parity::Even);

        // Test flip
        assert_eq!(Parity::Even.flip(), Parity::Odd);
        assert_eq!(Parity::Odd.flip(), Parity::Even);

        // Test sign
        assert_eq!(Parity::Even.sign(), 1);
        assert_eq!(Parity::Odd.sign(), -1);

        // Test from_count
        assert_eq!(Parity::from_count(0), Parity::Even);
        assert_eq!(Parity::from_count(1), Parity::Odd);
        assert_eq!(Parity::from_count(2), Parity::Even);
        assert_eq!(Parity::from_count(3), Parity::Odd);
    }

    #[test]
    fn test_total_ghost_number() {
        let mut d = Diagram::new();
        d.add_graded_wire("A", Parity::Even, 1);
        d.add_graded_wire("B", Parity::Odd, 2);
        d.add_graded_wire("C", Parity::Even, -1);

        assert_eq!(d.total_ghost_number(), 2, "1 + 2 + (-1) = 2");
    }

    #[test]
    fn test_total_parity() {
        let mut d = Diagram::new();
        d.add_graded_wire("A", Parity::Even, 0);
        d.add_graded_wire("B", Parity::Odd, 0);
        d.add_graded_wire("C", Parity::Odd, 0);

        // Even * Odd * Odd = Even
        assert_eq!(d.total_parity(), Parity::Even);

        let mut d2 = Diagram::new();
        d2.add_graded_wire("A", Parity::Odd, 0);

        assert_eq!(d2.total_parity(), Parity::Odd);
    }

    #[test]
    fn test_pants_compose_basic() {
        // Create two simple diagrams
        let mut left = Diagram::new();
        let l_boundary = left.add_wire("boundary");
        let l_internal = left.add_wire("left_internal");
        left.add_node("left_op", vec![l_internal], vec![l_boundary]);

        let mut right = Diagram::new();
        let r_boundary = right.add_wire("boundary");
        let r_internal = right.add_wire("right_internal");
        right.add_node("right_op", vec![r_boundary], vec![r_internal]);

        // Compose along the boundary
        let result = Diagram::pants_compose(&left, &right, &[l_boundary]);
        assert!(result.is_ok(), "Pants compose should succeed");

        let composed = result.unwrap();
        assert_eq!(composed.nodes.len(), 2);
    }

    #[test]
    fn test_pants_compose_empty_boundary_error() {
        let d1 = Diagram::new();
        let d2 = Diagram::new();

        let result = Diagram::pants_compose(&d1, &d2, &[]);
        assert!(result.is_err());
        assert!(matches!(result, Err(DiagramError::InvalidBoundary(_))));
    }

    #[test]
    fn test_connected_components() {
        // Single connected diagram
        let mut d1 = Diagram::new();
        let a = d1.add_wire("A");
        let b = d1.add_wire("B");
        d1.add_node("f", vec![a], vec![b]);
        d1.add_node("g", vec![b], vec![a]);
        assert_eq!(d1.connected_components(), 1);

        // Two disconnected components
        let mut d2 = Diagram::new();
        let x = d2.add_wire("X");
        let y = d2.add_wire("Y");
        d2.add_node("f", vec![x], vec![x]);
        d2.add_node("g", vec![y], vec![y]);
        assert_eq!(d2.connected_components(), 2);
    }

    #[test]
    fn test_euler_characteristic() {
        // Single node, no edges: chi = 1 - 0 = 1
        let mut d = Diagram::new();
        let w = d.add_wire("A");
        d.add_node("f", vec![w], vec![w]);

        // The wire connects node to itself, but not via another node
        // So no "edge" in the node-to-node sense
        assert!(d.euler_characteristic() <= 1);
    }

    #[test]
    fn test_brst_exact_detection() {
        // Create parent diagram
        let mut parent = Diagram::new();
        parent.add_graded_wire("A", Parity::Even, 0);

        // Apply Q to get child
        let child = parent.brst_transform().unwrap();

        // Child should be BRST-exact with respect to parent
        assert!(child.is_brst_exact(&parent));
    }

    // ============================================================
    // is_closed() and pair_of_pants_decomposition() Tests
    // ============================================================

    #[test]
    fn test_is_closed_empty_diagram() {
        let d = Diagram::new();
        assert!(d.is_closed(), "Empty diagram should be closed");
    }

    #[test]
    fn test_is_closed_self_loop_diagram() {
        // A diagram with only self-loops is closed
        let mut d = Diagram::new();
        let w = d.add_wire("A");
        d.add_node("f", vec![w], vec![w]); // Self-loop: same wire in and out
        assert!(d.is_closed(), "Self-loop diagram should be closed");
    }

    #[test]
    fn test_is_closed_cycle_diagram() {
        // A cycle: A -> f -> B -> g -> A
        let mut d = Diagram::new();
        let a = d.add_wire("A");
        let b = d.add_wire("B");
        d.add_node("f", vec![a], vec![b]);
        d.add_node("g", vec![b], vec![a]);
        assert!(d.is_closed(), "Cycle diagram should be closed");
    }

    #[test]
    fn test_is_closed_open_diagram() {
        // An open diagram with dangling input and output
        let mut d = Diagram::new();
        let input = d.add_wire("input");
        let output = d.add_wire("output");
        d.add_node("f", vec![input], vec![output]);
        assert!(
            !d.is_closed(),
            "Linear diagram with free boundaries should NOT be closed"
        );
    }

    #[test]
    fn test_is_closed_dangling_output() {
        // Diagram with a dangling output
        let mut d = Diagram::new();
        let a = d.add_wire("A");
        let b = d.add_wire("B");
        let c = d.add_wire("C"); // This wire is produced but never consumed
        d.add_node("f", vec![a], vec![b]);
        d.add_node("g", vec![b], vec![a, c]);
        assert!(
            !d.is_closed(),
            "Diagram with dangling output should NOT be closed"
        );
    }

    #[test]
    fn test_boundary_wires_extraction() {
        // Linear diagram: input -> f -> output
        let mut d = Diagram::new();
        let input = d.add_wire("input");
        let output = d.add_wire("output");
        d.add_node("f", vec![input], vec![output]);

        let (inputs, outputs) = d.boundary_wires();
        assert_eq!(inputs.len(), 1, "Should have 1 input boundary");
        assert_eq!(outputs.len(), 1, "Should have 1 output boundary");
        assert!(
            inputs.contains(&input),
            "Input wire should be in input boundaries"
        );
        assert!(
            outputs.contains(&output),
            "Output wire should be in output boundaries"
        );
    }

    #[test]
    fn test_boundary_wires_closed_diagram() {
        // Closed cycle has no boundaries
        let mut d = Diagram::new();
        let a = d.add_wire("A");
        let b = d.add_wire("B");
        d.add_node("f", vec![a], vec![b]);
        d.add_node("g", vec![b], vec![a]);

        let (inputs, outputs) = d.boundary_wires();
        assert!(
            inputs.is_empty(),
            "Closed diagram should have no input boundaries"
        );
        assert!(
            outputs.is_empty(),
            "Closed diagram should have no output boundaries"
        );
    }

    #[test]
    fn test_pair_of_pants_decomposition_simple() {
        // Simple diagram with one node
        let mut d = Diagram::new();
        let a = d.add_wire("A");
        let b = d.add_wire("B");
        d.add_node("f", vec![a], vec![b]);

        let decomp = d.pair_of_pants_decomposition();
        assert!(decomp.is_some(), "Simple diagram should decompose");

        let pieces = decomp.unwrap();
        assert!(!pieces.is_empty(), "Should have at least one piece");
    }

    #[test]
    fn test_pair_of_pants_decomposition_empty() {
        let d = Diagram::new();
        let decomp = d.pair_of_pants_decomposition();
        assert!(decomp.is_none(), "Empty diagram should return None");
    }

    #[test]
    fn test_pair_of_pants_decomposition_genus_1() {
        // Create a genus-1 diagram (torus-like)
        let mut d = Diagram::new();
        let w = d.add_wire("A");
        let node_id = d.add_node("f", vec![w], vec![w]);
        d.add_loop_simple(node_id, "handle").unwrap();

        assert_eq!(d.genus(), 1, "Should have genus 1");

        let decomp = d.pair_of_pants_decomposition();
        assert!(decomp.is_some(), "Genus-1 diagram should decompose");

        let pieces = decomp.unwrap();
        // A torus needs 2 pants (2*1 + 0 - 2 = 0, but we have structure)
        assert!(!pieces.is_empty(), "Should have pieces");
    }

    #[test]
    fn test_pair_of_pants_decomposition_preserves_grading() {
        // Decomposition should preserve wire grading (parity and ghost number)
        let mut d = Diagram::new();
        let fermionic = d.add_graded_wire("psi", Parity::Odd, 1);
        let bosonic = d.add_graded_wire("phi", Parity::Even, 0);
        d.add_node("interaction", vec![fermionic], vec![bosonic]);

        let decomp = d.pair_of_pants_decomposition();
        assert!(decomp.is_some());

        let pieces = decomp.unwrap();
        for piece in &pieces {
            // Check that grading is preserved in the pieces
            for wire in piece.wires.values() {
                if wire.name == "psi" {
                    assert_eq!(
                        wire.parity,
                        Parity::Odd,
                        "Fermionic parity should be preserved"
                    );
                    assert_eq!(wire.ghost_number, 1, "Ghost number should be preserved");
                }
                if wire.name == "phi" {
                    assert_eq!(
                        wire.parity,
                        Parity::Even,
                        "Bosonic parity should be preserved"
                    );
                    assert_eq!(wire.ghost_number, 0, "Ghost number should be preserved");
                }
            }
        }
    }

    #[test]
    fn test_ghost_number_conservation_through_composition() {
        // Total ghost number should be additive under composition
        let mut d1 = Diagram::new();
        d1.add_graded_wire("A", Parity::Even, 1);
        d1.add_graded_wire("B", Parity::Odd, 2);

        let mut d2 = Diagram::new();
        d2.add_graded_wire("C", Parity::Even, -1);
        d2.add_graded_wire("D", Parity::Odd, 3);

        let gh1 = d1.total_ghost_number();
        let gh2 = d2.total_ghost_number();

        let (composed, _sign) = Diagram::compose_with_signs(&d1, &d2);
        let gh_composed = composed.total_ghost_number();

        assert_eq!(
            gh_composed,
            gh1 + gh2,
            "Ghost number should be additive under composition"
        );
    }

    #[test]
    fn test_is_closed_with_graded_wires() {
        // Closed diagram with fermionic wires
        let mut d = Diagram::new();
        let psi1 = d.add_graded_wire("psi1", Parity::Odd, 0);
        let psi2 = d.add_graded_wire("psi2", Parity::Odd, 1);
        d.add_node("f", vec![psi1], vec![psi2]);
        d.add_node("g", vec![psi2], vec![psi1]);

        assert!(d.is_closed(), "Cycle with fermionic wires should be closed");
        assert_eq!(d.total_ghost_number(), 1, "Total ghost number: 0 + 1 = 1");
        assert_eq!(d.total_parity(), Parity::Even, "Odd * Odd = Even");
    }

    // ============================================================
    // Item 1: Incremental Rewrite & Neighbours Tests
    // ============================================================

    #[test]
    fn test_neighbours() {
        let mut d = Diagram::new();
        let w1 = d.add_wire("A");
        let w2 = d.add_wire("B");
        let w3 = d.add_wire("C");

        let n1 = d.add_node("f", vec![w1], vec![w2]);
        let n2 = d.add_node("g", vec![w2], vec![w3]);
        let _n3 = d.add_node("h", vec![w3], vec![w3]); // self-loop, no shared wire with n1

        let n1_neighbours = d.neighbours(n1);
        assert!(n1_neighbours.contains(&n2), "n1 and n2 share wire w2");
        assert!(!n1_neighbours.contains(&_n3), "n1 and n3 share no wire");

        let n2_neighbours = d.neighbours(n2);
        assert!(n2_neighbours.contains(&n1));
        assert!(n2_neighbours.contains(&_n3));
    }

    #[test]
    fn test_normalize_incremental_double_swap() {
        let mut d = Diagram::new();
        let in_a = d.add_wire("A");
        let in_b = d.add_wire("B");
        let mid_a = d.add_wire("A_mid");
        let mid_b = d.add_wire("B_mid");
        let out_a = d.add_wire("A_out");
        let out_b = d.add_wire("B_out");

        d.add_node("swap", vec![in_a, in_b], vec![mid_b, mid_a]);
        d.add_node("swap", vec![mid_b, mid_a], vec![out_a, out_b]);

        assert_eq!(d.nodes.len(), 2);

        let rules: Vec<Box<dyn LocalRewriteRule>> = vec![Box::new(RemoveDoubleSwap)];
        normalize_incremental(&mut d, &rules);

        assert_eq!(
            d.nodes.len(),
            0,
            "Double swap should be erased by incremental normalize"
        );
    }

    #[test]
    fn test_normalize_incremental_matches_normalize() {
        // Build a diagram with double swaps and verify both normalizers produce the same result
        let build_diagram = || {
            let mut d = Diagram::new();
            let a = d.add_wire("A");
            let b = d.add_wire("B");
            let m1 = d.add_wire("M1");
            let m2 = d.add_wire("M2");
            let o1 = d.add_wire("O1");
            let o2 = d.add_wire("O2");
            d.add_node("swap", vec![a, b], vec![m1, m2]);
            d.add_node("swap", vec![m1, m2], vec![o1, o2]);
            d
        };

        let mut d1 = build_diagram();
        let mut d2 = build_diagram();

        let old_rules: Vec<Box<dyn RewriteRule>> = vec![Box::new(RemoveDoubleSwap)];
        normalize(&mut d1, &old_rules);

        let new_rules: Vec<Box<dyn LocalRewriteRule>> = vec![Box::new(RemoveDoubleSwap)];
        normalize_incremental(&mut d2, &new_rules);

        assert_eq!(
            d1.nodes.len(),
            d2.nodes.len(),
            "Both normalizers should produce same node count"
        );
    }

    // ============================================================
    // Item 6: Koszul Sign Crossing Tests
    // ============================================================

    #[test]
    fn test_compose_with_signs_two_fermionic_one_fermionic() {
        // 2 fermionic wires from d1, 1 from d2
        // Old approximation: (-1)^(2*1) = +1
        // Actual crossings: 2 (each d1 fermionic crosses the d2 fermionic)
        // Sign: (-1)^2 = +1 -- same result in this case
        let mut d1 = Diagram::new();
        let w1 = d1.add_graded_wire("psi1", Parity::Odd, 0);
        let w2 = d1.add_graded_wire("psi2", Parity::Odd, 0);
        d1.add_node("f", vec![w1], vec![w2]);

        let mut d2 = Diagram::new();
        let w3 = d2.add_graded_wire("chi", Parity::Odd, 0);
        d2.add_node("g", vec![w3], vec![w3]);

        let (_composed, sign) = Diagram::compose_with_signs(&d1, &d2);
        // 2 crossings -> even -> sign = +1
        assert_eq!(sign, 1, "2 fermionic x 1 fermionic = 2 crossings = +1");
    }

    #[test]
    fn test_compose_with_signs_three_fermionic_one() {
        // 3 fermionic from d1, 1 from d2
        // Crossings: 3 (odd) -> sign = -1
        let mut d1 = Diagram::new();
        let w1 = d1.add_graded_wire("psi1", Parity::Odd, 0);
        let w2 = d1.add_graded_wire("psi2", Parity::Odd, 0);
        let w3 = d1.add_graded_wire("psi3", Parity::Odd, 0);
        d1.add_node("f", vec![w1], vec![w2]);
        d1.add_node("g", vec![w2], vec![w3]);

        let mut d2 = Diagram::new();
        let w4 = d2.add_graded_wire("chi", Parity::Odd, 0);
        d2.add_node("h", vec![w4], vec![w4]);

        let (_composed, sign) = Diagram::compose_with_signs(&d1, &d2);
        assert_eq!(sign, -1, "3 crossings = odd = -1");
    }

    // ============================================================
    // Item 7: Pair of Pants Decomposition Tests
    // ============================================================

    #[test]
    fn test_pair_of_pants_simple_3_boundary() {
        // A diagram with 3 boundary wires should return as a single pants piece
        let mut d = Diagram::new();
        let a = d.add_wire("in1");
        let b = d.add_wire("in2");
        let c = d.add_wire("out");
        d.add_node("merge", vec![a, b], vec![c]);

        let decomp = d.pair_of_pants_decomposition().unwrap();
        assert_eq!(
            decomp.len(),
            1,
            "3-boundary diagram is already a pants piece"
        );
        let (ib, ob) = decomp[0].boundary_wires();
        assert!(
            ib.len() + ob.len() <= 3,
            "Each piece should have at most 3 boundaries"
        );
    }

    #[test]
    fn test_pair_of_pants_pieces_have_bounded_boundaries() {
        // Larger diagram: each decomposition piece should have <= 3 boundaries
        let mut d = Diagram::new();
        let w1 = d.add_wire("A");
        let w2 = d.add_wire("B");
        let w3 = d.add_wire("C");
        let w4 = d.add_wire("D");
        let w5 = d.add_wire("E");

        d.add_node("f", vec![w1], vec![w2]);
        d.add_node("g", vec![w2], vec![w3]);
        d.add_node("h", vec![w3], vec![w4]);
        d.add_node("k", vec![w4], vec![w5]);

        if let Some(pieces) = d.pair_of_pants_decomposition() {
            for (i, piece) in pieces.iter().enumerate() {
                let (ib, ob) = piece.boundary_wires();
                assert!(
                    ib.len() + ob.len() <= 3,
                    "Piece {} has {} boundaries, expected <= 3",
                    i,
                    ib.len() + ob.len()
                );
            }
        }
    }
}
