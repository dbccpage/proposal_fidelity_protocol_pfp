pub mod analysis;
pub mod ast;
pub mod boundary_check;
pub mod codegen;
pub mod cubical_trace;
pub mod eager_validator;
pub mod emitter;
pub mod heyting_check;
pub mod lambda_emitter;
pub mod lexer;
pub mod lifetime_check;
pub mod light_cone;
// `modular_bootstrap` and `operator_presheaf` were declared here but their .rs
// files were never extracted into this tree (a hard compile error) and nothing
// references them — declarations removed for AP-0. `predual_norm`'s file was
// also missing but IS referenced by `streaming_compiler`, so it is kept as a
// stub (see `predual_norm.rs`).
pub mod parser;
pub mod phase_wiring;
pub mod planck_calibration;
pub mod predual_norm;
pub mod ptir;
pub mod resource_graph;
pub mod rewrite_proof;
pub mod streaming_compiler;
pub mod string_diagram;
pub mod symbol_table;
