//! product-claim observer: the signed LGGR defect encoded by the claim delta.
//!
//! The Local-Green/Global-Red (LGGR) sign convention maps each claim delta to a directed
//! defect:
//! * `Undersold` — code does *more* than the atlas claims: an NGD-shaped (negative gap)
//!   local-green/global-red drift;
//! * `Oversold` — the atlas claims more than the code delivers: a PGD-shaped overclaim;
//! * `Missing` — a product claim with no backing code: a CLAIM-WITHOUT-CODE candidate;
//! * `Accurate` — no signed defect.
use super::ObserverReading;
use crate::row::{ClaimDelta, ReconciliationRow};

/// Deterministic product-claim reading for a row.
pub fn check(row: &ReconciliationRow) -> ObserverReading {
    let mut findings = Vec::new();

    match row.claim_delta {
        ClaimDelta::Undersold => findings.push(
            "NGD-shaped: code does more than the atlas claims (local-green/global-red)".to_string(),
        ),
        ClaimDelta::Oversold => findings.push("PGD/overclaim".to_string()),
        ClaimDelta::Missing => findings.push("CLAIM-WITHOUT-CODE candidate".to_string()),
        ClaimDelta::Accurate => {}
    }

    ObserverReading {
        observer: "product-claim",
        findings,
    }
}
