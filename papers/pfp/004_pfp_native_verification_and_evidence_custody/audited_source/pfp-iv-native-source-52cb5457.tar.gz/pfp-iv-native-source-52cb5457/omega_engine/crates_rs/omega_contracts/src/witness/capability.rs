/// Functional/obstruction measurement capability for types that expose phi.
///
/// Phi is not witness-owned and is not universally canonical for every
/// contract. It applies only where a contract explicitly declares a
/// phi-related law or measurement boundary. Witness code may attest observed
/// phi behavior, but it does not promote that observation to authority.
///
/// The phi value represents the "distance from closure" or "obstruction mass"
/// of a state. Lower phi means closer to a fixed point.
pub trait HasPhi {
    /// Returns the phi (obstruction measure) of this value.
    ///
    /// Phi must be non-negative. Lower values indicate closer to closure.
    fn phi(&self) -> f64;
}

/// Phi law relation for declared phi-monotonic contracts.
///
/// Phi laws apply only to contracts that explicitly declare phi-monotonicity.
/// Witness code can attest observed phi behavior, but it does not certify or
/// authorize the result.
pub trait PhiLaw {
    /// Check if the phi law is satisfied for a before/after pair.
    ///
    /// For Lambda operators: phi(after) <= phi(before)
    fn phi_satisfied<T: HasPhi>(before: &T, after: &T) -> bool {
        after.phi() <= before.phi()
    }

    /// Compute the phi delta (change in phi).
    ///
    /// Negative delta means phi decreased (good).
    /// Positive delta means phi increased (violation).
    fn phi_delta<T: HasPhi>(before: &T, after: &T) -> f64 {
        after.phi() - before.phi()
    }
}

/// Default implementation of PhiLaw.
pub struct DefaultPhiLaw;
impl PhiLaw for DefaultPhiLaw {}

/// Trait for witness relations that check property preservation.
///
/// This is used for checking that operations preserve specific properties.
pub trait WitnessRelation<S> {
    /// Check if the property is preserved from before to after state.
    fn preserves(before: &S, after: &S) -> bool;
}

/// Trait for monotonicity witness relations.
///
/// A monotonic relation R(x, y) holds when some measure of y is <= measure of x.
pub trait MonotonicRelation<S, M> {
    /// Extract the measure from a state.
    fn measure(state: &S) -> M;

    /// Check if the monotonicity relation holds (measure(after) <= measure(before)).
    fn is_monotonic(before: &S, after: &S) -> bool
    where
        M: PartialOrd,
    {
        Self::measure(after) <= Self::measure(before)
    }
}

/// Phi monotonicity witness relation.
///
/// Checks that phi(after) <= phi(before).
pub struct PhiMonotonicity;

impl<S: HasPhi> WitnessRelation<S> for PhiMonotonicity {
    fn preserves(before: &S, after: &S) -> bool {
        after.phi() <= before.phi()
    }
}

impl<S: HasPhi> MonotonicRelation<S, f64> for PhiMonotonicity {
    fn measure(state: &S) -> f64 {
        state.phi()
    }
}
