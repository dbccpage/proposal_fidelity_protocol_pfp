/// Witness directive trait for configuring witness generation.
///
/// Action-candidate witness profiles may require phi-monotonicity,
/// idempotence, and determinism. Other contracts require only the witness
/// properties declared by their contract. A directive requests evidence; it
/// does not verify, certify, evaluate, license, terminalize, or execute.
///
/// This trait allows contracts to declare which witnesses should be generated
/// for their implementations.
pub trait WitnessDirective: crate::sealed::Sealed {
    // ========================================================================
    // Witness generation flags by operator type
    // ========================================================================

    /// Generate phi-monotonicity witnesses for Lambda operators.
    ///
    /// When true, property-based tests verify that phi(output) <= phi(input).
    const GENERATE_LAMBDA_WITNESSES: bool = false;

    /// Generate idempotence witnesses for Reducer operators.
    ///
    /// When true, property-based tests verify that r(r(x)) = r(x).
    const GENERATE_REDUCER_WITNESSES: bool = false;

    /// Generate determinism witnesses for Transform operators.
    ///
    /// When true, property-based tests verify that f(x) = f(x) for all x.
    const GENERATE_TRANSFORM_WITNESSES: bool = false;

    // ========================================================================
    // Required properties
    // ========================================================================

    /// Require totality: operator must not fail on any valid input.
    const REQUIRE_TOTAL: bool = false;

    /// Require determinism: operator must produce same output for same input.
    const REQUIRE_DETERMINISTIC: bool = false;

    /// Require phi-monotonicity: phi must not increase.
    const REQUIRE_PHI_MONOTONIC: bool = false;

    /// Require idempotence: applying twice equals applying once.
    const REQUIRE_IDEMPOTENT: bool = false;

    /// Require replay integrity evidence.
    const REQUIRE_REPLAY_INTEGRITY: bool = false;

    /// Require hash verification evidence.
    const REQUIRE_HASH_VERIFICATION: bool = false;

    /// Require explicit source artifact references.
    const REQUIRE_SOURCE_ARTIFACTS: bool = false;

    /// Require schema-hash binding evidence.
    const REQUIRE_SCHEMA_HASH: bool = false;

    // ========================================================================
    // Witness properties to verify
    // ========================================================================

    /// Properties that must be witnessed for this contract.
    ///
    /// The returned names are evidence requirements. They are not proof that
    /// the properties hold until a declared checker boundary validates them.
    fn required_witness_properties() -> &'static [&'static str] {
        &[]
    }
}

/// Standard witness properties from YAML canonical definitions.
pub mod witness_properties {
    /// Phi-monotonicity: phi(output) <= phi(input)
    pub const PHI_MONOTONICITY: &str = "phi_monotonicity";
    /// Idempotence: r(r(x)) = r(x)
    pub const IDEMPOTENCE: &str = "idempotence";
    /// Determinism: f(x) = f(x)
    pub const DETERMINISM: &str = "determinism";
    /// Totality: operator succeeds on all valid inputs
    pub const TOTALITY: &str = "totality";
    /// Replay integrity: trace can be replayed to same result
    pub const REPLAY_INTEGRITY: &str = "replay_integrity";
    /// Hash verification: hash matches expected value
    pub const HASH_VERIFICATION: &str = "hash_verification";
    /// Source artifacts: witness records bind explicit source artifacts
    pub const SOURCE_ARTIFACTS: &str = "source_artifacts";
    /// Schema hash: witness records bind the declared schema hash
    pub const SCHEMA_HASH: &str = "schema_hash";
    /// Basis linear independence: basis vectors are linearly independent
    pub const BASIS_LINEAR_INDEPENDENCE: &str = "basis_linear_independence";
    /// Vector space admissibility: type forms a valid vector space
    pub const VECTOR_SPACE_ADMISSIBILITY: &str = "vector_space_admissibility";
}
