Q-Continuum Finite-Descent Integration (the first real DescentResult)
=====================================================================

> [!NOTE]
> **Disposition:** live design lineage, but verify test counts in the current
> checkout before citing them. The current canonical Q surfaces are
> `omega_types::q_continuum`, `omega_q`, and `papers/coda_q`.

> Closes the layer's own highest gap (`08_ADVERSARIAL_REVIEW` objections 5/6;
> `09_FINAL_REPORT` §12: "connect one existing finite descent artifact to
> `DescentResult`"). It is also the **shared plug-in pattern** for the GR paper
> series: every finite-descent paper enters the Q layer the same way.

1. Purpose
----------

The `DescentGate` emits `DescentObligation`s and now **verifies Lean witnesses**: `verify_lean_witness`
takes a typed `LeanWitness` (a theorem + its `#print axioms` receipt) and *derives* the verdict from
the receipt's shape — clean ⇒ `Supported`, non-standard axiom ⇒ `ConditionallySupported`, `sorryAx`
⇒ `Residual` — so a caller cannot assert a verdict the proof does not support. (It still does not run
the finite engine itself: the receipt is produced externally by a real `lake env lean` run.) This doc
wires a **real, already-verified finite-descent artifact** (a published paper + its Lean theorems +
its encyclopedia entry) into the Q layer's `DescentResult` / `AuthorityTrace`, so the witness-gated
authority machinery runs on a genuine case. The first artifact is **QM_030 / ENC-1152** (LQG
kinematical shadows); `qm_holonomy_descent_witnesses()` encodes the QM_030/031 theorems with their
captured axiom receipts.

This does **not** make the Q layer a solver. It connects an *external* finite engine (Lean +
`regen_encyclopedia.py`) whose receipts become `Witness` and `Residual` values. The Q layer's job
is only to record them without overclaiming.

2. The mapping (finite-descent artifact → Q types)
--------------------------------------------------

| Finite-descent artifact | Q-continuum type (`omega_types::q_continuum`) |
|---|---|
| the paper as a speculative entry point | `QIdea` (status `Speculative`) |
| the paper's reconstruction claim, with its scope | `QClaim` (scope = `AuthorityScope`) |
| the finite shadow family (e.g. the holonomy ladder) | `FiniteProjection` (carrier + zero relation) |
| each motif / theorem cluster | `DescentObligation` |
| each **verified Lean theorem** + its `#print axioms` receipt | `Witness` (`kind: "lean-theorem"`, `provenance` = file + command + axiom set) |
| a witnessed motif | `DescentResult::supported(obligation, scope, witness)` → `TerminalStatus::Supported` |
| an **imported / Q-held** part (dynamics, area scale, continuum) | `Residual` → `DescentResult::failed(obligation, scope, residual)` → `TerminalStatus::Residual` |
| the accumulated verdict | `AuthorityTrace` (`record_descent_result` per result) |

**The firewall is structural, and now enforced in code.** `AuthorityTrace.record_descent_result`
*derives* strength from the accumulated evidence after every result (a `recompute_strength`, not a
monotone running max): `TerminalWithinScope` requires an in-scope `Supported` witness **and no
unresolved residual or counterexample**. A strong witness coexisting with a residual caps at
`ConditionallySupported`; witness-less support and scope violations are filed as residuals. So a Q
idea with *any* Q-held residual in its scope **cannot** reach `TerminalWithinScope` — and a *later*
residual demotes a previously-terminal trace. (Before the `recompute_strength` fix the monotone `max`
let a single `Supported` witness pin the trace terminal even as Q-held residuals accumulated; the
guarantee was prose-only. It is now covered by `in_scope_residual_demotes_terminal_to_conditional`.)
That is the "no laundering speculation into authority" guarantee.

3. Worked example — QM_030 / ENC-1152 (the first real DescentResult)
--------------------------------------------------------------------

```text
QIdea       id="idea:lqg-kinematics"
            body="LQG kinematical motifs have finite-descent shadows in the Omega holonomy ladder."
            provenance="Q-LQG-001; QM_030; ENC-1152"            status=Speculative

QClaim      id="claim:lqg-kinematical-shadows"  idea_id="idea:lqg-kinematics"
            scope  = AuthorityScope("lqg-kinematical-shadows")
                       .with_constraint("finite toy carriers: Q8 ⊂ SU(2), finite cycles")
                       .with_exclusion("continuum SU(2)")
                       .with_exclusion("Hamiltonian constraint / dynamics")
                       .with_exclusion("area scale 8πγℓ_P² and the SU(2) Casimir eigenvalue")

FiniteProjection  carrier="graph-cochain holonomy ladder over Q8/finite cycles"
                  zero_relation="gauge (im d0); holonomy is the H¹ invariant"

DescentObligations + DescentResults (all scope = the claim scope):
  o:holonomy   → supported, Witness(kind="lean-theorem",
                   prov="lean4/QM/{HolonomyCurvature,SU2HolonomyLQG}.lean: loop_pureGauge_holonomy_trivial,
                         q8_curvature_wilson_nonflat ⁅i,j⁆=-1; [propext]/std-trio; lean exit 0")
  o:gauge-H1   → supported, Witness(kind="lean-theorem",
                         provenance="SuperpositionCochain.lean: hol_d0_zero, holonomy_zero_iff_gauge")
  o:loop-dof   → supported, Witness(kind="lean-theorem",
                         provenance="SuperpositionH1Rank.lean: finrank_H1_eq_one, card_H1_cycle")
  o:flux-ccr   → supported, Witness(kind="lean-theorem",
                         provenance="FluxHolonomyLQG.lean: flux_hol_noncomm")
  o:area-gap   → supported, Witness(kind="lean-theorem",
                         provenance="AreaSpectrumLQG.lean: area_strictMono, area_one_eq √3/2")  + NOTE the eigenvalue/scale are imported (see residuals)
  o:dynamics   → failed,    Residual(obstruction=NonFiniteProjection,
                         "Hamiltonian constraint — open in LQG itself; no finite shadow yet")
  o:area-scale → failed,    Residual(obstruction=MissingWitness,
                         "j(j+1) Casimir eigenvalue + 8πγℓ_P² scale are imported, not descended")
  o:continuum  → failed,    Residual(obstruction=NonFiniteProjection,
                         "continuum SU(2) / measure — Q-held; cross_Zn_to_U1_refinement is one
                          certified-limit shadow, not the full continuum")

AuthorityTrace("claim:lqg-kinematical-shadows", scope) after recording all results:
  strength            = ConditionallySupported   (NOT TerminalWithinScope — residuals present)
  successful_descents = the 5 witnessed kinematical motifs
  residuals           = dynamics, area-scale, continuum  (the honest Q-held remainder)
  revocation          = {new counterexample in scope, witness replay failure, scope mismatch}
```

**Result.** The Q layer records LQG kinematics as *conditionally supported within the toy-carrier
scope*, with the dynamics / continuum / area-scale explicitly carried as residuals — never
"terminally supported", never "LQG derived". That is QM_030's honest status, now enforced by the
type system, not just the prose.

4. The GR-series plug-in pattern
--------------------------------

Every paper in the GR series (the `GR-STRIP-001` nouns: curvature=holonomy [done, QM_030],
metric=measurement-pairing, geodesic/transport, singularity=refusal/geodesic-incompleteness,
Bianchi=`d∘d=0` shadow, continuum-membrane) enters the Q layer the **same way**:

```text
GR noun  →  QIdea  →  QClaim (toy-carrier scope, dynamics/continuum excluded)
         →  FiniteProjection (its finite shadow)
         →  DescentObligations (its mechanized motifs)
         →  DescentResult::supported(Witness = its Lean theorems)        for the finite shadows
         →  DescentResult::failed(Residual)                              for the Q-held parts
         →  AuthorityTrace  (ConditionallySupported; dynamics a residual)
```

The series therefore produces one growing, witness-gated `QContinuumLedger` whose `AuthorityTrace`s
make the QM↔GR reconstruction's *exact* support boundary machine-checkable: which motifs are
witnessed, which stay Q-held. The **dynamics residual recurs** in every GR paper — and recurrence is
data (`ObstructionKind::RepeatedObstruction`): it marks the single open frontier the whole field
(and we) have not descended.

5. Rust-test spec — DISCHARGED
------------------------------

`holonomy_ladder_descent_ledger()` in `omega_types::q_continuum` builds the §3 example on real
receipts (every motif from `qm_holonomy_descent_witnesses()` recorded `Supported`, plus the dynamics
/ area-scale / continuum residuals), and the test
`holonomy_ladder_is_conditionally_supported_not_terminal` asserts:

```text
trace.strength == ConditionallySupported       (NOT TerminalWithinScope)
trace.successful_descents.len() == qm_holonomy_descent_witnesses().len()
trace.residuals.len() == 3                      (dynamics + area-scale + continuum)
!trace.is_terminal_within_domain("qm-gr-holonomy-ladder")    (no laundering)
```

The no-laundering guarantee is enforced structurally by `recompute_strength` (a later in-scope
residual demotes a terminal trace), covered by `in_scope_residual_demotes_terminal_to_conditional`.
Current validation should at minimum rerun:

```powershell
cargo test -p omega_types q_continuum -j 1
cargo test -p omega_q -j 1
```

This is the literal discharge of `09_FINAL_REPORT` §12 ("connect one existing finite descent
artifact to `DescentResult`") on a real artifact.

6. What this does NOT claim
---------------------------

* Not that the Q layer *proved* anything — the proofs are external (Lean); the Q layer only records
  receipts and refuses to overclaim.

* Not that LQG kinematics is terminally supported — the `AuthorityTrace` is `ConditionallySupported`
  with explicit residuals; the dynamics/continuum/area-scale stay Q-held.

* Not a finite-descent *engine* — the engine is Lean + `regen_encyclopedia.py`; this is the wiring
  that turns their receipts into Q `Witness`/`Residual` values.

* Mints no authority: a Q-layer `TerminalWithinScope` is local bookkeeping, never the certified
  CODA-FDA `Π#` terminal.
