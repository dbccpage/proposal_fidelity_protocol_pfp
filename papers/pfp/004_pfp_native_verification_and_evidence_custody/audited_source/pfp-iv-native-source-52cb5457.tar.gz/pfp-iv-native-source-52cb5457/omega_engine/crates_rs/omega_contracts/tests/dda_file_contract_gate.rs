use serde::Deserialize;
use std::collections::HashSet;
use std::path::{Path, PathBuf};

#[derive(Debug, Deserialize, Default)]
struct Exactness {
    exact_constructor_required: Option<bool>,
}

#[derive(Debug, Deserialize)]
struct FileContract {
    schema_version: String,
    contract_id: String,
    #[serde(rename = "crate")]
    krate: String,
    file: String,
    role: String,
    authority_effect: String,
    #[serde(default)]
    forbidden_substrings: Option<Vec<String>>,
    #[serde(default)]
    required_substrings: Option<Vec<String>>,
    #[serde(default)]
    required_tests: Option<Vec<String>>,
    #[serde(default)]
    exactness: Exactness,
}

fn collect_contracts(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = std::fs::read_dir(dir).unwrap_or_else(|err| panic!("read {dir:?}: {err}"));
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect_contracts(&path, out);
        } else if path
            .file_name()
            .and_then(|name| name.to_str())
            .is_some_and(|name| name.ends_with(".contract.yaml"))
        {
            out.push(path);
        }
    }
}

fn read_to_string(path: &Path) -> String {
    std::fs::read_to_string(path).unwrap_or_else(|err| panic!("read {path:?}: {err}"))
}

fn nonempty(list: &Option<Vec<String>>) -> impl Iterator<Item = &str> {
    list.iter()
        .flatten()
        .map(String::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty())
}

#[test]
fn dda_file_contracts_bind_to_sources_and_required_markers() {
    let manifest = Path::new(env!("CARGO_MANIFEST_DIR"));
    let engine_root = manifest
        .parent()
        .and_then(Path::parent)
        .expect("omega_contracts sits under omega_engine/crates");
    // Layout: DDA file contracts live under rust/ (corpus tree); not a top-level
    // contract_canonical_definitions/omega_discrete_deformation_algebra/ directory.
    let contract_dir =
        manifest.join("src/contract_canonical_definitions/rust/omega_discrete_deformation_algebra");

    let mut paths = Vec::new();
    collect_contracts(&contract_dir, &mut paths);
    paths.sort();

    assert!(
        paths.len() >= 2,
        "expected DDA lib and mub_cochain file contracts, got {}",
        paths.len()
    );

    let mut seen_files = HashSet::new();
    let mut checked = 0usize;
    let mut findings = Vec::new();

    for path in paths {
        let raw = read_to_string(&path);
        let contract: FileContract = match serde_yaml::from_str(&raw) {
            Ok(contract) => contract,
            Err(err) => {
                findings.push(format!("{} failed YAML parse: {err}", path.display()));
                continue;
            }
        };
        checked += 1;

        if contract.schema_version != "omega.file_contract.v1" {
            findings.push(format!(
                "{} has schema_version {}; expected omega.file_contract.v1",
                contract.contract_id, contract.schema_version
            ));
        }
        if contract.krate != "omega_discrete_deformation_calculus" {
            findings.push(format!(
                "{} binds crate {}; expected omega_discrete_deformation_calculus",
                contract.contract_id, contract.krate
            ));
        }
        if contract.role.trim().is_empty() || contract.authority_effect.trim().is_empty() {
            findings.push(format!(
                "{} must declare nonempty role and authority_effect",
                contract.contract_id
            ));
        }
        if !seen_files.insert(contract.file.clone()) {
            findings.push(format!("duplicate DDA file contract for {}", contract.file));
        }

        let source_path = engine_root.join(&contract.file);
        if !source_path.exists() {
            findings.push(format!(
                "{} source file missing: {}",
                contract.contract_id,
                source_path.display()
            ));
            continue;
        }
        let source = read_to_string(&source_path);

        for forbidden in nonempty(&contract.forbidden_substrings) {
            if source.contains(forbidden) {
                findings.push(format!(
                    "{} forbidden substring `{}` present in {}",
                    contract.contract_id,
                    forbidden,
                    source_path.display()
                ));
            }
        }
        for required in nonempty(&contract.required_substrings) {
            if !omega_contracts::source_satisfies_file_contract_substring(&source, required) {
                findings.push(format!(
                    "{} missing required substring `{}` in {}",
                    contract.contract_id,
                    required,
                    source_path.display()
                ));
            }
        }
        for required_test in nonempty(&contract.required_tests) {
            let fn_marker = format!("fn {required_test}");
            if !source.contains(&fn_marker) {
                findings.push(format!(
                    "{} missing required test `{}` in {}",
                    contract.contract_id,
                    required_test,
                    source_path.display()
                ));
            }
        }
        if contract.exactness.exact_constructor_required == Some(true)
            && !source.contains("checked_")
            && !source.contains("try_")
        {
            findings.push(format!(
                "{} requires exact construction but source lacks checked_/try_ constructors",
                contract.contract_id
            ));
        }
    }

    assert_eq!(
        checked, 2,
        "expected exactly the two DDA file contracts to be checked"
    );
    assert!(
        findings.is_empty(),
        "DDA file-contract findings:\n{}",
        findings.join("\n")
    );
}
