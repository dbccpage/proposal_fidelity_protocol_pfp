use super::identity::{ContractBound, NamedComponent};
use crate::kinds::BaseType;

/// Parses or intakes raw material into typed structure.
///
/// A constructor may reject malformed input, but it does not certify semantic
/// correctness or evaluate admissibility. Validation belongs to a Validator boundary.
pub trait Constructor<Raw, T: BaseType>: NamedComponent + ContractBound {
    type Error;

    fn construct(&self, raw: Raw) -> Result<T, Self::Error>;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ConstructorError {
    ParseError(String),
    SchemaMismatch,
    MissingRequiredField(&'static str),
    InvalidInvariant(String),
    NonFiniteNumericInput,
    UnsupportedRepresentation,
}
