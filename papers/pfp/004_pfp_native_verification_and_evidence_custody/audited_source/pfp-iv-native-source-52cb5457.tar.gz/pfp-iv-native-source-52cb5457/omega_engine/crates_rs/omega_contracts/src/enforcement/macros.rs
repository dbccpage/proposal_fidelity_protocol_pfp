#[macro_export]
macro_rules! assert_contract_binding {
    ($ty:ty, $contract:ty) => {{
        let _ = $crate::binding::audit_implementation::<$ty, $contract>().unwrap();
    }};
}

#[macro_export]
macro_rules! __impl_contract_base {
    ($ty:ident, $contract:ty, $kind:ty) => {
        #[derive(Debug, Clone, Copy, Default)]
        pub struct $ty;

        impl $crate::sealed::Sealed for $ty {}
        impl $kind for $ty {}

        impl $crate::binding::ImplementsContract<$contract> for $ty {}

        $crate::require_contract!($contract);

        const _: () = {
            fn assert_impl<I: $crate::binding::ImplementsContract<$contract>>() {}
            assert_impl::<$ty>();
        };
    };
}

#[macro_export]
macro_rules! attach_contract_laws {
    ($ty:ident, $contract:ty, $assert_fn:path) => {
        const _: () = {
            fn _run() {
                $assert_fn::<$contract>();
            }
        };
    };
    ($ty:ident, $contract:ty) => {};
}

#[macro_export]
macro_rules! attach_witness_profile {
    ($ty:ident, $contract:ty) => {
        $crate::enforcement::generated::emit_contract_witnesses!($ty, $contract);
    };
}

#[macro_export]
macro_rules! attach_test_harness {
    ($ty:ident, $contract:ty, $shape_check:path) => {
        #[cfg(test)]
        mod __witness_obligations {
            use super::*;

            #[test]
            fn contract_binding_is_valid() {
                $crate::assert_contract_binding!($ty, $contract);
            }

            #[test]
            fn shape_is_valid() {
                $shape_check::<$ty, $contract>();
            }
        }
    };
    ($ty:ident, $contract:ty) => {
        #[cfg(test)]
        mod __witness_obligations {
            use super::*;

            #[test]
            fn contract_binding_is_valid() {
                $crate::assert_contract_binding!($ty, $contract);
            }
        }
    };
}

#[macro_export]
macro_rules! impl_lambda {
    (
        type = $ty:ident,
        contract = $contract:ty,
        apply = |$input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::LambdaKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::LambdaKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::operators::LambdaOp<
                <$contract as $crate::binding::BoundContract>::Input,
                <$contract as $crate::binding::BoundContract>::Output,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            fn apply(
                &self,
                input: &<$contract as $crate::binding::BoundContract>::Input,
            ) -> Result<
                <$contract as $crate::binding::BoundContract>::Output,
                $crate::types::failure_lambda::LambdaFailure,
            > {
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::descriptors::assert_lambda_laws);
        $crate::attach_witness_profile!($ty, $contract);
        $crate::attach_test_harness!($ty, $contract, $crate::binding::require_lambda_shape);
    };
}

#[macro_export]
macro_rules! impl_reducer {
    (
        type = $ty:ident,
        contract = $contract:ty,
        apply = |$input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::ReducerKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::ReducerKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::operators::ReducerOp<
                <$contract as $crate::binding::BoundContract>::Input,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            fn apply(
                &self,
                input: &<$contract as $crate::binding::BoundContract>::Input,
            ) -> Result<
                <$contract as $crate::binding::BoundContract>::Input,
                $crate::types::failure_reducer::ReducerFailure,
            > {
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::descriptors::assert_reducer_laws);
        $crate::attach_witness_profile!($ty, $contract);
        $crate::attach_test_harness!($ty, $contract, $crate::binding::require_reducer_shape);
    };
}

#[macro_export]
macro_rules! impl_transform {
    (
        type = $ty:ident,
        contract = $contract:ty,
        apply = |$input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::TransformKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::TransformKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::operators::TransformOp<
                <$contract as $crate::binding::BoundContract>::Input,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            fn apply(
                &self,
                input: &<$contract as $crate::binding::BoundContract>::Input,
            ) -> Result<
                <$contract as $crate::binding::BoundContract>::Input,
                $crate::types::failure_transform::TransformFailure,
            > {
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::descriptors::assert_transform_laws);
        $crate::attach_witness_profile!($ty, $contract);
        $crate::attach_test_harness!($ty, $contract, $crate::binding::require_transform_shape);
    };
}

#[macro_export]
macro_rules! impl_meta {
    (
        type = $ty:ident,
        contract = $contract:ty,
        evaluate = |$self:ident, $input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::MetaKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::MetaKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::analysis::MetaRule<
                <$contract as $crate::binding::BoundContract>::Subject,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn evaluate(
                &self,
                input: &<$contract as $crate::binding::BoundContract>::Subject,
            ) -> Result<Self::Output, Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::descriptors::assert_meta_laws);
        $crate::attach_witness_profile!($ty, $contract);
        $crate::attach_test_harness!($ty, $contract, $crate::binding::require_meta_shape);
    };
}

#[macro_export]
macro_rules! impl_engine {
    (
        type = $ty:ident,
        contract = $contract:ty,
        step = |$self:ident, $input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::EngineKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::EngineKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl $crate::traits::execution::Engine<<$contract as $crate::binding::BoundContract>::Input>
            for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Operator = $ty;
            type License = String;
            type RuntimeState = <$contract as $crate::binding::BoundContract>::RuntimeState;
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Trace = omega_types::trace_artifact::VoidTrace;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn step(
                &mut self,
                input: <$contract as $crate::binding::BoundContract>::Input,
                _license: &Self::License,
            ) -> Result<(Self::RuntimeState, Self::Output, Self::Trace), Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::traits::assert_engine_laws);
        $crate::attach_test_harness!($ty, $contract);
    };
}

#[macro_export]
macro_rules! impl_pipeline {
    (
        type = $ty:ident,
        contract = $contract:ty,
        run = |$self:ident, $input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::PipelineKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::PipelineKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::execution::Pipeline<
                <$contract as $crate::binding::BoundContract>::Input,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Engine = $ty;
            type PipelineState = <$contract as $crate::binding::BoundContract>::RuntimeState;
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Trace = omega_types::trace_artifact::VoidTrace;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn run(
                &mut self,
                input: <$contract as $crate::binding::BoundContract>::Input,
            ) -> Result<(Self::PipelineState, Self::Output, Self::Trace), Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract);
        $crate::attach_test_harness!($ty, $contract);
    };
}

#[macro_export]
macro_rules! impl_runtime {
    (
        type = $ty:ident,
        contract = $contract:ty,
        start = |$self:ident, $arg:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::RuntimeKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::RuntimeKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::execution::Runtime<<$contract as $crate::binding::BoundContract>::Input>
            for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Pipeline = $ty;
            type Input = <$contract as $crate::binding::BoundContract>::Input;
            type RuntimeState = <$contract as $crate::binding::BoundContract>::RuntimeState;
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Trace = omega_types::trace_artifact::VoidTrace;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn start(
                &mut self,
                arg: Self::Input,
            ) -> Result<(Self::RuntimeState, Self::Output, Self::Trace), Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract);
        $crate::attach_test_harness!($ty, $contract);
    };
}

#[macro_export]
macro_rules! impl_analysis_unit {
    (
        type = $ty:ident,
        contract = $contract:ty,
        analyze = |$self:ident, $input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::AnalysisUnitKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::AnalysisUnitKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::analysis::AnalysisUnit<
                <$contract as $crate::binding::BoundContract>::Subject,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn analyze(
                &self,
                input: &<$contract as $crate::binding::BoundContract>::Subject,
            ) -> Result<Self::Output, Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::descriptors::assert_validation_laws);
        $crate::attach_test_harness!($ty, $contract);
    };
}

#[macro_export]
macro_rules! impl_policy_unit {
    (
        type = $ty:ident,
        contract = $contract:ty,
        decide = |$self:ident, $input:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::PolicyUnitKind);

        const _: () = {
            fn assert_kind<C: $crate::binding::BoundContract + $crate::kinds::PolicyUnitKind>() {}
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::analysis::PolicyUnit<
                <$contract as $crate::binding::BoundContract>::Subject,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn decide(
                &self,
                input: &<$contract as $crate::binding::BoundContract>::Subject,
            ) -> Result<Self::Output, Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::traits::assert_policy_laws);
        $crate::attach_test_harness!($ty, $contract);
    };
}

#[macro_export]
macro_rules! impl_action_executor {
    (
        type = $ty:ident,
        contract = $contract:ty,
        execute = |$self:ident, $decision:ident| $body:expr
    ) => {
        $crate::__impl_contract_base!($ty, $contract, $crate::kinds::ActionExecutorKind);

        const _: () = {
            fn assert_kind<
                C: $crate::binding::BoundContract + $crate::kinds::ActionExecutorKind,
            >() {
            }
            assert_kind::<$contract>();
        };
        impl $crate::traits::operators::OperatorIdentity for $ty {
            fn name(&self) -> &'static str {
                <$contract as $crate::binding::GeneratedContractImage>::DESCRIPTOR.id()
            }
        }
        impl
            $crate::traits::analysis::ActionExecutor<
                <$contract as $crate::binding::BoundContract>::Subject,
            > for $ty
        where
            $contract: $crate::binding::BoundContract,
        {
            type Output = <$contract as $crate::binding::BoundContract>::Output;
            type Error = $crate::types::failure_operator::OperatorFailure;
            fn execute(
                &mut self,
                decision: &<$contract as $crate::binding::BoundContract>::Subject,
            ) -> Result<Self::Output, Self::Error> {
                let $self = self;
                $body
            }
        }

        $crate::attach_contract_laws!($ty, $contract, $crate::traits::assert_engine_laws);
        $crate::attach_test_harness!($ty, $contract);
    };
}
