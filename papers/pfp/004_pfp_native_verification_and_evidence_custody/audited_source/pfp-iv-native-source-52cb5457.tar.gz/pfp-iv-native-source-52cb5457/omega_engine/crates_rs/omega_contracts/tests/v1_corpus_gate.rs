//! Task 16 — CI gate: every file currently marked `schema_version: omega.contract.v1`
//! across the whole canonical corpus must load and validate. Legacy (non-v1) files are
//! skipped by the loader (spec §7), so this does not force the un-migrated corpus through v1.
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn all_v1_contracts_in_corpus_validate() {
    let corpus = Path::new(env!("CARGO_MANIFEST_DIR")).join("src/contract_canonical_definitions");
    let report = load_v1_dir(&corpus).expect("corpus dir readable");
    // Repository census at 2026-08-26: 221 files explicitly declare
    // `schema_version: omega.contract.v1` (75 across the eight numbered core
    // families, 71 math, 74 rust, and 1 omega_morphism). The copied 510
    // threshold exceeded even the 289 `*.contract.yaml` files in this
    // repository, so the gate could never pass here. Keep the observed v1
    // corpus as a non-shrinking floor.
    assert!(
        report.loaded >= 221,
        "expected at least 221 v1 contracts, got {}",
        report.loaded
    );
    assert!(
        report.findings.is_empty(),
        "v1 corpus findings: {:#?}",
        report.findings
    );
}
