use super::identity::{ContractBound, NamedComponent};
use crate::kinds::{BaseType, ContractEffect};
use crate::schema::{EffectLawDecl, PhiLawDecl, StructureLawDecl};

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CandidateKind {
    Lambda,
    Reducer,
    Normalizer,
    Transform,
    Other,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LawDeclaration {
    pub id: String,
    pub phi_claim: Option<PhiLawDecl>,
    pub structure_claim: Option<StructureLawDecl>,
    pub effect_claim: Option<EffectLawDecl>,
    pub evidence_refs: Vec<String>,
}

pub trait DeclaredActionCandidate<S: BaseType, T: BaseType>:
    NamedComponent + ContractBound
{
    type Error;

    fn apply_candidate(&self, input: &S) -> Result<T, Self::Error>;
    fn law_declaration(&self) -> LawDeclaration;
    fn authority_effect(&self) -> ContractEffect {
        ContractEffect::EvidenceOnly
    }
    fn candidate_kind(&self) -> CandidateKind {
        CandidateKind::Other
    }
}

pub trait LambdaCandidate<S: BaseType, T: BaseType>: DeclaredActionCandidate<S, T> {}

pub trait ReducerCandidate<S: BaseType>: DeclaredActionCandidate<S, S> {}

pub trait NormalizerCandidate<S: BaseType>: DeclaredActionCandidate<S, S> {}

pub trait TransformCandidate<S: BaseType>: DeclaredActionCandidate<S, S> {}

/// Forgetful action candidate: discards structure with explicit loss declaration.
/// Maps to forgetful_action contract in 04_actions_contracts.yaml.
pub trait ForgetfulActionCandidate<S: BaseType, T: BaseType>:
    DeclaredActionCandidate<S, T>
{
    /// Returns the explicit loss declaration for discarded structure.
    fn loss_declaration(&self) -> LossDeclaration;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct LossDeclaration {
    pub lost_fields: Vec<String>,
    pub loss_class: LossClass,
    pub semantic_loss_declared: bool,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum LossClass {
    Structural,
    Semantic,
    QuotientRelevant,
}

/// Proposal generator candidate: produces detached candidates without evaluation.
/// Maps to proposal_generator contract in 04_actions_contracts.yaml.
pub trait ProposalGeneratorCandidate<S: BaseType, T: BaseType>:
    NamedComponent + ContractBound
{
    type Error;
    type Proposal;

    /// Generates candidate proposals without evaluating or ranking them.
    fn generate_proposals(&self, input: &S) -> Result<Vec<Self::Proposal>, Self::Error>;
}

/// Projector candidate: proposes explicit-loss projection to lower-dimensional subspace.
/// Maps to projector_candidate contract in 04_actions_contracts.yaml.
pub trait ProjectorCandidate<S: BaseType, T: BaseType>: DeclaredActionCandidate<S, T> {
    /// Returns the dimensions being discarded by this projection.
    fn discarded_dimensions(&self) -> Vec<String>;

    /// Returns invariants that are preserved by this projection.
    fn preserved_invariants(&self) -> Vec<String>;
}

/// Reflector candidate: quotes or reflects structure without execution.
/// Maps to reflector_candidate contract in 04_actions_contracts.yaml.
pub trait ReflectorCandidate<S: BaseType, T: BaseType>: DeclaredActionCandidate<S, T> {
    /// Returns the reflection mode used.
    fn reflection_mode(&self) -> ReflectionMode;
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ReflectionMode {
    /// Direct quotation without transformation.
    Quotation,
    /// Structural reflection preserving invariants.
    StructuralReflection,
    /// Meta-level reflection for inspection.
    MetaReflection,
}
