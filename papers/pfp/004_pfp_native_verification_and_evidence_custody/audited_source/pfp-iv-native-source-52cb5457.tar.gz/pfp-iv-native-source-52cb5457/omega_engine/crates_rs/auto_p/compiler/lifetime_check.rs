//! --- yaml
//! title: lifetime_check
//! file_name: lifetime_check.rs
//! file_location: ~/anomalon/anomalon_kernel/omega_core/src/compiler/lifetime_check.rs
//! status: Liquid
//! invariance_level: Tier 1
//! logic_system: Self-Repair Cohomology
//! substrate: Rust
//! description: >
//!   Phase 4 of the AutoP compiler (Lambda X-008). Topological Memory Management.
//!   Maps .atp declarations into per-scope ownership sub-complexes, detects resource
//!   leaks as H^1 cycles, and emits safe deallocation ordering via topological sort.
//!   Memory regions are topology. Cyclic references are H^1 holes. Safe deallocation
//!   occurs when H^1=0 (contractible to a point).
//! content_hash: a75204aa661fb6f3f78886289fb664daa8bd44954768452b55db81287b37cbc3
//! version: 2
//! ---

use std::collections::{HashMap, HashSet, VecDeque};

use serde::{Deserialize, Serialize};

use crate::topos::meta::meta_10::anomalon::OmegaVerdict;

use super::parser::TypeExpr;
use super::parser::{AtpModule, Declaration};
use super::symbol_table::{SymbolId, SymbolTable};

/// Recursively collect leaf type names from a TypeExpr, ignoring parameters.
fn collect_base_leaf_types(ty: &TypeExpr) -> HashSet<String> {
    let mut leaves = HashSet::new();
    match ty {
        TypeExpr::Arrow(left, right) => {
            leaves.extend(collect_base_leaf_types(left));
            leaves.extend(collect_base_leaf_types(right));
        }
        TypeExpr::Product(factors) => {
            for f in factors {
                leaves.extend(collect_base_leaf_types(f));
            }
        }
        TypeExpr::Named(name) => {
            leaves.insert(name.clone());
        }
        TypeExpr::Parameterized(name, _params) => {
            leaves.insert(name.clone());
        }
    }
    leaves
}

// ============================================================
// Output Types
// ============================================================

/// Result of the lifetime/memory analysis pass.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LifetimeCheckResult {
    pub scopes: Vec<ScopeAnalysis>,
    pub drop_order: Vec<DropDirective>,
    pub resource_escapes: Vec<ResourceEscape>,
    pub verdict: OmegaVerdict,
}

/// Per-scope contractibility analysis.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScopeAnalysis {
    pub scope_name: String,
    pub n_vertices: usize,
    pub n_edges: usize,
    pub has_cycle: bool,
    pub contractible: bool,
}

/// A safe deallocation directive: drop this scope at this position.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DropDirective {
    pub scope_name: String,
    pub order: usize,
}

/// A cross-scope resource escape (cycle in the scope dependency graph).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResourceEscape {
    pub from_scope: String,
    pub to_scope: String,
    pub leaked_type: String,
    pub message: String,
}

// ============================================================
// Internal: Per-Scope Directed Graph
// ============================================================

struct ScopeComplex {
    name: String,
    vertex_map: HashMap<SymbolId, usize>,
    edges: HashSet<(usize, usize)>,
}

impl ScopeComplex {
    fn new(name: String) -> Self {
        Self {
            name,
            vertex_map: HashMap::new(),
            edges: HashSet::new(),
        }
    }

    fn get_or_insert_vertex(&mut self, sym: SymbolId) -> usize {
        let next = self.vertex_map.len();
        *self.vertex_map.entry(sym).or_insert(next)
    }

    /// Adds a **directed** edge (a -> b). Direction models resource flow.
    fn add_edge(&mut self, a: usize, b: usize) {
        self.edges.insert((a, b));
    }

    /// Detects directed cycles via DFS with coloring.
    /// White(0) = unvisited, Gray(1) = in current path, Black(2) = done.
    fn has_directed_cycle(&self) -> bool {
        let n = self.vertex_map.len();
        if n == 0 {
            return false;
        }
        // Build adjacency list
        let mut adj: Vec<Vec<usize>> = vec![Vec::new(); n];
        for &(from, to) in &self.edges {
            if from < n && to < n {
                adj[from].push(to);
            }
        }

        let mut color = vec![0u8; n]; // 0=white, 1=gray, 2=black

        fn dfs(node: usize, adj: &[Vec<usize>], color: &mut [u8]) -> bool {
            color[node] = 1; // gray
            for &next in &adj[node] {
                if color[next] == 1 {
                    return true; // back edge = cycle
                }
                if color[next] == 0 && dfs(next, adj, color) {
                    return true;
                }
            }
            color[node] = 2; // black
            false
        }

        for v in 0..n {
            if color[v] == 0 && dfs(v, &adj, &mut color) {
                return true;
            }
        }
        false
    }

    fn analyze(&self) -> ScopeAnalysis {
        let n_vertices = self.vertex_map.len();
        let n_edges = self.edges.len();
        let has_cycle = self.has_directed_cycle();
        ScopeAnalysis {
            scope_name: self.name.clone(),
            n_vertices,
            n_edges,
            has_cycle,
            contractible: !has_cycle,
        }
    }
}

// ============================================================
// Topological Sort (Kahn's Algorithm)
// ============================================================

/// Run Kahn's algorithm on a directed graph.
///
/// Returns `Ok(order)` where `order[i]` is the drop position for node `i`,
/// or `Err(cycle_edges)` listing edges involved in cycles.
fn topological_sort_scopes(
    n_scopes: usize,
    dep_edges: &[(usize, usize)],
) -> Result<Vec<usize>, Vec<(usize, usize)>> {
    if n_scopes == 0 {
        return Ok(Vec::new());
    }

    let mut in_degree = vec![0usize; n_scopes];
    let mut adj: Vec<Vec<usize>> = vec![Vec::new(); n_scopes];

    for &(from, to) in dep_edges {
        adj[from].push(to);
        in_degree[to] += 1;
    }

    let mut queue: VecDeque<usize> = VecDeque::new();
    for (i, &deg) in in_degree.iter().enumerate() {
        if deg == 0 {
            queue.push_back(i);
        }
    }

    let mut order = vec![0usize; n_scopes];
    let mut position = 0usize;
    let mut processed = 0usize;

    while let Some(node) = queue.pop_front() {
        order[node] = position;
        position += 1;
        processed += 1;

        for &neighbor in &adj[node] {
            in_degree[neighbor] = in_degree[neighbor].checked_sub(1).unwrap_or(0);
            if in_degree[neighbor] == 0 {
                queue.push_back(neighbor);
            }
        }
    }

    if processed < n_scopes {
        // Cycle detected: use Tarjan SCC to find exact strongly connected components.
        let sccs = tarjan_scc(n_scopes, &adj);
        let mut in_cycle: Vec<bool> = vec![false; n_scopes];
        for scc in &sccs {
            let is_cycle = scc.len() > 1 || (scc.len() == 1 && adj[scc[0]].contains(&scc[0]));
            if is_cycle {
                for &node in scc {
                    in_cycle[node] = true;
                }
            }
        }
        // Report only edges where both endpoints are in the same SCC
        let mut cycle_edges = Vec::new();
        for &(from, to) in dep_edges {
            if in_cycle[from] && in_cycle[to] {
                cycle_edges.push((from, to));
            }
        }
        Err(cycle_edges)
    } else {
        Ok(order)
    }
}

/// Tarjan's algorithm for strongly connected components.
/// Returns SCCs in reverse topological order (leaves first).
fn tarjan_scc(n: usize, adj: &[Vec<usize>]) -> Vec<Vec<usize>> {
    struct TarjanState {
        index_counter: usize,
        stack: Vec<usize>,
        on_stack: Vec<bool>,
        index: Vec<Option<usize>>,
        lowlink: Vec<usize>,
        sccs: Vec<Vec<usize>>,
    }

    fn strongconnect(v: usize, adj: &[Vec<usize>], state: &mut TarjanState) {
        state.index[v] = Some(state.index_counter);
        state.lowlink[v] = state.index_counter;
        state.index_counter += 1;
        state.stack.push(v);
        state.on_stack[v] = true;

        for &w in &adj[v] {
            if state.index[w].is_none() {
                strongconnect(w, adj, state);
                state.lowlink[v] = state.lowlink[v].min(state.lowlink[w]);
            } else if state.on_stack[w] {
                state.lowlink[v] = state.lowlink[v].min(state.index[w].unwrap());
            }
        }

        if state.lowlink[v] == state.index[v].unwrap() {
            let mut scc = Vec::new();
            loop {
                let w = state.stack.pop().unwrap();
                state.on_stack[w] = false;
                scc.push(w);
                if w == v {
                    break;
                }
            }
            state.sccs.push(scc);
        }
    }

    let mut state = TarjanState {
        index_counter: 0,
        stack: Vec::new(),
        on_stack: vec![false; n],
        index: vec![None; n],
        lowlink: vec![0; n],
        sccs: Vec::new(),
    };

    for v in 0..n {
        if state.index[v].is_none() {
            strongconnect(v, adj, &mut state);
        }
    }

    state.sccs
}

// ============================================================
// Scope Resolution Helper
// ============================================================

/// Given leaf type names, find all scopes they could belong to.
fn resolve_scopes<'a>(
    leaf: &'a str,
    scope_section_index: &'a HashMap<String, Vec<String>>,
    scope_name_index: &'a HashMap<String, usize>,
) -> Vec<&'a str> {
    let mut matches = Vec::new();
    if let Some(scopes) = scope_section_index.get(leaf) {
        for sc in scopes {
            matches.push(sc.as_str());
        }
    }
    if scope_name_index.contains_key(leaf) {
        matches.push(leaf);
    }
    matches
}

// ============================================================
// Main Entry Point
// ============================================================

/// Run the lifetime/memory analysis on a parsed AtpModule.
///
/// Pipeline:
///   A. Build scope map (one ScopeComplex per manifold/sheaf)
///   B. Per-scope directed cycle analysis (contractibility check)
///   C. Build scope dependency graph (from morphisms/adjunctions)
///   D. Topological sort for drop order (reversed for safe deallocation)
///   E. Detect resource escapes (cycles in scope dependency graph)
///   F. Assemble verdict
pub fn check_lifetimes(module: &AtpModule, symbols: &mut SymbolTable) -> LifetimeCheckResult {
    // Empty module is vacuously safe.
    if module.declarations.is_empty() {
        return LifetimeCheckResult {
            scopes: Vec::new(),
            drop_order: Vec::new(),
            resource_escapes: Vec::new(),
            verdict: OmegaVerdict::Diamond,
        };
    }

    // ── Step A: Build scope map ──────────────────────────────────

    let mut scope_complexes: Vec<ScopeComplex> = Vec::new();
    // Maps scope name → index in scope_complexes
    let mut scope_name_index: HashMap<String, usize> = HashMap::new();
    // Maps section name → list of scope names (to prevent collisions and handle ambiguity)
    let mut scope_section_index: HashMap<String, Vec<String>> = HashMap::new();

    // Pass 1: Register all scope vertices
    for decl in &module.declarations {
        match decl {
            Declaration::Manifold(m) => {
                let idx = scope_complexes.len();
                let mut sc = ScopeComplex::new(m.name.clone());

                for section in &m.sections {
                    let sym = symbols.intern_user(&section.name);
                    sc.get_or_insert_vertex(sym);
                    scope_section_index
                        .entry(section.name.clone())
                        .or_default()
                        .push(m.name.clone());
                }

                scope_name_index.insert(m.name.clone(), idx);
                scope_complexes.push(sc);
            }
            Declaration::Sheaf(s) => {
                let idx = scope_complexes.len();
                let mut sc = ScopeComplex::new(s.name.clone());

                for section in &s.sections {
                    let sym = symbols.intern_user(&section.name);
                    sc.get_or_insert_vertex(sym);
                    scope_section_index
                        .entry(section.name.clone())
                        .or_default()
                        .push(s.name.clone());
                }

                scope_name_index.insert(s.name.clone(), idx);
                scope_complexes.push(sc);
            }
            _ => {}
        }
    }

    // Pass 2: Map local inner-scope edges
    for decl in &module.declarations {
        match decl {
            Declaration::Manifold(m) => {
                let idx = *scope_name_index.get(&m.name).unwrap();
                let sc = &mut scope_complexes[idx];

                for section in &m.sections {
                    if let TypeExpr::Arrow(ref src, ref tgt) = section.type_sig {
                        let src_leaves = collect_base_leaf_types(src);
                        let tgt_leaves = collect_base_leaf_types(tgt);

                        for sl in &src_leaves {
                            for tl in &tgt_leaves {
                                let sl_sym = symbols.intern_user(sl);
                                let tl_sym = symbols.intern_user(tl);
                                if let (Some(&si), Some(&ti)) =
                                    (sc.vertex_map.get(&sl_sym), sc.vertex_map.get(&tl_sym))
                                {
                                    sc.add_edge(si, ti);
                                }
                            }
                        }
                    }
                }
            }
            Declaration::Sheaf(s) => {
                let idx = *scope_name_index.get(&s.name).unwrap();
                let sc = &mut scope_complexes[idx];

                for section in &s.sections {
                    if let TypeExpr::Arrow(ref src, ref tgt) = section.type_sig {
                        let src_leaves = collect_base_leaf_types(src);
                        let tgt_leaves = collect_base_leaf_types(tgt);

                        for sl in &src_leaves {
                            for tl in &tgt_leaves {
                                let sl_sym = symbols.intern_user(sl);
                                let tl_sym = symbols.intern_user(tl);
                                if let (Some(&si), Some(&ti)) =
                                    (sc.vertex_map.get(&sl_sym), sc.vertex_map.get(&tl_sym))
                                {
                                    sc.add_edge(si, ti);
                                }
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }

    // ── Step B: Per-scope directed cycle analysis ────────────────

    let scope_analyses: Vec<ScopeAnalysis> =
        scope_complexes.iter().map(|sc| sc.analyze()).collect();

    let any_non_contractible = scope_analyses.iter().any(|sa| !sa.contractible);

    // ── Step C: Build scope dependency graph ──────────────────────

    let n_scopes = scope_complexes.len();
    let mut dep_edge_set: HashSet<(usize, usize)> = HashSet::new();
    // Track which declaration name caused each dependency edge
    let mut dep_edge_labels: HashMap<(usize, usize), Vec<String>> = HashMap::new();

    for decl in &module.declarations {
        match decl {
            Declaration::Morphism(m) => {
                let src_leaves = collect_base_leaf_types(&m.source);
                let tgt_leaves = collect_base_leaf_types(&m.target);

                for sl in &src_leaves {
                    let src_scopes = resolve_scopes(sl, &scope_section_index, &scope_name_index);
                    for tl in &tgt_leaves {
                        let tgt_scopes =
                            resolve_scopes(tl, &scope_section_index, &scope_name_index);
                        for ss in &src_scopes {
                            for ts in &tgt_scopes {
                                if ss != ts {
                                    if let (Some(&si), Some(&ti)) =
                                        (scope_name_index.get(*ss), scope_name_index.get(*ts))
                                    {
                                        let edge = (si, ti);
                                        dep_edge_set.insert(edge);
                                        dep_edge_labels
                                            .entry(edge)
                                            .or_default()
                                            .push(m.name.clone());
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Declaration::Adjunction(a) => {
                // Left arm: source -> target
                let left_src_leaves: Vec<_> = collect_base_leaf_types(&a.left.source)
                    .into_iter()
                    .collect();
                let left_tgt_leaves: Vec<_> = collect_base_leaf_types(&a.left.target)
                    .into_iter()
                    .collect();
                add_cross_scope_edges(
                    &left_src_leaves,
                    &left_tgt_leaves,
                    &a.name,
                    &scope_section_index,
                    &scope_name_index,
                    &mut dep_edge_set,
                    &mut dep_edge_labels,
                );

                // Right arm: source -> target
                let right_src_leaves: Vec<_> = collect_base_leaf_types(&a.right.source)
                    .into_iter()
                    .collect();
                let right_tgt_leaves: Vec<_> = collect_base_leaf_types(&a.right.target)
                    .into_iter()
                    .collect();
                add_cross_scope_edges(
                    &right_src_leaves,
                    &right_tgt_leaves,
                    &a.name,
                    &scope_section_index,
                    &scope_name_index,
                    &mut dep_edge_set,
                    &mut dep_edge_labels,
                );
            }
            Declaration::Functor(f) => {
                // Functor maps objects between categories: source_cat → target_cat
                let src = &f.source_cat;
                let tgt = &f.target_cat;
                let src_scopes = resolve_scopes(src, &scope_section_index, &scope_name_index);
                let tgt_scopes = resolve_scopes(tgt, &scope_section_index, &scope_name_index);
                for ss in &src_scopes {
                    for ts in &tgt_scopes {
                        if ss != ts {
                            if let (Some(&si), Some(&ti)) =
                                (scope_name_index.get(*ss), scope_name_index.get(*ts))
                            {
                                let edge = (si, ti);
                                dep_edge_set.insert(edge);
                                dep_edge_labels
                                    .entry(edge)
                                    .or_default()
                                    .push(f.name.clone());
                            }
                        }
                    }
                }
            }
            Declaration::NaturalTransformation(nt) => {
                // NaturalTransformation connects two functors: source_functor → target_functor
                let src = &nt.source_functor;
                let tgt = &nt.target_functor;
                let src_scopes = resolve_scopes(src, &scope_section_index, &scope_name_index);
                let tgt_scopes = resolve_scopes(tgt, &scope_section_index, &scope_name_index);
                for ss in &src_scopes {
                    for ts in &tgt_scopes {
                        if ss != ts {
                            if let (Some(&si), Some(&ti)) =
                                (scope_name_index.get(*ss), scope_name_index.get(*ts))
                            {
                                let edge = (si, ti);
                                dep_edge_set.insert(edge);
                                dep_edge_labels
                                    .entry(edge)
                                    .or_default()
                                    .push(nt.name.clone());
                            }
                        }
                    }
                }
            }
            Declaration::Operad(op) => {
                // Operad sections may reference types from different scopes
                for sec in &op.sections {
                    let leaves = collect_base_leaf_types(&sec.type_sig);
                    for leaf in &leaves {
                        let leaf_scopes =
                            resolve_scopes(leaf, &scope_section_index, &scope_name_index);
                        // Connect operad scope to leaf scope
                        let operad_scope = scope_name_index.get(op.name.as_str());
                        if let Some(os) = operad_scope {
                            for ls in &leaf_scopes {
                                if let Some(&li) = scope_name_index.get(*ls) {
                                    if *os != li {
                                        let edge = (*os, li);
                                        dep_edge_set.insert(edge);
                                        dep_edge_labels
                                            .entry(edge)
                                            .or_default()
                                            .push(op.name.clone());
                                    }
                                }
                            }
                        }
                    }
                }
            }
            _ => {}
        }
    }

    let dep_edges: Vec<(usize, usize)> = dep_edge_set.into_iter().collect();

    // ── Step D: Topological sort ─────────────────────────────────

    let mut resource_escapes = Vec::new();
    let drop_order;

    match topological_sort_scopes(n_scopes, &dep_edges) {
        Ok(order) => {
            // Reverse the topological order for safe deallocation:
            // Dependencies must be dropped BEFORE their owners.
            let max_pos = order.iter().copied().max().unwrap_or(0);
            drop_order = order
                .iter()
                .enumerate()
                .map(|(scope_idx, &pos)| DropDirective {
                    scope_name: scope_complexes[scope_idx].name.clone(),
                    order: max_pos - pos,
                })
                .collect();
        }
        Err(cycle_edges) => {
            // Step E: Detect resource escapes
            for (from, to) in &cycle_edges {
                let from_name = &scope_complexes[*from].name;
                let to_name = &scope_complexes[*to].name;
                let label = dep_edge_labels
                    .get(&(*from, *to))
                    .map(|v| v.join(", "))
                    .unwrap_or_else(|| "unknown".to_string());
                resource_escapes.push(ResourceEscape {
                    from_scope: from_name.clone(),
                    to_scope: to_name.clone(),
                    leaked_type: label.clone(),
                    message: format!(
                        "cross-scope cycle: {} -> {} via '{}' \
                         — resource escape (H^1 hole in scope dependency graph)",
                        from_name, to_name, label
                    ),
                });
            }
            drop_order = Vec::new();
        }
    }

    // ── Step F: Assemble verdict ─────────────────────────────────

    let verdict = if any_non_contractible || !resource_escapes.is_empty() {
        OmegaVerdict::Coal
    } else {
        OmegaVerdict::Diamond
    };

    LifetimeCheckResult {
        scopes: scope_analyses,
        drop_order,
        resource_escapes,
        verdict,
    }
}

/// Helper: add cross-scope directed edges from source leaves to target leaves.
fn add_cross_scope_edges(
    src_leaves: &[String],
    tgt_leaves: &[String],
    label: &str,
    scope_section_index: &HashMap<String, Vec<String>>,
    scope_name_index: &HashMap<String, usize>,
    dep_edge_set: &mut HashSet<(usize, usize)>,
    dep_edge_labels: &mut HashMap<(usize, usize), Vec<String>>,
) {
    for sl in src_leaves {
        let src_scopes = resolve_scopes(sl, scope_section_index, scope_name_index);
        for tl in tgt_leaves {
            let tgt_scopes = resolve_scopes(tl, scope_section_index, scope_name_index);
            for ss in &src_scopes {
                for ts in &tgt_scopes {
                    if ss != ts {
                        if let (Some(&si), Some(&ti)) =
                            (scope_name_index.get(*ss), scope_name_index.get(*ts))
                        {
                            let edge = (si, ti);
                            dep_edge_set.insert(edge);
                            dep_edge_labels
                                .entry(edge)
                                .or_default()
                                .push(label.to_string());
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compiler::lexer::tokenize;
    use crate::compiler::parser::parse;

    /// Helper: lex -> parse -> check lifetimes.
    fn check_source(source: &str) -> LifetimeCheckResult {
        let tokens = tokenize(source);
        let module = parse(&tokens).expect("parse failed");
        let mut symbols = SymbolTable::from_module(&module);
        check_lifetimes(&module, &mut symbols)
    }

    #[test]
    fn test_empty_module_diamond() {
        let module = AtpModule {
            declarations: Vec::new(),
        };
        let mut symbols = SymbolTable::from_module(&module);
        let result = check_lifetimes(&module, &mut symbols);
        assert_eq!(result.verdict, OmegaVerdict::Diamond);
        assert!(result.scopes.is_empty());
        assert!(result.drop_order.is_empty());
        assert!(result.resource_escapes.is_empty());
    }

    #[test]
    fn test_single_manifold_contractible() {
        // Manifold with 2 non-arrow sections: no internal edges → betti_1=0.
        let source = r#"manifold Point : Dim(2) where
  section x : Point
  section y : Point
  proof bounded : ok"#;

        let result = check_source(source);
        assert_eq!(result.verdict, OmegaVerdict::Diamond);
        assert_eq!(result.scopes.len(), 1);
        assert_eq!(result.scopes[0].scope_name, "Point");
        assert!(!result.scopes[0].has_cycle);
        assert!(result.scopes[0].contractible);
    }

    #[test]
    fn test_manifold_internal_cycle() {
        // Three sections forming a cycle via arrow types: A→B, B→C, C→A.
        // All three must be registered as vertices first via non-arrow sections,
        // then the arrow sections create internal edges forming a cycle.
        let source = r#"manifold Ring : Dim(1) where
  section A : Ring
  section B : Ring
  section C : Ring
  section f : A -> B
  section g : B -> C
  section h : C -> A
  proof ok : ok"#;

        let result = check_source(source);
        assert_eq!(
            result.verdict,
            OmegaVerdict::Coal,
            "internal cycle should produce Coal. Scopes: {:?}",
            result.scopes
        );
        assert_eq!(result.scopes.len(), 1);
        assert!(
            result.scopes[0].has_cycle,
            "directed cycle should be detected"
        );
        assert!(!result.scopes[0].contractible);
    }

    #[test]
    fn test_two_independent_scopes_diamond() {
        let source = r#"manifold M1 : Dim(1) where
  section a : M1
  proof p1 : ok

manifold M2 : Dim(1) where
  section b : M2
  proof p2 : ok"#;

        let result = check_source(source);
        assert_eq!(result.verdict, OmegaVerdict::Diamond);
        assert_eq!(result.scopes.len(), 2);
        assert!(result.scopes.iter().all(|s| s.contractible));
        // Both should have drop directives
        assert_eq!(result.drop_order.len(), 2);
    }

    #[test]
    fn test_linear_scope_dependency() {
        // M1 has section `a`, M2 has section `b`.
        // Morphism f: M1 -> M2 creates dependency M1 → M2.
        // Drop order: M2 before M1 (target dropped first = lower order number,
        // since it's a leaf in the reversed dependency).
        // Actually: Kahn's gives zero in-degree nodes first.
        // M1→M2 means M2 has in-degree 1, M1 has in-degree 0.
        // So M1 gets order 0, M2 gets order 1.
        let source = r#"manifold M1 : Dim(1) where
  section a : M1
  proof p1 : ok

manifold M2 : Dim(1) where
  section b : M2
  proof p2 : ok

morphism f : M1 -> M2 where
  f(a) = b
  proof pf : ok"#;

        let result = check_source(source);
        assert_eq!(
            result.verdict,
            OmegaVerdict::Diamond,
            "linear dependency should be Diamond. Escapes: {:?}",
            result.resource_escapes
        );
        assert_eq!(result.drop_order.len(), 2);

        // With reversed drop order, M2 (the dependency target) should be
        // dropped BEFORE M1 (the source/owner).
        let m1_order = result
            .drop_order
            .iter()
            .find(|d| d.scope_name == "M1")
            .unwrap()
            .order;
        let m2_order = result
            .drop_order
            .iter()
            .find(|d| d.scope_name == "M2")
            .unwrap()
            .order;
        assert!(
            m2_order < m1_order,
            "M2 (dependency) should drop before M1 (owner)"
        );
    }

    #[test]
    fn test_cross_scope_cycle_escape() {
        // Two morphisms creating a bidirectional dependency: M1→M2 and M2→M1.
        let source = r#"manifold M1 : Dim(1) where
  section a : M1
  proof p1 : ok

manifold M2 : Dim(1) where
  section b : M2
  proof p2 : ok

morphism f : M1 -> M2 where
  f(a) = b
  proof pf : ok

morphism g : M2 -> M1 where
  g(b) = a
  proof pg : ok"#;

        let result = check_source(source);
        assert_eq!(
            result.verdict,
            OmegaVerdict::Coal,
            "cross-scope cycle should be Coal"
        );
        assert!(
            !result.resource_escapes.is_empty(),
            "should have resource escapes"
        );
        // Drop order should be empty (cycle prevents ordering)
        assert!(
            result.drop_order.is_empty(),
            "cycle should prevent drop ordering"
        );
    }

    #[test]
    fn test_natural_atp_lifetime() {
        // Full natural.atp fixture: should be Diamond.
        // Natural is one scope, Stack is another. The FileIO adjunction
        // creates edges between Path and FileHandle, but neither is a
        // declared scope (no manifold/sheaf for Path or FileHandle),
        // so no cross-scope edges are created.
        let source = r#"manifold Natural : Dim(1) where
  section zero : Natural
  section succ : Natural -> Natural
  proof bounded : forall n, dim(n) = 1

morphism add : Natural * Natural -> Natural where
  add(zero, n) = n
  add(succ(m), n) = succ(add(m, n))
  proof total : forall m n, exists k, add(m, n) = k

sheaf Stack(T) where
  section empty : Stack(T)
  section push : T * Stack(T) -> Stack(T)
  section pop : Stack(T) -> T * Stack(T)
  proof inverse : forall t s, pop(push(t, s)) = (t, s)

adjunction FileIO where
  left open_file : Path -> FileHandle
  right close_file : FileHandle -> Path
  unit : forall p, close_file(open_file(p)) = p
  counit : forall h, open_file(close_file(h)) = h

tensor parallel(a, b) where
  disjoint : a intersect b = empty
  execute : a || b"#;

        let result = check_source(source);
        assert_eq!(
            result.verdict,
            OmegaVerdict::Diamond,
            "natural.atp should be Diamond through lifetime check. \
             Scopes: {:?}, Escapes: {:?}",
            result.scopes,
            result.resource_escapes
        );
        // Should have 2 scopes: Natural, Stack
        assert_eq!(result.scopes.len(), 2);
        assert!(result.resource_escapes.is_empty());
    }

    #[test]
    fn test_no_scopes_morphisms_only() {
        // Morphisms between implicit types (no manifold/sheaf) → 0 scopes.
        let source = r#"morphism f : Foo -> Bar where
  f(x) = x
  proof pf : ok"#;

        let result = check_source(source);
        assert_eq!(result.verdict, OmegaVerdict::Diamond);
        assert!(result.scopes.is_empty());
        assert!(result.drop_order.is_empty());
        assert!(result.resource_escapes.is_empty());
    }
}
