use super::candidates::DeclaredActionCandidate;
use crate::kinds::BaseType;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum OperatorClass {
    E,
    I,
    C,
    R,
    M,
}

use crate::kinds::ContractEffect;

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct DeclaredActionId(pub String);

#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ClassifiedActionId(pub String);

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ClassifiedAction {
    pub id: ClassifiedActionId,
    pub source_action: DeclaredActionId,
    pub class: OperatorClass,
    /// Classification evidence only. This is not an `ActionLicense` and is not
    /// execution authority.
    pub authority_effect: ContractEffect,
    pub classifier_id: String,
    pub evidence_refs: Vec<String>,
}

impl ClassifiedAction {
    pub fn new(
        id: ClassifiedActionId,
        source_action: DeclaredActionId,
        class: OperatorClass,
        authority_effect: ContractEffect,
        classifier_id: String,
        evidence_refs: Vec<String>,
    ) -> Result<Self, ContractEffect> {
        if !matches!(
            authority_effect,
            ContractEffect::EvidenceOnly | ContractEffect::RequestsDecision
        ) {
            return Err(authority_effect);
        }

        Ok(Self {
            id,
            source_action,
            class,
            authority_effect,
            classifier_id,
            evidence_refs,
        })
    }
}

/// Result of classifying an action candidate into the fixed-layer operator taxonomy.
///
/// Classification is not execution, licensing, or engine authority. Helper classifiers
/// should normally emit `EvidenceOnly`; evaluator-owned classifiers may emit
/// `RequestsDecision`.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ClassificationResult {
    pub class: OperatorClass,
    pub reason: String,
    pub authority_effect: ContractEffect,
    pub classifier_id: String,
    pub evidence_refs: Vec<String>,
}

impl ClassificationResult {
    pub fn evidence_only(
        class: OperatorClass,
        reason: String,
        classifier_id: String,
        evidence_refs: Vec<String>,
    ) -> Self {
        Self {
            class,
            reason,
            authority_effect: ContractEffect::EvidenceOnly,
            classifier_id,
            evidence_refs,
        }
    }

    pub fn requests_decision(
        class: OperatorClass,
        reason: String,
        classifier_id: String,
        evidence_refs: Vec<String>,
    ) -> Self {
        Self {
            class,
            reason,
            authority_effect: ContractEffect::RequestsDecision,
            classifier_id,
            evidence_refs,
        }
    }

    pub fn is_non_refusal_class(&self) -> bool {
        self.class != OperatorClass::M
    }

    pub fn is_non_execution_authority(&self) -> bool {
        matches!(
            self.authority_effect,
            ContractEffect::EvidenceOnly | ContractEffect::RequestsDecision
        )
    }
}

pub trait FixedLayerClassifier<S: BaseType, T: BaseType> {
    fn classify<C>(&self, candidate: &C, input: &S) -> ClassificationResult
    where
        C: DeclaredActionCandidate<S, T>;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classification_results_are_evidence_or_decision_not_execution() {
        let classified = ClassifiedAction::new(
            ClassifiedActionId("classified:1".to_string()),
            DeclaredActionId("action:1".to_string()),
            OperatorClass::E,
            ContractEffect::EvidenceOnly,
            "classifier:test".to_string(),
            Vec::new(),
        )
        .expect("evidence-only classification should be allowed");
        assert_eq!(classified.authority_effect, ContractEffect::EvidenceOnly);

        let forbidden = ClassifiedAction::new(
            ClassifiedActionId("classified:2".to_string()),
            DeclaredActionId("action:2".to_string()),
            OperatorClass::E,
            ContractEffect::AuthorizesTransition,
            "classifier:test".to_string(),
            Vec::new(),
        );
        assert_eq!(forbidden, Err(ContractEffect::AuthorizesTransition));

        let evidence = ClassificationResult::evidence_only(
            OperatorClass::E,
            "exact repair evidence".to_string(),
            "classifier:test".to_string(),
            vec!["evidence:1".to_string()],
        );
        assert_eq!(evidence.authority_effect, ContractEffect::EvidenceOnly);
        assert!(evidence.is_non_refusal_class());
        assert!(evidence.is_non_execution_authority());

        let decision = ClassificationResult::requests_decision(
            OperatorClass::M,
            "mutation refused".to_string(),
            "classifier:evaluator".to_string(),
            vec!["evidence:2".to_string()],
        );
        assert_eq!(decision.authority_effect, ContractEffect::RequestsDecision);
        assert!(!decision.is_non_refusal_class());
        assert!(decision.is_non_execution_authority());
    }
}
