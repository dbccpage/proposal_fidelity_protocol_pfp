//! government-law observer: governance changes are change-scoped, not row-scoped.
//!
//! A plain reconciliation row carries no governance change, so [`check`] is silent on it.
//! Governance is examined through [`check_change`] (a proposed change must arrive as a
//! complete licensed lift, per [`crate::governance::check_governance_strict`]) and
//! [`check_role`] (strict role/power separation, per [`crate::governance::role_may`]).
use super::ObserverReading;
use crate::governance::{check_governance_strict, role_may, GovChange, Power, Role};
use crate::row::ReconciliationRow;

/// Deterministic government-law reading for a plain row. Governance is change-scoped, so a
/// row that proposes no change yields no findings here.
pub fn check(_row: &ReconciliationRow) -> ObserverReading {
    // TODO(phase3): link anomalon_councils live role contracts
    ObserverReading {
        observer: "government-law",
        findings: Vec::new(),
    }
}

/// Examine a proposed governance change under the strict regime, wrapping the findings from
/// [`crate::governance::check_governance_strict`] as an observer reading.
pub fn check_change(change: &GovChange) -> ObserverReading {
    ObserverReading {
        observer: "government-law",
        findings: check_governance_strict(change),
    }
}

/// Whether a role may hold a power, delegating to the pinned strict role/power separation.
pub fn check_role(role: Role, power: Power) -> bool {
    role_may(role, power)
}
