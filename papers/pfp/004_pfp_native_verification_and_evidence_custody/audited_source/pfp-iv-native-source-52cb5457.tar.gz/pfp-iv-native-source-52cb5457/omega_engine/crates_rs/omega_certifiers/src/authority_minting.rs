//! Deprecated compatibility module.
//!
//! The old module name is retained so downstream imports keep compiling, but
//! every exported operation now seals evidence only. No item in this module
//! constructs authority.

#[deprecated(note = "use omega_certifiers::certificate_boundary")]
pub use crate::certificate_boundary::{certify_checked_packet, AuthorityVerdict};
