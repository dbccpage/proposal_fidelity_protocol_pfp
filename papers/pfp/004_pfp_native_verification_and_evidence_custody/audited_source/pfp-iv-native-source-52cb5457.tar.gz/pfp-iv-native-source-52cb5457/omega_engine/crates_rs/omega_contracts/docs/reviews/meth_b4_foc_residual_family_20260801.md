# Meth B4 — FOC residual mass family YAML pass

**Date:** 2026-08-01  
**Branch:** `feat/oe-math-b4-foc-residual-meth`  
**AuthorityEffect:** `None`  
**Ladder step:** 1 — Perfect math YAML (not RS/Py align, not LEAN4)

## Family definition

**B4 = FOC residual / obstruction mass core** (estate residual geometry scalars and classifiers).

Isolated from B1 LA storage, B2 homology, B3 legacy shells.

| Stem | Headline meth decision |
| --- | --- |
| `phi1` | Φ₁ = inf ‖ω−d₀α‖_{1,w}; ≠ Γ₂; no authority |
| `phi1_obstruction_mass` | Packaged mass scalar + evidence; distinct packaging |
| `gamma2_closure_defect` | Γ₂ = ‖d₁h‖₁; secondary after Φ₁ |
| `quotient_mass` | Q¹ mass metric packaging; default = Φ₁ |
| `closure_defect` | General closure defect; FOC d₁ instance is Γ₂ |
| `closure_regime` | Evaluation regime declaration (exact vs diagnostic) |
| `exact_repair` | α ∈ C⁰ repair object; exact class ⇔ Φ₁=0 |
| `finite_obstruction_trichotomy` | ExactRepair / StabilizedSurvivor / OpenObstruction |

## Standing FOC laws restated in YAML

1. Φ₁ and Γ₂ are **never identified**.  
2. Φ₁ is primary; Γ₂ secondary after Φ₁ selection.  
3. No AuthorityEffect / ActionLicense / GlobalGreen from residual scalars alone.  
4. Floating heuristics cannot emit exact trichotomy constructors.

## Residuals OPEN

| ID | Residual | Hand-off |
| --- | --- | --- |
| B4-R1 | Trichotomy RS enum rename (ClosedResidual / ActiveClosureFailure) | Stage-2 name align |
| B4-R2 | closure_defect display/DTO thin vs full functional | Stage-2 |
| B4-R3 | Possible near-duplicate quotient_mass ↔ phi1_obstruction_mass | future ≃ witness only |
| B4-R4 | LEAN4 | golden step — not this pass |

## Nonclaims

- Not PROVED / not GlobalGreen / not HoTT / not LEAN4  
- Not Stage-2 code-follows-YAML complete  

**AuthorityEffect: `None`.**
