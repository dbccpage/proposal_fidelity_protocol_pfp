"""Deeper Stage-1 (YAML-aware) on HAS_RS math contracts only.

Goes beyond mechanical regex: parse canonical section, GTLA/anti-theater
gates from math_contract_review_checklist, URN hygiene, overclaim heuristics.
Injects new potential_defects only when code not already present in debate.
AuthorityEffect None. Not PROVED. Not GlobalGreen.
"""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parents[5]
MATH = REPO / "omega_engine/crates/omega_contracts/src/contract_canonical_definitions/math"
STEMS = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_has_rs_stems.txt"
RECEIPT = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_stage1_has_rs_deep_receipt.md"
APPLY = True  # set False for dry-run


def split_debate(text: str) -> tuple[str, str]:
    key = "nomos_debate_NOT_CANONICAL:"
    if key not in text:
        empty = (
            "nomos_debate_NOT_CANONICAL:\n"
            '  banner: "NON-CANONICAL DEBATE ONLY — not contract law; not enforced; AuthorityEffect None"\n'
            "  not_part_of_contract_law: true\n"
            "  authority_effect: none\n"
            "  potential_defects: []\n"
            "  realization_delta_vs_implemented_math_file: []\n"
        )
        return text.rstrip() + "\n", empty
    i = text.index(key)
    return text[:i].rstrip() + "\n", text[i:]


def deep_findings(canon_text: str) -> list[tuple[str, str, str]]:
    findings: list[tuple[str, str, str]] = []
    try:
        data = yaml.safe_load(canon_text)
    except Exception as e:  # noqa: BLE001 — report parse as finding
        return [("PARSE_FAIL", "critical", f"canonical section unparseable: {e}")]
    if not isinstance(data, dict):
        return [("PARSE_FAIL", "critical", "canonical root not mapping")]

    sv = data.get("schema_version")
    if sv != "omega.contract.v1":
        findings.append(
            (
                "LEGACY_OR_MISSING_SCHEMA",
                "high",
                f"schema_version={sv!r}; expected omega.contract.v1",
            )
        )
    cid = str(data.get("contract_id") or "")
    if not cid.startswith("urn:omega:math:"):
        findings.append(
            ("C4_URN_DRIFT", "high", f"contract_id={cid!r}; want urn:omega:math:*")
        )
    if "urn:math:contract:" in cid:
        findings.append(("C4_URN_DRIFT", "high", "legacy urn:math:contract:* form"))

    desc = data.get("descriptor") if isinstance(data.get("descriptor"), dict) else {}
    ae = desc.get("authority_effect")
    if ae is None:
        if "authority_level" in data and "authority_effect" not in data:
            findings.append(
                (
                    "G_AUTHORITY_NONE",
                    "high",
                    f"legacy authority_level={data.get('authority_level')!r}; "
                    "no descriptor.authority_effect: none",
                )
            )
        elif str(data.get("authority_effect", "")).lower() != "none":
            top = data.get("authority_effect")
            if top is None or str(top).lower() != "none":
                findings.append(
                    (
                        "G_AUTHORITY_NONE",
                        "high",
                        f"missing/non-none authority_effect (descriptor={ae!r}, top={top!r})",
                    )
                )
    elif str(ae).lower() != "none":
        findings.append(
            (
                "G_AUTHORITY_NONE",
                "critical",
                f"descriptor.authority_effect={ae!r} not none",
            )
        )

    cca = desc.get("customer_claim_allowed", data.get("customer_claim_allowed"))
    if cca is True:
        findings.append(
            ("G_CUSTOMER_FALSE", "critical", "customer_claim_allowed is true")
        )
    elif cca is None and "customer_claim_allowed" not in desc and "customer_claim_allowed" not in data:
        findings.append(("G_CUSTOMER_FALSE", "medium", "customer_claim_allowed missing"))
    elif cca is not False and cca is not None:
        findings.append(
            ("G_CUSTOMER_FALSE", "medium", f"customer_claim_allowed={cca!r} not false")
        )

    math = data.get("math")
    if not isinstance(math, dict):
        findings.append(
            (
                "G_MATH_BLOCK",
                "high",
                "missing math: mapping (object_kind/domain/codomain expected)",
            )
        )
        math = {}
    else:
        if not math.get("object_kind"):
            findings.append(("MATH_OBJECT_KIND", "medium", "math.object_kind missing"))
        if "domain" not in math and "codomain" not in math:
            findings.append(
                (
                    "MATH_DOMAIN_CODOMAIN",
                    "low",
                    "math.domain and math.codomain both absent",
                )
            )

    req = data.get("requirements")
    laws = data.get("laws")
    has_laws = False
    if isinstance(laws, list) and laws:
        has_laws = True
    if isinstance(laws, dict) and laws:
        has_laws = True
    if isinstance(req, dict) and req.get("required_structures"):
        has_laws = True
    if isinstance(req, list) and req:
        has_laws = True
    if math.get("laws") or math.get("required_structures"):
        has_laws = True
    if not has_laws:
        findings.append(
            ("G_LAWS_OR_REQUIREMENTS", "high", "no non-empty laws or required_structures")
        )

    rs = None
    if isinstance(req, dict):
        rs = req.get("required_structures")
    if not rs:
        rs = math.get("required_structures")
    if not rs:
        findings.append(
            ("G_REQUIRED_STRUCTURES", "medium", "required_structures missing or empty")
        )

    nt = data.get("negative_tests")
    if nt is None and isinstance(req, dict):
        nt = req.get("negative_tests")
    if not nt:
        findings.append(
            ("G_NEGATIVE_TESTS", "medium", "negative_tests missing or empty")
        )

    doctrine = data.get("doctrine") if isinstance(data.get("doctrine"), dict) else {}
    if not doctrine.get("summary") and not doctrine.get("purpose"):
        findings.append(("DOCTRINE_SUMMARY", "low", "doctrine.summary missing"))
    nr = doctrine.get("non_role")
    if nr is None:
        findings.append(("G_NON_ROLE", "medium", "doctrine.non_role missing"))
    elif isinstance(nr, list) and len(nr) == 0:
        findings.append(
            ("DEV-THEATER", "high", "doctrine.non_role is empty list (theater risk)")
        )
    elif isinstance(nr, str) and not nr.strip():
        findings.append(
            ("DEV-THEATER", "high", "doctrine.non_role empty string")
        )

    if re.search(r"\bGlobalGreen\b|\bPROVED\b", canon_text) and not re.search(
        r"not\s+PROVED|not\s+GlobalGreen|does not claim", canon_text, re.I
    ):
        findings.append(
            (
                "MATH-OVERCLAIM",
                "high",
                "PROVED/GlobalGreen language without nearby nonclaim",
            )
        )
    if re.search(r"\bHoTT\b|\bUnivalence\b", canon_text) and not re.search(
        r"not\s+HoTT|does not (claim|mint)|nonclaim", canon_text, re.I
    ):
        findings.append(
            (
                "MATH-OVERCLAIM",
                "medium",
                "HoTT/Univalence present without nonclaim fence",
            )
        )

    st = str(data.get("status") or "")
    structural = {
        c
        for c, _, _ in findings
        if c
        in (
            "G_MATH_BLOCK",
            "LEGACY_OR_MISSING_SCHEMA",
            "C4_URN_DRIFT",
            "PARSE_FAIL",
        )
    }
    if st == "active" and structural:
        findings.append(
            (
                "STATUS_VS_CONTENT",
                "low",
                f"status={st!r} while structural residuals remain",
            )
        )

    # Deduplicate by code (keep first/highest severity order as produced)
    seen: set[str] = set()
    out: list[tuple[str, str, str]] = []
    for code, sev, det in findings:
        if code in seen:
            continue
        seen.add(code)
        out.append((code, sev, det))
    return out


def defect_item(code: str, detail: str, severity: str = "medium") -> str:
    # Escape quotes in detail for YAML double-quoted string
    safe = detail.replace("\\", "\\\\").replace('"', '\\"')
    return (
        "  - reviewer: panepistimion-math-prof\n"
        "    role: MATH_CANONICAL_REVIEW\n"
        f"    code: {code}\n"
        f"    severity: {severity}\n"
        '    claim_class: "[STANDARD]"\n'
        f'    detail: "DEEP Stage-1: {safe}"\n'
        '    recommendation: "Repair under meth-level math re-review (ADR-007/007a); not GlobalGreen."\n'
        "    pass: stage1_deep_has_rs\n"
    )


def existing_codes(debate: str) -> set[str]:
    return set(re.findall(r"(?m)^\s+code:\s*(\S+)\s*$", debate))


def inject_defects(debate: str, items: list[str]) -> str:
    if not items:
        return debate
    block = "".join(items)
    if "potential_defects: []" in debate:
        return debate.replace(
            "potential_defects: []", "potential_defects:\n" + block.rstrip("\n"), 1
        )
    # Insert after potential_defects: line — append at end of that list by
    # placing before realization_delta or end.
    marker = "  realization_delta_vs_implemented_math_file:"
    if marker in debate:
        i = debate.index(marker)
        return debate[:i] + block + debate[i:]
    if "potential_defects:" in debate:
        # append after key
        return debate.rstrip() + "\n" + block
    return debate.rstrip() + "\n  potential_defects:\n" + block


def main() -> None:
    stems = [s.strip() for s in STEMS.read_text(encoding="utf-8").splitlines() if s.strip()]
    code_c: Counter[str] = Counter()
    residual_rows: list[tuple[str, list[tuple[str, str, str]]]] = []
    pass_n = 0
    injected_n = 0

    for stem in stems:
        p = MATH / stem
        if not p.is_file():
            residual_rows.append((stem, [("MISSING_FILE", "critical", "stem path not found")]))
            continue
        text = p.read_text(encoding="utf-8")
        canon, debate = split_debate(text)
        findings = deep_findings(canon)
        for code, _, _ in findings:
            code_c[code] += 1
        if not findings:
            pass_n += 1
            residual_rows.append((stem, []))
            continue
        residual_rows.append((stem, findings))
        if not APPLY:
            continue
        have = existing_codes(debate)
        new_items = [
            defect_item(code, det, sev)
            for code, sev, det in findings
            if code not in have
        ]
        if not new_items:
            continue
        new_debate = inject_defects(debate, new_items)
        p.write_text(canon.rstrip() + "\n" + new_debate, encoding="utf-8")
        injected_n += 1

    residual_n = sum(1 for _, f in residual_rows if f)
    lines = [
        "# Stage-1 DEEP (HAS_RS only)",
        "",
        "**AuthorityEffect:** None",
        f"**Stems:** {len(stems)} from `rip_math_has_rs_stems.txt`",
        f"**Pass:** stage1_deep_has_rs (YAML-aware GTLA / anti-theater / URN / overclaim)",
        f"**Apply:** {APPLY}",
        "",
        "| Metric | Count |",
        "| --- | ---: |",
        f"| deep PASS (no residual) | {pass_n} |",
        f"| residual stems | {residual_n} |",
        f"| stems with new debate injects | {injected_n} |",
        "",
        "## Defect code histogram (deep)",
        "",
        "| Code | Count |",
        "| --- | ---: |",
    ]
    for code, n in code_c.most_common():
        lines.append(f"| `{code}` | {n} |")
    lines += [
        "",
        "## Residual stems",
        "",
        "| Stem | Codes |",
        "| --- | --- |",
    ]
    for stem, findings in residual_rows:
        if not findings:
            continue
        codes = ", ".join(f"`{c}`" for c, _, _ in findings)
        lines.append(f"| `{stem}` | {codes} |")
    lines += [
        "",
        "## Scope fence",
        "",
        "- Stage-1 deep only on HAS_RS set (not full 496 math corpus).",
        "- Does not edit canonical law fields; debate inject only.",
        "- Does not mint PROVED / GlobalGreen / AuthorityEffect.",
        "- Mechanical Stage-1 residual set is subset-related; deep reduces false",
        "  negatives on quoted `authority_effect: \"none\"` etc.",
        "",
        "**AuthorityEffect: None.**",
        "",
    ]
    RECEIPT.write_text("\n".join(lines), encoding="utf-8")
    print(
        f"stems={len(stems)} deep_pass={pass_n} residual={residual_n} injected={injected_n}"
    )
    print("codes", dict(code_c.most_common()))


if __name__ == "__main__":
    main()
