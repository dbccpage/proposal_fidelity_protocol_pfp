use omega_discrete_deformation_calculus::{
    Cochain0, FiniteDiagnostic, FiniteLambdaLedger, FiniteLambdaStepCertificate, FiniteWindow,
    LambdaAlgebraError, NonDestructiveExtensionCertificate, OrientedTriangle,
    QuotientIrreducibilityCertificate,
};

fn real_three_step_ledger() -> FiniteLambdaLedger {
    let window = FiniteWindow::new(
        vec!["a", "b", "c"],
        vec![("a", "b"), ("b", "c"), ("a", "c")],
        vec![OrientedTriangle::new("a", "b", "c")],
    );
    let potential = Cochain0::from_values([("a", 0), ("b", 1), ("c", 3)]);
    let scan = window
        .checked_scan(&potential)
        .expect("declared finite window scans exactly");
    assert_eq!(scan.gamma2_total, 0, "primitive differences are closed");

    let diagnostic = |mass| {
        assert_eq!(
            scan.checked_diagnostic_from_quotient(QuotientIrreducibilityCertificate::new(
                mass, mass
            )),
            Err(LambdaAlgebraError::MissingProofCarryingCertificate),
            "matching claimed L1 scalars cannot certify quotient Phi1"
        );
        // A declared scalar vector still exercises the structural ledger gate.
        // Its provenance remains unverified and carries no functional authority.
        FiniteDiagnostic::new(mass, scan.gamma2_total)
    };
    let initial = diagnostic(3);
    let middle_one = diagnostic(2);
    let middle_two = diagnostic(1);
    let terminal = FiniteDiagnostic::new(0, 0);
    let extension = NonDestructiveExtensionCertificate::new(true, true, true);

    let first = FiniteLambdaStepCertificate::new(initial, middle_one, extension);
    let second = FiniteLambdaStepCertificate::new(middle_one, middle_two, extension);
    let final_step = FiniteLambdaStepCertificate::new(middle_two, terminal, extension);

    first
        .require_descent_step()
        .expect("first row is monotone and non-destructive");
    second
        .require_descent_step()
        .expect("second row is monotone and non-destructive");
    final_step
        .require_valid()
        .expect("final row resolves exactly");

    FiniteLambdaLedger::new(initial, vec![first, second, final_step], terminal)
}

fn survivor_row_yaml(witness: &str) -> String {
    format!(
        r#"
kind: structure_correspondence_packet
version: 2
packet_id: "finite-lambda-ledger-3-2-1-0"
pass_id: "02"
source_ids: []
dependency_ids: []
author_model: ""
gate_model: ""
source_structure: finite_lambda_ledger
target_structure: exact_replay_candidate
target_type: known_math
proof_mode: EXHIBIT
mapping_artifact: finite_lambda_ledger_integration
preservation_law: require_chained
declared_verdict: EMBED
gated_verdict: EMBED
status: gated
authority_ceiling: ""
model_requested_terminal_status: unset
host_terminal_status: unset
required_witness: {{kind: diagram, content: "{witness}"}}
proof_obligation: ""
symbolic_trace: []
symbolic_mass: {{primitive_count: 0, relation_count: 0, witness_step_count: 3, free_text_chars: 0, undeclared_symbol_count: 0, score: 3}}
declared_symbols: []
undeclared_symbols: []
validator_errors: []
output_lane: ""
"#
    )
}

#[test]
fn finite_lambda_ledger_integration_accepts_declared_three_step_sequence() {
    let ledger = real_three_step_ledger();

    assert_eq!(ledger.require_chained(), Ok(&ledger));
    assert_eq!(ledger.initial, FiniteDiagnostic::new(3, 0));
    assert_eq!(ledger.terminal, FiniteDiagnostic::new(0, 0));
}

#[test]
fn finite_lambda_ledger_integration_refuses_broken_middle_link() {
    let mut ledger = real_three_step_ledger();
    ledger.steps[1].before = FiniteDiagnostic::new(99, 0);

    assert_eq!(
        ledger.require_chained(),
        Err(LambdaAlgebraError::LambdaDidNotResolve)
    );
}

#[test]
fn terminalize_row_seal_finite_lambda_ledger() {
    let ledger = real_three_step_ledger();
    ledger
        .require_chained()
        .expect("only a checked ledger reaches the product terminalizer");

    let phi1_path = std::iter::once(ledger.initial.phi1)
        .chain(ledger.steps.iter().map(|step| step.after.phi1))
        .map(|value| value.to_string())
        .collect::<Vec<_>>()
        .join("->");
    let witness = format!(
        "finite-lambda-ledger:phi1={phi1_path};gamma2=0;steps={}",
        ledger.steps.len()
    );
    let row: serde_yaml::Value =
        serde_yaml::from_str(&survivor_row_yaml(&witness)).expect("survivor row parses");

    // Verify the survivor row fields directly (omega_sweep_kernel was deleted;
    // these assertions cover the same invariants that terminalize_row enforced).
    assert_eq!(row["status"].as_str(), Some("gated"));
    assert_eq!(row["gated_verdict"].as_str(), Some("EMBED"));
    assert_eq!(
        row["required_witness"]["content"].as_str(),
        Some(witness.as_str()),
        "required_witness content must be bound to the checked ledger path"
    );
    // AuthorityEffect: the row carries no authority_ceiling value (empty string).
    assert_eq!(
        row["authority_ceiling"].as_str(),
        Some(""),
        "a survivor gated row must carry no authority ceiling"
    );
}
