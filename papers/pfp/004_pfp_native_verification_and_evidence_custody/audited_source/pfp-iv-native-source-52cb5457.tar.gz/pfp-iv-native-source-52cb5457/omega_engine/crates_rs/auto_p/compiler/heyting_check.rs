//! STUB — `heyting_check` (intuitionistic / Heyting compliance pass: detects
//! classical-logic violations such as LEM and DNE in proof blocks). The `.rs`
//! file was never extracted into the AutoP tree, yet `boundary_check` calls
//! `check_heyting_compliance`. This minimal stub returns no violations so the
//! tree builds. It is NOT the real checker — any classical-logic violation goes
//! undetected here, so tests asserting a Heyting tear fail honestly.

use super::parser::AtpModule;

#[derive(Debug, Clone)]
pub struct HeytingViolation {
    pub span: std::ops::Range<usize>,
    pub declaration: String,
    pub proof_name: String,
    pub violation: String,
}

/// STUB: real classical-logic-violation (LEM/DNE/…) detection removed.
pub fn check_heyting_compliance(_module: &AtpModule) -> Vec<HeytingViolation> {
    Vec::new()
}
