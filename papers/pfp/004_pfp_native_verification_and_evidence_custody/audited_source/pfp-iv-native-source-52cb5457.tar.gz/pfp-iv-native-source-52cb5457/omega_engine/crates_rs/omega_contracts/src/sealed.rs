pub use omega_contract_core::sealed::*;
