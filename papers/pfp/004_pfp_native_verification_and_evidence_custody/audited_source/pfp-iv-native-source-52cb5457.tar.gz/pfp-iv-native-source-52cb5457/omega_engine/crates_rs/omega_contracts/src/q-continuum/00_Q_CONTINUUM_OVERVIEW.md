Q-Continuum Overview
====================

1. Purpose
----------

The Q-continuum layer is a disciplined intake and probing surface for ideas that are not yet finite, formal, executable, or fully scoped. It accepts speculative ideas, analogies, models, paper fragments, authority candidates, and high-level claims, then turns them into finite probes and descent obligations.

It exists to keep unresolved structure visible instead of pretending that vague ideas are already proven.

2. Non-Purpose
--------------

The Q-continuum layer does not prove mathematics, derive physics, certify authority, solve quantum mechanics, solve general relativity, solve general intelligence, or close every obstruction. It does not replace finite descent, tests, proofs, receipts, or adversarial review.

3. Core Principle
-----------------

The Q-continuum may propose, probe, generalize, and preserve residual structure. The finite system must verify, obstruct, witness, terminalize, or refuse.

No Q-continuum object is terminally true merely by existing in the Q layer. Only finite descent can produce terminal support, terminal refusal, or terminal refutation.

4. Relationship To Primitive Difference
---------------------------------------

Primitive Difference is the lower-level discipline for distinguishing objects through finite differences, zero relations, quotients, invariants, and residuals. The Q-continuum layer does not replace that discipline. It prepares high-level material so that a finite Primitive Difference style question can eventually be asked:

* What is the finite carrier?
* What is the zero relation?
* What factors through the quotient?
* What obstruction remains when factorization fails?

5. Relationship To Finite Descent
---------------------------------

Finite descent is the gatekeeper. A Q idea can request finite probes, but support is earned only when a finite obligation receives a witness, a bounded refusal, a refutation, or a typed residual.

The first implementation provides `DescentGate` as a boundary object. It projects ideas and claims into `FiniteProjection` values and emits `DescentObligation` values. It does not fake a full finite descent engine.

6. Relationship To Obstruction Ledgers
--------------------------------------

The Q layer treats failed descent as data. A failed probe becomes a residual or obstruction ledger entry, not an erased attempt. Repeated obstruction must remain visible because recurrence is evidence about the weakness or incompleteness of the idea.

7. Relationship To Authority
----------------------------

Authority means bounded reliability, not prestige. It is accumulated from provenance, finite descents, witnesses, failed attempts, residuals, counterexamples, replay paths, and scope limits.

Authority can increase only after finite descent evidence is recorded. It can be weakened or revoked by counterexamples, replay failures, missing witnesses, or scope violations.

8. Relationship To Speculation
------------------------------

Speculation is allowed, but it must be labeled. A speculative idea is useful when it generates finite probes. It becomes dangerous when it is laundered into authority without witnesses.

The default status for a `QIdea` or `QClaim` is `Speculative`.

9. What This Layer May Claim
----------------------------

This layer may claim:

* it records Q-layer ideas and claims,
* it generates first-pass finite probes,
* it creates finite projections and descent obligations,
* it records witnesses, residuals, and counterexamples,
* it updates scoped authority traces from finite descent results,
* it keeps unsupported claims unsupported.

10. What This Layer Must Never Claim
------------------------------------

This layer must never claim:

* a Q idea is true because it was entered,
* a speculative analogy has theorem authority,
* a physics analogy is a physics result,
* a source has authority because it is prestigious,
* a claim is terminally supported without an in-scope witness,
* a finite example proves an unrestricted general theorem,
* a passing test proves mathematical truth outside its stated scope.
