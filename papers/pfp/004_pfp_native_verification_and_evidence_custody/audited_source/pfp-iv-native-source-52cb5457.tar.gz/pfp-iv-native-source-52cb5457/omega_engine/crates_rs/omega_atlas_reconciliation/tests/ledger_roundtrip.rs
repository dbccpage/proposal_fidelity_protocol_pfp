//! NDJSON ledger round-trip: write then read returns the same rows.
use omega_atlas_reconciliation::ledger::{read_ndjson, write_ndjson};
use omega_atlas_reconciliation::row::ReconciliationRow;

#[test]
fn ndjson_roundtrip_preserves_row() {
    let rows = vec![ReconciliationRow::sample_good()];
    let s = write_ndjson(&rows).unwrap();
    let back = read_ndjson(&s).unwrap();
    assert_eq!(back.len(), 1);
    assert_eq!(back[0].asset_id, rows[0].asset_id);
}
