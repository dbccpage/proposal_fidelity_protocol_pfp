use omega_atlas_reconciliation::row::*;
use omega_atlas_reconciliation::validator::validate_row;
#[test]
fn prose_mechanized_not_machine_checked() {
    let mut r = ReconciliationRow::sample_good();
    r.proof_status.status = "MECHANIZED".into();
    r.proof_status.lean_status = "NOT-STARTED".into();
    r.claimed = "machine-checked theorem".into();
    assert!(validate_row(&r).iter().any(|x| x.contains("two-axis")));
}
