//! Atlas Reconciliation Loop — deterministic Rust engine.
//! Diagnostic-only: reconciles code <-> product-claim <-> paper <-> proof <-> contract <-> doctrine.
//! Every row is a finite PrimitiveDifference judgment preserving three OmegaCore invariants.
pub mod cochain_validity;
pub mod congruence_core;
pub mod governance;
pub mod identity_witness;
pub mod ledger;
pub mod observers;
pub mod primitive_difference;
pub mod reconciler;
pub mod render;
pub mod row;
pub mod runner;
pub mod slice;
pub mod terminalize;
pub mod validator;
