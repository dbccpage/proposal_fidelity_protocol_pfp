//! The audit against a small, fully known repository.
//!
//! Each test names the case it pins, so a regression shows up as a named
//! failure rather than a changed count.

use omega_contract_bindings::audit::{
    audit, defines_symbol, warning_lines, AuditReport, BindingOutcome, BindingTarget, Resolution,
    Unresolved,
};
use std::path::{Path, PathBuf};

struct Fixture {
    root: PathBuf,
}

impl Fixture {
    fn new(name: &str) -> Self {
        let root = std::env::temp_dir().join(format!(
            "omega_contract_bindings_{}_{name}",
            std::process::id()
        ));
        let _ = std::fs::remove_dir_all(&root);
        let fixture = Fixture { root };
        fixture.write(
            "omega_engine/crates_rs/Cargo.toml",
            "[workspace]\nresolver = \"2\"\nmembers = [\n    \"alpha\",\n]\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/Cargo.toml",
            "[package]\nname = \"alpha\"\nversion = \"0.1.0\"\n\n\
             [[test]]\nname = \"extra\"\npath = \"checks/extra.rs\"\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/checks/extra.rs",
            "#[test]\nfn e() {}\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/src/lib.rs",
            "pub mod geometry;\n\
             #[cfg(test)]\n\
             mod tests;\n\
             #[path = \"odd/place.rs\"]\n\
             pub mod relocated;\n\
             pub use geometry::point::Point;\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/src/geometry/mod.rs",
            "pub(crate) mod point;\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/src/geometry/point.rs",
            "pub struct Point;\npub struct PointError;\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/src/odd/place.rs",
            "pub fn relocated() {}\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/src/orphan.rs",
            "pub struct Orphan;\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/src/tests.rs",
            "#[test]\nfn t() {}\n",
        );
        fixture.write(
            "omega_engine/crates_rs/alpha/tests/integration.rs",
            "#[test]\nfn i() {}\n",
        );
        fixture
    }

    fn write(&self, rel: &str, text: &str) {
        let path = self.root.join(rel);
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(path, text).unwrap();
    }

    fn contract(&self, name: &str, text: &str) {
        self.write(
            &format!(
                "omega_engine_governance/contracts/contracts_omega_engine_crates/{name}.contract.yaml"
            ),
            text,
        );
    }

    fn binding(&self, name: &str, krate: &str, module: &str, symbols: &[&str]) {
        // An empty `symbols:` key is YAML null, which the typed RustBinding
        // loader rejects, so an empty list is written by omitting the key.
        let symbols: String = if symbols.is_empty() {
            String::new()
        } else {
            let items: String = symbols.iter().map(|s| format!("  - {s}\n")).collect();
            format!("  symbols:\n{items}")
        };
        self.contract(
            name,
            &format!(
                "contract_id: urn:test:{name}\nrust_binding:\n  crate: {krate}\n  module: {module}\n{symbols}"
            ),
        );
    }

    fn run(&self) -> AuditReport {
        audit(&self.root).expect("fixture workspace is well formed")
    }
}

impl Drop for Fixture {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.root);
    }
}

fn outcome<'a>(report: &'a AuditReport, contract_id: &str) -> &'a BindingOutcome {
    report
        .outcomes
        .iter()
        .find(|o| o.binding.contract_id == contract_id)
        .unwrap_or_else(|| panic!("no outcome for {contract_id}: {report:#?}"))
}

fn alpha(path: &str) -> String {
    format!("omega_engine/crates_rs/alpha/{path}")
}

#[test]
fn a_nested_module_resolves_to_its_compiled_file() {
    let f = Fixture::new("nested");
    f.binding("good", "alpha", "geometry::point", &["Point", "PointError"]);
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:good").resolution,
        Resolution::Resolved {
            file: alpha("src/geometry/point.rs"),
            compiled: Some(true)
        }
    );
}

#[test]
fn only_the_symbols_the_file_lacks_are_reported() {
    let f = Fixture::new("symbols");
    f.binding("partial", "alpha", "geometry::point", &["Point", "Line"]);
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:partial").resolution,
        Resolution::Unresolved(Unresolved::MissingSymbols {
            file: alpha("src/geometry/point.rs"),
            symbols: vec!["Line".into()],
        })
    );
}

#[test]
fn a_crate_that_is_not_a_directory_under_crates_rs_is_unknown() {
    let f = Fixture::new("crate");
    f.binding("elsewhere", "omega_alpha", "geometry", &[]);
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:elsewhere").resolution,
        Resolution::Unresolved(Unresolved::UnknownCrate {
            krate: "omega_alpha".into()
        })
    );
}

#[test]
fn a_module_with_no_file_under_src_is_missing() {
    let f = Fixture::new("module");
    f.binding("renamed", "alpha", "geometry::line", &[]);
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:renamed").resolution,
        Resolution::Unresolved(Unresolved::ModuleFileMissing {
            krate: "alpha".into(),
            module: "geometry::line".into()
        })
    );
}

#[test]
fn a_file_no_mod_declaration_reaches_resolves_but_is_not_compiled() {
    let f = Fixture::new("orphan");
    f.binding("orphan", "alpha", "orphan", &["Orphan"]);
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:orphan").resolution,
        Resolution::Resolved {
            file: alpha("src/orphan.rs"),
            compiled: Some(false)
        }
    );
    assert_eq!(report.not_compiled().count(), 1);
}

#[test]
fn a_path_attribute_is_followed_and_a_file_contract_binds_the_file() {
    let f = Fixture::new("path_attr");
    f.contract(
        "place",
        "contract_id: urn:test:place\nkind: rust_file_contract\nfile: crates_rs/alpha/src/odd/place.rs\n",
    );
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:place").resolution,
        Resolution::Resolved {
            file: alpha("src/odd/place.rs"),
            compiled: Some(true)
        }
    );
}

#[test]
fn a_file_contract_for_a_missing_file_is_unresolved() {
    let f = Fixture::new("file_missing");
    f.contract(
        "gone",
        "contract_id: urn:test:gone\nkind: rust_file_contract\nfile: crates_rs/alpha/src/gone.rs\n",
    );
    let report = f.run();
    assert!(matches!(
        outcome(&report, "urn:test:gone").resolution,
        Resolution::Unresolved(Unresolved::FileMissing { .. })
    ));
}

#[test]
fn file_contract_crate_metadata_disagrees_with_its_file_and_module() {
    let f = Fixture::new("file_metadata");
    f.contract(
        "good",
        "contract_id: urn:test:good\nkind: rust_file_contract\ncrate: alpha\nfile: crates_rs/alpha/src/geometry/point.rs\nmodule_path: alpha::geometry::point\n",
    );
    f.contract(
        "old_module",
        "contract_id: urn:test:old_module\nkind: rust_file_contract\ncrate: alpha\nfile: crates_rs/alpha/src/geometry/point.rs\nmodule_path: old_alpha::geometry::point\n",
    );
    f.contract(
        "old_file",
        "contract_id: urn:test:old_file\nkind: rust_file_contract\ncrate: alpha\nfile: crates_rs/old_alpha/src/geometry/point.rs\nmodule_path: alpha::geometry::point\n",
    );
    let report = f.run();
    assert_eq!(report.malformed.len(), 2, "{:#?}", report.malformed);
    assert!(report.malformed.iter().any(|m| m.contains("old_module") && m.contains("module_path")));
    assert!(report.malformed.iter().any(|m| m.contains("old_file") && m.contains("file")));
    assert!(warning_lines(&report, "fixture").iter().any(|m| m.contains("CONTRACT_BINDING_MALFORMED") && m.contains("old_module")));
    assert_eq!(
        outcome(&report, "urn:test:good").resolution,
        Resolution::Resolved {
            file: alpha("src/geometry/point.rs"),
            compiled: Some(true)
        }
    );
}

#[test]
fn an_integration_test_file_has_no_compiled_status() {
    let f = Fixture::new("integration");
    f.contract(
        "it",
        "contract_id: urn:test:it\nkind: rust_file_contract\nfile: crates_rs/alpha/tests/integration.rs\n",
    );
    let report = f.run();
    assert_eq!(
        outcome(&report, "urn:test:it").resolution,
        Resolution::Resolved {
            file: alpha("tests/integration.rs"),
            compiled: None
        }
    );
}

#[test]
fn coverage_counts_compiled_files_and_excludes_test_modules() {
    let f = Fixture::new("coverage");
    f.binding("good", "alpha", "geometry::point", &["Point"]);
    f.binding("orphan", "alpha", "orphan", &["Orphan"]);
    let report = f.run();
    let alpha_coverage = &report.coverage[0];
    assert_eq!(alpha_coverage.krate, "alpha");
    // lib.rs, geometry/mod.rs, geometry/point.rs, odd/place.rs. tests.rs is
    // `#[cfg(test)]`, and an orphan never counts as compiled.
    assert_eq!(alpha_coverage.compiled, 4);
    // Only point.rs. Binding an uncompiled file earns no coverage.
    assert_eq!(alpha_coverage.bound, 1);
    // checks/extra.rs is a [[test]] target, so it is neither compiled source
    // nor an uncompiled orphan.
    assert_eq!(alpha_coverage.uncompiled, vec![alpha("src/orphan.rs")]);
}

#[test]
fn retired_contracts_are_skipped_and_malformed_bindings_are_reported() {
    let f = Fixture::new("skip");
    f.contract(
        "old",
        "contract_id: urn:test:old\nstatus: superseded\nrust_binding:\n  crate: nowhere\n  module: x\n",
    );
    f.contract(
        "bad",
        "contract_id: urn:test:bad\nrust_binding: alpha::geometry\n",
    );
    let report = f.run();
    assert_eq!(report.skipped_retired, 1);
    assert_eq!(report.malformed.len(), 1, "{:#?}", report.malformed);
    assert!(report.malformed[0].contains("urn:test:bad"));
    assert!(report.outcomes.is_empty());
}

#[test]
fn a_symbol_does_not_match_a_longer_identifier() {
    assert!(defines_symbol("pub struct MatrixError;", "MatrixError"));
    assert!(!defines_symbol("pub struct MatrixError;", "Matrix"));
}

#[test]
fn a_named_reexport_defines_a_symbol_but_a_glob_does_not() {
    assert!(defines_symbol("pub use crate::a::{B, C as D};", "D"));
    assert!(defines_symbol("pub use crate::a::B;", "B"));
    assert!(!defines_symbol("pub use crate::a::*;", "B"));
}

#[test]
fn the_real_estate_is_audited_and_every_binding_has_an_outcome() {
    let repo = Path::new(env!("CARGO_MANIFEST_DIR"))
        .ancestors()
        .nth(3)
        .unwrap()
        .to_path_buf();
    let report = audit(&repo).expect("the repository workspace manifest parses");
    assert!(report.outcomes.len() >= 50, "{} bindings", report.outcomes.len());
    assert!(report
        .coverage
        .iter()
        .any(|c| c.krate == "omega_contract_bindings" && c.compiled == 2));
    assert!(report.outcomes.iter().all(|o| match &o.binding.target {
        BindingTarget::Module { krate, .. } => !krate.is_empty(),
        BindingTarget::File { file } => !file.is_empty(),
    }));
    assert_eq!(
        omega_contract_bindings::summary::DECLARED,
        report.outcomes.len(),
        "the build-time run and this run read the same estate"
    );
}
