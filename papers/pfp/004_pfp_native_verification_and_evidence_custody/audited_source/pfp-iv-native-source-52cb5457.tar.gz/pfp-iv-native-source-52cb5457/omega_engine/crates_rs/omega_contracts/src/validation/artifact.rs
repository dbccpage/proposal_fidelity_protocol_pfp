use super::decision::ValidationStatus;
use crate::kinds::{ContractEffect, SchemaHash};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum ValidationResult<W, V> {
    Valid(Vec<W>),
    Invalid(Vec<V>),
    DomainError(Vec<V>),
}

impl<W, V> ValidationResult<W, V> {
    pub fn status(&self) -> ValidationStatus {
        match self {
            Self::Valid(_) => ValidationStatus::Valid,
            Self::Invalid(_) => ValidationStatus::Invalid,
            Self::DomainError(_) => ValidationStatus::DomainError,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ValidationArtifact<W, V> {
    pub artifact_id: String,
    pub validator_id: &'static str,
    pub validator_version: &'static str,
    pub subject_type: &'static str,
    pub subject_hash: String,
    pub property: &'static str,
    pub schema_hash: SchemaHash,
    pub status: ValidationStatus,
    pub result: ValidationResult<W, V>,
    pub authority_effect: ContractEffect,
    pub artifact_hash: String,
}

impl<W, V> ValidationArtifact<W, V> {
    // Artifact constructor mirrors the record's full field set by design.
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        artifact_id: String,
        validator_id: &'static str,
        validator_version: &'static str,
        subject_type: &'static str,
        subject_hash: String,
        property: &'static str,
        schema_hash: SchemaHash,
        result: ValidationResult<W, V>,
    ) -> Self {
        let status = result.status();
        let artifact_hash = validation_artifact_hash(
            &artifact_id,
            validator_id,
            validator_version,
            subject_type,
            &subject_hash,
            property,
            schema_hash,
            status,
        );

        Self {
            artifact_id,
            validator_id,
            validator_version,
            subject_type,
            subject_hash,
            property,
            schema_hash,
            status,
            result,
            authority_effect: ContractEffect::EvidenceOnly,
            artifact_hash,
        }
    }
}

// Hash helper binds every identity field of the artifact; the arity is the point.
#[allow(clippy::too_many_arguments)]
fn validation_artifact_hash(
    artifact_id: &str,
    validator_id: &'static str,
    validator_version: &'static str,
    subject_type: &'static str,
    subject_hash: &str,
    property: &'static str,
    schema_hash: SchemaHash,
    status: ValidationStatus,
) -> String {
    let mut hasher = blake3::Hasher::new();
    hasher.update(b"OmegaContracts.ValidationArtifact.v1");
    let mut update_part = |part: &str| {
        hasher.update(&(part.len() as u64).to_le_bytes());
        hasher.update(part.as_bytes());
    };
    update_part(artifact_id);
    update_part(validator_id);
    update_part(validator_version);
    update_part(subject_type);
    update_part(subject_hash);
    update_part(property);
    update_part(&schema_hash.to_string());
    update_part(&format!("{status:?}"));
    hasher.finalize().to_hex().to_string()
}
