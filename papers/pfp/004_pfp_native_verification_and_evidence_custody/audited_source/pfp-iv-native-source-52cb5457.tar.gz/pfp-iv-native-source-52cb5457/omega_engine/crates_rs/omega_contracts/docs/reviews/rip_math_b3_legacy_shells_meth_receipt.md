# B3 meth-level legacy shells

**AuthorityEffect:** None
**Pass:** b3_legacy_shells_meth
**Date:** 2026-08-01
**Isolation:** only exact_carrier, lefschetz_operator, maurer_cartan_equation, shor_topos

## Stems

| Stem | Headline meth decision |
| --- | --- |
| `exact_carrier` | Finite cochain carrier with exact d∘d=0 |
| `lefschetz_operator` | Finite pairing diagnostic; **not** Hard Lefschetz |
| `maurer_cartan_equation` | Finite MC residual; not full DGLA package |
| `shor_topos` | Discrete period geometry; **not** elementary topos |

## Nonclaims

- Not PROVED / not GlobalGreen / not HoTT / not LEAN4
- Overclaims repaired under meth review (YAML honesty, not code slop surrender)
- B2 homology and B4 left to other lanes

**AuthorityEffect: None.**
