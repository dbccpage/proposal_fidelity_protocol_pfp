use serde::{Deserialize, Serialize};

/// Validation decision result.
///
/// Note: This enum represents the *decision* outcome of a validation run.
/// For the ValidationStatus used in ValidationReport artifacts (per 05_governance.yaml),
/// see [`ValidationStatus`].
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ValidationDecision {
    Valid,
    Invalid,
    DomainError,
}

/// Validation status for validation reports.
///
/// Per 05_governance.yaml validator contract:
/// - Valid: Target satisfies all declared invariants
/// - Invalid: Target violates one or more declared invariants
/// - Indeterminate: Validation could not determine status (e.g., timeout, missing data)
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ValidationStatus {
    Valid,
    Invalid,
    DomainError,
    Indeterminate,
}

impl From<ValidationDecision> for ValidationStatus {
    fn from(decision: ValidationDecision) -> Self {
        match decision {
            ValidationDecision::Valid => Self::Valid,
            ValidationDecision::Invalid => Self::Invalid,
            ValidationDecision::DomainError => Self::DomainError,
        }
    }
}
