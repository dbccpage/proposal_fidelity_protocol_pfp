//! --- Math Contract: CP² Hopf Shadow (the n=2 shell — three charts, a real cocycle condition) ---
//!
//! The n=1 sibling (`hopf_shadow`, the S¹ → S³ → S² shell) presents its base by
//! TWO charts, so it has no triple overlaps: `C² = 0`, every 1-cochain is closed,
//! and the DDA trichotomy's `Open` branch is structurally unreachable there.
//!
//! The n=2 shell (S¹ → S⁵ → CP²) is where that changes. CP² needs THREE charts
//! `U_j = {z_j ≠ 0}`, and the triple overlap is nonempty — so for the first time
//! in this lane:
//!
//! * `C² ≠ 0` and the **cocycle condition** `δ¹g = 0` is a genuine constraint: a
//!   transition family that fails it is not a bundle at all;
//! * the runtime's `Open` classification (Γ > 0) becomes REACHABLE, and with it
//!   the runtime's own `DetectThenRepairPacket` (a `ResidualUpdate` repairs a
//!   cocycle violation — the defect is inside the carrier);
//! * `StabilizedSurvivor` (Φ > 0, Γ = 0) still means a genuine class, still
//!   repaired only by the `CarrierLift` of the n=1 lane.
//!
//! So this shell exercises the full trichotomy and BOTH repair mechanisms.
//!
//! # The finite model (every feature DECLARED, none derived)
//!
//! Sampling follows the classical homotopy types of the standard cover, each
//! declared and sampled — the charts are the contractible pieces of the
//! presentation (so a chart gauge is one constant), and:
//!
//! ```text
//! U_01 ≃ S¹  sampled by Z_k, circle coordinate = phase(z1/z0)  → index a
//! U_02 ≃ S¹  sampled by Z_k, circle coordinate = phase(z2/z0)  → index b
//! U_12 ≃ S¹  sampled by Z_k, circle coordinate = phase(z2/z1)  → index (b − a) mod k
//! U_012 ≃ T² sampled by Z_k × Z_k with coordinates (a, b)
//! ```
//!
//! Čech differentials (standard signs, `(δc)_{jl} = c_l − c_j`):
//!
//! ```text
//! δ⁰ : C⁰ = Z_k³ → C¹ = Z_k^{3k},  (δ⁰c)_{jl}[i] = c_l − c_j          (constant per circle)
//! δ¹ : C¹        → C² = Z_k^{k²},  (δ¹g)(a,b) = g12[(b−a)] − g02[b] + g01[a]
//! ```
//!
//! The **standard degree-d family** puts `g_{jl}[i] = d·i` on each circle; it is a
//! cocycle (`d(b−a) − db + da = 0`, checked for every (k,d) in tests) and it is a
//! coboundary iff every circle is constant iff `d ≡ 0 (mod k)` — the same
//! criterion as the n=1 shell, now over a three-chart presentation.
//!
//! # What this does NOT claim
//!
//! * **Not** a computation of `H*(CP²)`. This cover is not a good cover (its
//!   overlaps are not contractible), so the Čech complex over the sampled
//!   overlaps does not compute the cohomology of CP². What it decides is exactly
//!   what it checks: whether a declared transition family over this declared
//!   presentation is a coboundary of chart-constant gauges.
//! * **Not** a classification of bundles over CP².
//! * **Nothing about SU(3).** The n=2 shell is where Nielsen's paper reads
//!   `SU(3)` off the S⁵ isometry group; the descent ledger types that shell
//!   reduction as CONDITIONAL-DERIVED (sound group theory on imported "Given-1"
//!   hypotheses) and its physics readings as NOT DERIVED. None of that is
//!   bridged, implied, or used here — this module is finite ℤ_k clutching data
//!   and nothing else.
//! * No authority: every certificate here is a finite equality; nothing
//!   terminalizes, nothing mints.
//!
//! Provenance: TUFT intake plan §B2 follow-on (the n=2 shell);
//! `papers/101_topological_unified_field_theory/00_intake_provenance_and_bridge_plan.md`.
//! Sibling: `hopf_shadow` (n=1). Runtime: `degree_tower` (ENC-1181).

use crate::degree_tower::{
    BinaryCochainSegment, BinaryLinearMap, DdaOperationKind, DegreeDiagnostic, DegreeTrichotomy,
};
use omega_types::authority::RefusalSource;
use serde::Serialize;

/// Cap for the runtime bridge: the total-space segment carries `3k²` rows over a
/// `3k`-dimensional gauge space.
pub const CP2_BRIDGE_MAX_K: u64 = 8;

/// Cap on the equator sample count at *construction*.
///
/// Every family built here is fed to procedures whose cost is superlinear in `k`:
/// [`Cp2TransitionFamily::cocycle_defect`] allocates and fills `k²` entries, and
/// [`Cp2TransitionFamily::decide_section`] runs an exhaustive `k³` gauge-triple
/// sweep in which each triple compares three length-`k` circles — `k⁴` scalar
/// comparisons in the worst (refusing) case.
///
/// Bounding `k` once, at construction, is what keeps those bounded: it is the
/// only place all three circles and the sample count are established together.
/// Without it a caller-supplied `k` turns a decision procedure into an
/// unbounded sweep, and `k * k` silently wraps once `k > 2³²`.
///
/// 32 is deliberately generous — the largest fixture in this module uses `k = 10`
/// and the runtime bridge caps itself at [`CP2_BRIDGE_MAX_K`] = 8 — while holding
/// the refusing sweep to ~10⁶ comparisons.
pub const CP2_MAX_K: u64 = 32;

/// Errors of the finite CP² shadow model (not refusals).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Cp2ShadowError {
    /// Each circle must carry at least one sample (`k >= 1`).
    ZeroSampleCount,
    /// A supplied circle had the wrong length.
    RaggedCircle { expected: usize, actual: usize },
    /// The F₂ bridge requires `2 | k`: the reduction `Z_k → Z_2` is a group
    /// homomorphism only then (for odd `k` the wraparound carries an odd `k`
    /// and the reduction is not a pushforward of anything).
    OddSampleCount,
    /// `k` exceeds a declared cap. Raised at construction when `k > CP2_MAX_K`
    /// (which bounds the `k²` defect fill and the `k⁴` exhaustive gauge sweep),
    /// and by the runtime bridge when `k > CP2_BRIDGE_MAX_K` (the total-space
    /// segment has `3k²` rows).
    EquatorTooLarge,
    /// A section was requested for a family that is not a cocycle — it presents
    /// no bundle, so asking for its sections is a category error. Carries the
    /// defect weight so the caller sees how badly it fails.
    NotACocycle { defect_weight: usize },
    /// A degree-tower constructor rejected bridge-built data — unreachable by
    /// construction (dimensions and `δ¹δ⁰ = 0` hold by design; the runtime
    /// re-checks the latter), kept typed so no rejection is swallowed.
    RuntimeSegmentRejected,
    /// The Čech arithmetic here and the runtime's Gaussian elimination
    /// disagreed — unreachable, kept typed as the cross-verifier guard.
    MechanismDisagreement,
    /// The lifted total space did not diagnose Exact — unreachable for even `k`
    /// (the tautological fiber gauge realizes the pullback), kept typed.
    LiftNotExactOnTotalSpace,
}

/// A transition family over the declared three-chart CP² presentation: one
/// `Z_k`-valued cochain per pairwise overlap circle. Arbitrary families are
/// representable (that is what makes the cocycle condition testable); the
/// standard degree-`d` family is one constructor among them.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Cp2TransitionFamily {
    k: u64,
    g01: Vec<u64>,
    g02: Vec<u64>,
    g12: Vec<u64>,
}

/// A chart-constant gauge triple `(c0, c1, c2)` exhibiting the family as a
/// coboundary, with the exhaustive check receipt. Private fields + gated
/// constructor: only the decision procedure builds one.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub struct Cp2SectionWitness {
    gauges: [u64; 3],
    circle_samples_checked: u64,
}

impl Cp2SectionWitness {
    pub fn gauges(&self) -> [u64; 3] {
        self.gauges
    }
    /// Samples at which `(δ⁰c)_{jl} = g_{jl}` was verified (`3k`).
    pub fn circle_samples_checked(&self) -> u64 {
        self.circle_samples_checked
    }
}

/// Outcome of the flat-repair (chart-constant gauge) decision.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
pub enum Cp2SectionDecision {
    Found(Cp2SectionWitness),
    /// Verified refusal: no gauge triple trivializes the family. Carries the
    /// canonical refusal source and the exhaustiveness receipt (`k³` triples).
    Refused {
        source: RefusalSource,
        gauge_triples_checked: u64,
    },
}

/// Sealed certificate of one twisted lift at the n=2 shell: base survivor
/// (runtime-diagnosed and cross-checked against this module's own decision),
/// total space Exact per the runtime's own elimination.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct Cp2LiftPacket {
    base: DegreeDiagnostic,
    total: DegreeDiagnostic,
    refusal_at_base: RefusalSource,
    base_residual_dim: usize,
    total_residual_dim: usize,
    operations: [DdaOperationKind; 2],
}

impl Cp2LiftPacket {
    pub fn base(&self) -> &DegreeDiagnostic {
        &self.base
    }
    pub fn total(&self) -> &DegreeDiagnostic {
        &self.total
    }
    pub fn refusal_at_base(&self) -> RefusalSource {
        self.refusal_at_base
    }
    pub fn base_residual_dim(&self) -> usize {
        self.base_residual_dim
    }
    pub fn total_residual_dim(&self) -> usize {
        self.total_residual_dim
    }
    pub fn operations(&self) -> [DdaOperationKind; 2] {
        self.operations
    }
}

/// Outcome of running a family through the DDA runtime at mod 2. The first
/// variant is the branch the n=1 shell could not reach.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub enum Cp2ShellOutcome {
    /// Γ > 0: the reduced family violates the cocycle condition — it presents no
    /// bundle. Repairable INSIDE the carrier by a `ResidualUpdate` (the
    /// runtime's `DetectThenRepairPacket` applies); no carrier lift is involved.
    NotABundle {
        base: DegreeDiagnostic,
        /// The **mod-2** defect weight (= `base.gamma`): the number of torus
        /// points the F₂ runtime sees broken. This is a LOWER BOUND on the
        /// integral weight reported by `Cp2ShadowError::NotACocycle` — the
        /// reduction kills defects lying in `2Z_k`, so the two are NOT the
        /// same number (k=4, g01=[1,2,0,0]: reduced 4 vs integral 8).
        reduced_cocycle_defect_weight: usize,
    },
    /// Φ = 0: the reduced family is already a coboundary — a flat F₂ gauge
    /// exists and no lift is needed at this reduction.
    FlatMod2GaugeExists { base: DegreeDiagnostic },
    /// Φ > 0, Γ = 0: a genuine class at the base; the carrier lift absorbed it.
    Lifted(Cp2LiftPacket),
}

impl Cp2TransitionFamily {
    /// The standard degree-`d` family: `g_{jl}[i] = d·i mod k` on every circle.
    /// A cocycle for every `(k, d)` (tested).
    pub fn standard_degree(k: u64, d: u64) -> Result<Self, Cp2ShadowError> {
        if k == 0 {
            return Err(Cp2ShadowError::ZeroSampleCount);
        }
        if k > CP2_MAX_K {
            return Err(Cp2ShadowError::EquatorTooLarge);
        }
        let circle: Vec<u64> = (0..k).map(|i| mul_mod(d, i, k)).collect();
        Ok(Self {
            k,
            g01: circle.clone(),
            g02: circle.clone(),
            g12: circle,
        })
    }

    /// An arbitrary family (each circle of length `k`, values reduced mod `k`) —
    /// the constructor for perturbations that break the cocycle condition.
    pub fn from_circles(
        k: u64,
        g01: Vec<u64>,
        g02: Vec<u64>,
        g12: Vec<u64>,
    ) -> Result<Self, Cp2ShadowError> {
        if k == 0 {
            return Err(Cp2ShadowError::ZeroSampleCount);
        }
        if k > CP2_MAX_K {
            return Err(Cp2ShadowError::EquatorTooLarge);
        }
        for circle in [&g01, &g02, &g12] {
            if circle.len() as u64 != k {
                return Err(Cp2ShadowError::RaggedCircle {
                    expected: k as usize,
                    actual: circle.len(),
                });
            }
        }
        let reduce = |c: Vec<u64>| c.into_iter().map(|v| v % k).collect();
        Ok(Self {
            k,
            g01: reduce(g01),
            g02: reduce(g02),
            g12: reduce(g12),
        })
    }

    pub fn sample_count(&self) -> u64 {
        self.k
    }

    /// The three overlap circles in the layout order used by the F₂ bridge:
    /// `[g01, g02, g12]`.
    pub fn circles(&self) -> (&[u64], &[u64], &[u64]) {
        (&self.g01, &self.g02, &self.g12)
    }

    /// The cocycle defect `(δ¹g)(a,b) = g12[(b−a)] − g02[b] + g01[a]`, one value
    /// per triple-overlap sample (`k²`, indexed `a·k + b`).
    pub fn cocycle_defect(&self) -> Vec<u64> {
        let k = self.k;
        // `k <= CP2_MAX_K` holds by construction, so `k * k` cannot wrap; the
        // saturating form keeps that true even if the cap is ever raised, since a
        // capacity hint must never be a wrapped value.
        let mut defect = Vec::with_capacity(k.saturating_mul(k) as usize);
        for a in 0..k {
            for b in 0..k {
                let g12 = self.g12[((b + k - a) % k) as usize];
                let g02 = self.g02[b as usize];
                let g01 = self.g01[a as usize];
                defect.push((g12 + k - g02 + g01) % k);
            }
        }
        defect
    }

    /// `true` iff the family satisfies the cocycle condition — iff it presents a
    /// principal `Z_k`-bundle over the declared presentation at all.
    pub fn is_cocycle(&self) -> bool {
        self.cocycle_defect().iter().all(|value| *value == 0)
    }

    /// Decide flat repair: is the family the coboundary of a chart-constant
    /// gauge triple? Exhaustive over all `k³` triples, so the refusal is
    /// verified, never assumed. Requires a cocycle (a non-cocycle presents no
    /// bundle — typed error rather than a meaningless "no").
    pub fn decide_section(&self) -> Result<Cp2SectionDecision, Cp2ShadowError> {
        let defect_weight = self
            .cocycle_defect()
            .iter()
            .filter(|value| **value != 0)
            .count();
        if defect_weight != 0 {
            return Err(Cp2ShadowError::NotACocycle { defect_weight });
        }

        let k = self.k;
        let mut triples_checked: u64 = 0;
        for c0 in 0..k {
            for c1 in 0..k {
                for c2 in 0..k {
                    triples_checked += 1;
                    let d01 = (c1 + k - c0) % k;
                    let d02 = (c2 + k - c0) % k;
                    let d12 = (c2 + k - c1) % k;
                    let matches = self.g01.iter().all(|value| *value == d01)
                        && self.g02.iter().all(|value| *value == d02)
                        && self.g12.iter().all(|value| *value == d12);
                    if matches {
                        return Ok(Cp2SectionDecision::Found(Cp2SectionWitness {
                            gauges: [c0, c1, c2],
                            circle_samples_checked: 3 * k,
                        }));
                    }
                }
            }
        }
        Ok(Cp2SectionDecision::Refused {
            source: RefusalSource::NoLiftFound,
            gauge_triples_checked: triples_checked,
        })
    }

    // --- F₂ runtime bridge (ENC-1181) -----------------------------------------

    fn require_bridge_k(&self) -> Result<usize, Cp2ShadowError> {
        if !self.k.is_multiple_of(2) {
            return Err(Cp2ShadowError::OddSampleCount);
        }
        if self.k > CP2_BRIDGE_MAX_K {
            return Err(Cp2ShadowError::EquatorTooLarge);
        }
        Ok(self.k as usize)
    }

    /// The base segment over F₂: `C⁰ = F₂³` (chart constants) → `C¹ = F₂^{3k}`
    /// (three overlap circles) → `C² = F₂^{k²}` (the triple-overlap torus). The
    /// runtime's own constructor independently re-verifies `δ¹δ⁰ = 0`.
    pub fn base_mod2_segment(&self) -> Result<BinaryCochainSegment, Cp2ShadowError> {
        let k = self.require_bridge_k()?;

        // δ⁰ rows: (δc)_{jl} = c_l ⊕ c_j, constant along each circle.
        let mut delta0_rows = Vec::with_capacity(3 * k);
        delta0_rows.extend(std::iter::repeat_n(vec![true, true, false], k)); // c1 ⊕ c0
        delta0_rows.extend(std::iter::repeat_n(vec![true, false, true], k)); // c2 ⊕ c0
        delta0_rows.extend(std::iter::repeat_n(vec![false, true, true], k)); // c2 ⊕ c1
        let previous = BinaryLinearMap::from_rows(3, delta0_rows)
            .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)?;

        // δ¹ rows: (δg)(a,b) = g01[a] ⊕ g02[b] ⊕ g12[(b−a) mod k].
        let mut delta1_rows = Vec::with_capacity(k * k);
        for a in 0..k {
            for b in 0..k {
                let mut row = vec![false; 3 * k];
                row[a] = true;
                row[k + b] = true;
                row[2 * k + ((b + k - a) % k)] = true;
                delta1_rows.push(row);
            }
        }
        let next = BinaryLinearMap::from_rows(3 * k, delta1_rows)
            .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)?;

        BinaryCochainSegment::new(1, previous, next)
            .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)
    }

    /// The reduced (mod-2) family as a `C¹` residual in the bridge layout.
    pub fn reduced_mod2_residual(&self) -> Result<Vec<bool>, Cp2ShadowError> {
        self.require_bridge_k()?;
        let mut residual = Vec::with_capacity(3 * self.k as usize);
        for circle in [&self.g01, &self.g02, &self.g12] {
            residual.extend(circle.iter().map(|value| value % 2 == 1));
        }
        Ok(residual)
    }

    /// The total-space segment over F₂. Charts of `E` are the `3k` fiber
    /// components `(j, m)`; `δ⁰_E` evaluates, at overlap point `(jl, i, m)`,
    /// the chart-`l` gauge at fiber `(m + g_{jl}[i]) mod k` XOR the chart-`j`
    /// gauge at fiber `m`.
    ///
    /// Conventions (both DECLARED, and both diverge from the n=1 sibling):
    ///
    /// * **Degree 1, not 2.** This module labels segments by ČECH degree: the
    ///   residual lives in `C¹` of `E`'s `3k` charts, exactly as the base
    ///   residual lives in `C¹` of the base's 3 charts. `hopf_shadow` instead
    ///   labels its total space by residual-CELL-DIMENSION (degree 2, k² torus
    ///   patches), switching convention between its base and its total space.
    ///   The label is carried into `DegreeDiagnostic.degree`; it is inert here.
    /// * **`C²_E = 0` by truncation, not by absence.** Unlike the n=1 sibling
    ///   (two charts ⇒ genuinely no triple overlaps), `E`'s `3k` charts DO have
    ///   triple overlaps. Truncating is sound for this verdict only because
    ///   `diagnose` classifies `Φ = 0 ⇒ Exact` regardless of Γ, and a
    ///   coboundary is a cocycle — so a real `δ¹_E` would report Γ = 0 anyway.
    pub fn total_space_mod2_segment(&self) -> Result<BinaryCochainSegment, Cp2ShadowError> {
        let k = self.require_bridge_k()?;
        let component = |chart: usize, fiber: usize| chart * k + fiber;
        let mut rows = Vec::with_capacity(3 * k * k);
        for (chart_j, chart_l, circle) in [
            (0usize, 1usize, &self.g01),
            (0, 2, &self.g02),
            (1, 2, &self.g12),
        ] {
            for value in circle.iter().take(k) {
                let g = *value as usize % k;
                for m in 0..k {
                    let mut row = vec![false; 3 * k];
                    row[component(chart_l, (m + g) % k)] = true;
                    row[component(chart_j, m)] ^= true;
                    rows.push(row);
                }
            }
        }
        let previous = BinaryLinearMap::from_rows(3 * k, rows)
            .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)?;
        let next = BinaryLinearMap::zero(3 * k * k, 0);
        BinaryCochainSegment::new(1, previous, next)
            .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)
    }

    /// The pulled-back reduced family on the total space: value at `(jl, i, m)`
    /// is `ḡ_{jl}[i]` (constant along the fiber coordinate).
    pub fn pulled_back_mod2_residual(&self) -> Result<Vec<bool>, Cp2ShadowError> {
        let k = self.require_bridge_k()?;
        let mut out = Vec::with_capacity(3 * k * k);
        for circle in [&self.g01, &self.g02, &self.g12] {
            for value in circle.iter() {
                out.extend(std::iter::repeat_n(value % 2 == 1, k));
            }
        }
        Ok(out)
    }

    /// Run the family through the DDA runtime at mod 2 and classify it across
    /// the full trichotomy: `Open` (not a bundle — new at this shell), `Exact`
    /// (flat gauge), or `StabilizedSurvivor` → certified `CarrierLift`.
    pub fn verify_shell_lift(&self) -> Result<Cp2ShellOutcome, Cp2ShadowError> {
        let base_segment = self.base_mod2_segment()?;
        let base_residual = self.reduced_mod2_residual()?;
        let base = base_segment
            .diagnose(&base_residual)
            .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)?;

        // The integral cocycle defect, computed ONCE. Only one implication is
        // sound: `2 | k` makes the reduction `Z_k → Z_2` a homomorphism, so an
        // integral cocycle always reduces to one (Γ = 0). The CONVERSE FAILS —
        // the reduction has kernel `2Z_k`, so a defect lying in `2Z_k` (e.g. 2
        // at `k = 4`) is invisible to the runtime. Γ = 0 therefore certifies
        // nothing about the integral family.
        let integral_defect_weight = self
            .cocycle_defect()
            .iter()
            .filter(|value| **value != 0)
            .count();

        match base.classification {
            DegreeTrichotomy::Open => {
                // Γ > 0 at mod 2 ⟹ the reduced family is not a cocycle, and by
                // the sound direction above the integral family fails too. An
                // integral cocycle here WOULD be a real mechanism disagreement.
                if integral_defect_weight == 0 {
                    return Err(Cp2ShadowError::MechanismDisagreement);
                }
                Ok(Cp2ShellOutcome::NotABundle {
                    reduced_cocycle_defect_weight: base.gamma,
                    base,
                })
            }
            DegreeTrichotomy::Exact => {
                // Φ = 0 is a statement about the REDUCED family only; it does
                // not certify an integral cocycle. A family that fails closure
                // presents no bundle, so no flat-gauge verdict may be minted
                // for it — typed refusal, exactly as `decide_section` refuses.
                if integral_defect_weight != 0 {
                    return Err(Cp2ShadowError::NotACocycle {
                        defect_weight: integral_defect_weight,
                    });
                }
                Ok(Cp2ShellOutcome::FlatMod2GaugeExists { base })
            }
            DegreeTrichotomy::StabilizedSurvivor => {
                // Same fence as Exact: a mod-2-invisible defect must never earn
                // a `Cp2LiftPacket` — that would certify a twisted lift of a
                // family that is not a bundle at all.
                if integral_defect_weight != 0 {
                    return Err(Cp2ShadowError::NotACocycle {
                        defect_weight: integral_defect_weight,
                    });
                }
                // A genuine class: an integral cocycle with no chart-constant
                // F₂ gauge. Sound cross-check — an integral coboundary would
                // reduce to an F₂ coboundary (Φ = 0), so Φ > 0 forces the
                // integral decision to refuse.
                let integral_refused =
                    matches!(self.decide_section()?, Cp2SectionDecision::Refused { .. });
                if !integral_refused {
                    return Err(Cp2ShadowError::MechanismDisagreement);
                }
                let total_segment = self.total_space_mod2_segment()?;
                let total_residual = self.pulled_back_mod2_residual()?;
                let total = total_segment
                    .diagnose(&total_residual)
                    .map_err(|_| Cp2ShadowError::RuntimeSegmentRejected)?;
                if total.classification != DegreeTrichotomy::Exact || total.phi != 0 {
                    return Err(Cp2ShadowError::LiftNotExactOnTotalSpace);
                }
                Ok(Cp2ShellOutcome::Lifted(Cp2LiftPacket {
                    base,
                    total,
                    refusal_at_base: RefusalSource::NoLiftFound,
                    base_residual_dim: base_segment.residual_dim(),
                    total_residual_dim: total_segment.residual_dim(),
                    operations: [
                        DdaOperationKind::SuccessorProbe,
                        DdaOperationKind::CarrierLift,
                    ],
                }))
            }
        }
    }
}

/// `a·b mod m` in `u128` so the product is exact for every `m` (a `u64`
/// multiply silently wraps once `m > 2^32` — the defect an adversarial review
/// caught in the n=1 sibling).
fn mul_mod(a: u64, b: u64, m: u64) -> u64 {
    ((u128::from(a) * u128::from(b)) % u128::from(m)) as u64
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::degree_tower::DetectThenRepairPacket;

    /// The new structure at n=2: the standard degree-d family satisfies the
    /// cocycle condition for every (k, d) — d(b−a) − db + da = 0 in Z_k,
    /// verified over the whole k² torus.
    #[test]
    fn standard_family_is_a_cocycle_for_all_small_models() {
        for k in 1..=8u64 {
            for d in 0..k {
                let family = Cp2TransitionFamily::standard_degree(k, d).expect("fixture");
                let defect = family.cocycle_defect();
                assert_eq!(defect.len(), (k * k) as usize, "k={k} d={d}");
                assert!(
                    defect.iter().all(|value| *value == 0),
                    "standard family must be a cocycle at k={k} d={d}, defect={defect:?}"
                );
                assert!(family.is_cocycle(), "k={k} d={d}");
            }
        }
    }

    /// Section decision over the three-chart presentation: a chart-constant
    /// gauge triple exists iff d ≡ 0 (mod k) — the n=1 criterion, now with k³
    /// triples swept. Both branches inspect payloads; the witness is re-verified
    /// externally.
    #[test]
    fn section_iff_degree_zero_exhaustive() {
        for k in 1..=6u64 {
            for d in 0..k {
                let family = Cp2TransitionFamily::standard_degree(k, d).expect("fixture");
                match (
                    d,
                    family
                        .decide_section()
                        .expect("standard family is a cocycle"),
                ) {
                    (0, Cp2SectionDecision::Found(witness)) => {
                        assert_eq!(witness.circle_samples_checked(), 3 * k, "k={k}");
                        let [c0, c1, c2] = witness.gauges();
                        let (g01, g02, g12) = family.circles();
                        assert!(
                            g01.iter().all(|v| *v == (c1 + k - c0) % k)
                                && g02.iter().all(|v| *v == (c2 + k - c0) % k)
                                && g12.iter().all(|v| *v == (c2 + k - c1) % k),
                            "witness gauge fails externally at k={k}"
                        );
                    }
                    (0, other) => panic!("d=0 must yield a section at k={k}, got {other:?}"),
                    (
                        _,
                        Cp2SectionDecision::Refused {
                            source,
                            gauge_triples_checked,
                        },
                    ) => {
                        assert_eq!(source, RefusalSource::NoLiftFound, "k={k} d={d}");
                        assert_eq!(gauge_triples_checked, k * k * k, "k={k} d={d}");
                    }
                    (_, Cp2SectionDecision::Found(w)) => {
                        panic!("d={d} k={k} must refuse, found spurious witness {w:?}")
                    }
                }
            }
        }
    }

    /// A perturbed family is not a cocycle: flipping one value of g01 breaks
    /// closure at exactly the k torus points with that a-coordinate, and asking
    /// for its sections is a typed category error (it presents no bundle).
    #[test]
    fn perturbed_family_is_not_a_cocycle() {
        let k = 4u64;
        let (g01, g02, g12) = {
            let base = Cp2TransitionFamily::standard_degree(k, 2).expect("fixture");
            let (a, b, c) = base.circles();
            (a.to_vec(), b.to_vec(), c.to_vec())
        };
        let mut perturbed_g01 = g01;
        perturbed_g01[0] = (perturbed_g01[0] + 1) % k;
        let family =
            Cp2TransitionFamily::from_circles(k, perturbed_g01, g02, g12).expect("fixture");

        assert!(!family.is_cocycle());
        let defect = family.cocycle_defect();
        let defect_weight = defect.iter().filter(|v| **v != 0).count();
        assert_eq!(
            defect_weight, k as usize,
            "one flipped a-sample breaks k torus points"
        );
        assert_eq!(
            family.decide_section().unwrap_err(),
            Cp2ShadowError::NotACocycle {
                defect_weight: k as usize
            }
        );
    }

    /// **The branch the n=1 shell cannot reach.** A cocycle-violating family
    /// diagnoses as Open (Γ > 0) in the runtime, and — because the defect lives
    /// inside the carrier — the runtime's own DetectThenRepairPacket certifies
    /// the ResidualUpdate repair (cost = Φ = 1, after = Exact). No carrier lift
    /// is involved: this is not a class, it is a broken cocycle.
    #[test]
    fn runtime_open_branch_and_residual_update_repair() {
        let k = 4u64;
        let mut g01 = vec![0u64; k as usize];
        g01[0] = 1; // single violation on top of the trivial (d=0) family
        let family =
            Cp2TransitionFamily::from_circles(k, g01, vec![0; k as usize], vec![0; k as usize])
                .expect("fixture");

        match family.verify_shell_lift().expect("bridge runs") {
            Cp2ShellOutcome::NotABundle {
                base,
                reduced_cocycle_defect_weight,
            } => {
                assert_eq!(base.classification, DegreeTrichotomy::Open);
                assert_eq!(base.gamma, k as usize, "Γ = k torus points broken");
                assert_eq!(reduced_cocycle_defect_weight, k as usize);
                assert_eq!(base.phi, 1, "one flip away from the zero coboundary");
            }
            other => panic!("cocycle violation must diagnose NotABundle, got {other:?}"),
        }

        // The runtime's existing detect-then-repair mechanism now applies —
        // impossible in the n=1 lane, where Open was unreachable.
        let segment = family.base_mod2_segment().expect("segment");
        let residual = family.reduced_mod2_residual().expect("residual");
        let mut update = vec![false; 3 * k as usize];
        update[0] = true;
        let packet = DetectThenRepairPacket::verify(&segment, residual, update)
            .expect("residual update must repair a cocycle violation");
        assert_eq!(packet.before.classification, DegreeTrichotomy::Open);
        assert_eq!(packet.after.classification, DegreeTrichotomy::Exact);
        assert_eq!(packet.after.gamma, 0);
        assert_eq!(packet.repair_cost, 1);
        assert_eq!(
            packet.operations,
            [
                DdaOperationKind::SuccessorProbe,
                DdaOperationKind::ResidualUpdate
            ]
        );
    }

    /// The Hopf instance at the n=2 shell (k = 4, d = 1): base is a genuine
    /// StabilizedSurvivor with Φ = 3k/2 (each of the three circles is
    /// alternating, at Hamming distance k/2 from every chart-constant pattern),
    /// Γ = 0 (it IS a cocycle), and the carrier lift absorbs it.
    #[test]
    fn runtime_hopf_d1_survivor_then_carrier_lift() {
        let k = 4u64;
        let family = Cp2TransitionFamily::standard_degree(k, 1).expect("fixture");
        match family.verify_shell_lift().expect("bridge runs") {
            Cp2ShellOutcome::Lifted(packet) => {
                assert_eq!(
                    packet.base().classification,
                    DegreeTrichotomy::StabilizedSurvivor
                );
                assert_eq!(packet.base().phi, (3 * k / 2) as usize, "Φ = 3k/2");
                assert_eq!(packet.base().gamma, 0, "the standard family is a cocycle");
                assert_eq!(packet.total().classification, DegreeTrichotomy::Exact);
                assert_eq!(packet.total().phi, 0);
                assert_eq!(packet.refusal_at_base(), RefusalSource::NoLiftFound);
                assert_eq!(packet.base_residual_dim(), (3 * k) as usize);
                assert_eq!(packet.total_residual_dim(), (3 * k * k) as usize);
                assert_eq!(
                    packet.operations(),
                    [
                        DdaOperationKind::SuccessorProbe,
                        DdaOperationKind::CarrierLift
                    ]
                );
            }
            other => panic!("d=1 must lift, got {other:?}"),
        }
    }

    /// Even degrees reduce to the trivial F₂ family — flat gauge, no lift.
    #[test]
    fn runtime_even_degree_flat_gauge() {
        for (k, d) in [(4u64, 0u64), (4, 2), (6, 0), (6, 2), (6, 4)] {
            let family = Cp2TransitionFamily::standard_degree(k, d).expect("fixture");
            match family.verify_shell_lift().expect("bridge runs") {
                Cp2ShellOutcome::FlatMod2GaugeExists { base } => {
                    assert_eq!(base.classification, DegreeTrichotomy::Exact, "k={k} d={d}");
                    assert_eq!(base.phi, 0, "k={k} d={d}");
                    assert_eq!(base.gamma, 0, "k={k} d={d}");
                }
                other => panic!("even d={d} (k={k}) must be flat at mod 2, got {other:?}"),
            }
        }
    }

    /// Cross-mechanism agreement: for even k, the runtime's verdict on the
    /// standard family tracks degree parity exactly, and every survivor's total
    /// space is Exact. Two independent mechanisms (Čech arithmetic here,
    /// Gaussian elimination in the runtime), one verdict.
    #[test]
    fn runtime_agreement_sweep() {
        for k in [2u64, 4] {
            for d in 0..k {
                let family = Cp2TransitionFamily::standard_degree(k, d).expect("fixture");
                let outcome = family.verify_shell_lift().expect("bridge runs");
                match (outcome, d % 2) {
                    (Cp2ShellOutcome::FlatMod2GaugeExists { base }, 0) => {
                        assert_eq!(base.phi, 0, "k={k} d={d}");
                    }
                    (Cp2ShellOutcome::Lifted(packet), 1) => {
                        assert_eq!(packet.base().phi, (3 * k / 2) as usize, "k={k} d={d}");
                        assert_eq!(packet.total().classification, DegreeTrichotomy::Exact);
                    }
                    (outcome, parity) => {
                        panic!(
                            "mechanism disagreement at k={k} d={d}: {outcome:?}, parity={parity}"
                        )
                    }
                }
            }
        }
    }

    /// At k = 8 the total-space gauge space (3k = 24) exceeds the runtime's
    /// exhaustive-search cap, so the lift is certified through the runtime's
    /// Gaussian-elimination shortcut instead — the certificate must be the same.
    #[test]
    fn runtime_lift_uses_elimination_shortcut_at_large_k() {
        let family = Cp2TransitionFamily::standard_degree(8, 1).expect("fixture");
        match family.verify_shell_lift().expect("bridge runs") {
            Cp2ShellOutcome::Lifted(packet) => {
                assert_eq!(packet.total().classification, DegreeTrichotomy::Exact);
                assert_eq!(packet.total().phi, 0);
                assert_eq!(packet.total_residual_dim(), 3 * 8 * 8);
            }
            other => panic!("k=8 d=1 must lift, got {other:?}"),
        }
    }

    /// Failure paths are typed, never silent: k = 0, ragged circles, odd k
    /// (the F₂ reduction is not a homomorphism), and k over the bridge cap.
    #[test]
    fn failure_paths_are_typed() {
        assert_eq!(
            Cp2TransitionFamily::standard_degree(0, 1).unwrap_err(),
            Cp2ShadowError::ZeroSampleCount
        );
        // The construction cap refuses before any k²/k⁴ work is scheduled, on
        // both constructors. Without it, `decide_section` is an unbounded sweep.
        assert_eq!(
            Cp2TransitionFamily::standard_degree(CP2_MAX_K + 1, 1).unwrap_err(),
            Cp2ShadowError::EquatorTooLarge
        );
        let oversize = (CP2_MAX_K + 1) as usize;
        assert_eq!(
            Cp2TransitionFamily::from_circles(
                CP2_MAX_K + 1,
                vec![0; oversize],
                vec![0; oversize],
                vec![0; oversize],
            )
            .unwrap_err(),
            Cp2ShadowError::EquatorTooLarge
        );
        // The largest admitted k still constructs and decides.
        assert!(Cp2TransitionFamily::standard_degree(CP2_MAX_K, 1).is_ok());
        assert_eq!(
            Cp2TransitionFamily::from_circles(4, vec![0; 3], vec![0; 4], vec![0; 4]).unwrap_err(),
            Cp2ShadowError::RaggedCircle {
                expected: 4,
                actual: 3
            }
        );
        for k in [3u64, 5, 7] {
            let family = Cp2TransitionFamily::standard_degree(k, 1).expect("fixture");
            assert_eq!(
                family.verify_shell_lift().unwrap_err(),
                Cp2ShadowError::OddSampleCount,
                "k={k}"
            );
        }
        let family = Cp2TransitionFamily::standard_degree(10, 1).expect("fixture");
        assert_eq!(
            family.verify_shell_lift().unwrap_err(),
            Cp2ShadowError::EquatorTooLarge
        );
    }

    /// A defect in the KERNEL of `Z_k → Z_2` (e.g. 2 at k = 4) is invisible to
    /// the F₂ runtime: the reduced family looks like a perfectly good
    /// coboundary (or like the genuine Hopf survivor). Γ = 0 therefore does NOT
    /// certify an integral cocycle — only the converse holds — so the shell
    /// lift must REFUSE rather than mint a flat-gauge verdict or a lift packet
    /// for a family that presents no bundle.
    #[test]
    fn mod2_invisible_defect_refuses_rather_than_certifying() {
        // Exact branch: the reduced family is identically zero.
        let flat_looking =
            Cp2TransitionFamily::from_circles(4, vec![2, 0, 0, 0], vec![0; 4], vec![0; 4])
                .expect("fixture");
        assert!(
            !flat_looking.is_cocycle(),
            "a defect of 2 at k=4 is a real closure failure"
        );
        assert_eq!(
            flat_looking.reduced_mod2_residual().expect("residual"),
            vec![false; 12],
            "the defect vanishes under Z_4 → Z_2"
        );
        assert_eq!(
            flat_looking.verify_shell_lift().unwrap_err(),
            Cp2ShadowError::NotACocycle { defect_weight: 4 },
            "a non-bundle must not earn a flat-gauge verdict"
        );

        // StabilizedSurvivor branch: the reduction is byte-identical to the
        // genuine d=1 Hopf instance, so the runtime would hand back a lift.
        let hopf = Cp2TransitionFamily::standard_degree(4, 1).expect("fixture");
        let (g01, g02, g12) = hopf.circles();
        let mut perturbed = g01.to_vec();
        perturbed[0] = (perturbed[0] + 2) % 4;
        let survivor_looking =
            Cp2TransitionFamily::from_circles(4, perturbed, g02.to_vec(), g12.to_vec())
                .expect("fixture");
        assert!(!survivor_looking.is_cocycle());
        assert_eq!(
            survivor_looking.reduced_mod2_residual().expect("residual"),
            hopf.reduced_mod2_residual().expect("residual"),
            "reduction is indistinguishable from the genuine Hopf instance"
        );
        assert_eq!(
            survivor_looking.verify_shell_lift().unwrap_err(),
            Cp2ShadowError::NotACocycle { defect_weight: 4 },
            "a non-bundle must not earn a CarrierLift certificate"
        );

        // The genuine instance still lifts: the fence rejects non-bundles only.
        assert!(matches!(
            hopf.verify_shell_lift().expect("bridge runs"),
            Cp2ShellOutcome::Lifted(_)
        ));
    }

    /// Degree normalization: d = k is the trivial family (section found).
    #[test]
    fn degree_normalizes_mod_k() {
        let family = Cp2TransitionFamily::standard_degree(5, 5).expect("fixture");
        let (g01, _, _) = family.circles();
        assert!(g01.iter().all(|v| *v == 0));
        assert!(matches!(
            family.decide_section().expect("cocycle"),
            Cp2SectionDecision::Found(_)
        ));
    }
}
