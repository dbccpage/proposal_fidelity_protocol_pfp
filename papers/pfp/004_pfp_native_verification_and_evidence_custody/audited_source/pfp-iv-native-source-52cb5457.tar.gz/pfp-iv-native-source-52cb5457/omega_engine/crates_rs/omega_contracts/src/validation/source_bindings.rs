//! Strict, bytes-in audit of explicitly reviewed source/contract bindings.
//!
//! The caller supplies the complete declared inventory from pinned Git objects.
//! This module never walks a filesystem, guesses a migration, interprets lifecycle
//! strings as retirement authority, or treats a lexical test name as execution.
//! A clean static report is not behavioral acceptance. AuthorityEffect: None.

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};

const FILE_SCHEMA: &str = "omega.file_contract.v1";
const MAX_DOCUMENT_BYTES: usize = 4 * 1024 * 1024;

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct SourceBindingInput {
    pub documents: Vec<BindingDocument>,
    pub sources: Vec<BindingSource>,
    pub bindings: Vec<ReviewedSourceBinding>,
}

/// Repository-relative identity plus the exact supplied bytes, never a read path.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BindingDocument {
    pub path: String,
    pub bytes: Vec<u8>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct BindingSource {
    pub path: String,
    pub owner: String,
    pub bytes: Vec<u8>,
}

/// Explicit reviewed mapping. Declared paths are NOT rewritten or auto-resolved.
#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ReviewedSourceBinding {
    pub document: String,
    pub contract_id: String,
    pub declared_file: String,
    pub source: String,
    pub owner: String,
    pub document_sha256: String,
    pub source_sha256: String,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Serialize)]
#[serde(rename_all = "SCREAMING_SNAKE_CASE")]
pub enum SourceBindingCode {
    EmptyDocuments,
    EmptySources,
    EmptyBindings,
    InvalidPath,
    InvalidOwner,
    UnknownAuthorityEffect,
    DuplicateDocument,
    DuplicateSource,
    DuplicateContractIdentity,
    DuplicateDocumentBinding,
    DuplicateSourceBinding,
    UnboundDocument,
    UnboundSource,
    MissingDocument,
    MissingSource,
    DocumentTooLarge,
    InvalidDocument,
    UnsupportedSchema,
    EmptyField,
    InvalidObligation,
    ContractIdentityMismatch,
    DeclaredFileMismatch,
    OwnerMismatch,
    StaleDocument,
    StaleSource,
    InvalidSourceEncoding,
    ForbiddenSubstring,
    MissingRequiredSubstring,
}

#[derive(Debug, Clone, PartialEq, Eq, PartialOrd, Ord, Serialize)]
pub struct SourceBindingFinding {
    pub code: SourceBindingCode,
    pub path: String,
    pub detail: String,
}

#[derive(Debug, Serialize)]
pub struct LexicallyCheckedBinding {
    pub document: String,
    pub contract_id: String,
    pub source: String,
    pub document_sha256: String,
    pub source_sha256: String,
}

#[derive(Debug, Serialize)]
pub struct UnexecutedTestObligation {
    pub document_index: usize,
    pub document: String,
    pub test: String,
    pub state: &'static str,
}

#[derive(Debug, Serialize)]
pub struct SuppliedItemAccounting {
    pub input_index: usize,
    pub path: String,
    pub byte_count: usize,
    pub observed_sha256: String,
    pub reviewed_binding_count: usize,
}

#[derive(Debug, Serialize)]
pub struct SourceBindingReport {
    pub schema: &'static str,
    pub authority_effect: &'static str,
    pub supplied_documents: usize,
    pub supplied_sources: usize,
    pub supplied_bindings: usize,
    pub scope: &'static str,
    pub documents: Vec<SuppliedItemAccounting>,
    pub sources: Vec<SuppliedItemAccounting>,
    pub checked_bindings: Vec<LexicallyCheckedBinding>,
    pub findings: BTreeSet<SourceBindingFinding>,
    pub execution_obligations: Vec<UnexecutedTestObligation>,
    pub behavioral_validation: &'static str,
    pub relationship_validation: &'static str,
}

impl SourceBindingReport {
    /// Exact coverage and lexical checks only. No historical baseline or ratio.
    pub fn static_bindings_complete(&self) -> bool {
        self.findings.is_empty()
            && self.supplied_documents > 0
            && self.supplied_sources > 0
            && self.checked_bindings.len() == self.supplied_documents
            && self.checked_bindings.len() == self.supplied_sources
            && self.checked_bindings.len() == self.supplied_bindings
    }

    fn finding(&mut self, code: SourceBindingCode, path: &str, detail: impl Into<String>) {
        self.findings.insert(SourceBindingFinding {
            code,
            path: path.to_owned(),
            detail: detail.into(),
        });
    }
}

#[derive(Debug, Deserialize)]
struct FileContractShape {
    contract_id: String,
    #[serde(rename = "crate")]
    owner: String,
    file: String,
    role: String,
    status: String,
    authority_effect: String,
    #[serde(default)]
    forbidden_substrings: Vec<String>,
    #[serde(default)]
    required_substrings: Vec<String>,
    #[serde(default)]
    required_tests: Vec<String>,
}

fn canonical_repo_path(value: &str) -> bool {
    !value.is_empty()
        && !value.contains(['\\', ':', '\0', '\n', '\r'])
        && value
            .split('/')
            .all(|part| !part.is_empty() && part != "." && part != "..")
}

fn sha256(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn parse_document(
    document: &BindingDocument,
    report: &mut SourceBindingReport,
) -> Option<FileContractShape> {
    use SourceBindingCode as Code;
    if document.bytes.len() > MAX_DOCUMENT_BYTES {
        report.finding(
            Code::DocumentTooLarge,
            &document.path,
            "bounded document limit exceeded",
        );
        return None;
    }
    if document.bytes.starts_with(&[0xef, 0xbb, 0xbf])
        || std::str::from_utf8(&document.bytes).is_err()
    {
        report.finding(
            Code::InvalidDocument,
            &document.path,
            "strict UTF-8 without BOM required",
        );
        return None;
    }
    // Parse all mapping keys first, including unknown fields: duplicate unknown
    // keys must not be erased by struct deserialization's ignored-field path.
    let value: serde_yaml::Value = match serde_yaml::from_slice(&document.bytes) {
        Ok(value) => value,
        Err(error) => {
            report.finding(Code::InvalidDocument, &document.path, error.to_string());
            return None;
        }
    };
    if value
        .get("schema_version")
        .and_then(serde_yaml::Value::as_str)
        != Some(FILE_SCHEMA)
    {
        report.finding(
            Code::UnsupportedSchema,
            &document.path,
            "expected omega.file_contract.v1; no fields interpreted",
        );
        return None;
    }
    let contract: FileContractShape = match serde_yaml::from_value(value) {
        Ok(value) => value,
        Err(error) => {
            report.finding(Code::InvalidDocument, &document.path, error.to_string());
            return None;
        }
    };
    // This is the existing governance file-v1 vocabulary, not a grant of any
    // declared effect. The report itself always carries AuthorityEffect None.
    if !matches!(
        contract.authority_effect.as_str(),
        "none"
            | "evidence_only"
            | "fact_only"
            | "diagnostic_only"
            | "requires_evaluator"
            | "requests_decision"
            | "authorizes_transition"
            | "state_transition"
    ) {
        report.finding(
            Code::UnknownAuthorityEffect,
            &document.path,
            &contract.authority_effect,
        );
    }
    for (name, value) in [
        ("contract_id", &contract.contract_id),
        ("crate", &contract.owner),
        ("file", &contract.file),
        ("role", &contract.role),
        ("status", &contract.status),
        ("authority_effect", &contract.authority_effect),
    ] {
        if value.trim().is_empty() {
            report.finding(Code::EmptyField, &document.path, name);
        }
    }
    if !canonical_repo_path(&contract.file) {
        report.finding(
            Code::InvalidPath,
            &document.path,
            "declared file path is not canonical relative syntax",
        );
    }
    for (name, values) in [
        ("forbidden_substrings", &contract.forbidden_substrings),
        ("required_substrings", &contract.required_substrings),
        ("required_tests", &contract.required_tests),
    ] {
        let mut seen = BTreeSet::new();
        for value in values {
            if value.trim().is_empty() || !seen.insert(value) {
                report.finding(
                    Code::InvalidObligation,
                    &document.path,
                    format!("{name}: {value:?}"),
                );
            }
        }
    }
    Some(contract)
}

/// Audit exact inventory coverage and declared lexical obligations.
///
/// Inventory completeness relative to Git is the caller's responsibility and
/// must have its own source-bound receipt. This API accounts for every supplied
/// item, rejects duplicate/dangling mappings, and checks reviewed digest pins.
/// It does not validate ownership approval, arbitrary policy fields, lifecycle,
/// runtime enforcement, council rules, or test-execution evidence.
pub fn audit_source_bindings(input: &SourceBindingInput) -> SourceBindingReport {
    use SourceBindingCode as Code;
    let mut report = SourceBindingReport {
        schema: "omega.static-source-binding-audit.v1",
        authority_effect: "None",
        supplied_documents: input.documents.len(),
        supplied_sources: input.sources.len(),
        supplied_bindings: input.bindings.len(),
        scope: "CALLER_SUPPLIED_RUST_SOURCE_INVENTORY",
        documents: Vec::new(),
        sources: Vec::new(),
        checked_bindings: Vec::new(),
        findings: BTreeSet::new(),
        execution_obligations: Vec::new(),
        behavioral_validation: "NOT_PERFORMED",
        relationship_validation: "NOT_PERFORMED",
    };
    for (empty, code) in [
        (input.documents.is_empty(), Code::EmptyDocuments),
        (input.sources.is_empty(), Code::EmptySources),
        (input.bindings.is_empty(), Code::EmptyBindings),
    ] {
        if empty {
            report.finding(code, "", "no empty-scope acceptance");
        }
    }
    let mut documents = BTreeMap::new();
    let mut parsed = BTreeMap::new();
    let mut identities = BTreeSet::new();
    for (index, document) in input.documents.iter().enumerate() {
        report.documents.push(SuppliedItemAccounting {
            input_index: index,
            path: document.path.clone(),
            byte_count: document.bytes.len(),
            observed_sha256: sha256(&document.bytes),
            reviewed_binding_count: input
                .bindings
                .iter()
                .filter(|row| row.document == document.path)
                .count(),
        });
        if !canonical_repo_path(&document.path) || !document.path.ends_with(".contract.yaml") {
            report.finding(
                Code::InvalidPath,
                &document.path,
                "document path must be canonical repository-relative *.contract.yaml",
            );
        }
        if documents.insert(&document.path, document).is_some() {
            report.finding(
                Code::DuplicateDocument,
                &document.path,
                "duplicate supplied document",
            );
        }
        if let Some(contract) = parse_document(document, &mut report) {
            for test in &contract.required_tests {
                report.execution_obligations.push(UnexecutedTestObligation {
                    document_index: index,
                    document: document.path.clone(),
                    test: test.clone(),
                    state: "EXECUTION_EVIDENCE_NOT_SUPPLIED",
                });
            }
            if !identities.insert(contract.contract_id.clone()) {
                report.finding(
                    Code::DuplicateContractIdentity,
                    &document.path,
                    &contract.contract_id,
                );
            }
            parsed.insert(&document.path, contract);
        }
    }
    let mut sources = BTreeMap::new();
    for (index, source) in input.sources.iter().enumerate() {
        report.sources.push(SuppliedItemAccounting {
            input_index: index,
            path: source.path.clone(),
            byte_count: source.bytes.len(),
            observed_sha256: sha256(&source.bytes),
            reviewed_binding_count: input
                .bindings
                .iter()
                .filter(|row| row.source == source.path)
                .count(),
        });
        if !canonical_repo_path(&source.path) || !source.path.ends_with(".rs") {
            report.finding(
                Code::InvalidPath,
                &source.path,
                "source must be a canonical repository-relative Rust path",
            );
        }
        if source.owner.trim().is_empty() {
            report.finding(Code::InvalidOwner, &source.path, "source owner is empty");
        }
        if sources.insert(&source.path, source).is_some() {
            report.finding(
                Code::DuplicateSource,
                &source.path,
                "duplicate supplied source",
            );
        }
    }
    let mut bound_documents = BTreeSet::new();
    let mut bound_sources = BTreeSet::new();
    for binding in &input.bindings {
        let before = report.findings.len();
        for path in [&binding.document, &binding.source] {
            if !canonical_repo_path(path) {
                report.finding(
                    Code::InvalidPath,
                    path,
                    "binding path must be canonical repository-relative",
                );
            }
        }
        if !bound_documents.insert(&binding.document) {
            report.finding(
                Code::DuplicateDocumentBinding,
                &binding.document,
                "document bound more than once",
            );
        }
        if !bound_sources.insert(&binding.source) {
            report.finding(
                Code::DuplicateSourceBinding,
                &binding.source,
                "source bound more than once",
            );
        }
        let document = documents.get(&binding.document);
        let source = sources.get(&binding.source);
        if document.is_none() {
            report.finding(
                Code::MissingDocument,
                &binding.document,
                "binding target is outside supplied documents",
            );
        }
        if source.is_none() {
            report.finding(
                Code::MissingSource,
                &binding.source,
                "binding target is outside supplied sources",
            );
        }
        let (Some(document), Some(source)) = (document, source) else {
            continue;
        };
        let document_digest = sha256(&document.bytes);
        let source_digest = sha256(&source.bytes);
        if document_digest != binding.document_sha256 {
            report.finding(
                Code::StaleDocument,
                &binding.document,
                format!(
                    "expected {}, observed {}",
                    binding.document_sha256, document_digest
                ),
            );
        }
        if source_digest != binding.source_sha256 {
            report.finding(
                Code::StaleSource,
                &binding.source,
                format!(
                    "expected {}, observed {}",
                    binding.source_sha256, source_digest
                ),
            );
        }
        let Some(contract) = parsed.get(&binding.document) else {
            continue;
        };
        if binding.contract_id != contract.contract_id {
            report.finding(
                Code::ContractIdentityMismatch,
                &binding.document,
                &binding.contract_id,
            );
        }
        if binding.declared_file != contract.file {
            report.finding(
                Code::DeclaredFileMismatch,
                &binding.document,
                "declared path changed since mapping review",
            );
        }
        if binding.owner != source.owner || binding.owner != contract.owner {
            report.finding(
                Code::OwnerMismatch,
                &binding.document,
                "binding, source and declared crate owners differ",
            );
        }
        let source_text = match std::str::from_utf8(&source.bytes) {
            Ok(text) => text,
            Err(error) => {
                report.finding(
                    Code::InvalidSourceEncoding,
                    &binding.source,
                    error.to_string(),
                );
                continue;
            }
        };
        for forbidden in &contract.forbidden_substrings {
            if source_text.contains(forbidden) {
                report.finding(Code::ForbiddenSubstring, &binding.source, forbidden);
            }
        }
        for required in &contract.required_substrings {
            if !source_text.contains(required) {
                report.finding(Code::MissingRequiredSubstring, &binding.source, required);
            }
        }
        // A document-level shape/schema finding cannot be washed away by a
        // successful mapping, including after a duplicate record.
        if report.findings.len() == before
            && !report
                .findings
                .iter()
                .any(|finding| finding.path == binding.document || finding.path == binding.source)
        {
            report.checked_bindings.push(LexicallyCheckedBinding {
                document: binding.document.clone(),
                contract_id: binding.contract_id.clone(),
                source: binding.source.clone(),
                document_sha256: document_digest,
                source_sha256: source_digest,
            });
        }
    }
    for path in documents.keys() {
        if !bound_documents.contains(path) {
            report.finding(Code::UnboundDocument, path, "no reviewed source binding");
        }
    }
    for path in sources.keys() {
        if !bound_sources.contains(path) {
            report.finding(Code::UnboundSource, path, "no reviewed contract binding");
        }
    }
    report.checked_bindings.retain(|binding| {
        !report
            .findings
            .iter()
            .any(|finding| finding.path == binding.document || finding.path == binding.source)
    });
    report
        .checked_bindings
        .sort_by(|left, right| left.document.cmp(&right.document));
    report.execution_obligations.sort_by(|left, right| {
        (&left.document, left.document_index, &left.test).cmp(&(
            &right.document,
            right.document_index,
            &right.test,
        ))
    });
    report
}
