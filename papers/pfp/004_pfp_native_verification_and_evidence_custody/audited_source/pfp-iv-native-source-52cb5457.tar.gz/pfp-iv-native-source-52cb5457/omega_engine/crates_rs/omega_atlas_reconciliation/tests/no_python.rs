use std::path::Path;
fn scan(dir: &Path, hits: &mut Vec<String>) {
    if !dir.exists() {
        return;
    }
    for e in std::fs::read_dir(dir).unwrap().flatten() {
        let p = e.path();
        if p.is_dir() {
            scan(&p, hits);
        } else if p.extension().map_or(false, |x| x == "py") {
            hits.push(p.display().to_string());
        }
    }
}
#[test]
fn no_python_implementation_files() {
    let roots = [
        env!("CARGO_MANIFEST_DIR").to_string(),
        format!(
            "{}/../../research/encyclopedia/atlas_reconciliation",
            env!("CARGO_MANIFEST_DIR")
        ),
    ];
    let mut hits = Vec::new();
    for r in &roots {
        scan(Path::new(r), &mut hits);
    }
    assert!(
        hits.is_empty(),
        "Python implementation files are forbidden here (Architect ruling): {hits:?}"
    );
}
