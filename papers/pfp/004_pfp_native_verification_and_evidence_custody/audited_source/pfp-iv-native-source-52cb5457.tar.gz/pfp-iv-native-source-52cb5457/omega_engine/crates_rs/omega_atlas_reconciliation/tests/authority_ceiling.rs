use omega_atlas_reconciliation::row::*;
use omega_atlas_reconciliation::validator::validate_row;
fn good() -> ReconciliationRow {
    ReconciliationRow::sample_good()
}
#[test]
fn clean_row_passes() {
    assert!(validate_row(&good()).is_empty());
}
#[test]
fn ceiling_drift_flagged() {
    let mut r = good();
    r.declared_authority_effect = ContractEffect::FactOnly;
    r.role_pinned_ceiling = ContractEffect::EvidenceOnly;
    assert!(validate_row(&r).iter().any(|x| x.contains("ceiling drift")));
}
#[test]
fn law2_flagged() {
    let mut r = good();
    r.declared_authority_effect = ContractEffect::FactOnly;
    r.role_pinned_ceiling = ContractEffect::FactOnly;
    r.evidence_ceiling = EvidenceCeiling::ShapeOnly;
    assert!(validate_row(&r).iter().any(|x| x.contains("Law 2")));
}
#[test]
fn invariant_I_nonfactoring_no_residual() {
    let mut r = good();
    r.primitive_difference.factors_through_quotient = false;
    r.primitive_difference.residual_class = String::new();
    assert!(validate_row(&r).iter().any(|x| x.contains("invariant-I")));
}
#[test]
fn invariant_II_broken_chain() {
    let mut r = good();
    r.cochain_validity.d1_d0_zero = omega_atlas_reconciliation::cochain_validity::TriState::False;
    assert!(validate_row(&r).iter().any(|x| x.contains("invariant-II")));
}
#[test]
fn invariant_III_identity_loss() {
    let mut r = good();
    r.identity_witness.identity_loss_risk = true;
    assert!(validate_row(&r).iter().any(|x| x.contains("invariant-III")));
}
#[test]
fn open_requires_routed_work() {
    let mut r = good();
    r.routed_work.clear();
    assert!(validate_row(&r).iter().any(|x| x.contains("routed_work")));
}
