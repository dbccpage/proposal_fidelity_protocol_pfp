use crate::obstruction_runtime::{Candidate, CandidateGenerator};
pub use omega_homology::cycle_aware::{
    apply_correction, CorrectionStrategy, CycleAwareConfig, CycleCorrectableState, XiDiagnostic,
    XiDiagnosticError, XiDiagnosticFunctional, XiWitness, XiWitnessError,
};

// Re-export OperatorId so test code using `use super::*` can access it
#[cfg(test)]
pub(crate) use crate::obstruction_runtime::OperatorId;

/// A generator that proposes candidates targeting cycle obstructions
/// identified by Xi witnesses.
///
/// When the parent state has low Xi, this generator:
/// 1. Consumes a `XiDiagnostic` to compute harmonic projection and witness.
/// 2. Identifies the worst distorted edges via `XiWitness`.
/// 3. Proposes candidates that correct those edges (snap or nudge toward harmonic).
///
/// When Xi is already high, this generator produces no candidates, deferring
/// to other generators in the scheduler's mixture.
pub struct CycleAwareGenerator<D> {
    pub config: CycleAwareConfig,
    /// A diagnostic functional that securely computes harmonic projection and Xi value.
    pub diagnostic: D,
}

impl<S, D> CandidateGenerator<S> for CycleAwareGenerator<D>
where
    S: CycleCorrectableState,
    D: XiDiagnosticFunctional<S>,
{
    fn generate(&self, state: &S) -> Vec<Candidate<S>> {
        if self.config.validate().is_err() {
            return Vec::new();
        }

        if !state.validate_cycle_correctable() {
            return Vec::new();
        }

        let diagnostic = match self.diagnostic.diagnose(state) {
            Ok(d) => d,
            Err(_) => return Vec::new(),
        };

        // Validate diagnostic consistency against state
        if !diagnostic.is_valid_for_edge_count(state.edge_values().len()) {
            return Vec::new();
        }

        // Only activate when coherence is below threshold
        if diagnostic.xi_value >= self.config.xi_activation_threshold {
            return vec![];
        }

        let witness = diagnostic.witness;
        if witness.worst_edges.is_empty() {
            return vec![];
        }

        let worst_edges: Vec<usize> = witness
            .worst_edges
            .iter()
            .copied()
            .take(self.config.top_k_edges)
            .collect();

        if worst_edges.is_empty() {
            return vec![];
        }

        let mut candidates = Vec::new();

        // Strategy 1: Correct ALL worst edges simultaneously
        let corrected_all = apply_correction(
            state.edge_values(),
            &diagnostic.harmonic_projection,
            &worst_edges,
            &self.config.strategy,
        );
        candidates.push(Candidate::new(
            state.with_corrected_edges(corrected_all),
            "cycle_aware.bulk_correction",
            format!(
                "corrects {} worst edges (max_distortion={:.4}, xi={:.4})",
                worst_edges.len(),
                witness.max_distortion(),
                diagnostic.xi_value,
            ),
        ));

        // Strategy 2: Correct each worst edge individually (one candidate per edge)
        for &edge_idx in &worst_edges {
            let corrected_single = apply_correction(
                state.edge_values(),
                &diagnostic.harmonic_projection,
                &[edge_idx],
                &self.config.strategy,
            );
            candidates.push(Candidate::new(
                state.with_corrected_edges(corrected_single),
                "cycle_aware.single_edge",
                format!(
                    "corrects edge {} (distortion={:.4})",
                    edge_idx, witness.edge_distortions[edge_idx],
                ),
            ));
        }

        candidates
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use omega_homology::cycle_aware::{try_compute_xi_witness, XiDiagnostic, XiWitness};

    // --- Test state ---

    #[derive(Debug, Clone, PartialEq, serde::Serialize, serde::Deserialize)]
    struct GraphState {
        node_count: usize,
        edges: Vec<(usize, usize)>,
        edge_values: Vec<f64>,
    }

    impl CycleCorrectableState for GraphState {
        fn edge_values(&self) -> &[f64] {
            &self.edge_values
        }
        fn edges(&self) -> &[(usize, usize)] {
            &self.edges
        }
        fn node_count(&self) -> usize {
            self.node_count
        }
        fn with_corrected_edges(&self, corrected: Vec<f64>) -> Self {
            Self {
                node_count: self.node_count,
                edges: self.edges.clone(),
                edge_values: corrected,
            }
        }
    }

    fn triangle_state(edge_vals: Vec<f64>) -> GraphState {
        GraphState {
            node_count: 3,
            edges: vec![(0, 1), (1, 2), (2, 0)],
            edge_values: edge_vals,
        }
    }

    // --- Mock Diagnostic ---

    struct MockDiagnostic(Vec<f64>, f64);

    impl XiDiagnosticFunctional<GraphState> for MockDiagnostic {
        fn diagnose(&self, state: &GraphState) -> Result<XiDiagnostic, XiDiagnosticError> {
            let witness = try_compute_xi_witness(state.edge_values(), &self.0, self.1, 0)?;
            Ok(XiDiagnostic {
                harmonic_projection: self.0.clone(),
                xi_value: self.1,
                witness,
            })
        }
    }

    #[test]
    fn invalid_alpha_produces_no_candidates() {
        let state = triangle_state(vec![3.0, 1.0, 2.0]);

        let gen = CycleAwareGenerator {
            config: CycleAwareConfig {
                xi_activation_threshold: 0.5,
                top_k_edges: 2,
                strategy: CorrectionStrategy::GradientStep { alpha: f64::NAN },
            },
            diagnostic: MockDiagnostic(vec![2.0, 2.0, 2.0], 0.3),
        };

        assert!(gen.generate(&state).is_empty());
    }

    #[test]
    fn invalid_state_edge_lengths_produce_no_candidates() {
        let state = GraphState {
            node_count: 3,
            edges: vec![(0, 1), (1, 2), (2, 0)],
            edge_values: vec![1.0], // mismatch length
        };

        let gen = CycleAwareGenerator {
            config: CycleAwareConfig::default(),
            diagnostic: MockDiagnostic(vec![1.0], 0.2), // length 1 harmonic matches omega length but fails state cycle check
        };

        assert!(gen.generate(&state).is_empty());
    }

    // --- Generator tests ---

    #[test]
    fn generator_produces_no_candidates_when_xi_high() {
        let state = triangle_state(vec![1.0, 1.0, 1.0]);
        let gen = CycleAwareGenerator {
            config: CycleAwareConfig {
                xi_activation_threshold: 0.5,
                top_k_edges: 3,
                strategy: CorrectionStrategy::default(),
            },
            diagnostic: MockDiagnostic(vec![1.0, 1.0, 1.0], 0.95),
        };

        let candidates = gen.generate(&state);
        assert!(candidates.is_empty(), "should not generate when xi is high");
    }

    #[test]
    fn generator_produces_candidates_when_xi_low() {
        let state = triangle_state(vec![3.0, 1.0, 2.0]);
        let gen = CycleAwareGenerator {
            config: CycleAwareConfig {
                xi_activation_threshold: 0.5,
                top_k_edges: 2,
                strategy: CorrectionStrategy::GradientStep { alpha: 0.5 },
            },
            diagnostic: MockDiagnostic(vec![2.0, 2.0, 2.0], 0.3),
        };

        let candidates = gen.generate(&state);

        // 1 bulk + 2 single-edge = 3 candidates
        assert_eq!(candidates.len(), 3);

        assert_eq!(
            candidates[0].operator_id,
            OperatorId::from("cycle_aware.bulk_correction")
        );
        assert!(candidates[0]
            .provenance
            .0
            .contains("corrects 2 worst edges"));

        assert_eq!(
            candidates[1].operator_id,
            OperatorId::from("cycle_aware.single_edge")
        );
        assert_eq!(
            candidates[2].operator_id,
            OperatorId::from("cycle_aware.single_edge")
        );
    }

    #[test]
    fn bulk_correction_moves_state_toward_harmonic() {
        let state = triangle_state(vec![4.0, 0.0, 2.0]);
        let gen = CycleAwareGenerator {
            config: CycleAwareConfig {
                xi_activation_threshold: 0.5,
                top_k_edges: 3,
                strategy: CorrectionStrategy::GradientStep { alpha: 1.0 },
            },
            diagnostic: MockDiagnostic(vec![2.0, 2.0, 2.0], 0.1),
        };

        let candidates = gen.generate(&state);
        let bulk = &candidates[0];

        // With alpha=1.0 on all edges, the corrected state should equal the harmonic
        assert_eq!(
            bulk.state.edge_values,
            vec![2.0, 2.0, 2.0],
            "full step should snap to harmonic"
        );
    }

    // --- Diagnostic validation tests ---

    struct BadDiagnostic;

    impl XiDiagnosticFunctional<GraphState> for BadDiagnostic {
        fn diagnose(&self, _state: &GraphState) -> Result<XiDiagnostic, XiDiagnosticError> {
            Ok(XiDiagnostic {
                harmonic_projection: vec![1.0, 1.0, 1.0],
                xi_value: 0.2,
                witness: XiWitness {
                    edge_distortions: vec![f64::NAN],
                    worst_edges: vec![0],
                    xi_value: 0.2,
                },
            })
        }
    }

    #[test]
    fn invalid_diagnostic_produces_no_candidates() {
        let state = triangle_state(vec![3.0, 1.0, 2.0]);
        let gen = CycleAwareGenerator {
            config: CycleAwareConfig::default(),
            diagnostic: BadDiagnostic,
        };

        assert!(gen.generate(&state).is_empty());
    }

    #[test]
    fn diagnostic_xi_mismatch_produces_no_candidates() {
        struct MismatchDiagnostic;

        impl XiDiagnosticFunctional<GraphState> for MismatchDiagnostic {
            fn diagnose(&self, state: &GraphState) -> Result<XiDiagnostic, XiDiagnosticError> {
                let witness =
                    try_compute_xi_witness(state.edge_values(), &[2.0, 2.0, 2.0], 0.9, 3)?;

                // xi_value intentionally mismatched with witness.xi_value
                Ok(XiDiagnostic {
                    harmonic_projection: vec![2.0, 2.0, 2.0],
                    xi_value: 0.2,
                    witness,
                })
            }
        }

        let state = triangle_state(vec![3.0, 1.0, 2.0]);
        let gen = CycleAwareGenerator {
            config: CycleAwareConfig::default(),
            diagnostic: MismatchDiagnostic,
        };

        assert!(gen.generate(&state).is_empty());
    }

    #[test]
    fn invalid_edge_endpoint_produces_no_candidates() {
        let state = GraphState {
            node_count: 3,
            edges: vec![(0, 99), (1, 2), (2, 0)],
            edge_values: vec![1.0, 1.0, 1.0],
        };

        let gen = CycleAwareGenerator {
            config: CycleAwareConfig::default(),
            diagnostic: MockDiagnostic(vec![0.0, 0.0, 0.0], 0.2),
        };

        assert!(gen.generate(&state).is_empty());
    }
}
