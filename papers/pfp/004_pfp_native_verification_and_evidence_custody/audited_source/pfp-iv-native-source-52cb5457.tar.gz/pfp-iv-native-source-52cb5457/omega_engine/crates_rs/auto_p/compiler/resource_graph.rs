//! --- yaml
//! title: resource_graph
//! file_name: resource_graph.rs
//! file_location: omega_core/src/compiler/resource_graph.rs
//! status: Liquid
//! invariance_level: Tier 1
//! logic_system: Self-Repair Cohomology
//! substrate: Rust
//! description: >
//!   Unified Resource Flow Graph IR. Annotates the string diagram with
//!   multi-dimensional resource costs (error probability, qubit cost,
//!   dependency kind, ghost number) so each analysis pass becomes a cheap
//!   annotation rather than a full graph rebuild. Enables cross-pass
//!   optimization and critical-path analysis.
//! content_hash: pending
//! version: 1
//! ---

use std::collections::{HashMap, HashSet};

use super::parser::{AtpModule, Declaration};
use super::string_diagram::{Diagram, Node, WireId};

// ============================================================
// DependencyKind
// ============================================================

/// The type of dependency relationship a wire represents.
#[derive(Debug, Clone, PartialEq, Eq, Default)]
pub enum DependencyKind {
    /// No dependency annotation yet.
    #[default]
    None,
    /// Producer owns the resource -- consumer must take ownership.
    Ownership,
    /// Producer lends the resource -- consumer borrows it.
    Borrow,
    /// Quantum error propagation edge.
    ErrorFlow,
}

// ============================================================
// ResourceCost
// ============================================================

/// Multi-dimensional resource cost carried by every wire.
///
/// Each analysis pass annotates its relevant dimension:
/// - `error`: physical error probability (for tqc_budget)
/// - `qubit_cost`: qubit-time product / ancilla consumption
/// - `dependency`: topological dependency type (for lifetime_check)
/// - `ghost`: ghost number contribution (for BRST)
#[derive(Debug, Clone)]
pub struct ResourceCost {
    /// Physical error probability (for tqc_budget).
    pub error: f64,
    /// Qubit-time product (ancilla consumption).
    pub qubit_cost: usize,
    /// Topological dependency type (for lifetime_check).
    pub dependency: DependencyKind,
    /// Ghost number contribution (for BRST).
    pub ghost: i32,
}

impl Default for ResourceCost {
    fn default() -> Self {
        Self {
            error: 0.0,
            qubit_cost: 0,
            dependency: DependencyKind::None,
            ghost: 0,
        }
    }
}

// ============================================================
// ResourceGraph
// ============================================================

/// A string diagram annotated with per-wire resource costs.
///
/// This is a thin wrapper around `Diagram` that adds `ResourceCost` per wire.
/// Analysis passes annotate costs; optimization passes read them.
#[derive(Debug, Clone)]
pub struct ResourceGraph {
    /// The underlying string diagram.
    pub diagram: Diagram,
    /// Per-wire resource costs, keyed by WireId.
    pub costs: HashMap<WireId, ResourceCost>,
}

impl ResourceGraph {
    /// Build a ResourceGraph from a Diagram with default (zero) costs.
    pub fn from_diagram(diagram: Diagram) -> Self {
        let mut costs = HashMap::new();
        for &wire_id in diagram.wires.keys() {
            costs.insert(wire_id, ResourceCost::default());
        }
        Self { diagram, costs }
    }

    /// Get the resource cost for a wire (default if not annotated).
    pub fn cost(&self, wire_id: WireId) -> ResourceCost {
        self.costs.get(&wire_id).cloned().unwrap_or_default()
    }

    /// Mutably get or insert the resource cost for a wire.
    pub fn cost_mut(&mut self, wire_id: WireId) -> &mut ResourceCost {
        self.costs.entry(wire_id).or_default()
    }

    /// Annotate all wires with ownership dependency from AST analysis.
    ///
    /// For each morphism A->B in the module, the wire connecting them
    /// gets `DependencyKind::Ownership` (the morphism consumes A to produce B).
    pub fn annotate_ownership(&mut self, module: &AtpModule) {
        for decl in &module.declarations {
            if let Declaration::Morphism(m) = decl {
                // Collect wire IDs first to avoid borrowing self immutably and mutably
                let wires_to_mark: Vec<WireId> = self
                    .diagram
                    .nodes
                    .values()
                    .filter(|node| node.op == m.name)
                    .flat_map(|node| node.inputs.iter().copied())
                    .collect();
                for wire_id in wires_to_mark {
                    self.cost_mut(wire_id).dependency = DependencyKind::Ownership;
                }
            }
        }
    }

    /// Annotate wires with error costs based on operation type.
    ///
    /// T-gates get higher error, Cliffords get near-zero.
    pub fn annotate_error_costs(&mut self) {
        // Collect (wire_id, error) pairs first to avoid borrow conflict
        let annotations: Vec<(WireId, f64)> = self
            .diagram
            .nodes
            .values()
            .flat_map(|node| {
                let error = match node.op.as_str() {
                    "TGate" | "T" => 1e-3,
                    "SGate" | "S" => 1e-6,
                    "H" | "CNOT" | "CX" | "CZ" => 1e-9,
                    _ => 0.0,
                };
                if error > 0.0 {
                    node.outputs
                        .iter()
                        .map(move |&w| (w, error))
                        .collect::<Vec<_>>()
                } else {
                    Vec::new()
                }
            })
            .collect();
        for (wire_id, error) in annotations {
            self.cost_mut(wire_id).error = error;
        }
    }

    /// Annotate ghost numbers from the diagram's wire parity/ghost data.
    pub fn annotate_ghost_numbers(&mut self) {
        // Collect (wire_id, ghost) pairs first to avoid borrow conflict
        let ghosts: Vec<(WireId, i32)> = self
            .diagram
            .wires
            .iter()
            .map(|(&wire_id, wire)| (wire_id, wire.ghost_number))
            .collect();
        for (wire_id, ghost) in ghosts {
            self.cost_mut(wire_id).ghost = ghost;
        }
    }

    /// Run all annotation passes in sequence.
    pub fn annotate_all(&mut self, module: &AtpModule) {
        self.annotate_ownership(module);
        self.annotate_error_costs();
        self.annotate_ghost_numbers();
    }

    /// Compute the total error budget along a path of wires.
    ///
    /// Sums the error costs of each wire in the path.
    pub fn total_error(&self, path: &[WireId]) -> f64 {
        path.iter().map(|w| self.cost(*w).error).sum()
    }

    /// Compute total qubit cost along a path.
    pub fn total_qubit_cost(&self, path: &[WireId]) -> usize {
        path.iter().map(|w| self.cost(*w).qubit_cost).sum()
    }

    /// Find all wires with Ownership dependency (resources that are consumed).
    pub fn owned_wires(&self) -> Vec<WireId> {
        self.costs
            .iter()
            .filter(|(_, c)| c.dependency == DependencyKind::Ownership)
            .map(|(&id, _)| id)
            .collect()
    }

    /// Find all wires exceeding an error threshold.
    pub fn wires_exceeding_error(&self, threshold: f64) -> Vec<WireId> {
        self.costs
            .iter()
            .filter(|(_, c)| c.error > threshold)
            .map(|(&id, _)| id)
            .collect()
    }

    /// Find critical path: the path with highest cumulative error.
    /// Uses DFS through the diagram's node connections.
    pub fn critical_error_path(&self) -> (Vec<WireId>, f64) {
        // Simple DFS-based longest path computation
        // For DAGs, this gives the critical path
        let mut max_path: Vec<WireId> = Vec::new();
        let mut max_error: f64 = 0.0;

        // Find source wires (inputs not produced by any node)
        let produced: HashSet<WireId> = self
            .diagram
            .nodes
            .values()
            .flat_map(|n| n.outputs.iter().copied())
            .collect();
        let source_wires: Vec<WireId> = self
            .diagram
            .wires
            .keys()
            .filter(|w| !produced.contains(w))
            .copied()
            .collect();

        // DFS from each source wire
        for start in &source_wires {
            let mut stack: Vec<(WireId, Vec<WireId>, f64)> =
                vec![(*start, vec![*start], self.cost(*start).error)];
            while let Some((current, path, error)) = stack.pop() {
                // Find nodes that consume this wire
                let consumers: Vec<&Node> = self
                    .diagram
                    .nodes
                    .values()
                    .filter(|n| n.inputs.contains(&current))
                    .collect();

                if consumers.is_empty() {
                    // Terminal wire
                    if error > max_error {
                        max_error = error;
                        max_path = path;
                    }
                } else {
                    for consumer in consumers {
                        for &output in &consumer.outputs {
                            let mut new_path = path.clone();
                            new_path.push(output);
                            let new_error = error + self.cost(output).error;
                            stack.push((output, new_path, new_error));
                        }
                    }
                }
            }
        }

        (max_path, max_error)
    }
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::super::parser::{AtpModule, Declaration, MorphismDecl, TypeExpr};
    use super::super::string_diagram::Parity;
    use super::*;
    use logos::Span;

    fn make_empty_module() -> AtpModule {
        AtpModule {
            declarations: Vec::new(),
        }
    }

    fn make_module_with_morphism(name: &str) -> AtpModule {
        AtpModule {
            declarations: vec![Declaration::Morphism(MorphismDecl {
                name: name.to_string(),
                source: TypeExpr::Named("A".to_string()),
                target: TypeExpr::Named("B".to_string()),
                equations: vec![],
                proofs: vec![],
                span: Span { start: 0, end: 1 },
            })],
        }
    }

    fn make_simple_diagram() -> Diagram {
        let mut d = Diagram::new();
        let w0 = d.add_wire("input");
        let w1 = d.add_wire("output");
        d.add_node("identity", vec![w0], vec![w1]);
        d
    }

    fn make_t_gate_circuit() -> Diagram {
        let mut d = Diagram::new();
        let w0 = d.add_wire("q0");
        let w1 = d.add_wire("q1");
        let w2 = d.add_wire("q2");
        d.add_node("TGate", vec![w0], vec![w1]);
        d.add_node("H", vec![w1], vec![w2]);
        d
    }

    fn make_graded_diagram() -> Diagram {
        let mut d = Diagram::new();
        d.add_graded_wire("fermion", Parity::Odd, 1);
        d.add_graded_wire("boson", Parity::Even, 0);
        d.add_graded_wire("ghost", Parity::Odd, -1);
        d
    }

    #[test]
    fn test_from_diagram_default_costs() {
        let d = make_simple_diagram();
        let rg = ResourceGraph::from_diagram(d);

        // All wires should have default costs
        for &wire_id in rg.diagram.wires.keys() {
            let cost = rg.cost(wire_id);
            assert_eq!(cost.error, 0.0);
            assert_eq!(cost.qubit_cost, 0);
            assert_eq!(cost.dependency, DependencyKind::None);
            assert_eq!(cost.ghost, 0);
        }
    }

    #[test]
    fn test_annotate_error_costs() {
        let d = make_t_gate_circuit();
        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_error_costs();

        // Wire w1 (output of TGate) should have high error
        // Wire w2 (output of H) should have low error
        let t_gate_output = 1; // w1
        let h_output = 2; // w2

        assert!((rg.cost(t_gate_output).error - 1e-3).abs() < 1e-10);
        assert!((rg.cost(h_output).error - 1e-9).abs() < 1e-15);
    }

    #[test]
    fn test_annotate_ghost_numbers() {
        let d = make_graded_diagram();
        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_ghost_numbers();

        // Check ghost numbers are propagated
        assert_eq!(rg.cost(0).ghost, 1); // fermion
        assert_eq!(rg.cost(1).ghost, 0); // boson
        assert_eq!(rg.cost(2).ghost, -1); // ghost
    }

    #[test]
    fn test_annotate_ownership() {
        let mut d = Diagram::new();
        let w0 = d.add_wire("source");
        let w1 = d.add_wire("target");
        d.add_node("transform", vec![w0], vec![w1]);

        let module = make_module_with_morphism("transform");

        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_ownership(&module);

        // Input wire should be marked as Ownership
        assert_eq!(rg.cost(w0).dependency, DependencyKind::Ownership);
        // Output wire should remain None
        assert_eq!(rg.cost(w1).dependency, DependencyKind::None);
    }

    #[test]
    fn test_total_error_path() {
        let mut d = Diagram::new();
        let w0 = d.add_wire("q0");
        let w1 = d.add_wire("q1");
        let w2 = d.add_wire("q2");
        d.add_node("TGate", vec![w0], vec![w1]);
        d.add_node("TGate", vec![w1], vec![w2]);

        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_error_costs();

        // Path through both T-gates
        let path = vec![w1, w2];
        let total = rg.total_error(&path);

        // Two T-gates: 2 * 1e-3
        assert!((total - 2e-3).abs() < 1e-10);
    }

    #[test]
    fn test_owned_wires() {
        let mut d = Diagram::new();
        let w0 = d.add_wire("a");
        let w1 = d.add_wire("b");
        let w2 = d.add_wire("c");
        d.add_node("f", vec![w0], vec![w1]);
        d.add_node("g", vec![w1], vec![w2]);

        let module = make_module_with_morphism("f");

        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_ownership(&module);

        let owned = rg.owned_wires();
        assert_eq!(owned.len(), 1);
        assert!(owned.contains(&w0));
    }

    #[test]
    fn test_wires_exceeding_error() {
        let d = make_t_gate_circuit();
        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_error_costs();

        // Threshold below T-gate error but above H error
        let high_error = rg.wires_exceeding_error(1e-6);
        assert_eq!(high_error.len(), 1);
        assert!(high_error.contains(&1)); // T-gate output

        // Threshold below both
        let all_errors = rg.wires_exceeding_error(1e-12);
        assert_eq!(all_errors.len(), 2); // Both T and H outputs
    }

    #[test]
    fn test_critical_error_path() {
        // Build a diamond-shaped circuit:
        //   w0 -> T -> w1 -> H -> w3
        //   w0 -> S -> w2 -> H -> w4
        // Critical path should be through T-gate (higher error)
        let mut d = Diagram::new();
        let w0 = d.add_wire("input");
        let w1 = d.add_wire("t_out");
        let w2 = d.add_wire("s_out");
        let w3 = d.add_wire("h1_out");
        let w4 = d.add_wire("h2_out");

        d.add_node("TGate", vec![w0], vec![w1]);
        d.add_node("SGate", vec![w0], vec![w2]);
        d.add_node("H", vec![w1], vec![w3]);
        d.add_node("H", vec![w2], vec![w4]);

        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_error_costs();

        let (path, error) = rg.critical_error_path();

        // Critical path should go through T-gate
        assert!(path.contains(&w1)); // T-gate output
        assert!(error > 1e-4); // T-gate dominates
    }

    #[test]
    fn test_dependency_kind_default() {
        let dk = DependencyKind::default();
        assert_eq!(dk, DependencyKind::None);
    }

    #[test]
    fn test_resource_cost_default() {
        let rc = ResourceCost::default();
        assert_eq!(rc.error, 0.0);
        assert_eq!(rc.qubit_cost, 0);
        assert_eq!(rc.dependency, DependencyKind::None);
        assert_eq!(rc.ghost, 0);
    }

    #[test]
    fn test_cost_mut_inserts_default() {
        let d = make_simple_diagram();
        let mut rg = ResourceGraph::from_diagram(d);

        // Access a wire that doesn't exist (shouldn't happen normally)
        // but cost_mut should handle it gracefully
        let cost = rg.cost_mut(999);
        cost.error = 0.5;

        assert_eq!(rg.cost(999).error, 0.5);
    }

    #[test]
    fn test_annotate_all() {
        let mut d = Diagram::new();
        let w0 = d.add_graded_wire("ghost_in", Parity::Odd, 2);
        let w1 = d.add_wire("out");
        d.add_node("transform", vec![w0], vec![w1]);

        let module = make_module_with_morphism("transform");

        let mut rg = ResourceGraph::from_diagram(d);
        rg.annotate_all(&module);

        // Ghost number should be annotated
        assert_eq!(rg.cost(w0).ghost, 2);
        // Ownership should be annotated
        assert_eq!(rg.cost(w0).dependency, DependencyKind::Ownership);
    }

    #[test]
    fn test_total_qubit_cost() {
        let d = make_simple_diagram();
        let mut rg = ResourceGraph::from_diagram(d);

        // Manually set qubit costs
        rg.cost_mut(0).qubit_cost = 10;
        rg.cost_mut(1).qubit_cost = 20;

        let total = rg.total_qubit_cost(&[0, 1]);
        assert_eq!(total, 30);
    }

    #[test]
    fn test_empty_diagram() {
        let d = Diagram::new();
        let rg = ResourceGraph::from_diagram(d);

        assert!(rg.costs.is_empty());
        assert!(rg.owned_wires().is_empty());
        assert!(rg.wires_exceeding_error(0.0).is_empty());

        let (path, error) = rg.critical_error_path();
        assert!(path.is_empty());
        assert_eq!(error, 0.0);
    }
}
