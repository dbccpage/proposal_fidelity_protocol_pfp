//! Rosetta empirical layer: cross-domain residual-family stats under one alphabet.
//!
//! H-O2: if Algorithm Prime 000 + DDA is a domain-independent obstruction algebra,
//! then letter tapes and trichotomy branches should be comparable across domains
//! without domain-specific secret authority paths.
//!
//! This module **does not prove** the Rosetta conjecture. It computes finite
//! statistics and hard invariants (shared required letters, authority None,
//! no foreign alphabet symbols).

use crate::dda_alphabet::DdaOp;
use crate::oeprmalg0::{
    run_oeprmalg0, DefectBranch, DomainAdapter, EvidenceProvenance, Oeprmalg0Receipt, PrimeDomain,
    PrimeTerminal,
};
use omega_types::authority::AuthorityEffect;
use serde::Serialize;
use std::collections::{BTreeMap, BTreeSet};

/// Compact summary of one domain's Prime 000 letter tape.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct DomainTapeSummary {
    pub domain: String,
    pub residual_family_label: String,
    pub letter_tape: String,
    pub letter_histogram: BTreeMap<String, usize>,
    pub branch: String,
    pub terminal: String,
    pub phi1: Option<u64>,
    pub gamma2: Option<u64>,
    pub authority_effect: String,
    /// Whether THIS domain's masses were computed or declared.
    pub provenance: EvidenceProvenance,
}

impl DomainTapeSummary {
    pub fn from_receipt(r: &Oeprmalg0Receipt) -> Self {
        let mut hist: BTreeMap<String, usize> = BTreeMap::new();
        for ch in r.letter_tape.chars() {
            *hist.entry(ch.to_string()).or_insert(0) += 1;
        }
        // Normalize Λ if stored as multi-byte — letter() uses "Λ"
        Self {
            domain: r.domain.as_str().to_string(),
            residual_family_label: r.residual_family_label.clone(),
            letter_tape: r.letter_tape.clone(),
            letter_histogram: hist,
            branch: r.branch.as_str().to_string(),
            terminal: r.terminal.as_str().to_string(),
            phi1: r.phi1,
            gamma2: r.gamma2,
            // Read from the receipt. This was hard-coded `"None".into()`, so any
            // assertion comparing it to "None" compared a literal against itself
            // and could not fail.
            authority_effect: format!("{:?}", r.authority_effect),
            provenance: r.evidence_provenance,
        }
    }
}

/// Roster-level provenance, derived from the receipts rather than asserted.
///
/// The previous field was a hard-coded `FixtureDrivenStructuralDemo` on the whole
/// report. That was true when every adapter declared its numbers, and would have
/// silently stayed true after one began computing them.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub enum RosterProvenance {
    /// Every domain declared its masses.
    AllFixtureDriven,
    /// Some domains compute, some declare. Names the ones that compute.
    Mixed { verifier_produced: Vec<String> },
    /// Every domain's masses were computed by a verifier.
    AllVerifierProduced,
}

/// Aggregate Rosetta report over several domains.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct RosettaReport {
    /// What the numbers below actually are, derived from the receipts.
    pub provenance: RosterProvenance,
    pub domains: Vec<DomainTapeSummary>,
    /// Every domain emits C, R, and T at least once.
    pub shared_required_letters: bool,
    /// Every letter is in the declared 8-letter alphabet.
    pub alphabet_closed: bool,
    /// All receipts carry AuthorityEffect::None.
    pub authority_all_none: bool,
    /// Φ₁ and Γ₂ always stored as distinct slots (never a merged field).
    pub phi_gamma_separated: bool,
    /// Literature steps never appear before first T in any domain.
    pub literature_always_after_terminal: bool,
    pub branch_histogram: BTreeMap<String, usize>,
    pub terminal_histogram: BTreeMap<String, usize>,
    pub residual_family_count: usize,
    /// Distinct residual-family labels seen.
    pub residual_families: Vec<String>,
    /// Jaccard similarity of letter *sets* between domain pairs (scaled ×1000).
    pub pairwise_letter_jaccard_x1000: BTreeMap<String, u64>,
    /// No receipt violates a *decidable* letter law. Not full conformance — see
    /// `oeprmalg0_conformance::UNDECIDABLE_WITHOUT_PER_STEP_STATE`.
    pub no_decidable_letter_law_violation: bool,
    /// Domain -> the letter laws it broke. Empty iff the flag above is true.
    pub letter_law_violations: BTreeMap<String, Vec<String>>,
    pub rosetta_smoke_pass: bool,
}

fn alphabet_letters() -> BTreeSet<char> {
    DdaOp::alphabet()
        .iter()
        .flat_map(|o| o.letter().chars())
        .collect()
}

/// Build a Rosetta report from already-run receipts.
pub fn rosetta_from_receipts(receipts: &[Oeprmalg0Receipt]) -> RosettaReport {
    let allowed = alphabet_letters();
    let domains: Vec<DomainTapeSummary> = receipts
        .iter()
        .map(DomainTapeSummary::from_receipt)
        .collect();

    let shared_required_letters = domains.iter().all(|d| {
        d.letter_tape.contains('C') && d.letter_tape.contains('R') && d.letter_tape.contains('T')
    });

    let alphabet_closed = domains.iter().all(|d| {
        d.letter_tape.chars().all(|c| {
            // multi-byte ops: allow any char that appears in some alphabet letter
            allowed.contains(&c) || "Λ".contains(c)
        })
    });

    let authority_all_none = receipts
        .iter()
        .all(|r| r.authority_effect == AuthorityEffect::None);

    // Φ₁ and Γ₂ must be independent slots, not one mass surfaced twice.
    //
    // This previously matched all four (Option, Option) combinations and returned
    // `true` in every arm -- a tautology. It could not fail, so every conjunction
    // containing it was weaker than it read, and no test could tell it from a
    // constant. Replaced with a witness that can actually be absent:
    //
    // aliased fields cannot produce a receipt in which they DIFFER, so observing a
    // difference anywhere in the roster witnesses separation. A roster where they
    // never differ is reported unseparated rather than silently green -- weak
    // evidence, but evidence, and it fails when there is none.
    let phi_gamma_separated = receipts.iter().any(|r| match (r.phi1, r.gamma2) {
        (Some(p), Some(g)) => p != g,
        (Some(_), None) | (None, Some(_)) => true,
        (None, None) => false,
    });

    let literature_always_after_terminal = receipts.iter().all(|r| {
        let first_t = r.steps.iter().position(|s| s.op == "T");
        match first_t {
            None => r.steps.iter().all(|s| s.prime_step != 12),
            Some(i) => r.steps[..i].iter().all(|s| s.prime_step != 12),
        }
    });

    let mut branch_histogram: BTreeMap<String, usize> = BTreeMap::new();
    let mut terminal_histogram: BTreeMap<String, usize> = BTreeMap::new();
    for d in &domains {
        *branch_histogram.entry(d.branch.clone()).or_insert(0) += 1;
        *terminal_histogram.entry(d.terminal.clone()).or_insert(0) += 1;
    }

    let mut families: BTreeSet<String> = BTreeSet::new();
    for d in &domains {
        families.insert(d.residual_family_label.clone());
    }
    let residual_families: Vec<String> = families.iter().cloned().collect();

    let mut pairwise: BTreeMap<String, u64> = BTreeMap::new();
    for i in 0..domains.len() {
        for j in (i + 1)..domains.len() {
            let a: BTreeSet<char> = domains[i].letter_tape.chars().collect();
            let b: BTreeSet<char> = domains[j].letter_tape.chars().collect();
            let inter = a.intersection(&b).count() as u64;
            let union = a.union(&b).count() as u64;
            let jacc = if union == 0 {
                0
            } else {
                (inter * 1000) / union
            };
            let key = format!("{}|{}", domains[i].domain, domains[j].domain);
            pairwise.insert(key, jacc);
        }
    }

    // Letter-law conformance, per receipt. This was omitted entirely, so
    // `rosetta_smoke_pass` stayed true while a domain terminalised an open
    // residual — a T-law violation the checker could already see and the smoke
    // verdict simply never asked about.
    let letter_law_violations: BTreeMap<String, Vec<String>> = receipts
        .iter()
        .filter_map(|r| {
            let c = crate::oeprmalg0_conformance::check_receipt(r);
            let v = c.violations();
            if v.is_empty() {
                None
            } else {
                Some((
                    r.domain.as_str().to_string(),
                    v.iter().map(|x| format!("{x:?}")).collect(),
                ))
            }
        })
        .collect();
    let no_decidable_letter_law_violation = letter_law_violations.is_empty();

    let rosetta_smoke_pass = shared_required_letters
        && alphabet_closed
        && authority_all_none
        && phi_gamma_separated
        && literature_always_after_terminal
        && no_decidable_letter_law_violation
        && !domains.is_empty();

    // Derived, never asserted: the roster's provenance is whatever its receipts say.
    let verifier_produced: Vec<String> = receipts
        .iter()
        .filter(|r| r.evidence_provenance == EvidenceProvenance::VerifierProduced)
        .map(|r| r.domain.as_str().to_string())
        .collect();
    let provenance = if verifier_produced.is_empty() {
        RosterProvenance::AllFixtureDriven
    } else if verifier_produced.len() == receipts.len() {
        RosterProvenance::AllVerifierProduced
    } else {
        RosterProvenance::Mixed { verifier_produced }
    };

    RosettaReport {
        provenance,
        domains,
        shared_required_letters,
        alphabet_closed,
        authority_all_none,
        phi_gamma_separated,
        literature_always_after_terminal,
        branch_histogram,
        terminal_histogram,
        residual_family_count: residual_families.len(),
        residual_families,
        pairwise_letter_jaccard_x1000: pairwise,
        no_decidable_letter_law_violation,
        letter_law_violations,
        rosetta_smoke_pass,
    }
}

/// Run all provided adapters and compute the Rosetta report.
pub fn rosetta_run(adapters: &[&dyn DomainAdapter]) -> RosettaReport {
    let receipts: Vec<Oeprmalg0Receipt> = adapters.iter().map(|a| run_oeprmalg0(*a)).collect();
    rosetta_from_receipts(&receipts)
}

/// Convenience: run the built-in multi-domain roster.
pub fn rosetta_builtin_roster() -> RosettaReport {
    rosetta_from_receipts(&builtin_receipts())
}

/// The built-in roster's receipts, so conformance and the report read the same runs.
pub fn builtin_receipts() -> Vec<Oeprmalg0Receipt> {
    use crate::domain_adapters::{
        CodaResidualAdapter, Cp2ShadowAdapter, FspChannelAAdapter, GenericMss0Adapter,
        MubWallAdapter, SymbolGameExpressivityAdapter,
    };
    let g = GenericMss0Adapter;
    let m = MubWallAdapter;
    let f = FspChannelAAdapter;
    let c = CodaResidualAdapter;
    let s = SymbolGameExpressivityAdapter::default();
    // The CP² adapter is the only roster entry whose masses are computed. k=4,d=1
    // is even (the F₂ bridge needs 2|k) and inside CP2_MAX_K.
    let cp2 = Cp2ShadowAdapter::standard(4, 1).expect("k=4 is within CP2_MAX_K");
    let adapters: [&dyn DomainAdapter; 6] = [&g, &m, &f, &c, &s, &cp2];
    adapters.iter().map(|a| run_oeprmalg0(*a)).collect()
}

/// Residual-family row for empirical tables (domain × family × branch × terminal).
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct ResidualFamilyStat {
    pub domain: PrimeDomain,
    pub family: String,
    pub branch: DefectBranch,
    pub terminal: PrimeTerminal,
    pub phi1: Option<u64>,
    pub gamma2: Option<u64>,
    pub letter_tape: String,
}

pub fn residual_family_table(receipts: &[Oeprmalg0Receipt]) -> Vec<ResidualFamilyStat> {
    receipts
        .iter()
        .map(|r| ResidualFamilyStat {
            domain: r.domain,
            family: r.residual_family_label.clone(),
            branch: r.branch,
            terminal: r.terminal,
            phi1: r.phi1,
            gamma2: r.gamma2,
            letter_tape: r.letter_tape.clone(),
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::domain_adapters::{
        CodaResidualAdapter, FspChannelAAdapter, GenericMss0Adapter, MubWallAdapter,
        SymbolGameExpressivityAdapter,
    };

    /// Asserts only the conjuncts that can actually fail.
    #[test]
    fn rosetta_builtin_roster_reports_measurable_structure() {
        let report = rosetta_builtin_roster();

        assert_eq!(report.domains.len(), 6);
        assert!(report.residual_family_count >= 4);
        assert!(report.authority_all_none);
        assert!(report.alphabet_closed);
        assert!(report.literature_always_after_terminal);

        // `shared_required_letters` is FALSE, and that is the correct reading.
        //
        // It reported true only because a domain that refused kept executing:
        // MUB emits "refuse construction" at step 4, and the runner used to carry
        // on through Q¹ (R), the mass split, the lift search and routing (R
        // again), so the tape acquired the required letters *after* the refusal.
        //
        // With refusals terminal, MUB stops at step 4 and terminalises. Its tape
        // carries no `R`, because no residual projection ever ran. The Rosetta
        // "every domain emits C, R and T" invariant was an artifact of ignoring
        // refusals, not a property of the domains.
        assert!(
            !report.shared_required_letters,
            "a refusing domain cannot emit R; if this passes, refusals stopped              being terminal again"
        );
        let mub = report
            .domains
            .iter()
            .find(|d| d.domain == "mub")
            .expect("mub in roster");
        assert_eq!(mub.terminal, "Refusal");
        assert!(!mub.letter_tape.contains('R'));
    }

    /// The smoke verdict now consults letter-law conformance, and FSP breaks it.
    ///
    /// FSP has masses (1, 1) -> Open, terminalises with `T` at Γ₂ = 1, which the
    /// T law forbids ("T is inert and requires zero closure defect"). The old
    /// `rosetta_smoke_pass` never asked, so it stayed true over a known violation.
    #[test]
    fn smoke_verdict_sees_the_fsp_t_law_violation() {
        let report = rosetta_builtin_roster();

        assert!(
            !report.no_decidable_letter_law_violation,
            "expected FSP's T-law violation to be visible"
        );
        assert!(
            report.letter_law_violations.contains_key("fsp"),
            "violations recorded: {:?}",
            report.letter_law_violations
        );
        assert!(
            !report.rosetta_smoke_pass,
            "smoke must not pass while a domain terminalises an open residual"
        );
    }

    #[test]
    fn residual_family_table_has_distinct_labels() {
        let receipts = [
            run_oeprmalg0(&GenericMss0Adapter),
            run_oeprmalg0(&MubWallAdapter),
            run_oeprmalg0(&FspChannelAAdapter),
            run_oeprmalg0(&CodaResidualAdapter),
            run_oeprmalg0(&SymbolGameExpressivityAdapter::default()),
        ];
        let table = residual_family_table(&receipts);
        let labels: BTreeSet<_> = table.iter().map(|r| r.family.as_str()).collect();
        assert!(labels.len() >= 4);
        // FSP is Open (gamma2>0); generic/coda/sg are StabilizedSurvivor
        assert!(table.iter().any(|r| r.branch == DefectBranch::Open));
        assert!(table
            .iter()
            .any(|r| r.branch == DefectBranch::StabilizedSurvivor));
    }

    #[test]
    fn pairwise_jaccard_recorded() {
        let report = rosetta_run(&[&GenericMss0Adapter, &CodaResidualAdapter]);
        assert!(report
            .pairwise_letter_jaccard_x1000
            .contains_key("generic|coda"));
        let j = report.pairwise_letter_jaccard_x1000["generic|coda"];
        assert!(j > 0, "expected some shared letters");
    }

    /// The roster is no longer uniformly fixture-driven, and says so.
    #[test]
    fn roster_provenance_is_mixed_and_names_the_computed_domain() {
        let report = rosetta_builtin_roster();
        match &report.provenance {
            RosterProvenance::Mixed { verifier_produced } => {
                assert_eq!(verifier_produced, &vec!["cp2".to_string()]);
            }
            other => panic!("expected Mixed, got {other:?}"),
        }
        let cp2 = report
            .domains
            .iter()
            .find(|d| d.domain == "cp2")
            .expect("cp2 in roster");
        assert_eq!(cp2.provenance, EvidenceProvenance::VerifierProduced);

        // Everyone else still declares, and must still say so.
        for d in report.domains.iter().filter(|d| d.domain != "cp2") {
            assert_eq!(
                d.provenance,
                EvidenceProvenance::FixtureDrivenStructuralDemo,
                "{} claims verifier-produced masses it does not have",
                d.domain
            );
        }
    }

    /// The CP² masses are COMPUTED: perturb the family and they move.
    ///
    /// This is the falsifier that separates a verifier-backed adapter from one
    /// that merely claims to be. A declared adapter returns the same constants no
    /// matter what its carrier does, so the contrast below is the whole point:
    /// the same perturbation applied to a fixture adapter changes nothing.
    #[test]
    fn cp2_masses_respond_to_the_carrier_but_fixture_masses_do_not() {
        use crate::domain_adapters::{Cp2ShadowAdapter, GenericMss0Adapter};
        use crate::oeprmalg0::DomainAdapter;

        let flat = Cp2ShadowAdapter::standard(4, 0).expect("k=4 d=0 constructs");
        let twisted = Cp2ShadowAdapter::standard(4, 1).expect("k=4 d=1 constructs");

        assert_ne!(
            flat.residual_masses(),
            twisted.residual_masses(),
            "CP² masses did not respond to the degree — they are not being computed"
        );

        // The contrast: a declared adapter is blind to its own carrier.
        let fixture = GenericMss0Adapter;
        assert_eq!(fixture.residual_masses(), (1, 0));
        assert_eq!(
            fixture.evidence_provenance(),
            EvidenceProvenance::FixtureDrivenStructuralDemo
        );
    }

    /// A refused family must not be reported as closed.
    ///
    /// `(0, 0)` means "no defect". Inferring it from an absent diagnosis would
    /// turn "the runtime would not answer" into "there is nothing wrong", which is
    /// the specific false-green this branch exists to avoid.
    #[test]
    fn cp2_refusal_is_not_reported_as_closed() {
        use crate::domain_adapters::Cp2ShadowAdapter;
        use crate::oeprmalg0::DomainAdapter;

        // Odd k: the F₂ reduction is not a homomorphism, so the runtime refuses.
        let odd = Cp2ShadowAdapter::standard(5, 1).expect("k=5 constructs");
        assert!(!odd.justify_cochain(), "odd k must not claim justification");
        assert_ne!(
            odd.residual_masses(),
            (0, 0),
            "a refused diagnosis must not read as a closed residual"
        );
    }
}
