use crate::kinds::ContractEffect;

pub type CarrierId = String;
pub type ObservationId = String;
pub type ObstructionId = String;

/// Anything bound to a declared carrier manifest.
pub trait CarrierBound {
    type Carrier;

    fn carrier_id(&self) -> CarrierId;
    fn carrier(&self) -> &Self::Carrier;
}

/// A quotient projection must be explicit and certificate-producing.
/// It is not just a convenience method.
pub trait QuotientProjection {
    type EquivalenceRelation;
    type Quotient;
    type Error;

    fn project_quotient(
        &self,
        relation: &Self::EquivalenceRelation,
    ) -> Result<QuotientProjectionReport<Self::Quotient>, Self::Error>;
}

pub struct QuotientProjectionReport<Q> {
    pub quotient: Q,
    pub relation_hash: String,
    pub carrier_hash: String,
    pub authority_effect: ContractEffect,
}

impl<Q> QuotientProjectionReport<Q> {
    pub fn new(quotient: Q, relation_hash: String, carrier_hash: String) -> Self {
        Self {
            quotient,
            relation_hash,
            carrier_hash,
            authority_effect: ContractEffect::EvidenceOnly,
        }
    }
}

/// Observables extract evidence. They do not decide, repair, or terminalize.
pub trait ObservableSource<Input> {
    type Observation;
    type Error;

    fn observe(&self, input: &Input)
        -> Result<ObservationEnvelope<Self::Observation>, Self::Error>;
}

pub struct ObservationEnvelope<O> {
    pub observation_id: ObservationId,
    pub observation: O,
    pub subject_hash: String,
    pub observable_id: String,
    pub certificate_refs: Vec<String>,
    pub authority_effect: ContractEffect,
}

impl<O> ObservationEnvelope<O> {
    pub fn new(
        observation_id: ObservationId,
        observation: O,
        subject_hash: String,
        observable_id: String,
        certificate_refs: Vec<String>,
    ) -> Self {
        Self {
            observation_id,
            observation,
            subject_hash,
            observable_id,
            certificate_refs,
            authority_effect: ContractEffect::EvidenceOnly,
        }
    }
}

/// Obstruction reporting is descriptive. Evaluation happens elsewhere.
pub trait ObstructionSignatureProvider<Input> {
    type Signature;
    type Error;

    fn obstruction_signature(
        &self,
        input: &Input,
    ) -> Result<ObstructionReport<Self::Signature>, Self::Error>;
}

pub struct ObstructionReport<S> {
    pub obstruction_id: ObstructionId,
    pub signature: S,
    pub subject_hash: String,
    pub phi_ref: Option<String>,
    pub gamma_ref: Option<String>,
    pub certificate_refs: Vec<String>,
    pub authority_effect: ContractEffect,
}

impl<S> ObstructionReport<S> {
    pub fn new(
        obstruction_id: ObstructionId,
        signature: S,
        subject_hash: String,
        phi_ref: Option<String>,
        gamma_ref: Option<String>,
        certificate_refs: Vec<String>,
    ) -> Self {
        Self {
            obstruction_id,
            signature,
            subject_hash,
            phi_ref,
            gamma_ref,
            certificate_refs,
            authority_effect: ContractEffect::EvidenceOnly,
        }
    }
}

/// Shape only. No tensor algebra authority here.
pub trait HasTensorShape {
    fn shape(&self) -> &[usize];
}

// =============================================================================
// Boundary Contract (01_state.yaml)
// =============================================================================

/// Typed structural interface between local candidate spaces and global carrier state.
/// Maps to boundary contract in 01_state.yaml.
///
/// A Boundary declares the shape of crossing, admissibility predicates, and required
/// evidence references. A Boundary does not apply the crossing. It does not decide
/// admissibility. It does not transport state. It does not mutate carriers.
pub trait Boundary {
    type LocalSpace;
    type GlobalSpace;
    type CrossingType;
    type AdmissibilityPredicate;
    type EvidenceKind;

    fn boundary_id(&self) -> &str;
    fn local_space(&self) -> &Self::LocalSpace;
    fn global_space(&self) -> &Self::GlobalSpace;
    fn crossing_type(&self) -> &Self::CrossingType;
    fn admissibility_predicate(&self) -> &Self::AdmissibilityPredicate;
    fn required_evidence(&self) -> Vec<&Self::EvidenceKind>;
}

/// Crossing type enumeration from 01_state.yaml.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CrossingType {
    LocalToGlobalInjection,
    GlobalToLocalProjection,
    DeclaredEquivalence,
}

/// Boundary specification structure.
///
/// A boundary spec declares structure and required evidence only. It must not apply a
/// crossing, mutate state, or judge admissibility. Its authority effect should be
/// `None` or `EvidenceOnly`.
#[derive(Debug, Clone)]
pub struct BoundarySpec {
    pub boundary_id: String,
    pub local_space: String,
    pub global_space: String,
    pub crossing_type: CrossingType,
    pub admissibility_predicate_ref: String,
    pub required_evidence: Vec<String>,
    pub witness_refs: Vec<String>,
    pub certificate_refs: Vec<String>,
    pub boundary_hash: String,
    pub schema_hash: String,
    pub authority_effect: ContractEffect,
}

/// Boundary refusal conditions from 01_state.yaml.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum BoundaryRefusal {
    InvalidCarrierRef,
    CrossingTypeUndeclared,
    AdmissibilityPredicatePartial,
    RequiredEvidenceUnsatisfiable,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn observation_and_obstruction_reports_default_to_evidence_only() {
        let observation = ObservationEnvelope::new(
            "obs:1".to_string(),
            7usize,
            "subject:hash".to_string(),
            "observable:test".to_string(),
            Vec::new(),
        );
        assert_eq!(observation.authority_effect, ContractEffect::EvidenceOnly);

        let obstruction = ObstructionReport::new(
            "obsn:1".to_string(),
            "signature:test".to_string(),
            "subject:hash".to_string(),
            Some("phi:ref".to_string()),
            None,
            Vec::new(),
        );
        assert_eq!(obstruction.authority_effect, ContractEffect::EvidenceOnly);
    }

}
