//! Canonical improvement / maintenance contract family (V1).
//!
//! Normative types for the host-governed maintenance loop live here once.
//! Producers and consumers outside this module may reference these types; they
//! must not invent shadow semantic contracts or provenance fields.
//!
//! Encoding: every maintenance contract is serialized with
//! [`canonical_json::OMEGA_CANONICAL_JSON_V1`] (compact, recursively key-sorted,
//! raw-Unicode). Floating-point fields are forbidden. Raw inputs are always
//! hashed independently of semantic JSON.

pub mod canonical_json;
pub mod ids;
pub mod types;

pub use canonical_json::{
    dumps_canonical_v1, hash_canonical_v1, hash_raw_bytes, CanonicalJsonError,
    OMEGA_CANONICAL_JSON_V1,
};
pub use ids::{derive_candidate_id_from_body, derive_candidate_id_v1, derive_finding_id_v1};
pub use types::*;
