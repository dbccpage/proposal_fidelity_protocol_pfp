use crate::checked_packet::{CarrierManifestHash, CertifiedScalar, CheckerRef, ReplayHash};
use serde::{Deserialize, Serialize};

/// Verified exact Gamma2 type alias.
pub type VerifiedExactGamma2 = omega_functional::ExactGamma2Result;

/// Closure status enum for the certificate.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum ClosureStatus {
    Closed,
    Open,
    IndeterminateWithinTolerance,
}

/// Closure certificate: attests closure status of a quotient class.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClosureCertificate {
    pub gamma_2: CertifiedScalar,
    pub closure_status: ClosureStatus,
    pub carrier_hash: CarrierManifestHash,
    pub checker_ref: CheckerRef,
    pub replay_hash: ReplayHash,
}

#[derive(Debug, thiserror::Error, PartialEq, Eq)]
pub enum ClosureCertificateError {
    #[error("non-finite closure defect cannot be certified")]
    NonFinite,
    #[error("negative closure defect cannot be certified")]
    Negative,
}

impl ClosureCertificate {
    /// Create an exact closure certificate from verified exact Γ₂.
    ///
    /// Exact status rule:
    /// - `gamma2 == 0` -> Closed
    /// - `gamma2 > 0`  -> Open
    pub fn new_exact(
        gamma2: VerifiedExactGamma2,
        carrier_hash: CarrierManifestHash,
        checker_ref: CheckerRef,
        replay_hash: ReplayHash,
    ) -> Self {
        use num_traits::Zero;
        let val = gamma2.value();
        let status = if val.is_zero() {
            ClosureStatus::Closed
        } else {
            ClosureStatus::Open
        };
        let certified = CertifiedScalar::ExactRational(
            omega_functional::hashes::RationalValue::from_big_rational(val),
        );
        Self {
            gamma_2: certified,
            closure_status: status,
            carrier_hash,
            checker_ref,
            replay_hash,
        }
    }
}

/// Closure diagnostic: interval/float evaluation (NOT authority-bearing).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ClosureDiagnostic {
    pub gamma_2: CertifiedScalar,
    pub closure_status: ClosureStatus,
    pub carrier_hash: CarrierManifestHash,
    pub checker_ref: CheckerRef,
    pub replay_hash: ReplayHash,
}

impl ClosureDiagnostic {
    pub fn new_diagnostic_interval(
        lower: omega_functional::hashes::RationalValue,
        upper: omega_functional::hashes::RationalValue,
        carrier_hash: CarrierManifestHash,
        checker_ref: CheckerRef,
        replay_hash: ReplayHash,
        tol: f64,
    ) -> Result<Self, ClosureCertificateError> {
        let certified = CertifiedScalar::Interval { lower, upper };
        // No faithful f64 projection exists (NaN, non-finite, or a nonzero
        // value that underflows to 0.0). Refuse rather than certify from it.
        let Some(val) = certified.to_f64_diagnostic() else {
            return Err(ClosureCertificateError::NonFinite);
        };
        if val < 0.0 {
            return Err(ClosureCertificateError::Negative);
        }
        // `Closed` asserts Gamma2 = 0 exactly, so it is decided on the
        // rationals, not on `val == 0.0`. A strictly positive Gamma2 below the
        // f64 floor (e.g. 1/10^400) projects onto 0.0; deciding from the float
        // certified "no closure defect" for a certificate that has one.
        let status = if certified.is_exactly_zero() {
            ClosureStatus::Closed
        } else if val.abs() <= tol {
            ClosureStatus::IndeterminateWithinTolerance
        } else {
            ClosureStatus::Open
        };
        Ok(Self {
            gamma_2: certified,
            closure_status: status,
            carrier_hash,
            checker_ref,
            replay_hash,
        })
    }
}
