//! Compatibility law markers for older generated bindings.
//!
//! The canonical descriptor law model lives in `crate::descriptors::laws`.
//! This module remains as a lightweight compatibility shim and must not drift
//! into a second authority doctrine.

use crate::binding::BoundContract;

// --- Axis ---
pub trait PhiLaw {}
pub trait StructureLaw {}
pub trait EffectLaw {}
pub trait AuthorityLaw {}
pub trait CapabilityLaw {}

// --- Phi ---
pub struct NonIncreasing;
pub struct Reducing;
pub struct PreservingPhi;
pub struct UnclaimedPhi;

impl PhiLaw for NonIncreasing {}
impl PhiLaw for Reducing {}
impl PhiLaw for PreservingPhi {}
impl PhiLaw for UnclaimedPhi {}

// --- Structure ---
pub struct StructurePreserving;
pub struct StructureTransforming;
pub struct StructureReductive;

impl StructureLaw for StructurePreserving {}
impl StructureLaw for StructureTransforming {}
impl StructureLaw for StructureReductive {}

// --- Effect ---
pub struct Pure;
pub struct ReadOnly;
pub struct StatefulDeclared;

impl EffectLaw for Pure {}
impl EffectLaw for ReadOnly {}
impl EffectLaw for StatefulDeclared {}

// --- Markers ---
pub trait RequiredLaw {}
pub trait ForbiddenLaw {}
pub trait AllowedLaw {}

pub struct Required;
pub struct Forbidden;
pub struct Allowed;

impl RequiredLaw for Required {}
impl ForbiddenLaw for Forbidden {}
impl AllowedLaw for Allowed {}

// --- Capability Setting ---
pub trait CapabilitySetting {}
impl CapabilitySetting for Required {}
impl CapabilitySetting for Forbidden {}
impl CapabilitySetting for Allowed {}

// --- Authority Markers ---
pub struct NoAuthority;
pub struct EvidenceOnlyAuthority;
pub struct FactOnlyAuthority;
pub struct RequiresEvaluatorAuthority;
pub struct RequestsDecisionAuthority;
pub struct AuthorizesTransitionAuthority;
pub struct StateTransitionAuthority;

impl AuthorityLaw for NoAuthority {}
impl AuthorityLaw for EvidenceOnlyAuthority {}
impl AuthorityLaw for FactOnlyAuthority {}
impl AuthorityLaw for RequiresEvaluatorAuthority {}
impl AuthorityLaw for RequestsDecisionAuthority {}
impl AuthorityLaw for AuthorizesTransitionAuthority {}
impl AuthorityLaw for StateTransitionAuthority {}

// --- Base Profile ---
pub trait StrictContractLaw: BoundContract {
    type Authority: AuthorityLaw;
    type EmitsDecision: CapabilitySetting;
    type EmitsCertificate: CapabilitySetting;
    type EmitsAction: CapabilitySetting;
    type MutatesState: CapabilitySetting;
    type ExecutesTransition: CapabilitySetting;
    type CallsSolver: CapabilitySetting;
    type CallsLlm: CapabilitySetting;
}

// --- Specialized Profiles ---
pub trait StrictCandidateLaw: StrictContractLaw {
    type PhiClaim: PhiLaw;
    type StructureClaim: StructureLaw;
    type Effect: EffectLaw;
    type EvidenceOnly: RequiredLaw;
    type AdmittedOperatorClass: ForbiddenLaw;
}

pub trait StrictEngineLaw: StrictContractLaw {
    type StateTransition: RequiredLaw;
    type ComputesPhi: ForbiddenLaw;
    type ComputesGamma: ForbiddenLaw;
    type SignsCertificate: ForbiddenLaw;
    type TerminalizesInternally: ForbiddenLaw;
}

pub trait StrictCertificateLaw: StrictContractLaw {
    type ImmutableAfterEmit: RequiredLaw;
    type SignatureOrHash: RequiredLaw;
    type EvidenceRefs: RequiredLaw;
    type AuthorityNotExceedEvidence: RequiredLaw;
}

// --- Specific Authority Laws ---
pub trait StrictPolicyLaw: StrictContractLaw {
    type MetricComputation: ForbiddenLaw;
    type SolverExecution: ForbiddenLaw;
    type Terminalization: ForbiddenLaw;
    type Mutation: ForbiddenLaw;
    type Determinism: RequiredLaw;
}

pub trait StrictWitnessLaw: StrictContractLaw {
    type AuthorityEffectEvidenceOnly: RequiredLaw;
    type AdmissibilityDecision: ForbiddenLaw;
    type Mutation: ForbiddenLaw;
    type SourceArtifacts: RequiredLaw;
}

pub trait StrictReplayLaw: StrictContractLaw {
    type ReadOnly: RequiredLaw;
    type Mutation: ForbiddenLaw;
    type ReplayManifest: RequiredLaw;
    type ReplayHash: RequiredLaw;
    type PolicyHash: RequiredLaw;
}

pub trait StrictTerminalizerLaw: StrictContractLaw {
    type Certificate: RequiredLaw;
    type PolicyInterpretation: ForbiddenLaw;
    type MetricComputation: ForbiddenLaw;
    type Signing: ForbiddenLaw;
}

pub trait StrictPublicVerifyLaw: StrictContractLaw {
    type ReadOnly: RequiredLaw;
    type Signing: ForbiddenLaw;
    type Mutation: ForbiddenLaw;
    type RawPayload: ForbiddenLaw;
}

pub trait StrictMathObjectLaw: StrictContractLaw {
    type EmitsDecision: ForbiddenLaw;
    type EmitsCertificate: ForbiddenLaw;
    type EmitsAction: ForbiddenLaw;
    type CustomerClaim: ForbiddenLaw;
}

pub trait StrictMathComputationLaw: StrictContractLaw {
    type EmitsDecision: ForbiddenLaw;
    type EmitsCertificate: ForbiddenLaw;
    type EmitsAction: ForbiddenLaw;
    type CustomerClaim: ForbiddenLaw;
}

pub trait StrictLlmAdapterLaw: StrictContractLaw {
    type SelfCertification: ForbiddenLaw;
    type EmitsCertificate: ForbiddenLaw;
    type Terminalization: ForbiddenLaw;
    type RawResponseHash: RequiredLaw;
    type ParsedCandidateMapping: RequiredLaw;
}

pub trait StrictPacketizationLaw: StrictContractLaw {
    type LosslessRoundtrip: RequiredLaw;
    type ParserRequired: RequiredLaw;
    type GrammarRequired: RequiredLaw;
    type SemanticCertification: ForbiddenLaw;
}

// --- Assertions ---
pub trait SameLaw<T> {}
impl<T> SameLaw<T> for T {}

pub fn assert_candidate_laws<C>()
where
    C: StrictCandidateLaw<EvidenceOnly = Required, AdmittedOperatorClass = Forbidden>,
{
}

pub fn assert_engine_laws<C>()
where
    C: StrictEngineLaw<
        StateTransition = Required,
        ComputesPhi = Forbidden,
        ComputesGamma = Forbidden,
        SignsCertificate = Forbidden,
        TerminalizesInternally = Forbidden,
    >,
{
}

pub fn assert_certificate_laws<C>()
where
    C: StrictCertificateLaw<
        ImmutableAfterEmit = Required,
        SignatureOrHash = Required,
        EvidenceRefs = Required,
        AuthorityNotExceedEvidence = Required,
    >,
{
}

pub fn assert_policy_laws<C>()
where
    C: StrictPolicyLaw<
        MetricComputation = Forbidden,
        SolverExecution = Forbidden,
        Terminalization = Forbidden,
        Mutation = Forbidden,
        Determinism = Required,
    >,
{
}

pub fn assert_witness_laws<C>()
where
    C: StrictWitnessLaw<
        AuthorityEffectEvidenceOnly = Required,
        AdmissibilityDecision = Forbidden,
        Mutation = Forbidden,
        SourceArtifacts = Required,
    >,
{
}

pub fn assert_replay_laws<C>()
where
    C: StrictReplayLaw<
        ReadOnly = Required,
        Mutation = Forbidden,
        ReplayManifest = Required,
        ReplayHash = Required,
        PolicyHash = Required,
    >,
{
}

pub fn assert_terminalizer_laws<C>()
where
    C: StrictTerminalizerLaw<
        Certificate = Required,
        PolicyInterpretation = Forbidden,
        MetricComputation = Forbidden,
        Signing = Forbidden,
    >,
{
}

pub fn assert_public_verify_laws<C>()
where
    C: StrictPublicVerifyLaw<
        ReadOnly = Required,
        Signing = Forbidden,
        Mutation = Forbidden,
        RawPayload = Forbidden,
    >,
{
}

pub fn assert_math_object_laws<C>()
where
    C: StrictMathObjectLaw<
        EmitsDecision = Forbidden,
        EmitsCertificate = Forbidden,
        EmitsAction = Forbidden,
        CustomerClaim = Forbidden,
    >,
{
}

pub fn assert_math_computation_laws<C>()
where
    C: StrictMathComputationLaw<
        EmitsDecision = Forbidden,
        EmitsCertificate = Forbidden,
        EmitsAction = Forbidden,
        CustomerClaim = Forbidden,
    >,
{
}

pub fn assert_llm_adapter_laws<C>()
where
    C: StrictLlmAdapterLaw<
        SelfCertification = Forbidden,
        EmitsCertificate = Forbidden,
        Terminalization = Forbidden,
        RawResponseHash = Required,
        ParsedCandidateMapping = Required,
    >,
{
}

pub fn assert_packetization_laws<C>()
where
    C: StrictPacketizationLaw<
        LosslessRoundtrip = Required,
        ParserRequired = Required,
        GrammarRequired = Required,
        SemanticCertification = Forbidden,
    >,
{
}
