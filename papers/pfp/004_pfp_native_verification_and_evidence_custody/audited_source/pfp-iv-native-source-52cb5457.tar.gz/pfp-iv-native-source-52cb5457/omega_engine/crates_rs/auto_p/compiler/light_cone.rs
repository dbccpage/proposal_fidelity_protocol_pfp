//! --- yaml
//! title: distributed_light_cone
//! file_name: light_cone.rs
//! file_location: omega_core/src/compiler/light_cone.rs
//! ---
//! Upgrade 12: Distributed Light-Cone Propagation [Paper 027]
//!
//! Secures local causal constraints bounded by the Lieb-Robinson velocity ($v_{LR}$) of the
//! causal spacetime presheaf across concurrent distributed compute engines.

pub struct CausalLightCone {
    // Topologically, the speed of light c maps directly to the Lieb-Robinson bound v_LR
    pub lr_velocity: f64,
}

impl CausalLightCone {
    pub fn new(lr_velocity: f64) -> Self {
        Self { lr_velocity }
    }

    /// Bound iterative 'healing' iterations strictly inside the relative AST light cone.
    /// Defends async environments structurally against acausal topological corruptions.
    pub fn is_within_causal_bound(
        &self,
        ast_distance: usize,
        healing_iteration_depth: u32,
    ) -> bool {
        // max causality propagation geometry (v * t)
        let max_radius = self.lr_velocity * (healing_iteration_depth as f64);
        (ast_distance as f64) <= max_radius
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const EPS: f64 = 1e-12;

    #[test]
    fn distance_zero_always_within_bound() {
        let cone = CausalLightCone::new(1.0);

        // Distance 0 is always within bound regardless of depth
        assert!(cone.is_within_causal_bound(0, 0));
        assert!(cone.is_within_causal_bound(0, 1));
        assert!(cone.is_within_causal_bound(0, 100));
    }

    #[test]
    fn distance_exceeds_velocity_times_depth_is_outside() {
        let cone = CausalLightCone::new(2.0);

        // max_radius = 2.0 * 3 = 6.0
        // distance 7 > 6.0 => outside bound
        assert!(!cone.is_within_causal_bound(7, 3));

        // distance 10 > 6.0 => outside bound
        assert!(!cone.is_within_causal_bound(10, 3));
    }

    #[test]
    fn exact_boundary_case_is_within() {
        let cone = CausalLightCone::new(2.5);

        // max_radius = 2.5 * 4 = 10.0
        // distance 10 == 10.0 => within bound (<=)
        assert!(cone.is_within_causal_bound(10, 4));
    }

    #[test]
    fn just_inside_boundary_is_within() {
        let cone = CausalLightCone::new(2.5);

        // max_radius = 2.5 * 4 = 10.0
        // distance 9 < 10.0 => within bound
        assert!(cone.is_within_causal_bound(9, 4));
    }

    #[test]
    fn just_outside_boundary_is_outside() {
        let cone = CausalLightCone::new(2.5);

        // max_radius = 2.5 * 4 = 10.0
        // distance 11 > 10.0 => outside bound
        assert!(!cone.is_within_causal_bound(11, 4));
    }

    #[test]
    fn zero_velocity_only_allows_distance_zero() {
        let cone = CausalLightCone::new(0.0);

        // max_radius = 0.0 * depth = 0.0
        // Only distance 0 is within bound
        assert!(cone.is_within_causal_bound(0, 0));
        assert!(cone.is_within_causal_bound(0, 10));
        assert!(!cone.is_within_causal_bound(1, 10));
        assert!(!cone.is_within_causal_bound(1, 100));
    }

    #[test]
    fn constructor_sets_velocity() {
        let cone = CausalLightCone::new(3.14159);
        assert!((cone.lr_velocity - 3.14159).abs() < EPS);
    }

    #[test]
    fn large_depth_expands_boundary() {
        let cone = CausalLightCone::new(1.0);

        // max_radius = 1.0 * 100 = 100.0
        assert!(cone.is_within_causal_bound(100, 100));
        assert!(!cone.is_within_causal_bound(101, 100));
    }
}
