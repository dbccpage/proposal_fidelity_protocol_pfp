pub trait NamedComponent {
    fn name(&self) -> &'static str;
}

pub trait ContractBound {
    fn contract_id(&self) -> &'static str;
    fn schema_id(&self) -> Option<&'static str> {
        None
    }
}
