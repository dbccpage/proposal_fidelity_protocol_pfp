//! Deeper contract conformance: generated compile-time image descriptors must agree with
//! the canonical YAML contracts they represent.

use omega_contracts::binding::{audit_contract_type_bindings, GeneratedContractImage};
use omega_contracts::contract_images::{
    CochainComplexContract, CouncilDecisionContract, FiniteObstructionTrichotomyContract,
    InvariantDefectProfileContract, GENERATED_CONTRACT_IMAGE_CATALOG,
};
use omega_contracts::registry::OmegaContractV1;
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

fn collect_contracts(dir: &Path, out: &mut Vec<PathBuf>) {
    let Ok(rd) = std::fs::read_dir(dir) else {
        return;
    };
    for entry in rd.flatten() {
        let p = entry.path();
        if p.is_dir() {
            collect_contracts(&p, out);
        } else if p
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n.ends_with(".contract.yaml"))
        {
            out.push(p);
        }
    }
}

fn v1_contracts_by_id() -> BTreeMap<String, OmegaContractV1> {
    let corpus = Path::new(env!("CARGO_MANIFEST_DIR")).join("src/contract_canonical_definitions");
    let mut files = Vec::new();
    collect_contracts(&corpus, &mut files);

    let mut out = BTreeMap::new();
    for path in files {
        let text = std::fs::read_to_string(path).expect("contract readable");
        let Ok(shallow) = serde_yaml::from_str::<serde_yaml::Value>(&text) else {
            continue;
        };
        if shallow.get("schema_version").and_then(|v| v.as_str()) != Some("omega.contract.v1") {
            continue;
        }
        let c: OmegaContractV1 = serde_yaml::from_str(&text).expect("v1 contract parses");
        out.insert(c.contract_id.clone(), c);
    }
    out
}

#[test]
fn generated_image_catalog_covers_every_v1_rust_binding() {
    let contracts = v1_contracts_by_id();
    let expected: BTreeSet<_> = contracts
        .values()
        .filter(|c| c.rust_binding.is_some())
        .map(|c| c.contract_id.as_str())
        .collect();
    let actual: BTreeSet<_> = GENERATED_CONTRACT_IMAGE_CATALOG
        .iter()
        .map(|entry| entry.id)
        .collect();

    assert_eq!(
        actual, expected,
        "generated image catalog must cover exactly the v1 rust_binding contracts"
    );
}

#[test]
fn generated_image_descriptors_match_yaml_projection() {
    let contracts = v1_contracts_by_id();
    for entry in GENERATED_CONTRACT_IMAGE_CATALOG {
        let c = contracts
            .get(entry.id)
            .unwrap_or_else(|| panic!("catalog entry {} must have a YAML contract", entry.id));
        let proj = c.to_descriptor();
        let d = entry.descriptor;
        assert_eq!(d.id, proj.id.as_str(), "id mismatch for {}", entry.id);
        assert_eq!(
            d.category, proj.category,
            "category mismatch for {}",
            entry.id
        );
        assert_eq!(d.role, proj.role, "role mismatch for {}", entry.id);
        assert_eq!(d.status, proj.status, "status mismatch for {}", entry.id);
        assert_eq!(
            d.authority_effect, proj.authority_effect,
            "authority_effect mismatch for {}",
            entry.id
        );
    }
}

#[test]
fn existing_public_image_type_bindings_are_consistent() {
    assert!(audit_contract_type_bindings::<InvariantDefectProfileContract>().is_ok());
    assert!(audit_contract_type_bindings::<CochainComplexContract>().is_ok());
    assert!(audit_contract_type_bindings::<FiniteObstructionTrichotomyContract>().is_ok());
    assert!(audit_contract_type_bindings::<CouncilDecisionContract>().is_ok());
}

#[test]
fn existing_public_image_names_still_point_at_expected_contracts() {
    assert_eq!(
        InvariantDefectProfileContract::DESCRIPTOR.id,
        "urn:omega:math:invariant_defect_profile:v1.0.0"
    );
    assert_eq!(
        CochainComplexContract::DESCRIPTOR.id,
        "urn:omega:math:cochain_complex:v1.0.0"
    );
    assert_eq!(
        FiniteObstructionTrichotomyContract::DESCRIPTOR.id,
        "urn:omega:math:finite_obstruction_trichotomy:v0.2.0"
    );
    assert_eq!(
        CouncilDecisionContract::DESCRIPTOR.id,
        "urn:omega:governance:council_decision:v1.0.0"
    );
}
