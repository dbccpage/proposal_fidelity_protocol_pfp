//! Warning-only audit of how governance contracts bind to Rust in `crates_rs`.
//!
//! `build.rs` runs [`audit::audit`] over the repository and prints what it
//! finds as cargo warnings. [`summary`] holds the counts from that run, so the
//! later switch from warning to enforcement is a test that asserts on them.
//! AuthorityEffect: None.

pub mod audit;

/// Counts from the audit that ran when this crate was built.
pub mod summary {
    include!(concat!(env!("OUT_DIR"), "/binding_audit_summary.rs"));
}
