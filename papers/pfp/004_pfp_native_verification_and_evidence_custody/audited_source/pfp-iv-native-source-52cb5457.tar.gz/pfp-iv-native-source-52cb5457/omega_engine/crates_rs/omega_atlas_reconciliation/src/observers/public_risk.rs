//! public-risk observer: public copy may not use forbidden minting language.
//!
//! "Certificate != authority": public-facing copy must not claim that the system *certifies*,
//! *proves*, *verifies* truth, is *machine-checked*, or *predicts* — that language smuggles
//! authority the system does not hold. Each forbidden term found in the claim copy raises one
//! finding.
use super::ObserverReading;
use crate::row::ReconciliationRow;

/// Terms whose presence in public claim copy mints authority the system does not hold.
const FORBIDDEN_TERMS: &[&str] = &[
    "certificate",
    "proves",
    "verified",
    "machine-checked",
    "predicts",
    "certifies truth",
];

/// Match `word` in `text` only at ASCII word boundaries, so a forbidden term embedded inside an
/// innocent word does not fire (e.g. `"proves"` inside `"approves"`/`"improves"`, `"verified"`
/// inside `"unverified"`). Hyphenated terms (`machine-checked`) and multi-word terms
/// (`certifies truth`) still match because `-` and space are non-alphanumeric boundaries.
fn has_word_boundary(text: &str, word: &str) -> bool {
    if word.is_empty() {
        return false;
    }
    let mut start = 0;
    while let Some(idx) = text[start..].find(word) {
        let absolute_idx = start + idx;
        let left_ok =
            absolute_idx == 0 || !text.as_bytes()[absolute_idx - 1].is_ascii_alphanumeric();
        let right_ok = absolute_idx + word.len() == text.len()
            || !text.as_bytes()[absolute_idx + word.len()].is_ascii_alphanumeric();
        if left_ok && right_ok {
            return true;
        }
        start = absolute_idx + 1;
    }
    false
}

/// Deterministic public-risk reading for a row.
pub fn check(row: &ReconciliationRow) -> ObserverReading {
    // The public-copy firewall only governs PUBLIC-facing rows; Private/Research copy is
    // not under the public-minting constraint, so stay silent there.
    if row.surface != crate::row::Surface::Public {
        return ObserverReading {
            observer: "public-risk",
            findings: Vec::new(),
        };
    }

    let mut findings = Vec::new();
    let claimed = row.claimed.to_lowercase();

    for term in FORBIDDEN_TERMS {
        if has_word_boundary(&claimed, term) {
            findings.push(format!("forbidden public copy: '{}'", term));
        }
    }

    ObserverReading {
        observer: "public-risk",
        findings,
    }
}
