//! system-seam observer: a claimed product must be reachable as a runnable surface.
//!
//! A "product" that is not re-exported through `omega_core`, or whose only stated surface is
//! an unreachable `/healthz`-style endpoint, has a runnable-surface gap: the claim cannot be
//! exercised end-to-end via `omega_core` / `omega_api`.
use super::ObserverReading;
use crate::row::ReconciliationRow;

/// Deterministic system-seam reading for a row.
pub fn check(row: &ReconciliationRow) -> ObserverReading {
    let mut findings = Vec::new();
    let observed = row.observed.to_lowercase();

    if observed.contains("not re-exported") || observed.contains("/healthz") {
        findings.push(
            "runnable surface gap: claimed product not reachable via omega_core/omega_api"
                .to_string(),
        );
    }

    ObserverReading {
        observer: "system-seam",
        findings,
    }
}
