//! The seven deterministic observers.
//!
//! Reconciliation is cross-examined from seven independent vantage points, each a pure,
//! deterministic function over a single [`crate::row::ReconciliationRow`]. No observer
//! mints authority and none performs repo I/O in this phase — every reading is a finite
//! judgment derived from the row's own fields, so the same row always yields the same
//! findings. The seven vantage points are:
//!
//! 1. **code-reality** — does committed source correspond to a built, passing artifact?
//! 2. **math-proof** — is prose mechanization honestly distinguished from Lean, and is the
//!    proof relative to a declared axiom rather than "unconditionally proved"?
//! 3. **product-claim** — what signed LGGR defect (NGD / PGD / claim-without-code) does
//!    the claim delta encode?
//! 4. **contract-authority** — does the declared authority effect exceed its role pin?
//! 5. **public-risk** — does the public copy use forbidden minting language?
//! 6. **system-seam** — is the claimed product actually reachable as a runnable surface?
//! 7. **government-law** — is a governance change a complete licensed lift, and may a role
//!    hold a given power?
//
// TODO(phase3): link live omega_contract_core::validate / anomalon_councils so observer
// readings can be cross-checked against the canonical contract corpus and live role pins.
pub mod code;
pub mod contract_authority;
pub mod government_law;
pub mod math_proof;
pub mod product_claim;
pub mod public_risk;
pub mod system_seam;

use crate::row::ReconciliationRow;

/// One observer's deterministic reading of a row: its name plus the findings it raised.
/// An empty `findings` vector means that observer is satisfied with the row.
#[derive(Debug, Clone)]
pub struct ObserverReading {
    pub observer: &'static str,
    pub findings: Vec<String>,
}

/// Run all seven observers over a row and collect their readings, in the canonical
/// 1..=7 order above. Always returns exactly seven readings.
pub fn run_all(row: &ReconciliationRow) -> Vec<ObserverReading> {
    vec![
        code::check(row),
        math_proof::check(row),
        product_claim::check(row),
        contract_authority::check(row),
        public_risk::check(row),
        system_seam::check(row),
        government_law::check(row),
    ]
}
