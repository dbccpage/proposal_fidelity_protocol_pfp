//! Invariant (II) — cochain validity `d1 ∘ d0 = 0`.
//!
//! Mirrors OmegaCosmology.Primitives.FiniteObstructionTrichotomy and
//! OmegaCosmology.Primitives.ProjectionObstructionQuotient in
//! omega_engine/lean4/003_quantum_foundations/qm_015_qm_typed_authority_boundary_suite/:
//! every reconciliation chain must form a valid cochain complex, so the composite of
//! consecutive coboundary maps vanishes over F2. A chain whose dimensions do not compose
//! is malformed and yields `Unknown` (it cannot even be evaluated).
use serde::{Deserialize, Serialize};

/// Tri-stated validity of `d1 ∘ d0 = 0`.
///
/// * `True`    — the composite verifiably vanishes (valid cochain).
/// * `False`   — the composite is verifiably nonzero (invalid cochain).
/// * `Unknown` — cannot be evaluated (empty, or dimensions do not compose).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TriState {
    True,
    False,
    Unknown,
}

/// Serializable record of one cochain-validity judgment.
///
/// Carrier model (PROVISIONAL — doctrine v000, falsifiable, NOT established truth):
/// C⁰ = corrections a layer can emit, C¹ = downstream defects, C² = closure obligations;
/// d₀ = correction→defect incidence, d₁ = defect→obligation incidence. d₁∘d₀ = 0 ⟺ every
/// correction's emitted defects are jointly closed (mod 2). A nonzero composite ⇒ a correction
/// emits a downstream defect that nothing closes ⇒ RepresentationMalformed. An alternative CODA-OR
/// commuting-diamond model may supersede this; the loop records which model it used so a wrong
/// choice terminalizes as an obstruction, not a silent error.
///
/// `d1_d0_zero` is now the DECLARED value (what the proposer claims); the carried `d0`/`d1`
/// matrices are the source of truth. [`CochainValidity::computed_d1_d0_zero`] computes the actual
/// composite via [`check_d1_d0_zero_f2`]; the validator compares declared against computed and
/// flags any disagreement (the declared flag is never trusted on its own).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CochainValidity {
    pub chain: Vec<String>,
    pub d0_declared: String,
    pub d1_declared: String,
    pub d1_d0_zero: TriState,
    pub failure_reason: String,
    pub terminal_if_failed: Option<String>,
    /// F2 boundary matrix C⁰→C¹ (corrections → downstream defects). Provisional carrier model.
    pub d0: Vec<Vec<u8>>,
    /// F2 boundary matrix C¹→C² (defects → closure obligations). Provisional carrier model.
    pub d1: Vec<Vec<u8>>,
}

impl CochainValidity {
    /// Compute d₁∘d₀ over the carried F2 matrices (the source of truth — never trust the declared flag).
    pub fn computed_d1_d0_zero(&self) -> TriState {
        check_d1_d0_zero_f2(&self.d1, &self.d0)
    }
}

/// Compute `d1 · d0` over F2 and return whether it is the zero map.
///
/// `d0` is a matrix of `d0.len()` rows (the C1 dimension) by `cols` columns. Each row `r` of
/// `d1` must have inner length `r.len() == d0.len()`; otherwise the dimensions do not compose
/// and the result is `Unknown`. For each `d1` row `r` and each column `j`, the entry of the
/// composite is `XOR over k of (r[k] & d0[k][j])`. Returns `False` if any composite entry is
/// nonzero, else `True`. Empty input is `Unknown`.
pub fn check_d1_d0_zero_f2(d1: &[Vec<u8>], d0: &[Vec<u8>]) -> TriState {
    if d1.is_empty() || d0.is_empty() {
        return TriState::Unknown;
    }
    let cols = d0[0].len();
    for row in d0 {
        if row.len() != cols {
            return TriState::Unknown;
        }
    }
    for r in d1 {
        if r.len() != d0.len() {
            return TriState::Unknown;
        }
        for j in 0..cols {
            let mut acc: u8 = 0;
            for k in 0..d0.len() {
                // Reduce mod 2: mask each product to its low bit so a non-binary input
                // (e.g. a stray `2`) cannot silently XOR-cancel (2 ^ 2 == 0).
                acc ^= (r[k] & d0[k][j]) & 1;
            }
            if acc != 0 {
                return TriState::False;
            }
        }
    }
    TriState::True
}
