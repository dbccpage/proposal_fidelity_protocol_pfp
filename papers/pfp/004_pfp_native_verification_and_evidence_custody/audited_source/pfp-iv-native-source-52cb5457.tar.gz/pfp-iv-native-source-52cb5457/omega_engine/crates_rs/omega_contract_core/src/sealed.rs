pub trait Sealed {}
