//! Markdown renderer: a header row plus one line per reconciliation row.
use omega_atlas_reconciliation::render::render_md;
use omega_atlas_reconciliation::row::ReconciliationRow;

#[test]
fn render_md_has_header_and_row() {
    let out = render_md(&[ReconciliationRow::sample_good()]);
    assert!(out.contains("| asset | claim_delta | terminal | verdict |"));
    assert!(out.contains("| omega_types::authority | Undersold |"));
}
