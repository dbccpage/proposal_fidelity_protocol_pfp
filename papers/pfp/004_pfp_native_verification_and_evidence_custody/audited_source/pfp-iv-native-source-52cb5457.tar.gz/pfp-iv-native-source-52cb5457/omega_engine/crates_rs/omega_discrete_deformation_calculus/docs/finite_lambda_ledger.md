Finite Lambda Ledger
====================

`FiniteLambdaLedger` is the sequence-level exact descent record driven by the [finite-lambda ledger obstruction packet](../../omega_contracts/src/contract_canonical_definitions/core/09_packets/omega_finite_lambda_ledger_packet.md): non-final rows must pass `require_descent_step`, the final row must pass `require_valid`, and all endpoints must compose exactly. It is domain evidence for the shared [GTOC/GTLA pipeline](../../omega_pipeline/src/gtoc_gtla.rs), not a second obstruction classifier or an authority constructor. A sweep-kernel `Certificate` is only a product-local lane stamp; canonical authority remains gated by `omega_certifiers::certify_checked_packet` with exact checked evidence, a packet-bound descent witness, and decided `IsAuth`.
