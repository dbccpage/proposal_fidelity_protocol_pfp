//! Law bindings for generated contract images.
//!
//! `descriptors::laws` declares what each component role may and may not do, and
//! `build.rs` generates 412 contract images from the YAML corpus. Until a given
//! image declares its laws here, the two never meet: the law is written, the
//! contract exists, and nothing connects them.
//!
//! Binding an image is two lines of intent and one compile-time proof. The
//! `assert_*_laws` calls in the test module are the proof — each one fails to
//! compile if the associated types are not exactly what the law requires, so a
//! future edit that softens `Mutation` from `Forbidden` to `Required` is a build
//! error rather than a silent loosening.
//!
//! AuthorityEffect: None.

use crate::contract_images::{
    AppendLogContract, CouncilDecisionContract, CouncilMeetingAgendaContract,
    CouncilMeetingMinutesContract, DualTraceMemoryContract, ReplayKernelContract,
    ReplayTraceContainersContract, RetentionContract, SecretScrubberContract,
    TraceArtifactContract, TraceConfigContract, TracePathsContract, TracePolicyContract,
    TraceWriterContract,
};
use crate::descriptors::laws::{
    EffectEvidenceOnly, EvidenceEnvelopeFamily, Forbidden, Required, StrictContractLaw,
    StrictPolicyContract, StrictReplayContract, StrictTraceContract,
};

// ─── Trace ───────────────────────────────────────────────────────────────────
//
// A trace records what happened. It may not reinterpret it.

impl StrictContractLaw for TraceArtifactContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for TraceArtifactContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for TraceWriterContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for TraceWriterContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

// ─── Replay ──────────────────────────────────────────────────────────────────
//
// Replay recomputes and compares. A replayer that could repair would be able to
// make any trace verify.

impl StrictContractLaw for ReplayKernelContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictReplayContract for ReplayKernelContract {
    type ReadOnly = Required;
    type Mutation = Forbidden;
    type Repair = Forbidden;
    type Execution = Forbidden;
    type ReplayManifest = Required;
}


impl StrictContractLaw for AppendLogContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for AppendLogContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for ReplayTraceContainersContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for ReplayTraceContainersContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for RetentionContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for RetentionContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for SecretScrubberContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for SecretScrubberContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for TraceConfigContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for TraceConfigContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for TracePathsContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictTraceContract for TracePathsContract {
    type ImmutableAfterEmit = Required;
    type Mutation = Forbidden;
    type Certification = Forbidden;
    type PolicyInterpretation = Forbidden;
    type Execution = Forbidden;
}

impl StrictContractLaw for DualTraceMemoryContract {
    type Authority = EffectEvidenceOnly;
    type PrimaryFamily = EvidenceEnvelopeFamily;
}

impl StrictReplayContract for DualTraceMemoryContract {
    type ReadOnly = Required;
    type Mutation = Forbidden;
    type Repair = Forbidden;
    type Execution = Forbidden;
    type ReplayManifest = Required;
}

// ─── Policy ──────────────────────────────────────────────────────────────────
//
// Policy states thresholds and routes. It does not compute the numbers it routes
// on, run the solver, or decide the terminal -- those belong to the functional,
// the solver and the terminalizer respectively. Determinism is required because
// a policy that varies between replays makes the trace unreplayable.

impl StrictPolicyContract for TracePolicyContract {
    type MetricComputation = Forbidden;
    type SolverExecution = Forbidden;
    type Terminalization = Forbidden;
    type Mutation = Forbidden;
    type Determinism = Required;
}

impl StrictPolicyContract for CouncilDecisionContract {
    type MetricComputation = Forbidden;
    type SolverExecution = Forbidden;
    type Terminalization = Forbidden;
    type Mutation = Forbidden;
    type Determinism = Required;
}

impl StrictPolicyContract for CouncilMeetingAgendaContract {
    type MetricComputation = Forbidden;
    type SolverExecution = Forbidden;
    type Terminalization = Forbidden;
    type Mutation = Forbidden;
    type Determinism = Required;
}

impl StrictPolicyContract for CouncilMeetingMinutesContract {
    type MetricComputation = Forbidden;
    type SolverExecution = Forbidden;
    type Terminalization = Forbidden;
    type Mutation = Forbidden;
    type Determinism = Required;
}

// ─── Packetization: deliberately unbound ─────────────────────────────────────
//
// urn:omega:evidence:checked_packet:v1.0.0 declares fact_only and binds
// omega_certifiers::checked_packet -- the sealed CheckedPacket whose constructor
// demands VerifiedExactPhi1 and CertifiedExactTrichotomy. It earned FactOnly by
// requiring exact evidence, so binding it to StrictPacketizationContract (which
// requires EffectEvidenceOnly) would assert a law the corpus contradicts.
//
// It is a different object from omega_types::CheckedPacket, the transport
// boundary, which is correctly Uncertified. laws.rs has no Strict*Contract for a
// FactOnly artifact; that gap is real and is not filled by guessing here.

#[cfg(test)]
mod law_conformance {
    use super::*;
    use crate::descriptors::laws::{
        assert_policy_laws, assert_replay_laws, assert_trace_laws,
    };
    use crate::kinds::{ComponentRole, ContractEffect};
    use crate::binding::GeneratedContractImage;

    #[test]
    fn trace_images_satisfy_the_trace_laws() {
        assert_trace_laws::<TraceArtifactContract>();
        assert_trace_laws::<TraceWriterContract>();
        assert_trace_laws::<AppendLogContract>();
        assert_trace_laws::<ReplayTraceContainersContract>();
        assert_trace_laws::<RetentionContract>();
        assert_trace_laws::<SecretScrubberContract>();
        assert_trace_laws::<TraceConfigContract>();
        assert_trace_laws::<TracePathsContract>();
    }

    #[test]
    fn replay_images_satisfy_the_replay_laws() {
        assert_replay_laws::<ReplayKernelContract>();
        assert_replay_laws::<DualTraceMemoryContract>();
    }

    #[test]
    fn policy_images_satisfy_the_policy_laws() {
        assert_policy_laws::<TracePolicyContract>();
        assert_policy_laws::<CouncilDecisionContract>();
        assert_policy_laws::<CouncilMeetingAgendaContract>();
        assert_policy_laws::<CouncilMeetingMinutesContract>();
    }

    /// The laws above are hand-declared; the descriptor is generated from YAML.
    /// If they disagree, the binding is asserting something the corpus does not
    /// say, so this checks the one field both sides carry.
    #[test]
    fn every_bound_image_declares_evidence_only_in_its_generated_descriptor() {
        for descriptor in [
            TraceArtifactContract::DESCRIPTOR,
            TraceWriterContract::DESCRIPTOR,
            AppendLogContract::DESCRIPTOR,
            ReplayTraceContainersContract::DESCRIPTOR,
            RetentionContract::DESCRIPTOR,
            SecretScrubberContract::DESCRIPTOR,
            TraceConfigContract::DESCRIPTOR,
            TracePathsContract::DESCRIPTOR,
            ReplayKernelContract::DESCRIPTOR,
            DualTraceMemoryContract::DESCRIPTOR,
        ] {
            assert_eq!(
                descriptor.authority_effect,
                ContractEffect::EvidenceOnly,
                "{} binds StrictContractLaw<Authority = EffectEvidenceOnly> but its \
                 generated descriptor says otherwise",
                descriptor.id
            );
        }
    }

    /// Roles are generated too, and a trace law bound to a non-trace role would
    /// be a category error the type system cannot see.
    #[test]
    fn bound_images_carry_the_role_their_law_belongs_to() {
        assert_eq!(TraceArtifactContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(TraceWriterContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(AppendLogContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(ReplayTraceContainersContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(RetentionContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(SecretScrubberContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(TraceConfigContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(TracePathsContract::DESCRIPTOR.role, ComponentRole::Trace);
        assert_eq!(ReplayKernelContract::DESCRIPTOR.role, ComponentRole::Replay);
        assert_eq!(DualTraceMemoryContract::DESCRIPTOR.role, ComponentRole::Replay);
        assert_eq!(TracePolicyContract::DESCRIPTOR.role, ComponentRole::Policy);
        assert_eq!(CouncilDecisionContract::DESCRIPTOR.role, ComponentRole::Policy);
        assert_eq!(CouncilMeetingAgendaContract::DESCRIPTOR.role, ComponentRole::Policy);
        assert_eq!(CouncilMeetingMinutesContract::DESCRIPTOR.role, ComponentRole::Policy);
    }
}
