//! The strict first reconciliation slice, as ordered data.
//!
//! Architect ruling: **government before product**. The slice is descended in four tiers and
//! the descent order is load-bearing — authority core is reconciled first, then the
//! government core that pins it, then the encyclopedia library it cites, and only then the
//! product spine that consumes all three:
//!
//! A. **AuthorityCore** — the types and contracts that define what authority *is*.
//! B. **GovernmentCore** — the council runtime and governance enforcement that pin authority.
//! C. **EncLibrary** — the encyclopedia / finite-library the claims cite.
//! D. **ProductSpine** — the representation / certifier / sweep surfaces shipped to users.
//!
//! [`strict_slice`] returns the assets already sorted so every AuthorityCore precedes every
//! GovernmentCore, which precedes every EncLibrary, which precedes every ProductSpine.

/// The four reconciliation tiers, in strict descent order.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SliceTier {
    AuthorityCore,
    GovernmentCore,
    EncLibrary,
    ProductSpine,
}

/// A single asset in the strict slice, tagged with its tier.
pub struct SliceAsset {
    pub tier: SliceTier,
    pub asset: &'static str,
}

/// The strict first slice in A->B->C->D order (government before product). The returned Vec is
/// ordered so all AuthorityCore precede all GovernmentCore precede all EncLibrary precede all
/// ProductSpine.
pub fn strict_slice() -> Vec<SliceAsset> {
    use SliceTier::*;
    vec![
        // A — AuthorityCore
        SliceAsset {
            tier: AuthorityCore,
            asset: "omega_types",
        },
        SliceAsset {
            tier: AuthorityCore,
            asset: "omega_contract_core",
        },
        SliceAsset {
            tier: AuthorityCore,
            asset: "omega_contracts",
        },
        // B — GovernmentCore
        SliceAsset {
            tier: GovernmentCore,
            asset: "anomalon_councils",
        },
        SliceAsset {
            tier: GovernmentCore,
            asset: "omega_governance",
        },
        // C — EncLibrary
        SliceAsset {
            tier: EncLibrary,
            asset: "research/encyclopedia",
        },
        SliceAsset {
            tier: EncLibrary,
            asset: "encyclopedia/entries",
        },
        SliceAsset {
            tier: EncLibrary,
            asset: "encyclopedia/indexes",
        },
        SliceAsset {
            tier: EncLibrary,
            asset: "encyclopedia/manifests",
        },
        SliceAsset {
            tier: EncLibrary,
            asset: "finite-library",
        },
        // D — ProductSpine
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_representation",
        },
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_certifiers",
        },
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_symbol_game",
        },
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_sweep_kernel",
        },
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_proofer",
        },
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_sweeper",
        },
        SliceAsset {
            tier: ProductSpine,
            asset: "omega_epk",
        },
    ]
}
