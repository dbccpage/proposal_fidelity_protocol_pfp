use num_bigint::BigInt;
use num_rational::BigRational;
use omega_certifiers::checked_packet::{
    BoundaryMapsHash, CertificateRef, CertificateVerdict, CheckedClaimKind, CheckedClaimScope,
    CheckedPacket, CheckedPacketArgs, CheckedPacketCertificateError, DefectFieldHash, EvidenceRef,
    ObserverBoundaryHash, ReplayHash, ToleranceProfileHash, WeightsAndGaugesHash,
};
use omega_functional::gamma2::{DegreeOneResidualQ, ExactCochainComplexQ, Gamma2Functional};
use omega_functional::hashes::{CarrierManifestHash, CheckerRef, Hash256};
use omega_functional::phi1::{ExactPhi1Certificate, Phi1Functional};
use omega_functional::trichotomy::{classify_exact, ObstructionDiagnosticClass, TrichotomyOutcome};
use omega_types::authority::{AuthorityTerminal, CertifiedAuthority, DescentWitness, IsAuth};
use omega_types::EvidenceCeiling;
use omega_types::GuardEvidence;

fn r(value: i64) -> BigRational {
    BigRational::from_integer(BigInt::from(value))
}

fn create_evidence(
    primal_residual_val: i64,
    gamma2_complex_val: i64,
) -> (
    omega_functional::phi1::VerifiedExactPhi1,
    omega_functional::trichotomy::CertifiedExactTrichotomy,
) {
    let (omega, primal_residual, dual_witness, reported_value) = if primal_residual_val == 0 {
        (vec![r(1), r(1)], vec![r(0), r(0)], vec![r(0), r(0)], r(0))
    } else {
        (vec![r(2), r(0)], vec![r(1), r(-1)], vec![r(1), r(-1)], r(2))
    };

    let phi1 = Phi1Functional::verify_exact_certificate(ExactPhi1Certificate {
        omega,
        d0: vec![vec![r(1)], vec![r(1)]],
        weights: vec![r(1), r(1)],
        alpha: vec![r(1)],
        primal_residual,
        dual_witness,
        reported_value,
    })
    .unwrap();

    let complex = ExactCochainComplexQ::try_new(
        1,
        2,
        1,
        phi1.d0().to_vec(),
        vec![vec![r(gamma2_complex_val), r(-gamma2_complex_val)]],
    )
    .unwrap();
    let residual = DegreeOneResidualQ::try_new(&complex, phi1.primal_residual().to_vec()).unwrap();
    let gamma2 = Gamma2Functional::try_compute_exact_quotient(&residual).unwrap();
    let TrichotomyOutcome::Classified(trichotomy) = classify_exact(&phi1, &gamma2) else {
        panic!("must classify");
    };
    (phi1, trichotomy)
}

fn args(replay_hash_val: [u8; 32]) -> CheckedPacketArgs {
    CheckedPacketArgs {
        packet_id: Hash256([1; 32]),
        evidence_refs: vec![EvidenceRef(Hash256([2; 32]))],
        checker_ref: CheckerRef("test-checker".to_string()),
        schema_hash: Hash256([3; 32]),
        carrier_hash: CarrierManifestHash(Hash256([4; 32])),
        boundary_maps_hash: BoundaryMapsHash(Hash256([5; 32])),
        weights_and_gauges_hash: WeightsAndGaugesHash(Hash256([6; 32])),
        submitted_defect_hash: DefectFieldHash(Hash256([7; 32])),
        phi1_certificate_ref: CertificateRef(Hash256([8; 32])),
        closure_certificate_ref: CertificateRef(Hash256([9; 32])),
        observer_boundary_hash: ObserverBoundaryHash(Hash256([10; 32])),
        tolerance_profile_hash: ToleranceProfileHash(Hash256([11; 32])),
        replay_hash: ReplayHash(Hash256(replay_hash_val)),
        certificate_status: CertificateVerdict::Verified,
        checked_scope: CheckedClaimScope {
            claim_kind: CheckedClaimKind::ObstructionSummary,
            authority_ceiling: EvidenceCeiling::BoundaryChecked,
            law_refs: vec![],
        },
    }
}

fn dummy_witness() -> DescentWitness {
    DescentWitness::from_verified_replay(
        AuthorityTerminal::ExactRuleDerived,
        "descent:test",
        "0c".repeat(32),
    )
    .expect("witness")
}

fn dummy_is_auth() -> IsAuth {
    IsAuth::decide(
        AuthorityTerminal::ExactRuleDerived,
        GuardEvidence::new_valid(["cand_01"], "K_carrier_01", "blake3:deadbeef"),
    )
    .expect("is_auth")
}

#[test]
fn test_product_certificate_cannot_become_certified_authority() {
    // 1. ClosedResidual
    {
        let (phi1, trichotomy) = create_evidence(1, 0);
        assert_eq!(
            trichotomy.diagnostic_class(),
            ObstructionDiagnosticClass::ClosedResidual
        );
        let packet_args = args([12; 32]); // "0c" repeat 32 hex is [12; 32] dec
        let packet = CheckedPacket::new_checked(packet_args, &phi1, &trichotomy).unwrap();

        let res = packet.certify_evidence(dummy_witness(), dummy_is_auth());
        assert!(
            matches!(
                res,
                Err(CheckedPacketCertificateError::NotAuthorityBearing(
                    ObstructionDiagnosticClass::ClosedResidual
                ))
            ),
            "Expected NotAuthorityBearing(ClosedResidual), got {:?}",
            res
        );
    }

    // 2. ActiveClosureFailure
    {
        let (phi1, trichotomy) = create_evidence(1, 1);
        assert_eq!(
            trichotomy.diagnostic_class(),
            ObstructionDiagnosticClass::ActiveClosureFailure
        );
        let packet_args = args([12; 32]);
        let packet = CheckedPacket::new_checked(packet_args, &phi1, &trichotomy).unwrap();

        let res = packet.certify_evidence(dummy_witness(), dummy_is_auth());
        assert!(
            matches!(
                res,
                Err(CheckedPacketCertificateError::NotAuthorityBearing(
                    ObstructionDiagnosticClass::ActiveClosureFailure
                ))
            ),
            "Expected NotAuthorityBearing(ActiveClosureFailure), got {:?}",
            res
        );
    }
}

#[test]
fn test_forged_certified_authority_deserialization_fails() {
    let forged_json = r#"{
        "terminal": "ExactRuleDerived",
        "witness": {
            "origin": "ExactRuleDerived",
            "ref_path": "descent:test",
            "replay_hash": "blake3:4a4f89d3856b3e34b9d5c345389dcdcf385b2e38b2e38b2e38b2e38b2e38b2e3"
        },
        "is_auth": {
            "origin": "ExactRuleDerived",
            "guards": {
                "accessible": false,
                "deterministic": false,
                "obstruction_vanishes": false,
                "exhaustive": false,
                "skeletal": false,
                "no_lift": false,
                "no_refuse": false
            }
        }
    }"#;

    let res: Result<CertifiedAuthority, _> = serde_json::from_str(forged_json);
    assert!(
        res.is_err(),
        "Expected deserialization error for forged CertifiedAuthority"
    );
}
