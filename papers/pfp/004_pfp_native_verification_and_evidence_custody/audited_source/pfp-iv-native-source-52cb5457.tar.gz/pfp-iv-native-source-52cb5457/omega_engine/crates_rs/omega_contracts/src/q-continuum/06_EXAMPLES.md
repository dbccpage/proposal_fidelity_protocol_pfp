Q-Continuum Examples
====================

These examples demonstrate probing, not proof.

Example 1: Simple Mathematical Claim
------------------------------------

Input idea: "All even numbers greater than 2 are sums of two primes."

* Finite projections: bounded finite arithmetic ranges, explicit checked intervals, search receipts.
* Probe plan: definitions, examples, counterexamples, boundary, descent, source authority.
* Descent obligations: define checked range, supply enumerator or proof target, record counterexample search.
* Possible ledger entries: `MissingWitness` if no proof or bounded search receipt is supplied.
* Authority status: speculative or probed for bounded checks only.
* Terminal status: unresolved for the unrestricted general claim unless a proof exists.

Example 2: Business Claim
-------------------------

Input idea: "This product will make money."

* Finite projections: named customer segment, price, channel, cost model, time horizon.
* Probe plan: definition, measurement, boundary, counterexample, source authority.
* Descent obligations: customer pain evidence, willingness-to-pay evidence, reachable market, fulfillment cost, distribution path.
* Possible ledger entries: `Underdefined` for missing segment, `MissingWitness` for missing payment evidence.
* Authority status: conditionally supported only for tested segment and period.
* Terminal status: not globally supported.

Example 3: Paper Claim
----------------------

Input idea: "This paper derives quantum mechanics from primitive difference."

* Finite projections: explicit definitions, theorem statements, examples, formal witnesses, missing derivation rows.
* Probe plan: formalization, analogy break, source authority, physics scope, definitions, counterexamples.
* Descent obligations: separate definitions from analogies, cite theorem receipts, identify unsupported derivation steps.
* Possible ledger entries: `SourceUnsupported`, `AnalogyBreak`, `MissingWitness`.
* Authority status: no QM-derived authority is granted by this layer.
* Terminal status: speculative unless finite theorem witnesses and scope fences exist.

Example 4: Code Claim
---------------------

Input idea: "This Rust module implements finite descent."

* Finite projections: module path, exported types, test names, command receipts.
* Probe plan: implementation, invariant, type, definition, boundary.
* Descent obligations: compile target, test target, invariant tests, failure case tests.
* Possible ledger entries: `ImplementationMissing` if code path is absent, `ReplayMissing` if command receipt is missing.
* Authority status: implementation support only for tested behavior.
* Terminal status: `Implemented` or `Supported` only inside the exact code/test scope.

Example 5: Physics Analogy
--------------------------

Input idea: "Curvature is obstruction to global trivialization."

* Finite projections: definitions of bundle, connection, transport, local chart, global section, curvature, and example.
* Probe plan: definition, example, physics, analogy break, formalization, boundary.
* Descent obligations: provide a finite mathematical example and specify whether this is math, physics, or analogy.
* Possible ledger entries: `Underdefined` for missing definitions, `AnalogyBreak` for scope drift.
* Authority status: analogy or mathematical example support only.
* Terminal status: not a physics claim without sources, definitions, assumptions, and finite evidence.
