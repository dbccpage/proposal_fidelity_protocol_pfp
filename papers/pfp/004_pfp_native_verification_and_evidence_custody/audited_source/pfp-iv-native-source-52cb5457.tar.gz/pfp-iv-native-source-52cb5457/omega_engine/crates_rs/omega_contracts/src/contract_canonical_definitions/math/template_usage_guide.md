template usage guide: yaml math contracts
=========================================

quick start
-----------

1. **Copy the template:**
   ```bash
   cp math_contract_template.yaml my_contract.contract.yaml
   ```

2. **Fill REQUIRED fields:**
   * Metadata: `contract_id`, `title`, `version`, `status`, `kind`, `description`
   * Owner: `crate`, `module`, `rust_symbols`
   * Purpose, mathematical_object, dependencies, operations, validation, etc.

3. **Delete unused OPTIONAL fields:**
   * `certificates` (if no certificates needed)
   * `open_questions`, `wip_notes` (if status is not `mathematical_wip`)

4. **Validate YAML:**
   ```bash
   python -c "import yaml; yaml.safe_load(open('my_contract.contract.yaml'))"
   ```

5. **Commit:**
   ```bash
   git add my_contract.contract.yaml
   git commit -m "feat(law): add MyContract YAML math contract"
   ```

---

complete field reference
------------------------

### contract_id (REQUIRED)

**Type:** String

**Format:** `"urn:math:contract:<ContractName>:v<SEMVER>"`

**Description:** Unique identifier for this contract following URN format.

**Example:**
```yaml
contract_id: "urn:math:contract:Field:v1.0.0"
```

**Rules:**

* Must be unique across all math contracts
* Use PascalCase for contract name
* Include semantic version (MAJOR.MINOR.PATCH)
* Version must match `version` field

---

### title (REQUIRED)

**Type:** String

**Description:** Human-readable short title for the contract.

**Example:**
```yaml
title: "Field Contract"
```

**Rules:**

* Use Title Case
* Keep under 60 characters
* Include "Contract" suffix for clarity

---

### version (REQUIRED)

**Type:** String (Semantic Version)

**Format:** `"MAJOR.MINOR.PATCH"`

**Description:** Contract version following semver.

**Example:**
```yaml
version: "1.0.0"
```

**Version semantics:**

* **MAJOR:** Breaking changes (incompatible with previous version)
* **MINOR:** New features (backward compatible)
* **PATCH:** Bug fixes (backward compatible)

**Rules:**

* Must match version in `contract_id`
* Start at `0.1.0` for new contracts
* Bump to `1.0.0` when production-ready

---

### status (REQUIRED)

**Type:** Enum

**Values:**

* `canonical` - Production-ready, fully validated
* `staged` - Under development, REQUIRED fields present
* `archived` - Historical, minimal validation
* `mathematical_wip` - Active development with open questions

**Example:**
```yaml
status: "canonical"
```

**Enforcement by status:**

| Status | Enforcement Level | Notes |
|--------|------------------|-------|
| `canonical` | Full validation | All fields complete, all tests pass |
| `staged` | Warnings only | REQUIRED fields present, may have TODOs |
| `archived` | Minimal checking | Read-only, historical reference |
| `mathematical_wip` | Like staged + WIP tracking | Must have `open_questions` or `wip_notes` |

**When to use:**

* **canonical:** Contract is production-ready, all properties verified, tests pass
* **staged:** Contract is being developed, structure is complete but validation pending
* **archived:** Old version kept for reference, no longer actively maintained
* **mathematical_wip:** Active development with unresolved design questions

---

### authority_level (REQUIRED)

**Type:** String (fixed value)

**Value:** `"implementation_contract"`

**Description:** Authority level for this contract. Always `implementation_contract` for math contracts.

**Example:**
```yaml
authority_level: "implementation_contract"
```

**Rules:**

* Math contracts are implementation-level (not authority-conferring)
* Never change this value for math contracts

---

### kind (REQUIRED)

**Type:** String (fixed value)

**Value:** `"mathematical-structure"`

**Description:** Contract category. Always `mathematical-structure` for math contracts.

**Example:**
```yaml
kind: "mathematical-structure"
```

---

### description (REQUIRED)

**Type:** String (multi-line)

**Description:** Comprehensive description of what this contract represents and its role.

**Example:**
```yaml
description: >
  A Field is a set F equipped with two binary operations (addition
  and multiplication) that satisfy the field axioms, together with a
  canonical deterministic serialization for its elements. This contract
  defines the structure of F, validation that a given element belongs
  to F, and deterministic computation of field operations.
```

**Rules:**

* Use YAML literal block `>` for multi-line text
* First paragraph: What is this object?
* Second paragraph: Why does it exist / what is it used for?
* Keep under 500 characters

---

### owner (REQUIRED)

**Type:** Object

**Fields:**

* `crate` (REQUIRED): Crate name that owns this contract
* `module` (REQUIRED): Module path within crate
* `rust_symbols` (REQUIRED): List of primary Rust types implementing this contract

**Example:**
```yaml
owner:
  crate: "omega-foundations"
  module: "structures/field.rs"
  rust_symbols:

    * "Field"
    * "FieldOps"
    * "FieldValidator"
```

**How to determine:**

1. Search for struct: `grep -r "struct Field" omega_engine/crates/`
2. Check `Cargo.toml` in that directory for crate name
3. Note the module path (file path relative to `src/`)
4. List primary types/traits (struct, trait, validator)

---

### purpose (REQUIRED)

**Type:** Object

**Fields:**

* `summary` (REQUIRED): Single-paragraph high-level purpose
* `mathematical_role` (REQUIRED): Detailed mathematical context and usage
* `non_goals` (REQUIRED): List of excluded functionality (can be empty `[]`)

**Example:**
```yaml
purpose:
  summary: >
    A Field is a set F equipped with two binary operations that satisfy
    the field axioms, providing the scalar domain for vector spaces,
    matrices, and other linear structures.

  mathematical_role: >
    The Field contract captures the algebraic data of a field K.
    Every vector space, matrix, or fiber contract refers to a Field
    artifact by its hash as the scalar domain. From the perspective
    of a vector space V over K, the domain of the structural map is
    the one-dimensional vector space K with canonical basis {1K}.

  non_goals:

    * "Ordered or complete fields (separate FactEnvelopes)"
    * "Floating-point fields (excluded until rounding contract defined)"
    * "Infinite fields like ℚ, ℝ, ℂ (deferred to future versions)"
```

**Rules:**

* `summary`: 1-2 sentences, high-level "what and why"
* `mathematical_role`: 1-3 paragraphs, detailed mathematical context
* `non_goals`: Explicitly state what is OUT of scope (prevents scope creep)

---

### mathematical_object (REQUIRED)

**Type:** Object

**Fields:**

* `kind` (REQUIRED): Type of mathematical object
* `carrier` (REQUIRED): Description of underlying set/type
  * `description` (REQUIRED): Text description
  * `components` (OPTIONAL): Breakdown of structured components
* `notation` (REQUIRED): Standard mathematical notation
* `axioms` (REQUIRED): List of defining axioms (can be empty `[]`)

**Example:**
```yaml
mathematical_object:
  kind: "field"

  carrier:
    description: "Set F with binary operations (+, *) and identity elements"
    components:
      addition: "binary_operation"
      multiplication: "binary_operation"
      zero: "additive_identity"
      one: "multiplicative_identity"

  notation: "(F, +, *, 0, 1)"

  axioms:

    * id: "additive_group"
      statement: "(F, +) forms an abelian group with identity 0"
      enforcement: "validator"

    * id: "multiplicative_group"
      statement: "(F \\ {0}, *) forms an abelian group with identity 1"
      enforcement: "validator"

    * id: "distributivity"
      statement: "a * (b + c) = a * b + a * c for all a, b, c in F"
      enforcement: "runtime"
```

**Axiom enforcement types:**

* `structural`: Enforced by Rust type system (compile-time)
* `runtime`: Checked at runtime during operations
* `validator`: Checked by external validator function

**How to determine:**

* Consult mathematical definition (Wikipedia, nLab, textbook)
* Extract from contract's "Mathematical role" prose
* List fundamental axioms that DEFINE the structure (not derived properties)

---

### dependencies (REQUIRED)

**Type:** Object

**Fields:**

* `math_contracts` (REQUIRED): Other math contracts this depends on (can be empty `[]`)
* `non_math_contracts` (REQUIRED): Non-math contracts (replay, certificate, etc.) (can be empty `[]`)

**Example:**
```yaml
dependencies:
  math_contracts:

    * contract_id: "urn:math:contract:Set:v1.0.0"
      role: "underlying_set"

    * contract_id: "urn:math:contract:BinaryOperation:v1.0.0"
      role: "addition_and_multiplication"

  non_math_contracts:

    * contract_id: "replay_trace_contract"
      role: "deterministic_replay"

    * contract_id: "certificate_contract"
      role: "validation_certificates"
```

**Rules:**

* Include only DIRECT dependencies (not transitive)
* `role` field explains WHY this dependency is needed
* Always include `replay_trace_contract` for determinism (non-math)
* Check "Mathematical role" and "Required inputs" sections for hints

---

### required_properties (REQUIRED)

**Type:** List of property objects

**Property fields:**

* `id` (REQUIRED): Unique property identifier
* `statement` (REQUIRED): Property description
* `enforce` (REQUIRED): Enforcement mechanism
* `validator` (REQUIRED): Validator name

**Enforcement types:**

* `runtime_check`: Checked during operations (e.g., bounds checking)
* `constructor_check`: Checked at construction time
* `validator_check`: Checked by external validator
* `replay_check`: Checked during replay
* `compile_time`: Enforced by Rust type system

**Example:**
```yaml
required_properties:

  * id: "finite_shape"
    statement: "rows and cols are finite natural numbers"
    enforce: "runtime_check"
    validator: "shape_validator"

  * id: "deterministic_indexing"
    statement: "same matrix, row, and col always resolve to the same entry"
    enforce: "replay_check"
    validator: "replay_validator"
```

**Can be empty:** `required_properties: []`

---

### operations (REQUIRED)

**Type:** Object

**Fields:**

* `constructors` (REQUIRED): Construction operations (can be empty `[]`)
* `methods` (REQUIRED): Instance operations (can be empty `[]`)

**Constructor/method fields:**

* `name` (REQUIRED): Operation name
* `inputs` (REQUIRED): List of input types
* `output` (methods only): Output type
* `preconditions` (REQUIRED): Conditions that must hold before operation (can be empty `[]`)
* `postconditions` (REQUIRED): Conditions guaranteed after operation (can be empty `[]`)
* `deterministic` (REQUIRED): Must be `true` for math contracts

**Example:**
```yaml
operations:
  constructors:

    * name: "new"
      inputs: ["rows", "cols", "data"]
      preconditions:

        * "data_len_equals_rows_times_cols"
        * "rows > 0 and cols > 0"
      postconditions:

        * "valid_shape"
        * "deterministic_storage"
      deterministic: true

  methods:

    * name: "get"
      inputs: ["row_index", "col_index"]
      output: "entry"
      preconditions:

        * "index_in_bounds"
      postconditions:

        * "returns_valid_entry"
      deterministic: true

    * name: "matmul"
      inputs: ["other_matrix"]
      output: "result_matrix"
      preconditions:

        * "lhs_cols_equals_rhs_rows"
      postconditions:

        * "output_shape_correct"
      deterministic: true
```

**Rules:**

* **All math operations MUST be deterministic** (set `deterministic: true`)
* Preconditions define the valid domain
* Postconditions define guarantees on the output
* Use snake_case for operation names

---

### refusal_conditions (REQUIRED)

**Type:** List of strings

**Description:** Conditions that MUST cause operation failure. Defines the boundary of valid behavior.

**Example:**
```yaml
refusal_conditions:

  * "invalid_shape"
  * "data_length_mismatch"
  * "index_out_of_bounds"
  * "incompatible_matmul_shapes"
  * "scalar_domain_mismatch"
  * "nonfinite_float_without_policy"
  * "hidden_shape_coercion"
```

**Can be empty:** `refusal_conditions: []` (but rare - most contracts have failure modes)

**Purpose:**

* Explicitly documents what operations MUST reject
* Prevents silent failures or implicit coercion
* Used in negative test generation

---

### allowed_artifacts (REQUIRED)

**Type:** List of strings

**Description:** Artifact types this contract is allowed to produce.

**Common values for math contracts:**

* `StructureArtifact` - Complete specification of mathematical structure
* `FactEnvelope` - Mathematical claim about the structure
* `ValidationWitness` - Record of validation check
* `ComputationWitness` - Record of deterministic computation

**Example:**
```yaml
allowed_artifacts:

  * "StructureArtifact"
  * "FactEnvelope"
  * "ValidationWitness"
  * "ComputationWitness"
```

**Rules:**

* Include only artifacts this contract actually produces
* Most math contracts need all four above

---

### forbidden_artifacts (REQUIRED)

**Type:** List of strings

**Description:** Artifact types this contract MUST NOT produce.

**Standard values for math contracts:**

* `DecisionEnvelope` (authority-conferring)
* `Action` (execution of side effects)

**Example:**
```yaml
forbidden_artifacts:

  * "DecisionEnvelope"
  * "Action"
```

**Rules:**

* Always include `DecisionEnvelope` and `Action` for pure math contracts
* Math contracts do not confer authority or execute actions

---

### forbidden_authority (REQUIRED)

**Type:** List of strings

**Description:** Authority restrictions for this contract. Explains what authority-related things are NOT allowed.

**Standard statements for math contracts:**
```yaml
forbidden_authority:

  * "This contract is purely mathematical and confers no authority"
  * "No signing, certification, or trust markers allowed"
  * "No key material or identity information"
  * "authority_effect fixed to 'none'"
  * "No customer-facing claims"
```

**Rules:**

* Always include all five statements above for pure math contracts
* Math contracts are descriptive, not prescriptive
* No security or trust decisions can be based solely on math contract compliance

---

### validation (REQUIRED)

**Type:** Object

**Fields:**

* `validators` (REQUIRED): List of validators (can be empty `[]`)
* `replay_requirements` (REQUIRED): Replay determinism requirements
* `witness_requirements` (OPTIONAL): Required witness structure

**Example:**
```yaml
validation:
  validators:

    * name: "shape_validator"
      order: 1
      purpose: "Verify rows and cols are finite positive integers"

    * name: "storage_validator"
      order: 2
      purpose: "Verify data length equals rows * cols"

  replay_requirements:
    deterministic: true
    algorithm: "SHA-256"
    restrictions:

      * "No external state"
      * "No randomness"
      * "No time-dependent data"

  witness_requirements:
    ValidationWitness:

      * "witness_type"
      * "input_hashes"
      * "outcome"
      * "validator_function_hash"
    ComputationWitness:

      * "operation_name"
      * "artifact_hash"
      * "input_hashes"
      * "output_hash"
      * "algorithm_hash"
```

**Validators:**

* `name`: Function or module name
* `order`: Execution order (1-based)
* `purpose`: One-line description of what this validator checks

**Replay requirements:**

* `deterministic`: MUST be `true` for all math contracts
* `algorithm`: Hash algorithm (usually `SHA-256`)
* `restrictions`: List of determinism restrictions (no randomness, etc.)

**Witness requirements:**

* OPTIONAL: Only include if contract produces witnesses
* List required fields for each witness type

---

### certificates (OPTIONAL)

**Type:** Object

**Fields:**

* `required_for`: Operations that REQUIRE certificates
* `optional_for`: Operations that MAY use certificates

**Example:**
```yaml
certificates:
  required_for:

    * "primality_testing"
    * "irreducibility_verification"
  optional_for:

    * "field_extension_construction"
```

**When to include:**

* Only if contract explicitly uses certificates
* Omit entire section if not applicable

---

### rust_descriptor (REQUIRED)

**Type:** Object

**Fields:**

* `struct_name` (REQUIRED): Name of Rust descriptor struct
* `derives` (REQUIRED): List of derived traits
* `fields` (REQUIRED): List of descriptor fields (can be empty `[]`)

**Field specification:**

* `name`: Rust field name (snake_case)
* `type`: Rust type (e.g., `String`, `[u8; 32]`, `Option<u64>`)
* `description`: Purpose of this field

**Example:**
```yaml
rust_descriptor:
  struct_name: "FieldContractDescriptor"

  derives:

    * "Debug"
    * "Clone"
    * "PartialEq"
    * "Eq"
    * "Serialize"
    * "Deserialize"

  fields:

    * name: "contract_version"
      type: "String"
      description: "Contract version identifier"

    * name: "field_type"
      type: "String"
      description: "Field type tag (e.g., 'prime', 'binary_extension')"

    * name: "parameters_hash"
      type: "[u8; 32]"
      description: "SHA-256 hash of canonical parameter byte string"
```

**Rules:**

* Struct name pattern: `<ContractName>ContractDescriptor`
* Always derive: `Debug`, `Clone`, `PartialEq`, `Eq`, `Serialize`, `Deserialize`
* Field names use snake_case
* Field types are Rust syntax

---

### tests (REQUIRED)

**Type:** Object

**Fields:**

* `required` (REQUIRED): List of positive tests (can be empty `[]`)
* `negative_tests` (REQUIRED): List of negative tests (can be empty `[]`)

**Negative test specification:**

* `name`: Test name (snake_case)
* `description`: What must be rejected
* `expected_failure`: Validator that should reject this input

**Example:**
```yaml
tests:
  required:

    * "matrix_creates_valid_shape"
    * "matrix_get_is_deterministic"
    * "matrix_transpose_preserves_data"
    * "matrix_matmul_is_associative"

  negative_tests:

    * name: "reject_zero_rows"
      description: "Matrix with rows=0 must be rejected"
      expected_failure: "shape_validator"

    * name: "reject_mismatched_data_length"
      description: "Data length not equal to rows*cols must be rejected"
      expected_failure: "storage_validator"
```

**Rules:**

* Positive tests (`required`): Name the test function
* Negative tests: Specify what must fail and which validator rejects it
* Aim for 3-5 positive tests and 2-4 negative tests per contract

---

### products_using (REQUIRED)

**Type:** List of strings

**Description:** Products/components that depend on this contract.

**Common values:**
```yaml
products_using:

  * "Symbol Game"
  * "Omega Engine"
  * "Anomalon AI"
  * "EPK Framework"
  * "Kaggle Competition"
```

**How to determine:**

1. Search codebase: `grep -r "FieldContract" omega_engine/products/`
2. Check import statements in product code
3. Consult with product owners if unclear

**Can be empty:** `products_using: []` (for new/unused contracts)

---

### last_audited (REQUIRED)

**Type:** String (ISO 8601 date)

**Format:** `"YYYY-MM-DD"`

**Description:** Date of last audit/review.

**Example:**
```yaml
last_audited: "2026-05-25"
```

**Rules:**

* Use today's date for newly created contracts
* Update when contract undergoes significant review
* ISO 8601 format only

---

### open_questions (OPTIONAL)

**Type:** List of strings

**When to include:** Only when `status: mathematical_wip`

**Description:** Unresolved design questions that need to be answered.

**Example:**
```yaml
open_questions:

  * "How to support infinite fields (ℚ, algebraic number fields)?"
  * "What FactEnvelope types should be standardized?"
  * "How to encode binary extension irreducible polynomials?"
  * "Should we support symbolic parameters or only concrete values?"
```

**Rules:**

* Only for WIP contracts
* Phrase as questions
* Track blockers and design decisions
* Delete section when status becomes `canonical`

---

### wip_notes (OPTIONAL)

**Type:** List of strings

**When to include:** Only when `status: mathematical_wip`

**Description:** Implementation notes, current scope limitations, and design decisions.

**Example:**
```yaml
wip_notes:

  * "Currently targets exact finite fields only"
  * "Floating-point fields excluded until rounding contract defined"
  * "Field extension operations deferred to separate contract"
  * "Characteristic and order fields optional for future infinite field support"
```

**Rules:**

* Only for WIP contracts
* Document current scope and limitations
* Track implementation decisions
* Delete section when status becomes `canonical`

---

status levels explained
-----------------------

### canonical

**When to use:** Contract is production-ready, fully validated, and stable.

**Requirements:**

* All REQUIRED fields complete
* All validators implemented and tested
* Rust descriptor matches codebase
* All positive tests pass
* All negative tests properly reject inputs
* No `open_questions` or `wip_notes`

**Enforcement:** Full validation (errors on any issues)

---

### staged

**When to use:** Contract structure is complete but validation/implementation is pending.

**Requirements:**

* All REQUIRED fields present
* May have TODOs or incomplete implementations
* Validators may not be fully implemented
* Tests may be incomplete

**Enforcement:** Warnings only (issues noted but not blocking)

**Typical usage:** During initial migration from Markdown, before full validation

---

### mathematical_wip

**When to use:** Active development with unresolved design questions.

**Requirements:**

* All REQUIRED fields present
* MUST have `open_questions` or `wip_notes` (or both)
* Design not finalized
* May have competing approaches

**Enforcement:** Like `staged` (warnings only) plus WIP tracking

**Typical usage:** New contracts being designed, contracts undergoing major refactoring

---

### archived

**When to use:** Historical version kept for reference, no longer actively maintained.

**Requirements:**

* Minimal (basic YAML validity only)
* May be incomplete

**Enforcement:** Minimal checking

**Typical usage:** Old contract versions superseded by newer versions

---

common patterns for different contract types
--------------------------------------------

### algebraic structures (field, group, ring, module)

**Key sections:**

* `mathematical_object.axioms`: List group axioms, field axioms, etc.
* `operations.constructors`: Specify how to construct from parameters
* `operations.methods`: Binary operations (add, multiply, etc.)
* `validation.validators`: Parameter validation (e.g., primality for finite fields)

**Example axioms for Group:**
```yaml
axioms:

  * id: "closure"
    statement: "a * b in G for all a, b in G"
    enforcement: "validator"

  * id: "associativity"
    statement: "(a * b) * c = a * (b * c)"
    enforcement: "runtime"

  * id: "identity"
    statement: "exists e in G such that e * a = a * e = a for all a"
    enforcement: "structural"

  * id: "inverse"
    statement: "for all a in G, exists a^-1 such that a * a^-1 = e"
    enforcement: "validator"
```

---

### topological structures (space, continuous_map, boundary)

**Key sections:**

* `mathematical_object.carrier`: Describe underlying set and topology
* `operations.methods`: Continuous maps, boundary operators
* `required_properties`: Continuity, compactness, connectedness

**Example for Continuous Map:**
```yaml
required_properties:

  * id: "preserves_open_sets"
    statement: "preimage of open set is open"
    enforce: "validator_check"
    validator: "continuity_validator"
```

---

### categorical structures (category, functor, natural_transformation)

**Key sections:**

* `mathematical_object`: Define objects, morphisms, composition
* `operations.methods`: Composition, identity morphisms
* `required_properties`: Composition laws, functoriality

**Example for Category:**
```yaml
mathematical_object:
  carrier:
    description: "Collection of objects and morphisms"
    components:
      objects: "collection"
      morphisms: "hom_sets"
      composition: "morphism_composition"
      identity: "identity_morphisms"

required_properties:

  * id: "associativity"
    statement: "h ∘ (g ∘ f) = (h ∘ g) ∘ f"
    enforce: "runtime_check"
    validator: "composition_validator"

  * id: "identity_law"
    statement: "f ∘ id_A = f = id_B ∘ f"
    enforce: "runtime_check"
    validator: "identity_validator"
```

---

### homological structures (chain_complex, cochain_complex, cohomology)

**Key sections:**

* `dependencies`: Reference `boundary_map`, `module`, etc.
* `mathematical_object.axioms`: d² = 0 (boundary squared is zero)
* `operations.methods`: Boundary operators, homology groups

**Example for Chain Complex:**
```yaml
dependencies:
  math_contracts:

    * contract_id: "urn:math:contract:Module:v1.0.0"
      role: "chain_modules"

    * contract_id: "urn:math:contract:BoundaryMap:v1.0.0"
      role: "boundary_operators"

mathematical_object:
  axioms:

    * id: "boundary_squared_zero"
      statement: "d_{n-1} ∘ d_n = 0 for all n"
      enforcement: "validator"
```

---

### computational structures (matrix, tensor, polynomial)

**Key sections:**

* `required_properties`: Shape invariants, indexing bounds
* `operations.methods`: Arithmetic operations with shape laws
* `refusal_conditions`: Invalid shapes, out-of-bounds access
* `validation.replay_requirements`: Deterministic computation

**Example for Matrix:**
```yaml
required_properties:

  * id: "finite_shape"
    statement: "rows and cols are finite"
    enforce: "constructor_check"
    validator: "shape_validator"

operations:
  methods:

    * name: "matmul"
      inputs: ["other_matrix"]
      output: "result_matrix"
      preconditions:

        * "lhs_cols_equals_rhs_rows"
      postconditions:

        * "output_rows_equals_lhs_rows"
        * "output_cols_equals_rhs_cols"
      deterministic: true

refusal_conditions:

  * "incompatible_matmul_shapes"
  * "index_out_of_bounds"
```

---

rust integration patterns
-------------------------

### descriptor as contract key

The `rust_descriptor` serves as the primary key for all witnesses and fact envelopes:

```rust
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct FieldContractDescriptor {
    pub contract_version: String,
    pub field_type: String,
    pub parameters_hash: [u8; 32],
    // ...
}

impl FieldContractDescriptor {
    pub fn artifact_hash(&self) -> [u8; 32] {
        // SHA-256 over canonical serialization
        // Used as key in all witnesses
    }
}
```

**YAML:**
```yaml
rust_descriptor:
  struct_name: "FieldContractDescriptor"
  derives: ["Debug", "Clone", "PartialEq", "Eq", "Serialize", "Deserialize"]
  fields:

    * name: "contract_version"
      type: "String"
      description: "Contract version identifier"

    * name: "field_type"
      type: "String"
      description: "Field type (prime, binary_extension, etc.)"
```

---

### validator functions

Validators referenced in `validation.validators` should be implemented as:

```rust
pub fn shape_validator(descriptor: &MatrixContractDescriptor) -> ValidationResult {
    if descriptor.rows == 0 || descriptor.cols == 0 {
        return ValidationResult::Reject {
            reason: "invalid_shape",
            witness: ValidationWitness { /* ... */ }
        };
    }
    ValidationResult::Accept
}
```

**YAML:**
```yaml
validation:
  validators:

    * name: "shape_validator"
      order: 1
      purpose: "Verify rows and cols are positive"
```

---

### operation determinism

All operations must be deterministic (same inputs → same outputs):

```rust
impl Matrix {
    pub fn matmul(&self, other: &Matrix) -> Result<Matrix, MatrixError> {
        // Deterministic matrix multiplication
        // No randomness, no external state, no time dependence
        // Content-addressed: hash(self) + hash(other) → hash(result)
    }
}
```

**YAML:**
```yaml
operations:
  methods:

    * name: "matmul"
      inputs: ["other_matrix"]
      output: "result_matrix"
      deterministic: true  # REQUIRED
```

---

questions?
----------

For additional help:

1. Read `migration_guide.md` for Markdown → YAML conversion
2. Examine `basic_matrix.contract.yaml` for complete example
3. Check existing migrated contracts for patterns
4. Consult contract owners for domain-specific questions
