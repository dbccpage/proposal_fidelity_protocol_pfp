//! Human-readable markdown renderer for a reconciliation ledger.
//!
//! Produces a compact GitHub-flavored markdown table — one summary row per
//! [`ReconciliationRow`] — for pasting into a reconciliation report. This is a
//! lossy *view*; the NDJSON ledger (see [`crate::ledger`]) remains the source of
//! truth.
use crate::row::ReconciliationRow;

/// Render rows as a markdown table with columns asset / claim_delta / terminal /
/// verdict. Always emits the header and separator, then one row per input.
pub fn render_md(rows: &[ReconciliationRow]) -> String {
    let mut out = String::new();
    out.push_str("| asset | claim_delta | terminal | verdict |\n");
    out.push_str("|---|---|---|---|\n");
    for row in rows {
        out.push_str(&format!(
            "| {} | {:?} | {:?} | {:?} |\n",
            row.asset_id, row.claim_delta, row.terminal_status.status, row.recon_verdict
        ));
    }
    out
}
