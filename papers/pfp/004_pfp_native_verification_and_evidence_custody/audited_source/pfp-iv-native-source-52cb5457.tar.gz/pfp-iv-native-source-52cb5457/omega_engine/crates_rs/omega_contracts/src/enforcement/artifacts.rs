use crate::kinds::ContractEffect;
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;

#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum DecisionOrigin {
    EvaluatorGate,
    PolicyInterpretation,
    PolicySetResolution,
    EngineTransition,
}

pub type PolicyReason = String;

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum BoundEnforcement {
    Hard,
    Soft,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct BoundConstraint {
    pub target: String,
    pub limit: String,
    pub enforcement: BoundEnforcement,
    pub reason: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum PolicyDecision {
    Allowed,
    Forbidden { reason: PolicyReason },
    Bounded { constraints: Vec<BoundConstraint> },
    Undetermined { reason: PolicyReason },
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct PolicyDecisionEnvelope {
    pub policy_id: String,
    pub policy_version: String,
    pub policy_hash: String,
    pub request_hash: String,
    pub decision: PolicyDecision,
    pub clauses_evaluated: Vec<String>,
    pub clauses_fired: Vec<String>,
    pub authority_effect: ContractEffect,
    pub derivation: BTreeMap<String, String>,
}

/// Canonical representation of mathematical structure inside the engine.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct StructureArtifact {
    pub id: String,
    pub source_id: Option<String>,
}

/// A single typed evidence item.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Evidence {
    pub name: String,
    pub details: String,
}

/// Unchecked evidence artifact.
///
/// Per 00_constitution.yaml canonical_artifact_families:
/// EvidenceEnvelope is distinct from FactEnvelope. Evidence becomes
/// a Fact only after passing through a checking boundary.
///
/// Default authority_effect: EvidenceOnly
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct EvidenceEnvelope {
    pub id: String,
    pub evidence: Vec<Evidence>,
    pub witness_refs: Vec<String>,
    pub certificate_refs: Vec<String>,
    pub authority_effect: ContractEffect,
}

impl Default for EvidenceEnvelope {
    fn default() -> Self {
        Self {
            id: String::new(),
            evidence: Vec::new(),
            witness_refs: Vec::new(),
            certificate_refs: Vec::new(),
            authority_effect: ContractEffect::EvidenceOnly,
        }
    }
}

/// A single typed fact (checked evidence).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Fact {
    pub name: String,
    pub details: String,
}

/// Certified evidence of fact observation (checked by a boundary).
///
/// FactEnvelope is distinct from EvidenceEnvelope: it represents
/// evidence that has been checked and promoted to factual status.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct FactEnvelope {
    pub id: String,
    pub facts: Vec<Fact>,
    pub authority_effect: ContractEffect,
}

/// Certified resolution of policy or governance judgement.
///
/// Per 05_governance.yaml: DecisionEnvelope wraps policy decisions,
/// evaluation results, and auth decisions.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct DecisionEnvelope {
    pub id: String,
    pub decision: PolicyDecision,
    pub origin: DecisionOrigin,
    pub authority_effect: ContractEffect,
}

/// Scoped authorization to execute a state transition.
///
/// Per 00_constitution.yaml canonical_artifact_families and 08_lifts.yaml:
/// ActionLicense is distinct from Action. It authorizes a transition but
/// does not execute it. Only Engine executes licensed transitions.
///
/// Authority effect: AuthorizesTransition
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ActionLicense {
    /// Unique identifier for this license
    pub id: String,
    /// Scope of the licensed transition
    pub scope: String,
    /// Reference to the decision that supports this license
    pub decision_ref: String,
    /// Hash of the licensed transition parameters
    pub license_hash: String,
    /// Optional expiry epoch
    pub expiry: Option<u64>,
    /// Authority effect (always AuthorizesTransition)
    pub authority_effect: ContractEffect,
}

impl Default for ActionLicense {
    fn default() -> Self {
        Self {
            id: String::new(),
            scope: String::new(),
            decision_ref: String::new(),
            license_hash: String::new(),
            expiry: None,
            authority_effect: ContractEffect::AuthorizesTransition,
        }
    }
}

/// An execution artifact produced by Engine state changes.
///
/// Per 06_execution.yaml: Only Engine emits Action with StateTransition
/// authority. Action requires a prior ActionLicense.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct EngineAction {
    pub action_id: String,
    pub license_ref: String,
    pub pre_state_hash: String,
    pub post_state_hash: String,
    pub emitted_trace_ref: String,
    pub action_hash: String,
    pub authority_effect: ContractEffect,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum TerminalCategory {
    VerifiedComplete,
    Refused,
    Fallback,
    UnverifiedComplete,
    Indeterminate,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct TerminalEnvelope {
    pub terminal_id: String,
    pub terminal_category: TerminalCategory,
    pub state_ref: String,
    pub trace_ref: String,
    pub evaluator_decision_refs: Vec<String>,
    pub policy_decision_refs: Vec<String>,
    pub evidence_refs: Vec<String>,
    pub certificate_refs: Vec<String>,
    pub replay_refs: Vec<String>,
    pub clauses_fired: Vec<String>,
    pub envelope_hash: String,
    pub authority_effect: ContractEffect,
}

impl Default for TerminalEnvelope {
    fn default() -> Self {
        Self {
            terminal_id: String::new(),
            terminal_category: TerminalCategory::Indeterminate,
            state_ref: String::new(),
            trace_ref: String::new(),
            evaluator_decision_refs: vec![],
            policy_decision_refs: vec![],
            evidence_refs: vec![],
            certificate_refs: vec![],
            replay_refs: vec![],
            clauses_fired: vec![],
            envelope_hash: String::new(),
            authority_effect: ContractEffect::RequestsDecision,
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct CheckedTerminalEnvelope {
    pub envelope_ref: String,
    pub replay_ref: String,
    pub certificate_refs: Vec<String>,
    pub checked_hash: String,
    pub authority_effect: ContractEffect,
}

impl Default for CheckedTerminalEnvelope {
    fn default() -> Self {
        Self {
            envelope_ref: String::new(),
            replay_ref: String::new(),
            certificate_refs: vec![],
            checked_hash: String::new(),
            authority_effect: ContractEffect::FactOnly,
        }
    }
}

/// An unmodifiable, execution-neutral logging artifact.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct Record {
    pub id: String,
    pub timestamp: u64,
}

/// Orchestration boundary artifact produced by adapter wrappers.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct OrchestrationArtifact {
    pub id: String,
    pub stage: String,
    pub details: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_evidence_envelope_defaults_to_evidence_only() {
        // EvidenceEnvelope default should be EvidenceOnly per 02_evidence.yaml
        let envelope = EvidenceEnvelope::default();
        assert_eq!(envelope.authority_effect, ContractEffect::EvidenceOnly);
    }

    #[test]
    fn test_evidence_layer_authority_effects_are_canonical() {
        // Per 02_evidence.yaml: evidence layer may use None, EvidenceOnly, FactOnly
        assert!(ContractEffect::None.is_evidence_layer());
        assert!(ContractEffect::EvidenceOnly.is_evidence_layer());
        assert!(ContractEffect::FactOnly.is_evidence_layer());
        assert!(!ContractEffect::StateTransition.is_evidence_layer());
    }

    #[test]
    fn test_fact_envelope_cannot_express_state_transition() {
        // FactEnvelope is constrained by artifact law to evidence-layer authority.
        let envelope = FactEnvelope {
            id: "fact_1".to_string(),
            facts: vec![Fact {
                name: "observation".to_string(),
                details: "value".to_string(),
            }],
            authority_effect: ContractEffect::FactOnly,
        };
        assert_eq!(envelope.authority_effect, ContractEffect::FactOnly);
    }

    #[test]
    fn test_policy_decision_envelope_requests_decision() {
        let envelope = PolicyDecisionEnvelope {
            policy_id: "pol_1".to_string(),
            policy_version: "1.0".to_string(),
            policy_hash: "hash".to_string(),
            request_hash: "req".to_string(),
            decision: PolicyDecision::Allowed,
            clauses_evaluated: vec![],
            clauses_fired: vec![],
            authority_effect: ContractEffect::RequestsDecision,
            derivation: BTreeMap::new(),
        };
        assert!(envelope.authority_effect.is_decision());
    }

    #[test]
    fn test_policy_authority_effects_are_canonical() {
        // Per 05_governance.yaml: governance layer may use None, RequiresEvaluator, RequestsDecision
        assert_eq!(ContractEffect::None, ContractEffect::None);
        assert!(ContractEffect::RequiresEvaluator.is_decision());
        assert!(ContractEffect::RequestsDecision.is_decision());
        assert!(!ContractEffect::AuthorizesTransition.is_decision());
    }

    #[test]
    fn test_action_license_defaults_to_authorizes_transition() {
        // Per 08_lifts.yaml: ActionLicense authority_effect is AuthorizesTransition
        let license = ActionLicense::default();
        assert_eq!(
            license.authority_effect,
            ContractEffect::AuthorizesTransition
        );
        assert!(license.authority_effect.is_license());
    }

    #[test]
    fn test_action_license_is_distinct_from_action() {
        // ActionLicense authorizes; Action executes. Per 00_constitution.yaml
        let license = ActionLicense {
            id: "lic_1".to_string(),
            scope: "test_scope".to_string(),
            decision_ref: "dec_1".to_string(),
            license_hash: "hash123".to_string(),
            expiry: None,
            authority_effect: ContractEffect::AuthorizesTransition,
        };
        assert_eq!(
            license.authority_effect,
            ContractEffect::AuthorizesTransition
        );

        let action = EngineAction {
            action_id: "act_1".to_string(),
            license_ref: "lic_1".to_string(),
            pre_state_hash: "pre".to_string(),
            post_state_hash: "post".to_string(),
            emitted_trace_ref: "trace_1".to_string(),
            action_hash: "hash_1".to_string(),
            authority_effect: ContractEffect::StateTransition,
        };
        assert_eq!(action.authority_effect, ContractEffect::StateTransition);
        assert_eq!(action.license_ref, license.id);
    }

    #[test]
    fn test_only_action_can_express_engine_state_transition() {
        // Show that EngineAction holds the canonical StateTransition authority effect.
        let action = EngineAction {
            action_id: "act_1".to_string(),
            license_ref: "lic_1".to_string(),
            pre_state_hash: "pre".to_string(),
            post_state_hash: "post".to_string(),
            emitted_trace_ref: "trace_1".to_string(),
            action_hash: "hash_1".to_string(),
            authority_effect: ContractEffect::StateTransition,
        };
        assert_eq!(action.authority_effect, ContractEffect::StateTransition);
        assert!(action.authority_effect.is_execution());
    }

    #[test]
    fn test_engine_authority_effects_are_canonical() {
        // Per 06_execution.yaml and 08_lifts.yaml: AuthorizesTransition and StateTransition
        assert!(ContractEffect::AuthorizesTransition.is_license());
        assert!(ContractEffect::StateTransition.is_execution());
    }

    #[test]
    fn test_engine_action_has_required_fields() {
        let action = EngineAction {
            action_id: "act_1".to_string(),
            license_ref: "lic_1".to_string(),
            pre_state_hash: "pre".to_string(),
            post_state_hash: "post".to_string(),
            emitted_trace_ref: "trace_1".to_string(),
            action_hash: "hash".to_string(),
            authority_effect: ContractEffect::StateTransition,
        };
        assert_eq!(action.action_id, "act_1");
    }

    #[test]
    fn test_decision_envelope_includes_origin_and_authority() {
        // Per 05_governance.yaml: DecisionEnvelope includes origin and authority_effect
        let envelope = DecisionEnvelope {
            id: "dec_1".to_string(),
            decision: PolicyDecision::Allowed,
            origin: DecisionOrigin::EvaluatorGate,
            authority_effect: ContractEffect::RequiresEvaluator,
        };
        assert_eq!(envelope.origin, DecisionOrigin::EvaluatorGate);
        assert_eq!(envelope.authority_effect, ContractEffect::RequiresEvaluator);
    }
}
