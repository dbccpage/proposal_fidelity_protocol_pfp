//! Exercises seed-ledger file output inside an isolated temporary directory.
//! Running the test does not publish artifacts into the repository.

use omega_atlas_reconciliation::runner::seed_rows;
use omega_atlas_reconciliation::{ledger, render};
use std::fs;
use std::io::ErrorKind;
use std::path::PathBuf;
use std::sync::atomic::{AtomicU64, Ordering};

static NEXT_DIRECTORY: AtomicU64 = AtomicU64::new(0);

/// Owns only a directory this test exclusively created and its two output files.
struct TemporaryArtifacts(PathBuf);

impl TemporaryArtifacts {
    fn new() -> Self {
        let temp_root = std::env::temp_dir()
            .canonicalize()
            .expect("temporary root must exist");
        let checkout_root = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../..")
            .canonicalize()
            .expect("checkout root must exist");
        assert!(
            !temp_root.starts_with(checkout_root),
            "artifact test temporary root must be outside the checkout"
        );

        for _ in 0..1024 {
            let serial = NEXT_DIRECTORY.fetch_add(1, Ordering::Relaxed);
            let path = temp_root.join(format!(
                "coda-atlas-ledger-test-{}-{serial}",
                std::process::id()
            ));
            match fs::create_dir(&path) {
                Ok(()) => return Self(path),
                // A parallel process or a stale previous run owns this name.
                Err(error) if error.kind() == ErrorKind::AlreadyExists => continue,
                Err(error) => panic!("cannot create isolated artifact directory: {error}"),
            }
        }
        panic!("could not reserve an isolated artifact directory");
    }
}

impl Drop for TemporaryArtifacts {
    fn drop(&mut self) {
        // Exact-file cleanup cannot sweep another test's directory contents.
        let _ = fs::remove_file(self.0.join("capability_ledger.ndjson"));
        let _ = fs::remove_file(self.0.join("capability_ledger.md"));
        let _ = fs::remove_dir(&self.0);
    }
}

#[test]
fn capability_ledger_artifacts_roundtrip_in_isolated_temp_directory() {
    let artifacts = TemporaryArtifacts::new();
    let dir = &artifacts.0;
    let rows = seed_rows();

    let ndjson = ledger::write_ndjson(&rows).expect("seed rows must serialize");
    fs::write(dir.join("capability_ledger.ndjson"), &ndjson)
        .expect("write temporary capability_ledger.ndjson");

    let md = render::render_md(&rows);
    fs::write(dir.join("capability_ledger.md"), &md).expect("write temporary capability_ledger.md");

    // Exercise the actual file outputs, including serialization and rendering.
    let written_ndjson = fs::read_to_string(dir.join("capability_ledger.ndjson"))
        .expect("read temporary capability ledger");
    assert_eq!(written_ndjson, ndjson);
    assert_eq!(
        ledger::read_ndjson(&written_ndjson).unwrap().len(),
        rows.len()
    );
    let written_md = fs::read_to_string(dir.join("capability_ledger.md"))
        .expect("read temporary rendered ledger");
    assert_eq!(written_md, md);
    assert!(written_md.contains("| asset | claim_delta | terminal | verdict |"));
}
