//! Every `omega.contract.v1` contract that names a Rust binding must bind to a
//! source that exists, declare symbols that source defines, and name tests that
//! discharge its obligations.
//!
//! `rust_file_contract` already gets this treatment from
//! `rust_file_contract_gate.rs`. The v1 math corpus never did, so a contract
//! could bind a module that was renamed, list a symbol that was deleted, or
//! declare seven negative tests with nothing exercising them, and nothing
//! objected.
//!
//! `negative_tests` is prose and cannot be checked. `rust_binding.required_tests`
//! names the test that discharges each one, which can be. A contract with no
//! `required_tests` has not recorded that pairing yet — that is the worklist, in
//! `math_contract_baseline.txt`. A partial binding remains a worklist finding;
//! naming a carrier must not masquerade as a complete realization.
//!
//! A named test must be a real `#[test]`, and is looked for across the whole
//! crate rather than only in the bound module. Both halves matter. Resolving
//! crate-wide lets an obligation that is discharged once for the crate — a
//! structural fence, say — be named by every contract it covers without each
//! module restating it. Requiring `#[test]` is what stops that from becoming a
//! loophole: a plain `fn` of the right name satisfies a substring search while
//! the harness never runs it, so the pairing would read as discharged on the
//! strength of an identifier.
//!
//! AuthorityEffect: None.

use serde::Deserialize;
use std::collections::{BTreeMap, BTreeSet};
use std::path::{Path, PathBuf};

#[derive(Debug, Deserialize)]
struct Header {
    #[serde(default)]
    schema_version: String,
}

#[derive(Debug, Deserialize)]
struct RustBinding {
    #[serde(rename = "crate")]
    krate: String,
    module: String,
    #[serde(default)]
    symbols: Vec<String>,
    #[serde(default)]
    required_tests: Vec<String>,
    #[serde(default)]
    realization_scope: RealizationScope,
}

#[derive(Debug, Default, Deserialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
enum RealizationScope {
    #[default]
    Complete,
    PartialCarrier,
}

#[derive(Debug, Deserialize)]
struct MathContract {
    contract_id: String,
    #[serde(default)]
    rust_binding: Option<RustBinding>,
    #[serde(default)]
    negative_tests: Vec<serde_yaml::Value>,
}

fn collect(dir: &Path, out: &mut Vec<PathBuf>) {
    let entries = std::fs::read_dir(dir).unwrap_or_else(|err| panic!("read {dir:?}: {err}"));
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect(&path, out);
        } else if path
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n.ends_with(".contract.yaml"))
        {
            out.push(path);
        }
    }
}

/// `backend::basic_matrix` resolves to `src/backend/basic_matrix.rs`, or to
/// `src/backend/basic_matrix/mod.rs` when the module is a directory.
fn resolve(crates_rs: &Path, krate: &str, module: &str) -> Option<PathBuf> {
    let rel = module.replace("::", "/");
    let base = crates_rs.join(krate).join("src");
    [
        base.join(format!("{rel}.rs")),
        base.join(&rel).join("mod.rs"),
    ]
    .into_iter()
    .find(|p| p.is_file())
}

fn roots() -> (PathBuf, PathBuf) {
    let manifest = Path::new(env!("CARGO_MANIFEST_DIR"));
    let crates_rs = manifest
        .parent()
        .expect("omega_contracts sits in crates_rs");
    (
        manifest.join("src/contract_canonical_definitions"),
        crates_rs.to_path_buf(),
    )
}

fn audit() -> (BTreeSet<String>, usize, usize) {
    let (corpus, crates_rs) = roots();
    let mut paths = Vec::new();
    collect(&corpus, &mut paths);
    paths.sort();

    let mut findings = BTreeSet::new();
    let (mut bound, mut specified) = (0usize, 0usize);
    let mut test_cache: BTreeMap<String, BTreeSet<String>> = BTreeMap::new();

    for path in &paths {
        let rel = path.strip_prefix(&corpus).unwrap_or(path).to_string_lossy();
        let raw = std::fs::read_to_string(path).unwrap_or_else(|e| panic!("read {path:?}: {e}"));

        match serde_yaml::from_str::<Header>(&raw) {
            Ok(h) if h.schema_version == "omega.contract.v1" => {}
            _ => continue,
        }
        let contract: MathContract = match serde_yaml::from_str(&raw) {
            Ok(c) => c,
            Err(err) => {
                findings.insert(format!("{rel}: v1 contract is malformed: {err}"));
                continue;
            }
        };
        let Some(binding) = contract.rust_binding else {
            continue;
        };
        bound += 1;

        let Some(source_path) = resolve(&crates_rs, &binding.krate, &binding.module) else {
            findings.insert(format!(
                "{}: rust_binding {}::{} resolves to no file",
                contract.contract_id, binding.krate, binding.module
            ));
            continue;
        };
        let source = std::fs::read_to_string(&source_path).expect("resolved path is readable");

        for symbol in &binding.symbols {
            let declared = regex_lite_defines(&source, symbol);
            if !declared {
                findings.insert(format!(
                    "{}: declares symbol {symbol:?} that {}::{} does not define",
                    contract.contract_id, binding.krate, binding.module
                ));
            }
        }

        if binding.realization_scope == RealizationScope::PartialCarrier {
            findings.insert(partial_carrier_finding(
                &contract.contract_id,
                &binding.krate,
                &binding.module,
            ));
        }

        if binding.required_tests.is_empty() {
            if !contract.negative_tests.is_empty() {
                findings.insert(format!(
                    "{}: declares {} negative_tests and names no required_tests, \
                     so nothing checks that any of them is exercised",
                    contract.contract_id,
                    contract.negative_tests.len()
                ));
            }
            continue;
        }
        specified += 1;

        let tests = test_cache
            .entry(binding.krate.clone())
            .or_insert_with(|| crate_test_names(&crates_rs, &binding.krate));
        for test in &binding.required_tests {
            if !tests.contains(test) {
                findings.insert(format!(
                    "{}: required test {test:?} is not a #[test] anywhere in {}",
                    contract.contract_id, binding.krate
                ));
            }
        }
    }

    (findings, bound, specified)
}

/// Every `#[test]` function name declared under a crate's `src/` or `tests/`.
fn crate_test_names(crates_rs: &Path, krate: &str) -> BTreeSet<String> {
    let mut names = BTreeSet::new();
    let mut stack = vec![
        crates_rs.join(krate).join("src"),
        crates_rs.join(krate).join("tests"),
    ];
    while let Some(dir) = stack.pop() {
        let Ok(entries) = std::fs::read_dir(&dir) else {
            continue;
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                stack.push(path);
                continue;
            }
            if path.extension().and_then(|e| e.to_str()) != Some("rs") {
                continue;
            }
            if let Ok(text) = std::fs::read_to_string(&path) {
                collect_test_fns(&text, &mut names);
            }
        }
    }
    names
}

/// A `#[test]` attribute, then whatever attributes and comments follow it, then
/// the function it applies to. Anything else clears the attribute: a `#[test]`
/// is only in force for the item directly beneath it.
fn collect_test_fns(source: &str, out: &mut BTreeSet<String>) {
    let mut armed = false;
    for line in source.lines() {
        let line = line.trim();
        if line.starts_with("#[test]") || line.starts_with("#[tokio::test]") {
            armed = true;
            continue;
        }
        if !armed {
            continue;
        }
        if line.is_empty() || line.starts_with("//") || line.starts_with('#') {
            continue;
        }
        if let Some(name) = test_fn_name(line) {
            out.insert(name);
        }
        armed = false;
    }
}

fn test_fn_name(line: &str) -> Option<String> {
    let rest = line.strip_prefix("pub ").unwrap_or(line);
    let rest = rest.strip_prefix("async ").unwrap_or(rest);
    let rest = rest.strip_prefix("fn ")?;
    let name: String = rest
        .chars()
        .take_while(|c| c.is_alphanumeric() || *c == '_')
        .collect();
    (!name.is_empty()).then_some(name)
}

fn partial_carrier_finding(contract_id: &str, krate: &str, module: &str) -> String {
    format!(
        "{contract_id}: rust_binding {krate}::{module} is explicitly partial_carrier, \
         not a complete realization"
    )
}

/// Does the source define this symbol as a type, trait, function or constant,
/// or expose it through an explicit named public re-export? Globs remain
/// insufficient because they do not identify the claimed binding.
fn regex_lite_defines(source: &str, symbol: &str) -> bool {
    let direct = [
        "struct ", "enum ", "trait ", "fn ", "type ", "const ", "static ",
    ]
    .iter()
    .any(|kw| {
        source
            .match_indices(&format!("{kw}{symbol}"))
            .any(|(i, m)| {
                // The next character must not continue the identifier, so
                // `Matrix` does not match `MatrixError`.
                source[i + m.len()..]
                    .chars()
                    .next()
                    .is_none_or(|c| !c.is_alphanumeric() && c != '_')
            })
    });
    direct
        || source.lines().any(|line| {
            let line = line.trim();
            let Some(reexport) = line
                .strip_prefix("pub use ")
                .and_then(|value| value.strip_suffix(';'))
            else {
                return false;
            };
            if reexport.ends_with("::*") {
                return false;
            }
            if let Some((_, group)) = reexport.split_once("::{") {
                let Some(group) = group.strip_suffix('}') else {
                    return false;
                };
                return group.split(',').any(|item| {
                    let mut parts = item.split_whitespace();
                    parts.next() == Some(symbol)
                        || (parts.next() == Some("as") && parts.next() == Some(symbol))
                });
            }
            reexport
                .rsplit("::")
                .next()
                .is_some_and(|item| item.trim() == symbol)
        })
}

fn baseline() -> BTreeSet<String> {
    let path = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/math_contract_baseline.txt");
    std::fs::read_to_string(&path)
        .unwrap_or_else(|e| panic!("read {}: {e}", path.display()))
        .lines()
        .map(str::trim)
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .map(str::to_owned)
        .collect()
}

#[test]
fn no_math_contract_is_unbound_beyond_the_recorded_baseline() {
    let (findings, bound, _) = audit();
    let known = baseline();

    let regressions: Vec<_> = findings.difference(&known).cloned().collect();
    assert!(
        regressions.is_empty(),
        "{} new math-contract finding(s) across {bound} bound contracts:\n  {}",
        regressions.len(),
        regressions.join("\n  ")
    );

    let repaired: Vec<_> = known.difference(&findings).cloned().collect();
    assert!(
        repaired.is_empty(),
        "{} baseline entr(ies) no longer reproduce; delete entries only when \
         their obligations are discharged, otherwise restore the explicit \
         worklist finding:\n  {}",
        repaired.len(),
        repaired.join("\n  ")
    );
}

#[test]
fn explicit_named_reexports_count_but_globs_do_not() {
    assert!(regex_lite_defines(
        "pub use crate::boundary::{Evidence, Verdict};",
        "Verdict"
    ));
    assert!(regex_lite_defines(
        "pub use crate::boundary::Evidence;",
        "Evidence"
    ));
    assert!(!regex_lite_defines(
        "pub use crate::boundary::*;",
        "Evidence"
    ));
}

#[test]
fn the_exemplars_pair_every_obligation_with_a_test() {
    let (findings, _, specified) = audit();
    // Exact ids, not substrings: omega_quantum_physics carries its own
    // density_matrix contract, and matching on the word caught that instead.
    const EXEMPLARS: [&str; 2] = [
        "urn:omega:math:basic_matrix:v1.0.0",
        "urn:omega:math:density_matrix:v1.0.0",
    ];
    let exemplars: Vec<_> = findings
        .iter()
        .filter(|f| EXEMPLARS.iter().any(|id| f.starts_with(id)))
        .cloned()
        .collect();
    assert!(
        exemplars.is_empty(),
        "the worked exemplars must stay clean; a loop copies whatever they do:\n  {}",
        exemplars.join("\n  ")
    );
    assert!(
        specified >= 2,
        "expected at least the two exemplars to name required_tests; found {specified}"
    );
}

#[test]
fn the_gate_reaches_the_corpus_it_claims_to_check() {
    let (_, bound, _) = audit();
    assert!(
        bound > 100,
        "expected the v1 corpus to bind over a hundred modules; saw {bound}"
    );
}

#[test]
fn a_partial_carrier_remains_an_explicit_worklist_finding() {
    assert_eq!(
        partial_carrier_finding(
            "urn:omega:math:combinatorial_chain_functor:v0.1.0",
            "omega_homology",
            "finite_directed_graph",
        ),
        "urn:omega:math:combinatorial_chain_functor:v0.1.0: rust_binding \
         omega_homology::finite_directed_graph is explicitly partial_carrier, \
         not a complete realization"
    );
}
