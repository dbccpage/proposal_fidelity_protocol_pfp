Math contract → `omega.contract.v1` migration checklist
=======================================================

The canonical target shape is **`finite_obstruction_trichotomy.contract.yaml`**. This
checklist captures the *machine* rules that make a converted contract load + validate
(verified against `registry/v1_types.rs`, `v1_validate.rs`, `v1_loader.rs`,
`v1_vocabulary.rs`) and the *editorial* rules for a faithful conversion.

Pilot batch (this doc's first application): `cochain_complex`, `cochain_group`,
`cech_cochain` — the cochain family adjacent to the already-migrated
`cohomology` / `chain_complex` / `gamma2_closure_defect` / `phi1_obstruction_mass`.

Hard machine rules (a violation = a corpus-gate finding)
--------------------------------------------------------

1. **Top-level keys are a closed set** (`OmegaContractV1`, `#[serde(deny_unknown_fields)]`).
   Allowed only: `schema_version, contract_id, title, kind, status, layer, role,
   descriptor, math, requirements, definition, laws, equivalence, replay, relationships,
   rust_binding, negative_tests, doctrine, wip`. **Every legacy-only key**
   (`owner, version, authority_level, description, purpose, mathematical_object,
   dependencies, required_properties, operations, refusal_conditions, allowed_artifacts,
   forbidden_artifacts, forbidden_authority, validation, rust_descriptor, tests,
   certificates, products_using, last_audited, open_questions, wip_notes`) **must be
   dropped or remapped** — a stray top-level key fails the parse.

2. **`descriptor` keys are also a closed set** (`DescriptorBlock`, `deny_unknown_fields`):
   `authority_effect, evidence_ceiling, runtime_enforcement, customer_claim_allowed,
   dependencies, terminals, refusals, operator_classes, constitution, constraints, replay,
   witnesses, subject_type, capabilities, laws, runtime_state_type`.

3. **`schema_version: "omega.contract.v1"`** exactly.
4. **`contract_id`** must start with `urn:omega:` — migrate `urn:math:contract:Foo:v0.1.0`
   → `urn:omega:math:foo:v1.0.0` (snake_case name). Must be unique across the v1 corpus.

5. **`kind: "math_contract"`** (legacy `mathematical-structure` is NOT a valid kind).
6. **Math firewall** (enforced for math kinds): `descriptor.authority_effect: "none"` and
   `descriptor.runtime_enforcement: false`.

7. **`status`** ∈ `{active, draft, deprecated, experimental, mathematical_wip,
   exact_rational_classifier_implemented}` (snake_case). Keep `mathematical_wip` unless the
   object is genuinely implemented (→ `active`).

8. **Terminals / refusals come from the seeded vocabulary only**
   (`v1_vocabulary.rs`): terminals `{ExactRepair, StabilizedSurvivor, OpenObstruction}`;
   refusals `{Invalid, Incomparable, TriRefused(NumericUndecidable), NumericUndecidable,
   UnknownTerminal, UnknownRefusal}`. A descriptive structural contract that emits **none**
   of these declares **empty** `terminals`/`refusals` — do NOT invent class names, and do
   NOT copy the trichotomy's classes into an unrelated contract.

9. **`math.codomain` must not carry `classes`/`meta_outcomes` unless those names are also in
   `descriptor.terminals.may_support` / `refusals.may_emit`** (intra-file consistency,
   `v1_loader::intra_file_consistency`). Use `codomain: { description: ... }` for structural
   objects to avoid the coupling.

10. **`descriptor.dependencies.proof_obligations`** must match `^(PO|SG|OB)-[A-Za-z0-9-]+$`.
    Omit (empty list) if none apply.

Editorial / honesty rules
-------------------------

* **Never fabricate** the math-specific sections. Map only what the legacy file states:
  * legacy `mathematical_object` → `math` (`object_kind, symbol, ascii_symbol, notation,
    domain, codomain, definition`).

  * legacy `required_properties` → `requirements.required_structures` (+ `compatibility`).
  * legacy axioms / `operations` invariants → `laws` (the mathematically-meaningful
    identities only; drop constructor/method signatures — they are code scaffolding).

  * legacy equality rules → `equivalence`; `validation.replay_requirements` → `replay`.
  * legacy `mathematical_role` / cross-references → `relationships` (link siblings with
    `[[name]]`).

  * legacy `refusal_conditions` + `tests.negative_tests` → `negative_tests` (flat strings).
  * legacy `description` / `purpose` / `non_goals` / `forbidden_authority` → `doctrine`
    (`summary` + `non_role`).

  * legacy `open_questions` / `wip_notes` → `wip`.
* **`rust_binding` only when verified.** Include `{crate, module, symbols}` ONLY for symbols
  that actually exist (grep the crate for the `pub` declaration). If they are aspirational,
  **omit `rust_binding`** rather than fabricate a binding — Pontius Pilate's governance
  daemon audits these and condemns dangling symbols. (Pilot: only `cochain_complex` had a
  real symbol — `omega_homology::CochainComplex`; the other two correctly omit it.)

* Prefer **empty `descriptor.dependencies.contracts`** and express dependencies in
  `requirements` / `relationships` until the depended-on contracts are themselves migrated
  (their canonical URN scheme is still changing).

Per-batch procedure
-------------------

1. Convert the family's files to the shape above.
2. Bump `tests/v1_corpus_gate.rs` `report.loaded >= N` by the batch size (and the comment).
3. `cargo test -j 1 -p omega_contracts` — `v1_corpus_gate`, `v1_math_recent`, and
   `math_corpus` must stay green (findings empty, ids unique, no authority violations).

4. (Optional) verify each new `rust_binding` acquits under the governance daemon.
