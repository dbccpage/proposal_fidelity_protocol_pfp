//! integration test for Anomalon Operator OS role boundaries.
//!
//! Enforces the 10 static-analysis rules to protect crate domains,
//! prevent operad/engine inflation, and preserve rational exactness.

use omega_contract_core::kinds::ComponentRole;
use omega_contract_core::registry::OmegaContractV1;
use std::collections::{BTreeMap, HashSet};
use std::path::{Path, PathBuf};

// Target crates
const TARGET_CRATES: &[&str] = &[
    "omega_pipelines",
    "omega_certifiers",
    "omega_id_run",
    "omega_replay",
    "omega_lifts",
    "omega_functional",
];

// Entry point files
const ENTRY_POINTS: &[&str] = &["lib.rs", "main.rs", "mod.rs"];

type ModuleBinding = (String, String);

/// A module can implement several independently named contract symbols. Empty
/// symbol lists retain the old module-wide binding only when no other contract
/// shares that module; they cannot silently overlap a named-symbol declaration.
/// This checks declaration ownership, not implementation or behavioral validity.
fn unique_bound_modules(
    contracts: &[(PathBuf, OmegaContractV1)],
) -> Result<HashSet<ModuleBinding>, String> {
    let mut by_module: BTreeMap<ModuleBinding, Vec<(&Path, &OmegaContractV1)>> = BTreeMap::new();
    for (path, contract) in contracts {
        if let Some(binding) = &contract.rust_binding {
            if TARGET_CRATES.contains(&binding.krate.as_str()) {
                by_module
                    .entry((binding.krate.clone(), binding.module.clone()))
                    .or_default()
                    .push((path, contract));
            }
        }
    }

    let mut modules = HashSet::new();
    for (module, declarations) in by_module {
        if declarations.len() > 1
            && declarations.iter().any(|(_, contract)| {
                contract
                    .rust_binding
                    .as_ref()
                    .is_some_and(|binding| binding.symbols.is_empty())
            })
        {
            return Err(format!(
                "Rule 2 Violation: Ambiguous module-wide binding for {module:?}"
            ));
        }
        let mut symbols = BTreeMap::new();
        for (path, contract) in declarations {
            let binding = contract.rust_binding.as_ref().expect("grouped binding");
            for symbol in &binding.symbols {
                if symbol.trim().is_empty() {
                    return Err(format!(
                        "Rule 2 Violation: Empty symbol for {module:?} in {} ({})",
                        contract.contract_id,
                        path.display()
                    ));
                }
                if let Some((previous_id, previous_path)) =
                    symbols.insert(symbol, (&contract.contract_id, path))
                {
                    return Err(format!(
                        "Rule 2 Violation: Duplicate symbol {symbol:?} for {module:?}: \
                         {previous_id} ({}) and {} ({})",
                        previous_path.display(),
                        contract.contract_id,
                        path.display()
                    ));
                }
            }
        }
        modules.insert(module);
    }
    Ok(modules)
}

/// Every declaration bound to a module contributes its restrictions; the first
/// parsed declaration must not hide a later Diagnostic, Engine or Validator role.
fn module_has_role(
    contracts: &[(PathBuf, OmegaContractV1)],
    krate: &str,
    module: &str,
    role: ComponentRole,
) -> bool {
    contracts.iter().any(|(_, contract)| {
        contract.role == Some(role)
            && contract
                .rust_binding
                .as_ref()
                .is_some_and(|binding| binding.krate == krate && binding.module == module)
    })
}

fn collect_rs_files(dir: &Path, krate: &str, out: &mut Vec<(PathBuf, String, String)>) {
    let Ok(rd) = std::fs::read_dir(dir) else {
        return;
    };
    for entry in rd.flatten() {
        let p = entry.path();
        if p.is_dir() {
            if p.file_name().and_then(|n| n.to_str()) == Some("bin") {
                continue;
            }
            collect_rs_files(&p, krate, out);
        } else if p.extension().and_then(|e| e.to_str()) == Some("rs") {
            let filename = p.file_name().and_then(|n| n.to_str()).unwrap();
            if ENTRY_POINTS.contains(&filename) {
                continue;
            }
            let stem = p.file_stem().and_then(|s| s.to_str()).unwrap().to_string();
            out.push((p, krate.to_string(), stem));
        }
    }
}

fn collect_yaml_files(dir: &Path, out: &mut Vec<PathBuf>) {
    let Ok(rd) = std::fs::read_dir(dir) else {
        return;
    };
    for entry in rd.flatten() {
        let p = entry.path();
        if p.is_dir() {
            collect_yaml_files(&p, out);
        } else if p
            .file_name()
            .and_then(|n| n.to_str())
            .is_some_and(|n| n.ends_with(".contract.yaml"))
        {
            out.push(p);
        }
    }
}

fn clean_comments(src: &str) -> String {
    let mut out = String::new();
    let mut in_block = false;
    for line in src.lines() {
        let trimmed = line.trim();
        if in_block {
            if trimmed.contains("*/") {
                in_block = false;
                if let Some(idx) = trimmed.find("*/") {
                    let rest = &trimmed[idx + 2..];
                    if !rest.trim().starts_with("//") {
                        out.push_str(rest);
                        out.push('\n');
                    }
                }
            }
            continue;
        }
        if trimmed.starts_with("/*") {
            if !trimmed.contains("*/") {
                in_block = true;
            }
            continue;
        }
        if trimmed.starts_with("//") {
            continue;
        }
        // remove inline comments
        let code = if let Some(idx) = line.find("//") {
            &line[..idx]
        } else {
            line
        };
        out.push_str(code);
        out.push('\n');
    }
    out
}

#[test]
fn test_governance_rules() {
    let manifest = Path::new(env!("CARGO_MANIFEST_DIR"));
    let corpus = manifest.join("src/contract_canonical_definitions");
    let crates_root = manifest
        .parent()
        .expect("omega_contracts sits under crates/");

    // Collect target Rust files
    let mut target_files = Vec::new();
    for krate in TARGET_CRATES {
        let src_dir = crates_root.join(krate).join("src");
        if src_dir.exists() {
            collect_rs_files(&src_dir, krate, &mut target_files);
        }
    }

    // Collect YAML contracts
    let mut yaml_files = Vec::new();
    collect_yaml_files(&corpus, &mut yaml_files);

    // Non-vacuity: every rule below is a `for` over one of these collections, so an
    // empty collection makes the whole gate pass while examining nothing. A renamed
    // crate (the `src_dir.exists()` skip above) or a moved corpus path would do it
    // silently. Assert the inputs exist before asserting anything about them.
    assert!(
        !target_files.is_empty(),
        "no target .rs files collected from {:?} for crates {:?} -- the gate would pass vacuously",
        crates_root,
        TARGET_CRATES
    );
    assert!(
        !yaml_files.is_empty(),
        "no contract YAML collected from {:?} -- the gate would pass vacuously",
        corpus
    );

    let mut contracts = Vec::new();
    let mut unparseable = Vec::new();
    for path in yaml_files {
        let text = std::fs::read_to_string(&path).expect("read yaml");
        let Ok(shallow) = serde_yaml::from_str::<serde_yaml::Value>(&text) else {
            // Previously a bare `continue`: a malformed contract was indistinguishable
            // from an absent one, so a syntax error silently removed a file from
            // governance. Collect and report instead of skipping in silence.
            unparseable.push(path);
            continue;
        };
        if shallow.get("schema_version").and_then(|v| v.as_str()) != Some("omega.contract.v1") {
            continue;
        }
        let c: OmegaContractV1 = serde_yaml::from_str(&text).expect("parse yaml");
        contracts.push((path, c));
    }
    assert!(
        unparseable.is_empty(),
        "contract YAML that does not parse is skipped by this gate, so it is governed by \
         nothing. Fix or remove: {:#?}",
        unparseable
    );
    assert!(
        !contracts.is_empty(),
        "no v1 contracts parsed -- every rule below would pass vacuously"
    );

    // Rule 1: Each module has declared coverage.
    // Rule 2: Unique named-symbol owners, with no ambiguous module-wide overlap.
    let mut bound_files =
        unique_bound_modules(&contracts).unwrap_or_else(|error| panic!("{error}"));

    let mut unmapped_files = Vec::new();
    for (path, krate, stem) in &target_files {
        let key = (krate.clone(), stem.clone());
        if !bound_files.remove(&key) {
            unmapped_files.push(format!(
                "Crate: {}, Module: {} (File: {:?})",
                krate, stem, path
            ));
        }
    }

    if !unmapped_files.is_empty() {
        panic!(
            "Rule 1 Violation: The following target Rust source files do not have a corresponding contract mapping:\n{}",
            unmapped_files.join("\n")
        );
    }

    if !bound_files.is_empty() {
        let mut real_extra = Vec::new();
        for (krate, module) in bound_files {
            if module == "lib" {
                let lib_path = crates_root.join(&krate).join("src").join("lib.rs");
                if lib_path.exists() {
                    continue;
                }
            }
            real_extra.push(format!("{}::{}", krate, module));
        }
        if !real_extra.is_empty() {
            panic!(
                "Rule 1 Violation: The following contract bindings specify target-crate files that do not exist:\n{}",
                real_extra.join("\n")
            );
        }
    }

    // Rule 3: Exact cannot use f64
    let exact_rational_modules = [
        ("omega_functional", "gamma2"),
        ("omega_functional", "phi1"),
        ("omega_functional", "trichotomy"),
    ];

    for (path, krate, stem) in &target_files {
        let is_exact = exact_rational_modules
            .iter()
            .any(|(ek, es)| ek == krate && es == stem);
        if is_exact {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            if clean_src.contains("f64") {
                panic!(
                    "Rule 3 Violation: Exact rational file {:?} contains the forbidden substring 'f64'",
                    path
                );
            }
        }
    }

    // Rule 4: Diagnostic cannot mint authority
    for (path, krate, stem) in &target_files {
        if module_has_role(&contracts, krate, stem, ComponentRole::Diagnostic) {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &[
                "fn authority_from_outcome",
                "fn mint_authority",
                "CertifiedAuthority::certify",
                "promote_authorized_local_result_v1",
                "AuthorityEffect::Certified",
            ] {
                if clean_src.contains(forbidden) {
                    panic!(
                            "Rule 4 Violation: Diagnostic file {:?} contains forbidden authority-construction token '{}'",
                            path, forbidden
                        );
                }
            }
        }
    }

    // Rule 5: omega_id_run cannot own functionals
    for (path, krate, _stem) in &target_files {
        if krate == "omega_id_run" {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &[
                "struct Phi1Functional",
                "impl Phi1Functional",
                "struct Gamma2Functional",
                "impl Gamma2Functional",
            ] {
                if clean_src.contains(forbidden) {
                    panic!(
                        "Rule 5 Violation: omega_id_run file {:?} defines or implements forbidden functional '{}'",
                        path, forbidden
                    );
                }
            }
        }
    }

    // Rule 6: Xi cannot certify
    for (path, _krate, stem) in &target_files {
        let references_xi = stem == "xi" || stem == "xi_diagnostic";
        if references_xi {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &[
                "authority_from_outcome",
                "mint_authority",
                "CertifiedAuthority::certify",
                "promote_authorized_local_result_v1",
                "AuthorityEffect::Certified",
            ] {
                if clean_src.contains(forbidden) {
                    panic!(
                        "Rule 6 Violation: File {:?} defining/referencing Xi contains forbidden authority-construction token '{}'",
                        path, forbidden
                    );
                }
            }
        }
    }

    // Rule 7: Pipeline cannot terminalize
    for (path, krate, _stem) in &target_files {
        if krate == "omega_pipelines" {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &["authority_from_outcome", "mint_authority", "Terminalizer"] {
                if clean_src.contains(forbidden) {
                    panic!(
                        "Rule 7 Violation: omega_pipelines file {:?} contains forbidden token '{}'",
                        path, forbidden
                    );
                }
            }
        }
    }

    // Rule 8: Functional cannot judge
    for (path, krate, _stem) in &target_files {
        if krate == "omega_functional" {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &[
                "PolicyDecision",
                "TerminalEnvelope",
                "evaluate_admissibility",
                "authorize_transition",
                "Admissibility",
            ] {
                if clean_src.contains(forbidden) {
                    panic!(
                        "Rule 8 Violation: omega_functional file {:?} contains forbidden evaluator/judgment logic token '{}'",
                        path, forbidden
                    );
                }
            }
        }
    }

    // Rule 9: Engine cannot compute
    let mut engine_files = Vec::new();
    let engine_src_dir = crates_root.join("omega_engines").join("src");
    if engine_src_dir.exists() {
        collect_rs_files(&engine_src_dir, "omega_engines", &mut engine_files);
    }
    for (path, krate, stem) in target_files.iter().chain(&engine_files) {
        let is_engine = krate == "omega_engines"
            || module_has_role(&contracts, krate, stem, ComponentRole::Engine);
        if is_engine {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &[
                "struct Phi1Functional",
                "impl Phi1Functional",
                "struct Gamma2Functional",
                "impl Gamma2Functional",
            ] {
                if clean_src.contains(forbidden) {
                    panic!(
                        "Rule 9 Violation: Engine-role file {:?} contains forbidden functional token '{}'",
                        path, forbidden
                    );
                }
            }
        }
    }

    // Rule 10: Validator cannot repair/certify/evaluate
    for (path, krate, stem) in &target_files {
        if module_has_role(&contracts, krate, stem, ComponentRole::Validator) {
            let src = std::fs::read_to_string(path).expect("read source file");
            let clean_src = clean_comments(&src);
            for forbidden in &[
                "repair_target",
                "normalize_target",
                "fix_target",
                "EngineResult",
                "PolicyDecision",
                "TerminalEnvelope",
                "ActionLicense",
                "sign_certificate",
                "save_certificate",
                "create_certificate",
            ] {
                if clean_src.contains(forbidden) {
                    panic!(
                        "Rule 10 Violation: Validator-role file {:?} contains forbidden token '{}'",
                        path, forbidden
                    );
                }
            }
        }
    }
}

fn binding_fixture(
    id: &str,
    symbols: &[&str],
    role: Option<ComponentRole>,
) -> (PathBuf, OmegaContractV1) {
    let mut contract: OmegaContractV1 = serde_yaml::from_str(include_str!(
        "../src/contract_canonical_definitions/math/quantum_gaps.contract.yaml"
    ))
    .expect("real named-symbol contract must parse");
    contract.contract_id = id.into();
    contract.role = role;
    contract.rust_binding.as_mut().unwrap().symbols =
        symbols.iter().map(|symbol| (*symbol).into()).collect();
    (PathBuf::from(format!("{id}.contract.yaml")), contract)
}

#[test]
fn distinct_real_symbols_can_share_their_actual_module() {
    let contracts = [
        (
            PathBuf::from("quantum_gaps.contract.yaml"),
            serde_yaml::from_str(include_str!(
                "../src/contract_canonical_definitions/math/quantum_gaps.contract.yaml"
            ))
            .unwrap(),
        ),
        (
            PathBuf::from("quantum_gap_functional.contract.yaml"),
            serde_yaml::from_str(include_str!(
                "../src/contract_canonical_definitions/math/quantum_gap_functional.contract.yaml"
            ))
            .unwrap(),
        ),
    ];
    let expected = HashSet::from([("omega_functional".into(), "quantum_gaps".into())]);
    assert_eq!(unique_bound_modules(&contracts).unwrap(), expected);
    let reversed = [contracts[1].clone(), contracts[0].clone()];
    assert_eq!(unique_bound_modules(&reversed).unwrap(), expected);
}

#[test]
fn duplicate_named_symbol_has_a_bounded_ownership_refusal() {
    let contracts = [
        binding_fixture("first", &["QuantumGaps"], None),
        binding_fixture("second", &["QuantumGaps"], None),
    ];
    assert_eq!(
        unique_bound_modules(&contracts).unwrap_err(),
        "Rule 2 Violation: Duplicate symbol \"QuantumGaps\" for (\"omega_functional\", \"quantum_gaps\"): first (first.contract.yaml) and second (second.contract.yaml)"
    );
}

#[test]
fn a_declaration_cannot_repeat_its_own_symbol() {
    let contracts = [binding_fixture(
        "repeated",
        &["QuantumGaps", "QuantumGaps"],
        None,
    )];
    assert_eq!(
        unique_bound_modules(&contracts).unwrap_err(),
        "Rule 2 Violation: Duplicate symbol \"QuantumGaps\" for (\"omega_functional\", \"quantum_gaps\"): repeated (repeated.contract.yaml) and repeated (repeated.contract.yaml)"
    );
}

#[test]
fn a_sole_module_wide_binding_remains_admitted() {
    assert_eq!(
        unique_bound_modules(&[binding_fixture("module", &[], None)]).unwrap(),
        HashSet::from([("omega_functional".into(), "quantum_gaps".into())])
    );
}

#[test]
fn module_wide_and_named_bindings_are_ambiguous_in_either_order() {
    for other_symbols in [&[][..], &["QuantumGaps"][..]] {
        let contracts = [
            binding_fixture("module", &[], None),
            binding_fixture("other", other_symbols, None),
        ];
        let reversed = [contracts[1].clone(), contracts[0].clone()];
        for order in [&contracts, &reversed] {
            assert_eq!(
                unique_bound_modules(order).unwrap_err(),
                "Rule 2 Violation: Ambiguous module-wide binding for (\"omega_functional\", \"quantum_gaps\")"
            );
        }
    }
}

#[test]
fn blank_symbols_cannot_disguise_a_module_wide_binding() {
    for symbol in ["", " "] {
        let contracts = [binding_fixture("empty", &[symbol], None)];
        assert_eq!(
            unique_bound_modules(&contracts).unwrap_err(),
            "Rule 2 Violation: Empty symbol for (\"omega_functional\", \"quantum_gaps\") in empty (empty.contract.yaml)"
        );
    }
}

#[test]
fn every_matching_role_applies_in_both_contract_orders() {
    for role in [
        ComponentRole::Diagnostic,
        ComponentRole::Engine,
        ComponentRole::Validator,
    ] {
        let contracts = [
            binding_fixture("unrestricted", &["QuantumGaps"], None),
            binding_fixture("restricted", &["QuantumGapFunctional"], Some(role)),
        ];
        assert_eq!(unique_bound_modules(&contracts).unwrap().len(), 1);
        let reversed = [contracts[1].clone(), contracts[0].clone()];
        for order in [&contracts, &reversed] {
            assert!(module_has_role(
                order,
                "omega_functional",
                "quantum_gaps",
                role
            ));
            assert!(!module_has_role(
                order,
                "omega_functional",
                "other_module",
                role
            ));
            assert!(!module_has_role(order, "other_crate", "quantum_gaps", role));
        }
        assert!(!module_has_role(
            &contracts[..1],
            "omega_functional",
            "quantum_gaps",
            role
        ));
    }
}
