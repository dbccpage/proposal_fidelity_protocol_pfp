//! Witness module for law enforcement.
//!
//! Canonical witness types live in `crate::witness::evidence`.
//! Test-time property macros live beside the persistent evidence producers but
//! do not emit persisted witness artifacts.
