use omega_contracts::artifact_policy::{
    build_publication_plan_v1, gate_artifact_route_v1, redact_artifact_v1, ArtifactLicenseV1,
    ArtifactPolicyError, ArtifactPolicyV1, ArtifactRouteV1, PolicyArtifactV1, RedactionRuleV1,
    RetentionClassV1, VisibilityClassV1, ARTIFACT_POLICY_SCHEMA_V1,
};
use omega_types::authority::AuthorityEffect;

const HASH: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";

fn policy(visibility: VisibilityClassV1) -> ArtifactPolicyV1 {
    ArtifactPolicyV1 {
        schema_version: ARTIFACT_POLICY_SCHEMA_V1.to_owned(),
        artifact_id: "artifact-1".to_owned(),
        visibility,
        retention: RetentionClassV1::Project,
        permitted_observers: vec!["host".to_owned()],
        permitted_routes: vec![
            ArtifactRouteV1::InternalModel,
            ArtifactRouteV1::ExternalModel,
            ArtifactRouteV1::Log,
            ArtifactRouteV1::Memory,
            ArtifactRouteV1::Publication,
        ],
        license: ArtifactLicenseV1::Licensed {
            identifier: "MIT".to_owned(),
        },
        provenance_sha256: HASH.to_owned(),
        expires_at_epoch_seconds: None,
        authority_effect: AuthorityEffect::None,
    }
}

fn artifact(bytes: &[u8]) -> PolicyArtifactV1 {
    PolicyArtifactV1 {
        artifact_id: "artifact-1".to_owned(),
        bytes: bytes.to_vec(),
    }
}

#[test]
fn unknown_visibility_class_fails_deserialization() {
    let json = serde_json::to_value(policy(VisibilityClassV1::Public)).unwrap();
    let mut object = json.as_object().unwrap().clone();
    object.insert("visibility".to_owned(), "secretish".into());
    let parsed: Result<ArtifactPolicyV1, _> = serde_json::from_value(object.into());
    assert!(parsed.is_err());
}

#[test]
fn private_artifact_is_refused_by_external_model_route() {
    let error = gate_artifact_route_v1(
        &artifact(b"private"),
        &policy(VisibilityClassV1::Private),
        ArtifactRouteV1::ExternalModel,
        "host",
        1,
        None,
    )
    .unwrap_err();
    assert_eq!(error, ArtifactPolicyError::PrivateExternalRoute);
}

#[test]
fn private_logs_and_memory_require_byte_bound_redaction() {
    let original = artifact(b"token=secret");
    let (redacted, receipt) = redact_artifact_v1(
        &original,
        &[RedactionRuleV1 {
            literal: b"secret".to_vec(),
            replacement: b"[REDACTED]".to_vec(),
        }],
    )
    .unwrap();
    assert_ne!(receipt.input_sha256(), receipt.output_sha256());
    assert!(receipt.authority_effect().is_none());
    assert_eq!(receipt.artifact_id(), "artifact-1");
    assert_eq!(receipt.rule_count(), 1);

    for route in [ArtifactRouteV1::Log, ArtifactRouteV1::Memory] {
        let no_receipt = gate_artifact_route_v1(
            &original,
            &policy(VisibilityClassV1::Private),
            route,
            "host",
            1,
            None,
        );
        assert_eq!(
            no_receipt.unwrap_err(),
            ArtifactPolicyError::RedactionRequired
        );
        let routed = gate_artifact_route_v1(
            &redacted,
            &policy(VisibilityClassV1::Private),
            route,
            "host",
            1,
            Some(&receipt),
        )
        .unwrap();
        assert!(routed.redaction_receipt_sha256.is_some());
    }
}

#[test]
fn tampered_redacted_bytes_fail_receipt_binding() {
    let original = artifact(b"token=secret");
    let (_, receipt) = redact_artifact_v1(
        &original,
        &[RedactionRuleV1 {
            literal: b"secret".to_vec(),
            replacement: b"[REDACTED]".to_vec(),
        }],
    )
    .unwrap();
    let error = gate_artifact_route_v1(
        &artifact(b"token=tampered"),
        &policy(VisibilityClassV1::Private),
        ArtifactRouteV1::Memory,
        "host",
        1,
        Some(&receipt),
    )
    .unwrap_err();
    assert_eq!(error, ArtifactPolicyError::RedactionReceiptMismatch);
}

#[test]
fn expired_artifacts_are_excluded_and_unlicensed_artifacts_block_release() {
    let mut expired = policy(VisibilityClassV1::Public);
    expired.expires_at_epoch_seconds = Some(10);
    let plan = build_publication_plan_v1(&[(artifact(b"expired"), expired)], 10, true).unwrap();
    assert!(plan.artifacts.is_empty());
    assert!(!plan.publication_performed);

    let mut unlicensed = policy(VisibilityClassV1::Public);
    unlicensed.license = ArtifactLicenseV1::Unlicensed;
    assert_eq!(
        build_publication_plan_v1(&[(artifact(b"blocked"), unlicensed)], 1, true).unwrap_err(),
        ArtifactPolicyError::Unlicensed
    );
}

#[test]
fn publication_needs_human_promotion_and_still_does_not_publish() {
    let entries = [(artifact(b"public"), policy(VisibilityClassV1::Public))];
    assert_eq!(
        build_publication_plan_v1(&entries, 1, false).unwrap_err(),
        ArtifactPolicyError::HumanPromotionRequired
    );
    let plan = build_publication_plan_v1(&entries, 1, true).unwrap();
    assert!(plan.human_promotion_recorded);
    assert!(!plan.publication_performed);
    assert!(plan.authority_effect.is_none());
}
