//! Partition-refinement algorithm and minimal adequate congruence-core quotient engine.
//!
//! Formal Lean 4 backing: `004_pcc_finite_refine.lean` and `004_pcc_adequacy.lean` (ProofPacketPCC).
//! Theorem C1 (`PCC.adequacy`): Quotient space `X / Core_C(ker o)` is the minimal adequate representation.
//! Theorem A4 (`PCC.sub_core_of_invariant`): `Core_C(R)` is the unique maximal C-invariant sub-relation.

use std::collections::{BTreeMap, BTreeSet};

/// Result of a partition refinement computation for a state space under context action.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct QuotientPartition {
    /// Equivalence classes, where each class is a list of state indices.
    pub equivalence_classes: Vec<Vec<usize>>,
    /// State index to quotient class index mapping.
    pub class_map: Vec<usize>,
    /// Iteration level at which the partition stabilized (P_{k+1} == P_k).
    pub stabilization_index: usize,
    /// Total number of minimal adequate quotient states |X_hat|.
    pub num_classes: usize,
}

/// Compute the contextual congruence core partition for a finite state space X.
///
/// # Parameters
/// - `num_states`: Total number of states in X (indexed 0..num_states-1).
/// - `num_actions`: Total number of context actions in C (indexed 0..num_actions-1).
/// - `transition`: Function `T(c, x) -> x'` returning state after action `c`.
/// - `observe`: Function `O(x) -> observable_id` returning discrete observable.
pub fn compute_congruence_core<FTrans, FObs, O>(
    num_states: usize,
    num_actions: usize,
    transition: FTrans,
    observe: FObs,
) -> QuotientPartition
where
    FTrans: Fn(usize, usize) -> usize,
    FObs: Fn(usize) -> O,
    O: Ord + Clone,
{
    if num_states == 0 {
        return QuotientPartition {
            equivalence_classes: Vec::new(),
            class_map: Vec::new(),
            stabilization_index: 0,
            num_classes: 0,
        };
    }

    // Level 0: Initial partition by immediate observation O(x)
    let mut current_class_map = vec![0; num_states];
    let mut obs_to_class: BTreeMap<O, usize> = BTreeMap::new();
    let mut next_class_id = 0;

    for x in 0..num_states {
        let obs = observe(x);
        let class_id = *obs_to_class.entry(obs).or_insert_with(|| {
            let id = next_class_id;
            next_class_id += 1;
            id
        });
        current_class_map[x] = class_id;
    }

    let mut prev_num_classes = obs_to_class.len();
    let mut stabilization_index = 0;

    loop {
        // Compute signature vector for each state under current partition:
        // Signature(x) = (current_class_map[x], [current_class_map[c • x] for c in C])
        let mut sig_to_new_class: BTreeMap<(usize, Vec<usize>), usize> = BTreeMap::new();
        let mut new_class_map = vec![0; num_states];
        let mut new_next_id = 0;

        for x in 0..num_states {
            let cur_c = current_class_map[x];
            let mut action_targets = Vec::with_capacity(num_actions);
            for c in 0..num_actions {
                let next_x = transition(c, x);
                action_targets.push(current_class_map[next_x]);
            }
            let sig = (cur_c, action_targets);

            let new_id = *sig_to_new_class.entry(sig).or_insert_with(|| {
                let id = new_next_id;
                new_next_id += 1;
                id
            });
            new_class_map[x] = new_id;
        }

        // Check if partition stabilized (number of classes unchanged & identical equivalence relation)
        if new_next_id == prev_num_classes && new_class_map == current_class_map {
            break;
        }

        current_class_map = new_class_map;
        prev_num_classes = new_next_id;
        stabilization_index += 1;
    }

    // Reconstruct equivalence classes
    let num_classes = *current_class_map.iter().max().unwrap_or(&0) + 1;
    let mut equivalence_classes = vec![Vec::new(); num_classes];
    for (x, &cls) in current_class_map.iter().enumerate() {
        equivalence_classes[cls].push(x);
    }

    QuotientPartition {
        equivalence_classes,
        class_map: current_class_map,
        stabilization_index,
        num_classes,
    }
}

/// Check if two states x and y are congruence-core equivalent under all contexts up to depth D.
pub fn is_congruence_equivalent<FTrans, FObs, O>(
    num_actions: usize,
    transition: &FTrans,
    observe: &FObs,
    x: usize,
    y: usize,
    max_depth: usize,
) -> bool
where
    FTrans: Fn(usize, usize) -> usize,
    FObs: Fn(usize) -> O,
    O: PartialEq,
{
    if observe(x) != observe(y) {
        return false;
    }
    if max_depth == 0 || num_actions == 0 {
        return true;
    }

    let mut queue = vec![(x, y, 0)];
    let mut visited = BTreeSet::new();
    visited.insert((x, y));

    while let Some((sx, sy, depth)) = queue.pop() {
        if depth >= max_depth {
            continue;
        }
        for c in 0..num_actions {
            let nx = transition(c, sx);
            let ny = transition(c, sy);
            if observe(nx) != observe(ny) {
                return false;
            }
            if visited.insert((nx, ny)) {
                queue.push((nx, ny, depth + 1));
            }
        }
    }

    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_constant_profile_single_class() {
        // All states observe 0 -> 1 equivalence class, 0 stabilization steps
        let num_states = 5;
        let num_actions = 2;
        let transition = |_c, x| (x + 1) % num_states;
        let observe = |_x| 0;

        let partition = compute_congruence_core(num_states, num_actions, transition, observe);
        assert_eq!(partition.num_classes, 1);
        assert_eq!(partition.stabilization_index, 0);
        assert_eq!(partition.equivalence_classes[0].len(), 5);
    }

    #[test]
    fn test_fiber_flip_two_classes() {
        // States 0,1 observe 0; states 2,3 observe 1
        let num_states = 4;
        let num_actions = 1;
        let transition = |_c, x| match x {
            0 => 1,
            1 => 0,
            2 => 3,
            _ => 2,
        };
        let observe = |x| if x < 2 { 0 } else { 1 };

        let partition = compute_congruence_core(num_states, num_actions, transition, observe);
        assert_eq!(partition.num_classes, 2);
        assert_eq!(partition.stabilization_index, 0);
    }

    #[test]
    fn test_chain4_peeling_stabilization() {
        // 4-state chain peeling:
        // State 3 observes 1; states 0,1,2 observe 0.
        // Action 0 steps forward: 0->1, 1->2, 2->3, 3->3.
        // Step 0: {0,1,2}, {3}
        // Step 1: {0,1}, {2}, {3}
        // Step 2: {0}, {1}, {2}, {3} (stabilizes at index 2 with 4 classes)
        let num_states = 4;
        let num_actions = 1;
        let transition = |_c: usize, x: usize| if x < 3 { x + 1 } else { 3 };
        let observe = |x: usize| if x == 3 { 1 } else { 0 };

        let partition = compute_congruence_core(num_states, num_actions, transition, observe);
        assert_eq!(partition.num_classes, 4);
        assert_eq!(partition.stabilization_index, 2);
        for i in 0..4 {
            assert_eq!(partition.equivalence_classes[i].len(), 1);
        }
    }
}
