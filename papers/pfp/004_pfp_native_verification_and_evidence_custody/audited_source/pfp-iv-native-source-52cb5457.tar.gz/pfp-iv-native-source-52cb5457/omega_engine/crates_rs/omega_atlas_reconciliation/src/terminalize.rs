pub use omega_terminalizers::pointed_classifier::{
    terminalize, ObstructionStatus, TerminalizerRefusal,
};
