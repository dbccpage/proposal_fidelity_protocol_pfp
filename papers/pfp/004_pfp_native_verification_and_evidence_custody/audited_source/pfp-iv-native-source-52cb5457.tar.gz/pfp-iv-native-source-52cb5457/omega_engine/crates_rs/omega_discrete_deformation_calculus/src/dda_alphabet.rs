//! The canonical DDA operation alphabet — `{E, R, C, I, Λ/Meta, D, M, T}`.
//!
//! Canonical provenance:
//! `coda_atlas/F004_papers/006_project_anomalon_codename_woland_omega_engine/001_discrete_deformation_calculus/discrete_deformation_calculus.md`
//! (Paper ID: `oe_010_dda_trace_calculus`, Series: `008_engine_runtime`).
//!
//! GTOC is no longer used; all current DDA hails from Discrete Deformation Calculus (DDC / DDA).
//!
//! Three core DDC obligations are carried structurally, not by comment:
//!
//! * **DDA-0 / Lawful Transition Typing** (`OE010-01`..`OE010-05`) — "Every lawful transition
//!   must emit a typed DDA operation together with the local execution log or explicit refusal to
//!   execute." A [`DdaStep`] cannot be constructed without a [`StepOutcome`], so
//!   a logless step is unrepresentable rather than merely discouraged.
//! * **DDC Out-of-Window Import Boundary** — imported representation theorems (Gleason, Hilbert space, Born
//!   ontology) are *not* DDA operations; a transformation licensed from outside
//!   the declared finite 2-window is an import/oracle and drives the trace to
//!   [`TraceTerminal::OracleNeeded`]. There is deliberately **no** `DdaOp`
//!   variant for "import" — see [`DdaTrace::import`].
//! * **DDC No-Authority Firewall** (`OE010-04`) — a well-typed DDA trace does not mint authority. [`DdaTrace`]
//!   exposes [`DdaTrace::authority_effect`], which returns
//!   `AuthorityEffect::None` unconditionally; the type has no method producing an
//!   authority-bearing value at all. Authorization requires the separate host
//!   promotion contract with verified certificate, receipt DAG, witness
//!   attestation, and human event; none of those capabilities lives here.
//!
//! What this module is NOT: a scheduler, a prover, or an authority source. It
//! records which lawful op was emitted, with what log, in what order.

use omega_types::authority::AuthorityEffect;
use serde::{Deserialize, Serialize};

/// The eight lawful transitions of Discrete Deformation Calculus (`discrete_deformation_calculus.md` §1).
///
/// The letters are the canonical DDA operational alphabet \(\mathcal{A}_{\mathrm{DDA}} = \{E, R, C, I, \Lambda, D, M, T\}\).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum DdaOp {
    /// `E` — exact repair: discharge the defect outright (residual → 0).
    ExactRepair,
    /// `R` — residual projection: carry forward what repair could not remove.
    ResidualProjection,
    /// `C` — context exposure: declare/split the carrier and its 2-window.
    ContextExposure,
    /// `I` — integration: append to the local ledger.
    Integration,
    /// `Λ`/`Meta` — structural lift or extension. Lift *trigger* is not lift
    /// *license*: a lift needs obstruction, preservation, and
    /// non-destruction witnesses plus a terminalizer route.
    Lift,
    /// `D` — descent / re-index (e.g. refine the window).
    Descent,
    /// `M` — mutation / typed refusal.
    Refusal,
    /// `T` — terminalization. Emitting `T` records a terminal status; it does
    /// **not** mint authority (`AuthorityEffect::None`).
    Terminalize,
}

impl DdaOp {
    /// The spine letter.
    pub fn letter(self) -> &'static str {
        match self {
            DdaOp::ExactRepair => "E",
            DdaOp::ResidualProjection => "R",
            DdaOp::ContextExposure => "C",
            DdaOp::Integration => "I",
            DdaOp::Lift => "Λ",
            DdaOp::Descent => "D",
            DdaOp::Refusal => "M",
            DdaOp::Terminalize => "T",
        }
    }

    /// The full declared alphabet, in spine order.
    pub fn alphabet() -> [DdaOp; 8] {
        [
            DdaOp::ExactRepair,
            DdaOp::ResidualProjection,
            DdaOp::ContextExposure,
            DdaOp::Integration,
            DdaOp::Lift,
            DdaOp::Descent,
            DdaOp::Refusal,
            DdaOp::Terminalize,
        ]
    }
}

/// DDC invariant: every emitted op carries **either** its local execution log
/// Canonical closed refusal vocabulary (matching DDC paper M_REASONS).
///
/// Refusal is a typed terminal, not an unhandled error. Each variant
/// represents a closed reason code.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub enum RefusalReason {
    #[serde(rename = "REFUSED_INVALID_WITNESS")]
    RefusedInvalidWitness,
    #[serde(rename = "REFUSED_BUDGET_EXHAUSTED")]
    RefusedBudgetExhausted,
    #[serde(rename = "REFUSED_NON_ZERO_CURL")]
    RefusedNonZeroCurl,
    #[serde(rename = "REFUSED_UNLICENSED_LIFT")]
    RefusedUnlicensedLift,
    #[serde(rename = "REFUSED_LIFT_TRIGGER")]
    RefusedLiftTrigger,
    #[serde(rename = "REFUSED_MISSING_LOSS_LEDGER")]
    RefusedMissingLossLedger,
    #[serde(rename = "REFUSED_MISSING_RECEIPT")]
    RefusedMissingReceipt,
    #[serde(rename = "REFUSED_REQUIRES_LIFT")]
    RefusedRequiresLift,
    #[serde(rename = "REFUSED_DETECTOR_INADEQUATE")]
    RefusedDetectorInadequate,
    #[serde(rename = "REFUSED_OPEN_OBSTRUCTION")]
    RefusedOpenObstruction,
}

impl RefusalReason {
    pub fn as_str(self) -> &'static str {
        match self {
            RefusalReason::RefusedInvalidWitness => "REFUSED_INVALID_WITNESS",
            RefusalReason::RefusedBudgetExhausted => "REFUSED_BUDGET_EXHAUSTED",
            RefusalReason::RefusedNonZeroCurl => "REFUSED_NON_ZERO_CURL",
            RefusalReason::RefusedUnlicensedLift => "REFUSED_UNLICENSED_LIFT",
            RefusalReason::RefusedLiftTrigger => "REFUSED_LIFT_TRIGGER",
            RefusalReason::RefusedMissingLossLedger => "REFUSED_MISSING_LOSS_LEDGER",
            RefusalReason::RefusedMissingReceipt => "REFUSED_MISSING_RECEIPT",
            RefusalReason::RefusedRequiresLift => "REFUSED_REQUIRES_LIFT",
            RefusalReason::RefusedDetectorInadequate => "REFUSED_DETECTOR_INADEQUATE",
            RefusalReason::RefusedOpenObstruction => "REFUSED_OPEN_OBSTRUCTION",
        }
    }

    pub fn from_str_code(s: &str) -> Option<Self> {
        match s {
            "REFUSED_INVALID_WITNESS" => Some(RefusalReason::RefusedInvalidWitness),
            "REFUSED_BUDGET_EXHAUSTED" => Some(RefusalReason::RefusedBudgetExhausted),
            "REFUSED_NON_ZERO_CURL" => Some(RefusalReason::RefusedNonZeroCurl),
            "REFUSED_UNLICENSED_LIFT" => Some(RefusalReason::RefusedUnlicensedLift),
            "REFUSED_LIFT_TRIGGER" => Some(RefusalReason::RefusedLiftTrigger),
            "REFUSED_MISSING_LOSS_LEDGER" => Some(RefusalReason::RefusedMissingLossLedger),
            "REFUSED_MISSING_RECEIPT" => Some(RefusalReason::RefusedMissingReceipt),
            "REFUSED_REQUIRES_LIFT" => Some(RefusalReason::RefusedRequiresLift),
            "REFUSED_DETECTOR_INADEQUATE" => Some(RefusalReason::RefusedDetectorInadequate),
            "REFUSED_OPEN_OBSTRUCTION" => Some(RefusalReason::RefusedOpenObstruction),
            _ => None,
        }
    }
}

impl std::fmt::Display for RefusalReason {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

impl From<&str> for RefusalReason {
    fn from(s: &str) -> Self {
        if let Some(r) = Self::from_str_code(s) {
            return r;
        }
        let lower = s.to_lowercase();
        if lower.contains("lift") {
            Self::RefusedUnlicensedLift
        } else if lower.contains("budget") {
            Self::RefusedBudgetExhausted
        } else if lower.contains("curl") || lower.contains("exact") {
            Self::RefusedNonZeroCurl
        } else if lower.contains("ledger") || lower.contains("loss") {
            Self::RefusedMissingLossLedger
        } else if lower.contains("receipt") {
            Self::RefusedMissingReceipt
        } else if lower.contains("detector")
            || lower.contains("inadequate")
            || lower.contains("blind")
        {
            Self::RefusedDetectorInadequate
        } else if lower.contains("open") || lower.contains("obstruction") {
            Self::RefusedOpenObstruction
        } else {
            Self::RefusedInvalidWitness
        }
    }
}

impl From<String> for RefusalReason {
    fn from(s: String) -> Self {
        Self::from(s.as_str())
    }
}

impl From<&String> for RefusalReason {
    fn from(s: &String) -> Self {
        Self::from(s.as_str())
    }
}

/// DDC invariant: every emitted op carries **either** its local execution log
/// **or** an explicit refusal to execute. There is no third state, and no way to
/// emit an op with neither.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub enum StepOutcome {
    /// The op executed; the string is the local execution log.
    Executed { log: String },
    /// The op was refused; carries a typed refusal reason from [`RefusalReason`].
    RefusedToExecute { reason: RefusalReason },
}

/// One lawful transition: a typed op plus its log-or-refusal.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub struct DdaStep {
    pub op: DdaOp,
    pub outcome: StepOutcome,
}

impl DdaStep {
    /// Emit an executed op with its local execution log.
    pub fn executed(op: DdaOp, log: impl Into<String>) -> Self {
        Self {
            op,
            outcome: StepOutcome::Executed { log: log.into() },
        }
    }

    /// Emit an op that explicitly refused to execute.
    pub fn refused(op: DdaOp, reason: impl Into<RefusalReason>) -> Self {
        Self {
            op,
            outcome: StepOutcome::RefusedToExecute {
                reason: reason.into(),
            },
        }
    }

    /// True when the step actually ran.
    pub fn is_executed(&self) -> bool {
        matches!(self.outcome, StepOutcome::Executed { .. })
    }
}

/// Where a trace currently stands. Not an authority (`AuthorityEffect::None`); a status.
#[derive(Debug, Clone, PartialEq, Eq, Serialize)]
pub enum TraceTerminal {
    /// No `T` and no `M` yet.
    Open,
    /// `T` emitted and executed through a gated terminalizer.
    Terminalized,
    /// `T` emitted through raw `emit` without a gated terminalizer (Hole 7).
    UnverifiedTerminal,
    /// `M` emitted: typed refusal. A valid terminal, not a failure.
    Refused,
    /// DDC: an import/oracle was requested — outside the declared window.
    /// The trace cannot terminalize on its own authority.
    OracleNeeded { import: String },
}

/// An append-only sequence of lawful transitions.
///
/// Mints nothing. See the module docs for the DDC obligations this type
/// carries structurally.
#[derive(Debug, Clone, Default, PartialEq, Eq, Serialize)]
pub struct DdaTrace {
    steps: Vec<DdaStep>,
    oracle: Option<String>,
    gated_terminal: bool,
}

impl DdaTrace {
    pub fn new() -> Self {
        Self {
            steps: Vec::new(),
            oracle: None,
            gated_terminal: false,
        }
    }

    /// Append a lawful transition via the raw path.
    ///
    /// Per Hole 7, emitting `Terminalize` here does NOT produce `TraceTerminal::Terminalized`.
    /// Only [`Self::emit_gated_terminal`] or a verified terminalizer can set `Terminalized`.
    pub fn emit(&mut self, step: DdaStep) -> &mut Self {
        self.steps.push(step);
        self
    }

    /// Gated terminalization: records an executed terminal from a verified gate.
    /// Closes Hole 7: raw `emit` cannot yield `TraceTerminal::Terminalized`.
    pub fn emit_gated_terminal(&mut self, step: DdaStep) -> &mut Self {
        self.gated_terminal = true;
        self.steps.push(step);
        self
    }

    /// DDC Out-of-Window Import: record that a transformation was licensed from **outside** the
    /// declared finite 2-window (an imported representation theorem, a
    /// continuum move, ...). This is deliberately *not* a [`DdaOp`]: the
    /// alphabet has no import letter, because an import is not a lawful
    /// transition. It drives the terminal to [`TraceTerminal::OracleNeeded`]
    /// and cannot be cleared by emitting more ops.
    pub fn import(&mut self, what: impl Into<String>) -> &mut Self {
        self.oracle = Some(what.into());
        self
    }

    pub fn steps(&self) -> &[DdaStep] {
        &self.steps
    }

    /// The spine letters, in emission order — e.g. `"C E D Λ I T"`.
    pub fn letters(&self) -> String {
        self.steps
            .iter()
            .map(|s| s.op.letter())
            .collect::<Vec<_>>()
            .join(" ")
    }

    /// Current terminal status.
    ///
    /// An outstanding import wins over everything: an oracle cannot be
    /// terminalized away by appending `T`.
    pub fn terminal(&self) -> TraceTerminal {
        if let Some(import) = &self.oracle {
            return TraceTerminal::OracleNeeded {
                import: import.clone(),
            };
        }
        for step in self.steps.iter().rev() {
            match (step.op, step.is_executed()) {
                (DdaOp::Terminalize, true) => {
                    if self.gated_terminal {
                        return TraceTerminal::Terminalized;
                    } else {
                        return TraceTerminal::UnverifiedTerminal;
                    }
                }
                (DdaOp::Refusal, true) => return TraceTerminal::Refused,
                _ => {}
            }
        }
        TraceTerminal::Open
    }

    /// **DDC No-Authority Firewall (`OE010-04`).** A well-typed DDA trace does not mint authority.
    /// This is the only authority-shaped method on the type and it is constant:
    /// no trace, however long, well-typed, or terminalized, can return anything
    /// else. Authority requires verified certificates and external promotion.
    pub fn authority_effect(&self) -> AuthorityEffect {
        AuthorityEffect::None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn alphabet_is_the_eight_spine_letters() {
        let letters: Vec<&str> = DdaOp::alphabet().iter().map(|o| o.letter()).collect();
        assert_eq!(letters, ["E", "R", "C", "I", "Λ", "D", "M", "T"]);
    }

    #[test]
    fn ddc_every_step_carries_log_or_refusal() {
        // The invariant is structural: both constructors demand a payload, so a
        // logless step cannot be built. Assert both shapes round-trip.
        let e = DdaStep::executed(DdaOp::ExactRepair, "discharged defect on e_3");
        let m = DdaStep::refused(DdaOp::Lift, "no non-destruction witness");
        assert!(e.is_executed());
        assert!(!m.is_executed());
        match m.outcome {
            StepOutcome::RefusedToExecute { reason } => {
                assert_eq!(reason, RefusalReason::RefusedInvalidWitness);
            }
            _ => panic!("expected refusal"),
        }
    }

    #[test]
    fn trace_records_letters_in_order() {
        let mut t = DdaTrace::new();
        t.emit(DdaStep::executed(
            DdaOp::ContextExposure,
            "carrier declared",
        ))
        .emit(DdaStep::executed(DdaOp::ExactRepair, "antiderivative"))
        .emit(DdaStep::executed(DdaOp::Descent, "refine P_n -> P_2n"));
        assert_eq!(t.letters(), "C E D");
        assert_eq!(t.terminal(), TraceTerminal::Open);
    }

    #[test]
    fn terminalize_sets_terminalized() {
        let mut t = DdaTrace::new();
        t.emit_gated_terminal(DdaStep::executed(DdaOp::Terminalize, "sealed 1000/3"));
        assert_eq!(t.terminal(), TraceTerminal::Terminalized);
    }

    #[test]
    fn raw_terminalize_yields_unverified_terminal() {
        let mut t = DdaTrace::new();
        t.emit(DdaStep::executed(DdaOp::Terminalize, "sealed 1000/3"));
        assert_eq!(t.terminal(), TraceTerminal::UnverifiedTerminal);
    }

    #[test]
    fn typed_refusal_is_a_valid_terminal() {
        let mut t = DdaTrace::new();
        t.emit(DdaStep::executed(
            DdaOp::Refusal,
            "Dirichlet: debt #4 unpayable",
        ));
        assert_eq!(t.terminal(), TraceTerminal::Refused);
    }

    #[test]
    fn refused_terminalize_does_not_terminalize() {
        // An op that refused to execute did not happen.
        let mut t = DdaTrace::new();
        t.emit(DdaStep::refused(DdaOp::Terminalize, "no witness support"));
        assert_eq!(t.terminal(), TraceTerminal::Open);
    }

    #[test]
    fn ddc_import_forces_oracle_needed() {
        let mut t = DdaTrace::new();
        t.emit(DdaStep::executed(DdaOp::ContextExposure, "window"))
            .import("Gleason's theorem");
        match t.terminal() {
            TraceTerminal::OracleNeeded { import } => assert_eq!(import, "Gleason's theorem"),
            other => panic!("expected OracleNeeded, got {other:?}"),
        }
    }

    #[test]
    fn ddc_oracle_cannot_be_terminalized_away() {
        // Appending T after an import must NOT clear the oracle: an import is
        // licensed from outside the declared window and no lawful op can pay it.
        let mut t = DdaTrace::new();
        t.import("continuum path integral")
            .emit_gated_terminal(DdaStep::executed(DdaOp::Terminalize, "claiming a seal"));
        assert!(matches!(t.terminal(), TraceTerminal::OracleNeeded { .. }));
    }

    #[test]
    fn ddc_no_trace_mints_authority() {
        // Empty, executed, terminalized, refused — every shape returns None.
        let empty = DdaTrace::new();
        assert_eq!(empty.authority_effect(), AuthorityEffect::None);

        let mut sealed = DdaTrace::new();
        for op in DdaOp::alphabet() {
            if op == DdaOp::Terminalize {
                sealed.emit_gated_terminal(DdaStep::executed(op, "log"));
            } else {
                sealed.emit(DdaStep::executed(op, "log"));
            }
        }
        assert_eq!(sealed.terminal(), TraceTerminal::Terminalized);
        assert_eq!(
            sealed.authority_effect(),
            AuthorityEffect::None,
            "DDC No-Authority Firewall: a well-typed, fully terminalized trace still mints nothing"
        );
    }
}
