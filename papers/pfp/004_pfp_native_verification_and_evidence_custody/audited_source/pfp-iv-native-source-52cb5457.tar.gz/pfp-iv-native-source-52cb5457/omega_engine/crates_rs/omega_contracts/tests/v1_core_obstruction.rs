//! Sprint 2 — the migrated 03_obstruction layer loads and validates cleanly.
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn obstruction_layer_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/03_core_obstruction");
    let report = load_v1_dir(&dir).expect("dir readable");
    assert_eq!(
        report.loaded, 5,
        "expected 5 migrated obstruction contracts"
    );
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}
