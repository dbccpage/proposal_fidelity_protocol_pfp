use omega_discrete_deformation_calculus::{
    Cochain1, FiniteWindow, LambdaAlgebraError, OrientedTriangle,
};
use std::collections::BTreeMap;

/// 1. Locally acceptable judgments whose triangle does not close.
/// We construct a situation where Author accepts Proposal (edge AP = 0),
/// Proposal is accepted by Evaluator (edge PE = 0), yet the Evaluator
/// does not accept the Author (edge EA = 1). Despite edge-wise local
/// compatibility, the global triangle boundary does not close (d1 h != 0).
#[test]
fn demo_1_locally_acceptable_triangle_does_not_close() -> Result<(), LambdaAlgebraError> {
    let window = FiniteWindow::new(
        vec!["A", "P", "E"],
        vec![("A", "P"), ("P", "E"), ("A", "E")],
        vec![OrientedTriangle::new("A", "P", "E")],
    );

    let mut cochain = Cochain1::new();
    cochain.checked_add_term("A", "P", 0)?; // Author accepts Proposal
    cochain.checked_add_term("P", "E", 0)?; // Proposal accepted by Evaluator
    cochain.checked_add_term("E", "A", 1)?; // Evaluator has discrepancy with Author

    // d1 h (boundary check) = ab + bc + ca
    // ab = 0, bc = 0, ca = 1 -> 1 != 0.
    let scan = window.checked_scan_c1(&cochain)?;
    assert_eq!(
        scan.face_gamma2[0], 1,
        "The triangle closure check yields a non-zero defect"
    );
    assert_eq!(scan.gamma2_total, 1);

    Ok(())
}

/// 2. Degenerate shared projection (common-mode failure).
/// We show that under a degenerate projection P1 that discards a critical
/// distinction, the tripartite system appears completely consistent (gamma2 = 0).
/// Under an alternative projection P2 that retains the distinction, the
/// inconsistency is exposed as a non-zero closure defect (gamma2 = 1).
#[test]
fn demo_2_common_mode_failure_under_degenerate_projection() -> Result<(), LambdaAlgebraError> {
    struct State {
        secret_bit: bool,
    }

    let author_state = State { secret_bit: true };
    let proposal_state = State { secret_bit: false };
    let evaluator_state = State { secret_bit: true };

    let window = FiniteWindow::new(
        vec!["A", "P", "E"],
        vec![("A", "P"), ("P", "E"), ("A", "E")],
        vec![OrientedTriangle::new("A", "P", "E")],
    );

    // Projection 1: Degenerate projection map (discards secret_bit, mapping all to 0)
    let p1 = |_s: &State| -> i64 { 0 };

    let mut cochain_p1 = Cochain1::new();
    cochain_p1.checked_add_term("A", "P", p1(&author_state) - p1(&proposal_state))?;
    cochain_p1.checked_add_term("P", "E", p1(&proposal_state) - p1(&evaluator_state))?;
    cochain_p1.checked_add_term("E", "A", p1(&evaluator_state) - p1(&author_state))?;

    let scan_p1 = window.checked_scan_c1(&cochain_p1)?;
    assert_eq!(
        scan_p1.gamma2_total, 0,
        "Degenerate projection hides the composition defect"
    );

    // Projection 2: Alternative projection map (retains secret_bit as 1 or 0)
    let p2 = |s: &State| -> i64 {
        if s.secret_bit {
            1
        } else {
            0
        }
    };

    // A checks P (accepts P's public state) -> 0
    // E checks P (detects P's secret_bit does not match E's expectation) -> 1
    // A checks E (accepts E) -> 0
    let mut cochain_p2 = Cochain1::new();
    cochain_p2.checked_add_term("A", "P", 0)?;
    cochain_p2.checked_add_term("P", "E", p2(&evaluator_state) - p2(&proposal_state))?; // 1 - 0 = 1
    cochain_p2.checked_add_term("E", "A", 0)?;

    let scan_p2 = window.checked_scan_c1(&cochain_p2)?;
    assert_eq!(
        scan_p2.gamma2_total, 1,
        "Alternative projection exposes the hidden composition defect"
    );

    Ok(())
}

/// 3. Quotienting reduces candidate evaluation count.
/// We demonstrate that grouping candidates by their obstruction signature
/// (cardinality of quotient classes) reduces the number of full evaluations needed.
#[test]
fn demo_3_quotienting_reduces_evaluation_overhead() {
    struct Proposal {
        _content: String,
        signature: (u64, u64),
    }

    let candidates = vec![
        Proposal {
            _content: "A1".to_string(),
            signature: (1, 0),
        },
        Proposal {
            _content: "A2".to_string(),
            signature: (1, 0),
        },
        Proposal {
            _content: "A3".to_string(),
            signature: (1, 0),
        },
        Proposal {
            _content: "B1".to_string(),
            signature: (0, 2),
        },
        Proposal {
            _content: "B2".to_string(),
            signature: (0, 2),
        },
        Proposal {
            _content: "C1".to_string(),
            signature: (0, 0),
        },
    ];

    // Quotienting: Group proposals by signature.
    let mut quotient: BTreeMap<(u64, u64), Vec<&Proposal>> = BTreeMap::new();
    for p in &candidates {
        quotient.entry(p.signature).or_default().push(p);
    }

    // 6 candidates are reduced to 3 equivalence classes.
    assert_eq!(quotient.len(), 3);
    assert!(quotient.len() < candidates.len());
}
