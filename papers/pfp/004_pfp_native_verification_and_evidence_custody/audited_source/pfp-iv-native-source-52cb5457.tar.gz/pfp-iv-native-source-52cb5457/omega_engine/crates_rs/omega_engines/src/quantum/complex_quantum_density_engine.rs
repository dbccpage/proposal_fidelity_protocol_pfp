use crate::quantum::density_config::DensityMatrixConfig;
use crate::quantum::density_error::DensityMatrixError;
use crate::quantum::density_matrix::{CVector, ComplexDensityMatrix};
use constants::numeric_constants::EPSILON_QUANTUM_EIGEN;
use nalgebra::{Complex, DMatrix};
use tracing::debug;

fn complex_to_real_block(matrix: &DMatrix<Complex<f64>>) -> DMatrix<f64> {
    let n = matrix.nrows();
    let mut block = DMatrix::zeros(2 * n, 2 * n);
    for i in 0..n {
        for j in 0..n {
            let z = matrix[(i, j)];
            block[(i, j)] = z.re;
            block[(i, j + n)] = -z.im;
            block[(i + n, j)] = z.im;
            block[(i + n, j + n)] = z.re;
        }
    }
    block
}

pub struct ComplexQuantumDensityEngine;

impl ComplexQuantumDensityEngine {
    pub fn complex_state_from_embedding(
        embedding: &[f64],
        phase_fn: Option<&dyn Fn(usize, f64) -> f64>,
    ) -> Result<CVector, DensityMatrixError> {
        if embedding.is_empty() || embedding.iter().any(|x| !x.is_finite()) {
            return Err(DensityMatrixError::NonPhysical);
        }
        let max_val = embedding.iter().cloned().fold(f64::NEG_INFINITY, f64::max);
        let exps: Vec<f64> = embedding.iter().map(|x| (x - max_val).exp()).collect();
        let sum: f64 = exps.iter().sum();
        if sum < EPSILON_QUANTUM_EIGEN || !sum.is_finite() {
            return Err(DensityMatrixError::NonPhysical);
        }

        let mut psi = CVector::zeros(embedding.len());
        for (i, &x) in embedding.iter().enumerate() {
            let p = exps[i] / sum;
            let phase = phase_fn.map(|f| f(i, x)).unwrap_or(0.0);
            if !phase.is_finite() {
                return Err(DensityMatrixError::NonPhysical);
            }
            psi[i] = Complex::from_polar(p.sqrt(), phase);
        }

        let cfg = DensityMatrixConfig::default();
        let norm2: f64 = psi.iter().map(|c| c.re * c.re + c.im * c.im).sum();
        if (norm2 - 1.0).abs() > cfg.trace_tol() {
            return Err(DensityMatrixError::TraceNotOne {
                trace: norm2,
                tol: cfg.trace_tol(),
            });
        }

        Ok(psi)
    }

    pub fn apply_complex_unitary(
        dm: &ComplexDensityMatrix,
        u: &nalgebra::DMatrix<Complex<f64>>,
    ) -> Result<ComplexDensityMatrix, DensityMatrixError> {
        if u.nrows() != dm.dim() || u.ncols() != dm.dim() {
            return Err(DensityMatrixError::DimensionMismatch {
                expected: dm.dim(),
                actual: u.nrows(),
            });
        }

        let cfg = DensityMatrixConfig::default();
        let identity = nalgebra::DMatrix::<Complex<f64>>::identity(dm.dim(), dm.dim());
        let check = u.adjoint() * u;

        let mut max_diff = 0.0_f64;
        for i in 0..dm.dim() {
            for j in 0..dm.dim() {
                let diff_val = check[(i, j)] - identity[(i, j)];
                let diff = diff_val.re.hypot(diff_val.im);
                if diff > max_diff {
                    max_diff = diff;
                }
            }
        }

        let frob_diff = (check - identity).norm();

        if max_diff > cfg.unitary_tol() || frob_diff > cfg.unitary_tol() {
            return Err(DensityMatrixError::NonUnitary { defect: frob_diff });
        }

        let new_rho = u * dm.rho() * u.adjoint();
        let result = ComplexDensityMatrix::from_validated(
            new_rho.nrows(),
            new_rho.as_slice().to_vec(),
            &cfg,
        )
        .unwrap();

        let trace = result.rho().trace();
        let eigs = nalgebra::SymmetricEigen::new(complex_to_real_block(result.rho())).eigenvalues;
        let min_ev = eigs.iter().cloned().fold(f64::INFINITY, f64::min);

        debug!(
            "defect metrics: |tr(ρ) - 1| = {:.10}, λ_min = {:.10}",
            (trace.re - 1.0).abs(),
            min_ev
        );

        debug_assert!(result.rho().iter().all(|x| x.is_finite()));
        debug_assert!(result.rho().trace().im.abs() <= cfg.trace_tol());

        if !result.rho().iter().all(|x| x.is_finite()) {
            return Err(DensityMatrixError::NonPhysical);
        }

        let mut max_hermitian_defect = trace.im.abs();
        let adjoint = result.rho().adjoint();
        for i in 0..result.dim() {
            for j in 0..result.dim() {
                let diff = result.rho()[(i, j)] - adjoint[(i, j)];
                let defect = diff.re.hypot(diff.im);
                if defect > max_hermitian_defect {
                    max_hermitian_defect = defect;
                }
            }
        }

        if max_hermitian_defect > cfg.hermitian_tol() {
            return Err(DensityMatrixError::NonHermitian {
                defect: max_hermitian_defect,
            });
        }

        if (trace.re - 1.0).abs() > cfg.trace_tol() {
            return Err(DensityMatrixError::TraceNotOne {
                trace: trace.re,
                tol: cfg.trace_tol(),
            });
        }

        if min_ev < -cfg.psd_tol() {
            return Err(DensityMatrixError::NotPositiveSemidefinite {
                min_eigenvalue: min_ev,
                tol: cfg.psd_tol(),
            });
        }

        Ok(result)
    }

    pub fn validate_complex_density_matrix(
        dm: ComplexDensityMatrix,
    ) -> Result<ComplexDensityMatrix, DensityMatrixError> {
        let cfg = DensityMatrixConfig::default();
        let trace = dm.rho().trace();
        let eigs = nalgebra::SymmetricEigen::new(complex_to_real_block(dm.rho())).eigenvalues;
        let min_ev = eigs.iter().cloned().fold(f64::INFINITY, f64::min);

        debug!(
            "defect metrics: |tr(ρ) - 1| = {:.10}, λ_min = {:.10}",
            (trace.re - 1.0).abs(),
            min_ev
        );

        debug_assert!(dm.rho().trace().im.abs() <= cfg.trace_tol());

        if !dm.rho().iter().all(|x| x.is_finite()) {
            return Err(DensityMatrixError::NonPhysical);
        }

        let mut max_hermitian_defect = trace.im.abs();
        let adjoint = dm.rho().adjoint();
        for i in 0..dm.dim() {
            for j in 0..dm.dim() {
                let diff = dm.rho()[(i, j)] - adjoint[(i, j)];
                let defect = diff.re.hypot(diff.im);
                if defect > max_hermitian_defect {
                    max_hermitian_defect = defect;
                }
            }
        }

        if max_hermitian_defect > cfg.hermitian_tol() {
            return Err(DensityMatrixError::NonHermitian {
                defect: max_hermitian_defect,
            });
        }

        if (trace.re - 1.0).abs() > cfg.trace_tol() {
            return Err(DensityMatrixError::TraceNotOne {
                trace: trace.re,
                tol: cfg.trace_tol(),
            });
        }

        if min_ev < -cfg.psd_tol() {
            return Err(DensityMatrixError::NotPositiveSemidefinite {
                min_eigenvalue: min_ev,
                tol: cfg.psd_tol(),
            });
        }

        Ok(dm)
    }

    pub fn purity_complex(dm: &ComplexDensityMatrix) -> Result<f64, DensityMatrixError> {
        let cfg = DensityMatrixConfig::default();
        let tr = (dm.rho() * dm.rho()).trace();
        if tr.im.abs() > cfg.hermitian_tol() {
            return Err(DensityMatrixError::NonHermitian {
                defect: tr.im.abs(),
            });
        }
        Ok(tr.re)
    }

    pub fn von_neumann_entropy_complex(
        dm: &ComplexDensityMatrix,
    ) -> Result<f64, DensityMatrixError> {
        let cfg = DensityMatrixConfig::default();
        let eigs = nalgebra::SymmetricEigen::new(complex_to_real_block(dm.rho())).eigenvalues;
        let mut entropy = 0.0;

        for &lam in &eigs {
            if lam < -cfg.psd_tol() {
                return Err(DensityMatrixError::NotPositiveSemidefinite {
                    min_eigenvalue: lam,
                    tol: cfg.psd_tol(),
                });
            } else if lam > 0.0 {
                entropy += -lam * lam.ln();
            }
        }
        Ok(entropy)
    }

    pub fn diagonal_overlap_fidelity(
        a: &ComplexDensityMatrix,
        b: &ComplexDensityMatrix,
    ) -> Result<f64, DensityMatrixError> {
        if a.dim() != b.dim() {
            return Err(DensityMatrixError::DimensionMismatch {
                expected: a.dim(),
                actual: b.dim(),
            });
        }
        let cfg = DensityMatrixConfig::default();
        let mut sum = 0.0;

        for i in 0..a.dim() {
            let ai = a.rho()[(i, i)].re;
            let bi = b.rho()[(i, i)].re;

            if ai < -cfg.psd_tol() || bi < -cfg.psd_tol() {
                return Err(DensityMatrixError::NotPositiveSemidefinite {
                    min_eigenvalue: ai.min(bi),
                    tol: cfg.psd_tol(),
                });
            }

            if ai > 0.0 && bi > 0.0 {
                sum += (ai * bi).sqrt();
            }
        }

        let overlap = sum * sum;
        if overlap < -cfg.trace_tol() || overlap > 1.0 + cfg.trace_tol() {
            return Err(DensityMatrixError::NonPhysical);
        }

        Ok(overlap)
    }

    pub fn full_fidelity_complex_unimplemented(
        a: &ComplexDensityMatrix,
        b: &ComplexDensityMatrix,
    ) -> Result<f64, DensityMatrixError> {
        if a.dim() != b.dim() {
            return Err(DensityMatrixError::DimensionMismatch {
                expected: a.dim(),
                actual: b.dim(),
            });
        }
        Err(DensityMatrixError::NonPhysical)
    }
}
