use omega_atlas_reconciliation::primitive_difference::*;
fn ray_zero(a: &Vec<i64>, b: &Vec<i64>) -> bool {
    a.len() == b.len() && !a.is_empty() && a.iter().zip(b).all(|(x, y)| x * b[0] == y * a[0])
}
#[test]
fn invariant_observable_factors() {
    let phi = |v: &Vec<i64>| -> i64 { v[0].signum() };
    let pd = PrimitiveDifference::new(ray_zero);
    let witnesses = vec![(vec![2, 4], vec![1, 2]), (vec![3, 3], vec![6, 6])];
    assert!(pd.factors_through(&witnesses, &phi));
}
#[test]
fn noninvariant_observable_is_real_obstruction() {
    let psi = |v: &Vec<i64>| -> i64 { v[0] };
    let pd = PrimitiveDifference::new(ray_zero);
    let witnesses = vec![(vec![2, 4], vec![1, 2])];
    assert!(!pd.factors_through(&witnesses, &psi));
}
#[test]
fn lggr_pair_witness() {
    let phi = |v: &Vec<i64>| v[0].signum();
    let psi = |v: &Vec<i64>| v[0];
    let pd = PrimitiveDifference::new(ray_zero);
    let w = (vec![2, 4], vec![1, 2]);
    assert!(pd.invariant_on(&[w.clone()], &phi));
    assert!(!pd.invariant_on(&[w], &psi));
}
