Integration Notes
=================

> [!NOTE]
> **Disposition:** dated integration note for the first Q-continuum slice.
> Current Q admission policy also lives in `omega_q`, while the shared data
> kernel remains in `omega_types::q_continuum`.

1. Location
-----------

The shared Q-continuum data kernel lives in:

* `omega_engine/crates/omega_types/src/q_continuum.rs`

It is exported from:

* `omega_engine/crates/omega_types/src/lib.rs`

The current Q admission and packet policy surface lives in:

* `omega_engine/crates/omega_q/`

2. Existing Code Connection
---------------------------

`omega_types` is the shared DTO crate, already using serde and low-level authority terminology. The Q-continuum layer is placed there because it is a serializable boundary vocabulary rather than an engine. Current admission behavior is handled by `omega_q`.

The implementation does not replace existing certified authority, terminal status, or finite descent code.

3. Stubbed
----------

Stubbed or DESIGN_ONLY:

* durable storage,
* external finite descent engine (running it — the receipt is produced externally),
* proof checker bridge — *partially implemented*: `verify_lean_witness` consumes a Lean `#print axioms` receipt (`LeanWitness`) and enforces the firewall rule on its shape; it does not invoke `lake`/`lean`,
* empirical measurement pipeline,
* replay artifact store,
* adversarial review automation.

4. Implemented
--------------

Implemented:

* Q input DTOs,
* probe kinds,
* finite projections,
* descent obligations,
* descent results,
* residuals,
* authority scopes,
* authority traces,
* in-memory ledger,
* deterministic probe plan generation,
* descent gate boundary,
* tests for the required invariants.

5. Design-Only
--------------

`TerminalCandidate` exists as a record, but external terminal certification remains DESIGN_ONLY. Persistence is also DESIGN_ONLY.

6. How To Run Tests
-------------------

From `omega_engine`:

```powershell
cargo test -p omega_types q_continuum -j 1
cargo test -p omega_q -j 1
cargo check -p omega_types -j 1
```

7. How To Extend
----------------

Next extensions should stay narrow:

* add real finite descent adapters,
* add receipt links to ledger rows,
* add persistence only after a storage owner is clear,
* add proof-engine bridges only with explicit theorem receipts,
* add richer probe generators only if their outputs remain finite and auditable.
