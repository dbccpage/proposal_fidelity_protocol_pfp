//! Actual native command tests; checked-in code only. AuthorityEffect: None.

use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::io::Write;
use std::process::{Command, Stdio};

fn hash(bytes: &[u8]) -> String {
    format!("{:x}", Sha256::digest(bytes))
}

fn fixture() -> Value {
    let document = b"schema_version: omega.file_contract.v1\ncontract_id: urn:test:command:v1\ncrate: omega_fixture\nfile: crates_rs/omega_fixture/src/lib.rs\nrole: fixture\nstatus: active\nauthority_effect: none\nrequired_substrings: ['return 7']\nrequired_tests: ['returns_seven']\n";
    let source = b"pub fn value() -> u8 { return 7; }";
    let document_path = "omega_engine_governance/contracts/test/file.contract.yaml";
    let source_path = "omega_engine/crates_rs/omega_fixture/src/lib.rs";
    json!({
        "documents": [{"path": document_path, "bytes": document.to_vec()}],
        "sources": [{"path": source_path, "owner": "omega_fixture", "bytes": source.to_vec()}],
        "bindings": [{
            "document": document_path, "contract_id": "urn:test:command:v1",
            "declared_file": "crates_rs/omega_fixture/src/lib.rs", "source": source_path,
            "owner": "omega_fixture", "document_sha256": hash(document), "source_sha256": hash(source),
        }],
    })
}

fn invoke(raw: &[u8]) -> (i32, Value) {
    let mut child = Command::new(env!("CARGO_BIN_EXE_omega_contract_binding_audit"))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("native fixture process must start");
    child.stdin.take().unwrap().write_all(raw).unwrap();
    let output = child
        .wait_with_output()
        .expect("native fixture process must end");
    assert!(output.stderr.is_empty(), "{:?}", output.stderr);
    let status = output
        .status
        .code()
        .expect("process must have an exit code");
    let value = match serde_json::from_slice(&output.stdout) {
        Ok(value) => value,
        Err(error) => panic!("native output was not JSON: {error}"),
    };
    (status, value)
}

#[test]
fn native_command_binds_input_digest_without_claiming_execution() {
    let raw = serde_json::to_vec(&fixture()).unwrap();
    let (code, result) = invoke(&raw);
    assert_eq!(code, 0);
    assert_eq!(result["input_sha256"], hash(&raw));
    assert_eq!(
        result["schema_version"],
        "omega.source-binding.command-outcome.v1"
    );
    assert_eq!(result["static_bindings_complete"], true);
    assert_eq!(result["authority_effect"], "None");
    assert_eq!(result["audit"]["behavioral_validation"], "NOT_PERFORMED");
    assert_eq!(
        result["audit"]["execution_obligations"][0]["test"],
        "returns_seven"
    );
    assert_eq!(
        result["audit"]["execution_obligations"][0]["state"],
        "EXECUTION_EVIDENCE_NOT_SUPPLIED"
    );
}

#[test]
fn native_command_refuses_stale_source_with_a_named_finding() {
    let mut input = fixture();
    input["sources"][0]["bytes"] = json!(b"pub fn value() -> u8 { return 0; }".to_vec());
    let raw = serde_json::to_vec(&input).unwrap();
    let (code, result) = invoke(&raw);
    assert_eq!(code, 1);
    assert_eq!(result["input_sha256"], hash(&raw));
    assert_eq!(result["static_bindings_complete"], false);
    let findings = result["audit"]["findings"]
        .as_array()
        .expect("findings must be retained");
    assert!(findings.iter().any(|row| row["code"] == "STALE_SOURCE"));
    assert_eq!(result["audit"]["supplied_sources"], 1);
}

#[test]
fn native_command_refuses_missing_binding_without_dropping_inputs() {
    let mut input = fixture();
    input["bindings"] = json!([]);
    let (code, result) = invoke(&serde_json::to_vec(&input).unwrap());
    assert_eq!(code, 1);
    assert_eq!(result["static_bindings_complete"], false);
    assert_eq!(result["audit"]["sources"].as_array().unwrap().len(), 1);
    assert_eq!(result["audit"]["documents"].as_array().unwrap().len(), 1);
    assert!(result["audit"]["findings"]
        .as_array()
        .unwrap()
        .iter()
        .any(|row| row["code"] == "UNBOUND_SOURCE"));
}

#[test]
fn native_command_refuses_unknown_fields_and_malformed_bytes() {
    let mut input = fixture();
    input["claim_all_tests_passed"] = json!(true);
    for raw in [
        serde_json::to_vec(&input).unwrap(),
        vec![0xff],
        b"null".to_vec(),
    ] {
        let (code, result) = invoke(&raw);
        assert_eq!(code, 2);
        assert_eq!(result["refusal"], "INPUT_SCHEMA_REFUSED");
        assert_eq!(result["static_bindings_complete"], false);
        assert_eq!(result["authority_effect"], "None");
        assert!(result.get("audit").is_none());
    }
}
