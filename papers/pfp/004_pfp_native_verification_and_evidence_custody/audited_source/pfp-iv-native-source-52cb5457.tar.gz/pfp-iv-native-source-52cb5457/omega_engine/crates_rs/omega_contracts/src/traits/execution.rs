use crate::kinds::{BaseType, ContractEffect};
use crate::traits::identity::NamedComponent as OperatorIdentity;
use omega_types::trace_artifact::TraceArtifact;

pub trait Runtime<S: BaseType> {
    type Pipeline: Pipeline<S>;
    type Input;
    type RuntimeState: BaseType;
    type Output;
    type Trace: TraceArtifact;
    type Error;

    // (state, output, trace) is the contract's canonical step result triple.
    #[allow(clippy::type_complexity)]
    fn start(
        &mut self,
        input: Self::Input,
    ) -> Result<(Self::RuntimeState, Self::Output, Self::Trace), Self::Error>;
}

pub trait Pipeline<S: BaseType> {
    type Engine: Engine<S>;
    type PipelineState: BaseType;
    type Output: BaseType;
    type Trace: TraceArtifact;
    type Error;

    // (state, output, trace) is the contract's canonical step result triple.
    #[allow(clippy::type_complexity)]
    fn run(
        &mut self,
        input: S,
    ) -> Result<(Self::PipelineState, Self::Output, Self::Trace), Self::Error>;
}

pub trait Engine<S: BaseType> {
    type Operator: OperatorIdentity;
    type License;
    type RuntimeState: BaseType;
    type Output: BaseType;
    type Trace: TraceArtifact;
    type Error;

    // (state, output, trace) is the contract's canonical step result triple.
    #[allow(clippy::type_complexity)]
    fn step(
        &mut self,
        state: S,
        license: &Self::License,
    ) -> Result<(Self::RuntimeState, Self::Output, Self::Trace), Self::Error>;
}

pub trait Search<S: BaseType>: Pipeline<S> {}
pub trait Solver<S: BaseType>: Pipeline<S> {}
pub trait SelectionStrategy {}
pub trait ContinuationPolicy {}
pub trait BudgetPolicy {}

// =============================================================================
// Kernel Contract (06_execution.yaml)
// =============================================================================

/// Bounded authority unit owning exactly one semantic class.
/// Maps to kernel contract in 06_execution.yaml.
///
/// Kernel is a bounded authority declaration for one semantic class. Kernels are not operators,
/// do not participate in E/I/C/R/M, and do not execute unless a separate Engine contract grants
/// StateTransition authority.
pub trait Kernel {
    type SemanticClass;
    type InputFamily;
    type OutputFamily;

    fn kernel_id(&self) -> &str;
    fn semantic_class(&self) -> &Self::SemanticClass;
    fn input_families(&self) -> Vec<&Self::InputFamily>;
    fn output_families(&self) -> Vec<&Self::OutputFamily>;
}

/// Kernel manifest declares the bounded authority unit.
#[derive(Debug, Clone)]
pub struct KernelManifest {
    pub kernel_id: String,
    pub semantic_class: String,
    pub input_family_refs: Vec<String>,
    pub output_family_refs: Vec<String>,
    pub manifest_hash: String,
}

// =============================================================================
// Health Model Contract (06_execution.yaml)
// =============================================================================

/// Invariant-relative health reporting.
/// Maps to health_model contract in 06_execution.yaml.
///
/// HealthModel reports invariant-relative health state. Raw health reports are EvidenceOnly.
/// Checked health reports may support FactOnly claims only after source, invariant family,
/// measurement, and certificate references are checked.
pub trait HealthModel {
    type Subject;
    type InvariantFamily;
    type Report;
    type Error;

    fn report_health(
        &self,
        subject: &Self::Subject,
        invariant_family: &Self::InvariantFamily,
    ) -> Result<Self::Report, Self::Error>;
}

/// Health state enumeration from 06_execution.yaml.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HealthState {
    Healthy,
    Degraded,
    InvariantThreat,
    BoundaryFailure,
    Unknown,
}

/// Health report structure.
#[derive(Debug, Clone)]
pub struct HealthReport {
    pub subject_ref: String,
    pub invariant_family_ref: String,
    pub health_state: HealthState,
    pub measurement_refs: Vec<String>,
    pub evidence_refs: Vec<String>,
    pub report_hash: String,
    pub authority_effect: ContractEffect,
}

impl HealthReport {
    pub fn new(
        subject_ref: String,
        invariant_family_ref: String,
        health_state: HealthState,
        measurement_refs: Vec<String>,
        evidence_refs: Vec<String>,
        report_hash: String,
    ) -> Self {
        Self {
            subject_ref,
            invariant_family_ref,
            health_state,
            measurement_refs,
            evidence_refs,
            report_hash,
            authority_effect: ContractEffect::EvidenceOnly,
        }
    }
}

// =============================================================================
// Health Reporting Interface Contract (06_execution.yaml)
// =============================================================================

/// Reference-only consumption boundary for health reports.
/// Maps to health_reporting_interface contract in 06_execution.yaml.
///
/// HealthReportingInterface exposes health report references to consumers without creating
/// new authority. It does not prescribe action, evaluate, certify, license, execute, or mutate.
pub trait HealthReportingInterface {
    type ReportRef;
    type Consumer;
    type View;
    type Error;

    fn view_report(
        &self,
        report_ref: &Self::ReportRef,
        consumer: &Self::Consumer,
    ) -> Result<Self::View, Self::Error>;
}

/// Health report view structure.
#[derive(Debug, Clone)]
pub struct HealthReportView {
    pub report_ref: String,
    pub consumer_ref: String,
    pub projection_schema_ref: String,
    pub view_hash: String,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn health_report_defaults_to_evidence_only() {
        let report = HealthReport::new(
            "subject:1".to_string(),
            "invariant:1".to_string(),
            HealthState::Healthy,
            Vec::new(),
            Vec::new(),
            "hash:report".to_string(),
        );
        assert_eq!(report.authority_effect, ContractEffect::EvidenceOnly);
    }
}
