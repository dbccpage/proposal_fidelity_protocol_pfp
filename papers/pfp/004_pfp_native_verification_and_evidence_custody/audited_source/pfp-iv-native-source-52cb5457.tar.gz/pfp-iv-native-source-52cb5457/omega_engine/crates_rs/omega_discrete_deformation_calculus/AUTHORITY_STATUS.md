---
title: OEPRMALG authority status — what this crate does and does not establish
date: 2026-09-26
status: ENFORCED_TYPEMODEL_HOLES_CLOSED_OR_FENCED
AuthorityEffect: None
---

# What this crate establishes

The Prime rules (`oeprmalg0`, `oeprmalg1`, `oeprmalg2`) are a **control law**, not
an authority root. They decide whether a step is lawful and record what licensed
it. They mint nothing.

Six review rounds went into hardening the evidence surfaces, and the honest
summary is:

> **The rules make authority claims legible, bound and committed. They do not
> make them unforgeable, and cannot.**

Any code in this process can implement a trait and return what it likes. What
sealing buys is that a counterfeit must **commit to what it claims to be** — its
implementation, version, readout, carrier, declared degrees — and those
commitments are checked against the site and folded into the tape head. A lie
becomes a written, hashed lie rather than an invisible one.

Closing the remainder needs an attestation boundary outside this process. That
is a deliberate scope line, not an oversight.

# Why this file exists

Five review rounds followed the same shape: each fix closed the surfaces that
were named and revealed adjacent ones. An automated audit of **97 evidence
surfaces** then found a defect all five rounds had missed — `terminalize` did not
recompute the permit binding that `write_step` did — and executed it green.

The lesson is that "make in-process authority unforgeable" is not a reachable
goal, so chasing it does not converge. The reachable goal is:

> Every authority claim states what it establishes, and every gap is named.

This file is the register. A claim in code that is not honest about its own
limits is worse than a documented hole.

# Resolution of named holes

Under OEv1.0.0-rc.1 PR 5, the architectural holes have been addressed:

## Closed holes

| # | Hole | Status | Resolution |
|---|---|---|---|
| 1 | Independent carrier and d0 labels | **CLOSED** | Bound into canonical `BoundCarrierManifest` and committed in `ScopeBinding`. |
| 2 | `LossLedger` had no scope | **CLOSED** | `LossLedger` now holds `ScopeBinding` and is checked against the site scope in `transport`, `can_continue_n`, and `admit_write`. |
| 6 | Unchecked obligation closure & continuation permit reuse | **CLOSED** | `ObligationRegistry` issues single-use `TerminalPermit` only when all open obligations are discharged. |
| 7 | Raw trace API could emit `Terminalized` | **CLOSED** | Raw trace `emit(Terminalize)` yields `UnverifiedTerminal`; `TraceTerminal::Terminalized` requires the `DdaTrace::emit_gated_terminal()` gate. |
| 8 | Terminalization did not close the run | **CLOSED** | Typestate enforcement: `terminalize(OpenControlState) -> TerminalControlState` consumes open state, making post-terminal continuation unrepresentable at compile time. |
| 9 | `next_carrier` committed but never applied | **CLOSED** | `write_step` applies `next_carrier_manifest` to `state.manifest` on repacketization. |

## Fenced holes (CallerAttested, AuthorityEffect::None)

| # | Hole | Status | Fencing |
|---|---|---|---|
| 3 | `SameCarrierExhaustion::by_searching` | **FENCED** | Wrapped as `CallerAttested<T>` with `AuthorityEffect::None`. Never feeds root authority. |
| 4 | `NineUpLiftBits` public booleans | **FENCED** | Wrapped as `CallerAttested<T>` with `AuthorityEffect::None`. Never feeds root authority. |
| 5 | Counterclaim caller-chosen | **FENCED** | Wrapped as `CallerAttested<T>` with `AuthorityEffect::None`. Never feeds root authority. |

# What is enforced

For contrast, so this file is not read as "nothing works":

- `StepOp` has **no terminalize variant** — `write_step` cannot express `T`.
- One shared `admit_write` gate: both writers recompute the permit binding, re-check every scoped evidence member, and re-check the residual's carrier.
- A terminal and an ordinary write no longer share a tape head; the Γ₂ receipt and obligation closure are committed into it.
- Budget is spent atomically with the write, so an issued-and-dropped permit costs nothing.
- `StepPermit` is not `Clone` and is consumed by value; `ControlState` is neither `Clone` nor `Deserialize`.
- No sealed evidence type derives `Deserialize`.
- Φ₁ endpoints come only from `Phi1Functional::verify_exact_certificate`, must share a `d₀`, and that `d₀` must be the one the run declared.
- Γ₂ is compared exactly over ℚ; `1/1000000000` is not a terminal.
- Every one of the six canonical anti-cheat laws has a fixture that violates it alone and is caught, and a clean fixture that violates none.

# Evidence status

**Author-reported.** GitHub Actions is disabled repository-wide and the only
status reported is Vercel, which attests the web deployment. See
`omega_engine/omega_engine_operations/gate_truth.yaml` → `actions-disabled` and
`vercel-attests-only-the-web-deployment`. Every test count in this crate's
commit messages is a claim requiring reproduction.

`AuthorityEffect: None`.
