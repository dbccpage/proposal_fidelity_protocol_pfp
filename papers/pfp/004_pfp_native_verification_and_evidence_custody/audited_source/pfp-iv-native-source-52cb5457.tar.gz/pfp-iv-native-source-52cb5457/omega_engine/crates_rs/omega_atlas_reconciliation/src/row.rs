//! The v2 Atlas Reconciliation schema as Rust types.
//!
//! One `ReconciliationRow` is the full finite judgment for a single asset along the
//! reconciliation spine code <-> product-claim <-> paper <-> proof <-> contract <-> doctrine.
//! The authority/ceiling/role classifications are the LIVE canonical types, re-exported from
//! `omega_contract_core::kinds` (`ContractEffect`, `ComponentRole`) and
//! `omega_types::ceiling` (`EvidenceCeiling`) — no local mirror enums.
use serde::{Deserialize, Serialize};

pub use omega_contract_core::kinds::{ComponentRole, ContractEffect};
pub use omega_types::ceiling::EvidenceCeiling;

use crate::cochain_validity::{CochainValidity, TriState};
use crate::identity_witness::IdentityWitness;
use crate::primitive_difference::PrimitiveDifferenceJudgment;

/// Loop-local strength rank for the contract-doctrine ContractEffect (the canonical enum
/// intentionally omits Ord). Declaration order is the strength chain.
/// TODO(canonical): promote to `ComponentRole::pinned_authority_effect` in omega_contract_core.
pub fn authority_rank(e: ContractEffect) -> u8 {
    match e {
        ContractEffect::None => 0,
        ContractEffect::EvidenceOnly => 1,
        ContractEffect::FactOnly => 2,
        ContractEffect::RequiresEvaluator => 3,
        ContractEffect::RequestsDecision => 4,
        ContractEffect::AuthorizesTransition => 5,
        ContractEffect::StateTransition => 6,
    }
}

const ADMIT_NONE: &[ContractEffect] = &[ContractEffect::None];
const ADMIT_EVIDENCE: &[ContractEffect] = &[ContractEffect::EvidenceOnly];
const ADMIT_FACT: &[ContractEffect] = &[ContractEffect::FactOnly];

/// Local mirror of the effects `omega_contract_core::validate` admits for a role.
///
/// The first component is the ceiling written onto a new row. The slice holds
/// every other effect the validator also admits. `MathObject` admits `None` or
/// `EvidenceOnly`. `MathComputation` admits `EvidenceOnly` or `FactOnly`.
/// `Validator` admits `EvidenceOnly` or `FactOnly`.
/// TODO(canonical): replace with the admission rule on `ComponentRole` in omega_contract_core.
fn admitted_ceilings(role: ComponentRole) -> (ContractEffect, &'static [ContractEffect]) {
    use ComponentRole as R;
    use ContractEffect::*;
    match role {
        R::BaseType | R::Carrier | R::Packet => (EvidenceOnly, &[]),
        R::CheckedPacket => (FactOnly, &[]),
        R::Certificate | R::CertificateKernel => (EvidenceOnly, &[]),
        R::CertificateStore | R::CertificateApiInterface => (None, &[]),
        R::Witness | R::Diagnostic | R::HealthModel | R::Measurement | R::Observable => {
            (EvidenceOnly, &[])
        }
        R::Evaluator => (RequestsDecision, &[]),
        R::Validator => (EvidenceOnly, ADMIT_FACT),
        R::Terminalizer => (EvidenceOnly, &[]),
        R::TerminalMapper => (RequestsDecision, &[]),
        R::Engine => (StateTransition, &[]),
        R::Kernel | R::Pipeline => (None, &[]),
        R::Runtime => (EvidenceOnly, &[]),
        R::Policy => (RequestsDecision, &[]),
        R::Search | R::Solver | R::Replay | R::Lift => (EvidenceOnly, &[]),
        R::LiftLicense => (AuthorizesTransition, &[]),
        R::LlmAdapter
        | R::WebsiteApi
        | R::SymbolGame
        | R::Packetization
        | R::StructureSweep
        | R::ProductKernelIntake
        | R::FixedLayerOperatorAlgebra
        | R::DeclaredActionCandidate
        | R::RepresentationBoundary
        | R::IntakeConstructor
        | R::ProposalGenerator
        | R::Trace
        | R::AnalysisUnit
        | R::Boundary => (EvidenceOnly, &[]),
        R::AuthInterface => (None, &[]),
        R::MathObject => (EvidenceOnly, ADMIT_NONE),
        R::MathComputation => (FactOnly, ADMIT_EVIDENCE),
        R::PublicVerifyService
        | R::SearchKernel
        | R::SolverKernel
        | R::CounterfeitDetector
        | R::Constitution => (EvidenceOnly, &[]),
    }
}

/// Ceiling stored on a newly built row for `role`.
pub fn pinned_authority_effect(role: ComponentRole) -> ContractEffect {
    admitted_ceilings(role).0
}

/// Whether `effect` is one of the effects `validate` admits for `role`.
pub fn role_admits_ceiling(role: ComponentRole, effect: ContractEffect) -> bool {
    let (pin, also) = admitted_ceilings(role);
    effect == pin || also.contains(&effect)
}

/// How the product claim compares to the observed reality of the asset.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ClaimDelta {
    Undersold,
    Accurate,
    Oversold,
    Missing,
}

/// Top-level reconciliation verdict for the asset.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ReconVerdict {
    Aligned,
    Drifted,
    ClaimWithoutCode,
    CodeWithoutProduct,
    Overclaim,
    UnverifiableAbstain,
}

/// Disclosure surface the asset is exposed on.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Surface {
    Public,
    Private,
    Research,
}

/// Build state of the asset's code.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BuildStatus {
    Builds,
    UnbuiltUnwired,
    NotApplicable,
}

/// State of the asset's tests.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TestsState {
    None,
    WrittenUnrun,
    Run,
    Green,
    CiGated,
}

/// Basis on which an authority claim rests.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum AuthorityBasis {
    Test,
    Lean,
    Golden,
    Replay,
    None,
}

/// Terminal classification of the reconciliation row.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum TerminalStatus {
    ExactRepair,
    StabilizedSurvivor,
    LicensedLift,
    OpenObstruction,
    BudgetUnknown,
    NoRule,
    Refused,
    RepresentationMalformed,
    CochainInvalid,
    GovernanceDrift,
}

/// Where residual work is routed.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Route {
    Sprint,
    MathDev,
    PaperHygiene,
    Doctrine,
    None,
}

/// Result of an adversarial verification pass on the row's own claim.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum VerifyResult {
    Confirmed,
    Downgraded,
    Refuted,
}

/// A single authority claim and its basis.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AuthClaim {
    pub claim: String,
    pub basis: AuthorityBasis,
}

/// Proof / mechanization status of the asset (the two-axis honesty record).
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProofStatus {
    pub enc_refs: Vec<String>,
    pub status: String,
    pub lean_status: String,
    pub relative_axioms: Vec<String>,
}

/// Terminal status plus the human-readable reason for it.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Terminal {
    pub status: TerminalStatus,
    pub reason: String,
}

/// Verification verdict plus the refutation attempt that produced it.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VerifyVerdict {
    pub result: VerifyResult,
    pub refutation: String,
}

/// A piece of residual work and where it is routed.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoutedItem {
    pub item: String,
    pub route: Route,
}

/// The full v2 reconciliation judgment for a single asset.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ReconciliationRow {
    pub row_id: String,
    pub asset_id: String,
    pub claimed: String,
    pub observed: String,
    pub claim_delta: ClaimDelta,
    pub recon_verdict: ReconVerdict,
    pub surface: Surface,
    pub build_status: BuildStatus,
    pub tests_state: TestsState,
    pub proof_status: ProofStatus,
    pub evidence_ceiling: EvidenceCeiling,
    pub declared_authority_effect: ContractEffect,
    pub role: ComponentRole,
    pub role_pinned_ceiling: ContractEffect,
    pub authority_basis: Vec<AuthClaim>,
    pub primitive_difference: PrimitiveDifferenceJudgment,
    pub cochain_validity: CochainValidity,
    pub identity_witness: IdentityWitness,
    pub terminal_status: Terminal,
    pub verify_verdict: VerifyVerdict,
    pub routed_work: Vec<RoutedItem>,
    pub doctrine_version: String,
}

impl ReconciliationRow {
    /// A fully-valid sample row that passes `validate_row`.
    ///
    /// Models the canonical undersold case: `omega_types::authority` was claimed a "stub"
    /// in the atlas but is observed to be a hardened, machine-checked, sealed authority type
    /// with green tests — an UNDERSOLD drift whose product wrapper is still missing.
    pub fn sample_good() -> Self {
        let mut identity_witness = IdentityWitness::tiger();
        identity_witness.object_kind = "crate".to_string();

        Self {
            row_id: "ROW-0001".to_string(),
            asset_id: "omega_types::authority".to_string(),
            claimed: "stub".to_string(),
            observed: "HARDENED machine-checked".to_string(),
            claim_delta: ClaimDelta::Undersold,
            recon_verdict: ReconVerdict::Drifted,
            surface: Surface::Private,
            build_status: BuildStatus::Builds,
            tests_state: TestsState::Green,
            proof_status: ProofStatus {
                enc_refs: vec!["ENC-0001".to_string()],
                status: "PROVED-PROSE".to_string(),
                lean_status: "MECHANIZED".to_string(),
                relative_axioms: vec![],
            },
            evidence_ceiling: EvidenceCeiling::LocalReplay,
            declared_authority_effect: ContractEffect::None,
            role: ComponentRole::MathObject,
            role_pinned_ceiling: pinned_authority_effect(ComponentRole::MathObject),
            authority_basis: vec![AuthClaim {
                claim: "sealed authority type".to_string(),
                basis: AuthorityBasis::Lean,
            }],
            primitive_difference: PrimitiveDifferenceJudgment {
                left_presentation: "atlas:stub".to_string(),
                right_presentation: "code:HARDENED".to_string(),
                zero_difference_relation: "path off-by-one + rename".to_string(),
                licensed_equivalences: vec!["crates/ prefix".to_string()],
                quotient_residual: "maturity mismatch".to_string(),
                residual_class: "UNDERSOLD".to_string(),
                factors_through_quotient: true,
            },
            cochain_validity: CochainValidity {
                chain: vec![
                    "product".to_string(),
                    "crate".to_string(),
                    "proof".to_string(),
                    "contract".to_string(),
                ],
                d0_declared: "atlas->crate".to_string(),
                d1_declared: "crate->proof".to_string(),
                d1_d0_zero: TriState::True,
                failure_reason: String::new(),
                terminal_if_failed: None,
                // Honest commuting carrier: d0=[[1],[1]], d1=[[1,1]] → 1⊕1=0 → computes True.
                d0: vec![vec![1u8], vec![1u8]],
                d1: vec![vec![1u8, 1u8]],
            },
            identity_witness,
            terminal_status: Terminal {
                status: TerminalStatus::OpenObstruction,
                reason: "undersold; product wrapper missing".to_string(),
            },
            verify_verdict: VerifyVerdict {
                result: VerifyResult::Confirmed,
                refutation: "tried to show stub; found sealed + tests".to_string(),
            },
            routed_work: vec![RoutedItem {
                item: "wrap authority surface".to_string(),
                route: Route::Sprint,
            }],
            doctrine_version: "000".to_string(),
        }
    }
}
