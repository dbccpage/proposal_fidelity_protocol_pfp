use super::parser::{
    AdjunctionDecl, AtpModule, BinOpKind, CategoryDecl, Declaration, Expr, FunctorDecl,
    ManifoldDecl, MorphismDecl, SheafDecl, TypeExpr,
};
// WOUND: use super::tower_placer::TowerAddress;
/// Stub TowerAddress — meta_04 tower_placer not available
#[derive(Debug, Clone)]
pub struct TowerAddress {
    pub tier: u8,
    pub description: String,
    pub dir_name: String,
}

/// Result of emitting a Lambda.
#[derive(Debug, Clone)]
pub struct EmittedLambda {
    /// The Lambda .rs file content.
    pub source: String,
    /// The mod.rs content for the Lambda directory.
    pub mod_rs: String,
    /// The address this Lambda was placed at.
    pub address: TowerAddress,
}

/// Emit a Tower Lambda from a verified module, address, and proof hash.
pub fn emit_lambda(module: &AtpModule, address: &TowerAddress, proof_hash: &str) -> EmittedLambda {
    let mut out = String::new();
    let file_name = sanitize_ident(&address.description.to_lowercase().replace(' ', "_"));
    let file_name = if file_name.is_empty() {
        "lambda".to_string()
    } else {
        file_name
    };

    // YAML header
    emit_header(&mut out, &file_name, address, proof_hash);

    // Emit each declaration
    for decl in &module.declarations {
        match decl {
            Declaration::Manifold(m) => emit_manifold(&mut out, m),
            Declaration::Morphism(m) => emit_morphism(&mut out, m),
            Declaration::Sheaf(s) => emit_sheaf(&mut out, s),
            Declaration::Adjunction(a) => emit_adjunction(&mut out, a),
            Declaration::Category(c) => emit_category(&mut out, c),
            Declaration::Functor(f) => emit_functor(&mut out, f),
            Declaration::Operator(op) => {
                emit_morphism_like(&mut out, &op.name, &op.source, &op.target, &op.equations)
            }
            Declaration::Cohomology(ch) => {
                emit_morphism_like(&mut out, &ch.name, &ch.source, &ch.target, &ch.equations)
            }
            _ => {
                // Other declaration types get comment stubs
                out.push_str(&format!("// TODO: emit {:?}\n\n", decl_kind_name(decl)));
            }
        }
    }

    // Test module
    emit_tests(&mut out, module, address);

    let mod_rs = format!(
        "//! {} — {}\npub mod {};\n",
        address.dir_name.to_uppercase(),
        address.description,
        file_name,
    );

    EmittedLambda {
        source: out,
        mod_rs,
        address: address.clone(),
    }
}

// ============================================================
// Header
// ============================================================

fn emit_header(out: &mut String, file_name: &str, addr: &TowerAddress, proof_hash: &str) {
    out.push_str(&format!("//! --- yaml\n"));
    out.push_str(&format!("//! title: {}\n", file_name));
    out.push_str(&format!("//! file_name: {}.rs\n", file_name));
    out.push_str(&format!(
        "//! file_location: omega_core/src/ascent/algebra/morphisms/{}/{}.rs\n",
        addr.dir_name, file_name
    ));
    out.push_str("//! status: Coal\n");
    out.push_str(&format!("//! invariance_level: Tier {}\n", addr.tier));
    out.push_str("//! logic_system: Self-Repair Cohomology\n");
    out.push_str("//! substrate: Rust\n");
    out.push_str(&format!("//! description: >\n"));
    out.push_str(&format!(
        "//!   {} — {}\n",
        addr.dir_name.to_uppercase(),
        addr.description
    ));
    out.push_str(&format!("//!   Auto-generated from .atp specification.\n"));
    out.push_str(&format!("//! proof_hash: {}\n", proof_hash));
    out.push_str("//! version: 1\n");
    out.push_str("//! ---\n\n");
}

// ============================================================
// Declaration Emitters
// ============================================================

fn emit_manifold(out: &mut String, m: &ManifoldDecl) {
    let name = sanitize_ident(&m.name);
    out.push_str(&format!("/// Manifold: {} — Dim({})\n", name, m.dim_bound));
    out.push_str(&format!(
        "pub const {}_DIM: usize = {};\n\n",
        name.to_uppercase(),
        m.dim_bound
    ));

    // Emit sections as function stubs
    for sec in &m.sections {
        let sec_name = sanitize_ident(&sec.name);
        let type_str = render_type_rust(&sec.type_sig);
        out.push_str(&format!(
            "/// Section: {} : {}\n",
            sec_name,
            render_type_display(&sec.type_sig)
        ));
        out.push_str(&format!("pub fn {}() -> {} {{\n", sec_name, type_str));
        out.push_str("    todo!(\"Fill from Lean proof term\")\n");
        out.push_str("}\n\n");
    }
}

fn emit_morphism(out: &mut String, m: &MorphismDecl) {
    emit_morphism_like(out, &m.name, &m.source, &m.target, &m.equations);
}

fn emit_morphism_like(
    out: &mut String,
    name: &str,
    source: &TypeExpr,
    target: &TypeExpr,
    equations: &[super::parser::Equation],
) {
    let fn_name = sanitize_ident(name);
    let src_type = render_type_rust(source);
    let tgt_type = render_type_rust(target);

    out.push_str(&format!(
        "/// Morphism: {} : {} → {}\n",
        fn_name,
        render_type_display(source),
        render_type_display(target)
    ));

    // Emit equations as doc comments
    for eq in equations {
        out.push_str(&format!(
            "/// Equation: {} = {}\n",
            render_expr_display(&eq.lhs),
            render_expr_display(&eq.rhs)
        ));
    }

    out.push_str(&format!(
        "pub fn {}(x: {}) -> {} {{\n",
        fn_name, src_type, tgt_type
    ));
    out.push_str("    todo!(\"Fill from Lean proof term\")\n");
    out.push_str("}\n\n");
}

fn emit_sheaf(out: &mut String, s: &SheafDecl) {
    let name = sanitize_ident(&s.name);
    let type_params = if s.type_params.is_empty() {
        String::new()
    } else {
        format!(
            "<{}>",
            s.type_params
                .iter()
                .map(|p| sanitize_ident(p))
                .collect::<Vec<_>>()
                .join(", ")
        )
    };

    out.push_str(&format!("/// Sheaf: {}{}\n", name, type_params));
    out.push_str(&format!("pub struct {}{} {{\n", name, type_params));
    out.push_str("    _phantom: std::marker::PhantomData<()>,\n");
    out.push_str("}\n\n");

    // Emit sections as methods
    for sec in &s.sections {
        let sec_name = sanitize_ident(&sec.name);
        let type_str = render_type_rust(&sec.type_sig);
        out.push_str(&format!(
            "/// Section: {} : {}\n",
            sec_name,
            render_type_display(&sec.type_sig)
        ));
        out.push_str(&format!(
            "pub fn {}_{}() -> {} {{\n",
            name.to_lowercase(),
            sec_name,
            type_str
        ));
        out.push_str("    todo!(\"Fill from Lean proof term\")\n");
        out.push_str("}\n\n");
    }
}

fn emit_adjunction(out: &mut String, a: &AdjunctionDecl) {
    let name = sanitize_ident(&a.name);
    let left = sanitize_ident(&a.left.name);
    let right = sanitize_ident(&a.right.name);

    out.push_str(&format!(
        "/// Adjunction: {} ({} ⊣ {})\n",
        name, left, right
    ));

    // Left adjoint
    let l_src = render_type_rust(&a.left.source);
    let l_tgt = render_type_rust(&a.left.target);
    out.push_str(&format!(
        "/// Left adjoint: {} : {} → {}\n",
        left,
        render_type_display(&a.left.source),
        render_type_display(&a.left.target)
    ));
    out.push_str(&format!("pub fn {}(x: {}) -> {} {{\n", left, l_src, l_tgt));
    out.push_str("    todo!(\"Fill from Lean proof term\")\n");
    out.push_str("}\n\n");

    // Right adjoint
    let r_src = render_type_rust(&a.right.source);
    let r_tgt = render_type_rust(&a.right.target);
    out.push_str(&format!(
        "/// Right adjoint: {} : {} → {}\n",
        right,
        render_type_display(&a.right.source),
        render_type_display(&a.right.target)
    ));
    out.push_str(&format!("pub fn {}(x: {}) -> {} {{\n", right, r_src, r_tgt));
    out.push_str("    todo!(\"Fill from Lean proof term\")\n");
    out.push_str("}\n\n");
}

fn emit_category(out: &mut String, c: &CategoryDecl) {
    let name = sanitize_ident(&c.name);
    out.push_str(&format!("/// Category: {}\n", name));
    for obj in &c.objects {
        out.push_str(&format!("///   object: {}\n", obj));
    }
    out.push_str(&format!("pub struct {} {{\n", name));
    out.push_str("    _objects: Vec<String>,\n");
    out.push_str("}\n\n");
}

fn emit_functor(out: &mut String, f: &FunctorDecl) {
    let name = sanitize_ident(&f.name);
    let src = sanitize_ident(&f.source_cat);
    let tgt = sanitize_ident(&f.target_cat);
    out.push_str(&format!("/// Functor: {} : {} → {}\n", name, src, tgt));
    for (s, t) in &f.object_map {
        out.push_str(&format!("///   {} ↦ {}\n", s, t));
    }
    out.push_str(&format!("pub struct {};\n\n", name));
}

// ============================================================
// Tests
// ============================================================

fn emit_tests(out: &mut String, _module: &AtpModule, addr: &TowerAddress) {
    out.push_str("#[cfg(test)]\n");
    out.push_str("mod tests {\n");
    out.push_str("    use super::*;\n\n");

    out.push_str(&format!(
        "    #[test]\n    fn test_{}_exists() {{\n",
        addr.dir_name
    ));
    out.push_str(&format!(
        "        // Smoke test: Lambda {} compiles\n",
        addr.dir_name.to_uppercase()
    ));
    out.push_str("        assert!(true);\n");
    out.push_str("    }\n");

    out.push_str("}\n");
}

// ============================================================
// Helpers
// ============================================================

fn sanitize_ident(name: &str) -> String {
    let cleaned: String = name
        .chars()
        .filter(|c| c.is_ascii_alphanumeric() || *c == '_')
        .collect();
    if cleaned.is_empty() {
        "_unnamed".to_string()
    } else if cleaned.starts_with(|c: char| c.is_ascii_digit()) {
        format!("_{}", cleaned)
    } else {
        cleaned
    }
}

fn render_type_rust(ty: &TypeExpr) -> String {
    match ty {
        TypeExpr::Named(s) => match s.as_str() {
            "Real" | "Float" | "ℝ" => "f64".to_string(),
            "Int" | "Integer" | "ℤ" => "i64".to_string(),
            "Nat" | "Natural" | "ℕ" => "usize".to_string(),
            "Bool" => "bool".to_string(),
            "Unit" => "()".to_string(),
            _ => sanitize_ident(s),
        },
        TypeExpr::Arrow(a, b) => {
            format!(
                "/* {} -> {} */ f64",
                render_type_rust(a),
                render_type_rust(b)
            )
        }
        TypeExpr::Product(parts) => {
            let strs: Vec<String> = parts.iter().map(render_type_rust).collect();
            format!("({})", strs.join(", "))
        }
        TypeExpr::Parameterized(name, args) => {
            let base = sanitize_ident(name);
            if args.is_empty() {
                base
            } else {
                let arg_strs: Vec<String> = args.iter().map(render_type_rust).collect();
                format!("{}<{}>", base, arg_strs.join(", "))
            }
        }
    }
}

fn render_type_display(ty: &TypeExpr) -> String {
    match ty {
        TypeExpr::Named(s) => s.clone(),
        TypeExpr::Arrow(a, b) => format!("{} → {}", render_type_display(a), render_type_display(b)),
        TypeExpr::Product(parts) => parts
            .iter()
            .map(render_type_display)
            .collect::<Vec<_>>()
            .join(" × "),
        TypeExpr::Parameterized(name, args) => {
            let args_str: Vec<String> = args.iter().map(render_type_display).collect();
            format!("{}({})", name, args_str.join(", "))
        }
    }
}

fn render_expr_display(e: &Expr) -> String {
    match e {
        Expr::Var(s) => s.clone(),
        Expr::Int(n) => n.to_string(),
        Expr::App(name, args) => {
            let arg_strs: Vec<String> = args.iter().map(render_expr_display).collect();
            format!("{}({})", name, arg_strs.join(", "))
        }
        Expr::Tuple(elems) => {
            let s: Vec<String> = elems.iter().map(render_expr_display).collect();
            format!("({})", s.join(", "))
        }
        Expr::Compose(lhs, rhs) => {
            format!(
                "{} ∘ {}",
                render_expr_display(lhs),
                render_expr_display(rhs)
            )
        }
        Expr::BinOp(lhs, op, rhs) => {
            let op_str = match op {
                BinOpKind::Add => "+",
                BinOpKind::Sub => "-",
                BinOpKind::Mul => "*",
                BinOpKind::Div => "/",
                BinOpKind::Pow => "^",
            };
            format!(
                "({} {} {})",
                render_expr_display(lhs),
                op_str,
                render_expr_display(rhs)
            )
        }
        Expr::Neg(inner) => format!("-{}", render_expr_display(inner)),
    }
}

fn decl_kind_name(decl: &Declaration) -> &'static str {
    match decl {
        Declaration::Manifold(_) => "manifold",
        Declaration::Morphism(_) => "morphism",
        Declaration::Sheaf(_) => "sheaf",
        Declaration::Adjunction(_) => "adjunction",
        Declaration::Tensor(_) => "tensor",
        Declaration::Orbit(_) => "orbit",
        Declaration::Functor(_) => "functor",
        Declaration::NaturalTransformation(_) => "natural",
        Declaration::Category(_) => "category",
        Declaration::Network(_) => "network",
        Declaration::Deploy(_) => "deploy",
        Declaration::Operad(_) => "operad",
        Declaration::Bundle(_) => "bundle",
        Declaration::Topos(_) => "topos",
        Declaration::Presheaf(_) => "presheaf",
        Declaration::Cohomology(_) => "cohomology",
        Declaration::Operator(_) => "operator",
    }
}

#[cfg(test)]
// AP-0: re-enabled (was `#[cfg(any())]` — "WOUND: API drift"). The drift was the
// Meta-04 `tower_placer::TowerAddress`, now locally stubbed with 3 fields; the
// test's address literal below was trimmed to match (the deleted module's
// 7-field address is gone).
mod tests {
    use super::*;
    use crate::compiler::lexer::tokenize;
    use crate::compiler::parser::parse;

    fn emit_test_module(source: &str) -> EmittedLambda {
        let tokens = tokenize(source);
        let module = parse(&tokens).expect("parse failed");
        let addr = TowerAddress {
            tier: 0,
            dir_name: "l001".to_string(),
            description: "Power Series".to_string(),
        };
        emit_lambda(&module, &addr, "test_proof_hash_abc123")
    }

    #[test]
    fn test_emit_manifold() {
        let result = emit_test_module(
            "manifold Natural : Dim(1) where\n  section zero : Natural\n  proof p : ok",
        );
        assert!(result.source.contains("NATURAL_DIM: usize = 1"));
        assert!(result.source.contains("pub fn zero()"));
        assert!(result.source.contains("proof_hash: test_proof_hash_abc123"));
    }

    #[test]
    fn test_emit_morphism() {
        let result =
            emit_test_module("morphism inc : A -> B where\n  inc(x) = succ(x)\n  proof p : ok");
        assert!(result.source.contains("pub fn inc(x:"));
        assert!(result.source.contains("Equation: inc(x) = succ(x)"));
    }

    #[test]
    fn test_emit_sheaf() {
        let result =
            emit_test_module("sheaf Stack(T) where\n  section empty : Stack(T)\n  proof p : ok");
        assert!(result.source.contains("pub struct Stack<T>"));
        assert!(result.source.contains("pub fn stack_empty()"));
    }

    #[test]
    fn test_emit_adjunction() {
        let result = emit_test_module(
            "adjunction FileIO where\n  \
             left open_file : Path -> FileHandle\n  \
             right close_file : FileHandle -> Path\n  \
             unit : forall p, close_file(open_file(p)) = p\n  \
             counit : forall h, open_file(close_file(h)) = h",
        );
        assert!(result.source.contains("pub fn open_file(x:"));
        assert!(result.source.contains("pub fn close_file(x:"));
        assert!(result.source.contains("Adjunction: FileIO"));
    }

    #[test]
    fn test_emit_category() {
        let result = emit_test_module("category Grp where\n  object Element\n  proof p : ok");
        assert!(result.source.contains("pub struct Grp"));
        assert!(result.source.contains("object: Element"));
    }

    #[test]
    fn test_mod_rs_generated() {
        let result = emit_test_module("manifold M : Dim(2) where\n  section x : M\n  proof p : ok");
        assert!(result.mod_rs.contains("L001"));
        assert!(result.mod_rs.contains("pub mod"));
    }

    #[test]
    fn test_yaml_header_contains_tier() {
        let result = emit_test_module("manifold M : Dim(2) where\n  section x : M\n  proof p : ok");
        assert!(result.source.contains("invariance_level: Tier 0"));
        assert!(result.source.contains("status: Coal"));
    }
}
