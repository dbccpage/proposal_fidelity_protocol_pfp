//! --- yaml
//! title: eager_validator
//! file_name: eager_validator.rs
//! file_location: omega_core/src/woland/eager_validator.rs
//! status: Diamond
//! invariance_level: Tier 1
//! logic_system: Woland Eager Validation
//! substrate: Rust
//! content_hash: 4ed6f3c9adad90acd426a0cf4279460ed7e5ca7c1ad0afb30c9a00931227965b
//! version: 2
//! ---
//! # Gate 5 — EagerValidator
//!
//! Sits between PTIR -> Woland -> Execution Substrate.
//! Enforces:
//! - H^2: Proof existence and integrity
//! - H^1: Contractibility preservation
//! - H_inf: No infinite-order cycles
//! - Ownership integrity

use blake3::Hash;
use std::collections::HashSet;
use std::sync::Arc;

// GeometricOpCode needs to be imported or referenced from phase_wiring
use crate::compiler::phase_wiring::GeometricOpCode;

pub type ProofHash = Hash;

#[derive(Debug)]
pub enum SentinelTear {
    H1Semantic(String),
    H2Structural(String),
    H2HeytingViolation(String),
    HInfNonTermination(String),
    CertificateMismatch(String),
}

#[derive(Debug, Clone)]
pub struct WitnessedInstruction {
    pub opcode: GeometricOpCode,
    pub morphism_id: String,
    pub h1_witness: ProofHash,
    pub entropy_witness: ProofHash,
    pub stalk_hash: ProofHash,
}

pub struct PCIR {
    pub instruction_tape: Vec<WitnessedInstruction>,
    pub global_betti_certificate: ProofHash,
    pub fundamental_group_order: Option<u64>, // None = infinite
    /// Morphism IDs tainted by classical logic violations (from heyting_check)
    pub heyting_tainted: HashSet<String>,
}

pub struct EagerValidator {
    trusted_proof_index: Arc<HashSet<ProofHash>>,
}

fn encode_opcode(op: &GeometricOpCode) -> Vec<u8> {
    match op {
        GeometricOpCode::InstantiateManifold(id) => {
            [b"INSTANTIATE".as_ref(), id.as_bytes()].concat()
        }
        GeometricOpCode::ExecuteManifold(id) => [b"EXECUTE".as_ref(), id.as_bytes()].concat(),
        GeometricOpCode::CollapseManifold(id) => [b"COLLAPSE".as_ref(), id.as_bytes()].concat(),
    }
}

impl EagerValidator {
    pub fn new(trusted_proof_index: Arc<HashSet<ProofHash>>) -> Self {
        Self {
            trusted_proof_index,
        }
    }

    pub fn validate(&self, pcir: &PCIR) -> Result<(), SentinelTear> {
        // 1️⃣ Empty Tape Vacuum Check
        if pcir.instruction_tape.is_empty() {
            return Err(SentinelTear::H1Semantic(
                "Empty instruction tape: no executable manifold.".into(),
            ));
        }

        // 2️⃣ H∞ Detection — fundamental group must be finite and non-zero
        if let Some(order) = pcir.fundamental_group_order {
            if order == 0 {
                return Err(SentinelTear::HInfNonTermination(
                    "Invalid π₁ order: zero.".into(),
                ));
            }
        } else {
            return Err(SentinelTear::HInfNonTermination(
                "Infinite-order π₁ cycle detected.".into(),
            ));
        }

        // 3️⃣ Global Betti Certificate Check
        if !self
            .trusted_proof_index
            .contains(&pcir.global_betti_certificate)
        {
            return Err(SentinelTear::H2Structural(
                "Missing or untrusted global Betti certificate.".into(),
            ));
        }

        // Execution ordering guard
        let mut seen_exec = HashSet::new();

        // 4️⃣ Per-Instruction Eager Verification
        for (idx, inst) in pcir.instruction_tape.iter().enumerate() {
            // H2 — Structural proof must exist
            if !self.trusted_proof_index.contains(&inst.h1_witness) {
                return Err(SentinelTear::H2Structural(format!(
                    "Instruction {} missing H1 witness.",
                    idx
                )));
            }

            if !self.trusted_proof_index.contains(&inst.entropy_witness) {
                return Err(SentinelTear::H2Structural(format!(
                    "Instruction {} missing entropy witness.",
                    idx
                )));
            }

            // H1 — Stalk alignment continuity and witness binding
            if !self.validate_binding(inst) {
                return Err(SentinelTear::CertificateMismatch(format!(
                    "Instruction {} stalk mismatch.",
                    idx
                )));
            }

            // Monotonicity Guard: No collapse prior to execution
            match &inst.opcode {
                GeometricOpCode::ExecuteManifold(id) => {
                    seen_exec.insert(id.clone());
                }
                GeometricOpCode::CollapseManifold(id) if !seen_exec.contains(id) => {
                    return Err(SentinelTear::H1Semantic(format!(
                        "Collapse without execution: {}",
                        id
                    )));
                }
                _ => {}
            }
            // 5️⃣ Heyting Compliance — reject classical-tainted morphisms
            if pcir.heyting_tainted.contains(&inst.morphism_id) {
                return Err(SentinelTear::H2HeytingViolation(format!(
                    "Instruction {} references Heyting-tainted morphism '{}'",
                    idx, inst.morphism_id
                )));
            }
        }

        Ok(())
    }

    fn validate_binding(&self, inst: &WitnessedInstruction) -> bool {
        let mut hasher = blake3::Hasher::new();
        hasher.update(inst.morphism_id.as_bytes());
        hasher.update(inst.h1_witness.as_bytes());
        hasher.update(&encode_opcode(&inst.opcode));
        let expected = hasher.finalize();

        expected == inst.stalk_hash
    }
}

// ============================================================================
// Tests — PCIR validation, WolandTear variants, binding integrity
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;
    use std::sync::Arc;

    // ---- helpers ----

    /// Compute the correct stalk hash for a given instruction's fields.
    fn compute_stalk_hash(
        morphism_id: &str,
        h1_witness: &ProofHash,
        opcode: &GeometricOpCode,
    ) -> ProofHash {
        let mut hasher = blake3::Hasher::new();
        hasher.update(morphism_id.as_bytes());
        hasher.update(h1_witness.as_bytes());
        hasher.update(&encode_opcode(opcode));
        hasher.finalize()
    }

    /// Build a trusted proof index containing the given hashes.
    fn make_trusted(hashes: &[ProofHash]) -> Arc<HashSet<ProofHash>> {
        Arc::new(hashes.iter().cloned().collect())
    }

    /// Create a random proof hash from a seed string.
    fn proof_hash(seed: &str) -> ProofHash {
        blake3::hash(seed.as_bytes())
    }

    /// Build a well-formed WitnessedInstruction whose stalk_hash is valid.
    fn good_instruction(
        opcode: GeometricOpCode,
        morphism_id: &str,
        h1_witness: ProofHash,
        entropy_witness: ProofHash,
    ) -> WitnessedInstruction {
        let stalk_hash = compute_stalk_hash(morphism_id, &h1_witness, &opcode);
        WitnessedInstruction {
            opcode,
            morphism_id: morphism_id.to_string(),
            h1_witness,
            entropy_witness,
            stalk_hash,
        }
    }

    /// Build a minimal valid PCIR: one InstantiateManifold + one ExecuteManifold.
    fn make_valid_pcir(trusted: &Arc<HashSet<ProofHash>>) -> PCIR {
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        // Both h1, entropy, and betti must be in the trusted index
        assert!(trusted.contains(&h1));
        assert!(trusted.contains(&ent));
        assert!(trusted.contains(&betti));

        let inst_a = good_instruction(
            GeometricOpCode::InstantiateManifold("A".into()),
            "morph_init_A",
            h1,
            ent,
        );
        let exec_a = good_instruction(
            GeometricOpCode::ExecuteManifold("A".into()),
            "morph_exec_A",
            h1,
            ent,
        );

        PCIR {
            instruction_tape: vec![inst_a, exec_a],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        }
    }

    /// Standard trusted proof set for most tests.
    fn standard_trusted() -> Arc<HashSet<ProofHash>> {
        make_trusted(&[
            proof_hash("h1_alpha"),
            proof_hash("entropy_alpha"),
            proof_hash("global_betti"),
            proof_hash("h1_beta"),
            proof_hash("entropy_beta"),
        ])
    }

    // ====================================================================
    // 1. Happy path — valid PCIR passes validation
    // ====================================================================

    #[test]
    fn valid_pcir_passes() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let pcir = make_valid_pcir(&trusted);
        assert!(validator.validate(&pcir).is_ok());
    }

    // ====================================================================
    // 2. Empty tape => H1Semantic tear
    // ====================================================================

    #[test]
    fn empty_tape_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let pcir = PCIR {
            instruction_tape: vec![],
            global_betti_certificate: proof_hash("global_betti"),
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };
        match validator.validate(&pcir) {
            Err(SentinelTear::H1Semantic(msg)) => {
                assert!(
                    msg.contains("Empty instruction tape"),
                    "Unexpected message: {msg}"
                );
            }
            other => panic!("Expected H1Semantic for empty tape, got: {other:?}"),
        }
    }

    // ====================================================================
    // 3. Infinite fundamental group => HInfNonTermination tear
    // ====================================================================

    #[test]
    fn infinite_fundamental_group_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let mut pcir = make_valid_pcir(&trusted);
        pcir.fundamental_group_order = None; // Infinite order

        match validator.validate(&pcir) {
            Err(SentinelTear::HInfNonTermination(msg)) => {
                assert!(msg.contains("Infinite-order"), "Unexpected message: {msg}");
            }
            other => panic!("Expected HInfNonTermination for infinite pi_1, got: {other:?}"),
        }
    }

    // ====================================================================
    // 4. Zero fundamental group order => HInfNonTermination tear
    // ====================================================================

    #[test]
    fn zero_fundamental_group_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let mut pcir = make_valid_pcir(&trusted);
        pcir.fundamental_group_order = Some(0);

        match validator.validate(&pcir) {
            Err(SentinelTear::HInfNonTermination(msg)) => {
                assert!(msg.contains("zero"), "Unexpected message: {msg}");
            }
            other => panic!("Expected HInfNonTermination for zero order, got: {other:?}"),
        }
    }

    // ====================================================================
    // 5. Untrusted global Betti certificate => H2Structural tear
    // ====================================================================

    #[test]
    fn untrusted_betti_certificate_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let mut pcir = make_valid_pcir(&trusted);
        pcir.global_betti_certificate = proof_hash("UNTRUSTED_BETTI");

        match validator.validate(&pcir) {
            Err(SentinelTear::H2Structural(msg)) => {
                assert!(
                    msg.contains("Betti certificate"),
                    "Unexpected message: {msg}"
                );
            }
            other => panic!("Expected H2Structural for untrusted betti, got: {other:?}"),
        }
    }

    // ====================================================================
    // 6. Missing H1 witness => H2Structural tear
    // ====================================================================

    #[test]
    fn untrusted_h1_witness_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1_bad = proof_hash("UNTRUSTED_H1");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        let inst = good_instruction(
            GeometricOpCode::InstantiateManifold("X".into()),
            "morph_X",
            h1_bad,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![inst],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H2Structural(msg)) => {
                assert!(msg.contains("H1 witness"), "Unexpected message: {msg}");
            }
            other => panic!("Expected H2Structural for untrusted H1, got: {other:?}"),
        }
    }

    // ====================================================================
    // 7. Missing entropy witness => H2Structural tear
    // ====================================================================

    #[test]
    fn untrusted_entropy_witness_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent_bad = proof_hash("UNTRUSTED_ENTROPY");
        let betti = proof_hash("global_betti");

        let inst = good_instruction(
            GeometricOpCode::InstantiateManifold("X".into()),
            "morph_X",
            h1,
            ent_bad,
        );

        let pcir = PCIR {
            instruction_tape: vec![inst],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H2Structural(msg)) => {
                assert!(msg.contains("entropy witness"), "Unexpected message: {msg}");
            }
            other => panic!("Expected H2Structural for untrusted entropy, got: {other:?}"),
        }
    }

    // ====================================================================
    // 8. Stalk hash mismatch => CertificateMismatch tear
    // ====================================================================

    #[test]
    fn stalk_hash_mismatch_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        let mut inst = good_instruction(
            GeometricOpCode::InstantiateManifold("X".into()),
            "morph_X",
            h1,
            ent,
        );
        // Corrupt the stalk hash
        inst.stalk_hash = proof_hash("CORRUPTED_STALK");

        let pcir = PCIR {
            instruction_tape: vec![inst],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::CertificateMismatch(msg)) => {
                assert!(msg.contains("stalk mismatch"), "Unexpected message: {msg}");
            }
            other => panic!("Expected CertificateMismatch for bad stalk, got: {other:?}"),
        }
    }

    // ====================================================================
    // 9. Collapse without prior execution => H1Semantic tear
    // ====================================================================

    #[test]
    fn collapse_without_execution_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        // Collapse "A" without ever executing "A"
        let inst = good_instruction(
            GeometricOpCode::CollapseManifold("A".into()),
            "morph_collapse_A",
            h1,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![inst],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H1Semantic(msg)) => {
                assert!(
                    msg.contains("Collapse without execution"),
                    "Unexpected message: {msg}"
                );
            }
            other => panic!("Expected H1Semantic for collapse-without-exec, got: {other:?}"),
        }
    }

    // ====================================================================
    // 10. Execute then collapse => valid ordering
    // ====================================================================

    #[test]
    fn execute_then_collapse_passes() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        let exec = good_instruction(
            GeometricOpCode::ExecuteManifold("A".into()),
            "morph_exec_A",
            h1,
            ent,
        );
        let collapse = good_instruction(
            GeometricOpCode::CollapseManifold("A".into()),
            "morph_collapse_A",
            h1,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![exec, collapse],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        assert!(validator.validate(&pcir).is_ok());
    }

    // ====================================================================
    // 11. Multiple manifolds — independent execution ordering
    // ====================================================================

    #[test]
    fn multi_manifold_independent_ordering() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        // Execute A, Execute B, Collapse A, Collapse B
        let exec_a = good_instruction(
            GeometricOpCode::ExecuteManifold("A".into()),
            "morph_exec_A",
            h1,
            ent,
        );
        let exec_b = good_instruction(
            GeometricOpCode::ExecuteManifold("B".into()),
            "morph_exec_B",
            h1,
            ent,
        );
        let collapse_a = good_instruction(
            GeometricOpCode::CollapseManifold("A".into()),
            "morph_collapse_A",
            h1,
            ent,
        );
        let collapse_b = good_instruction(
            GeometricOpCode::CollapseManifold("B".into()),
            "morph_collapse_B",
            h1,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![exec_a, exec_b, collapse_a, collapse_b],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        assert!(validator.validate(&pcir).is_ok());
    }

    // ====================================================================
    // 12. Collapse B without executing B (A is executed, not B)
    // ====================================================================

    #[test]
    fn collapse_wrong_manifold_rejected() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        let exec_a = good_instruction(
            GeometricOpCode::ExecuteManifold("A".into()),
            "morph_exec_A",
            h1,
            ent,
        );
        let collapse_b = good_instruction(
            GeometricOpCode::CollapseManifold("B".into()),
            "morph_collapse_B",
            h1,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![exec_a, collapse_b],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H1Semantic(msg)) => {
                assert!(
                    msg.contains("Collapse without execution"),
                    "Unexpected message: {msg}"
                );
                assert!(msg.contains("B"), "Should mention manifold B: {msg}");
            }
            other => panic!("Expected H1Semantic for wrong collapse target, got: {other:?}"),
        }
    }

    // ====================================================================
    // 13. validate_binding correctness — deterministic stalk hash
    // ====================================================================

    #[test]
    fn validate_binding_deterministic() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");

        let inst = good_instruction(
            GeometricOpCode::ExecuteManifold("M".into()),
            "morph_M",
            h1,
            ent,
        );

        // validate_binding should pass for a well-formed instruction
        assert!(validator.validate_binding(&inst));
    }

    // ====================================================================
    // 14. validate_binding fails for tampered morphism_id
    // ====================================================================

    #[test]
    fn validate_binding_tampered_morphism_id() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");

        let mut inst = good_instruction(
            GeometricOpCode::ExecuteManifold("M".into()),
            "morph_M",
            h1,
            ent,
        );
        // Tamper with morphism_id after stalk_hash was computed
        inst.morphism_id = "TAMPERED".to_string();

        assert!(!validator.validate_binding(&inst));
    }

    // ====================================================================
    // 15. encode_opcode coverage — all three variants
    // ====================================================================

    #[test]
    fn encode_opcode_all_variants() {
        let enc_inst = encode_opcode(&GeometricOpCode::InstantiateManifold("X".into()));
        assert!(enc_inst.starts_with(b"INSTANTIATE"));

        let enc_exec = encode_opcode(&GeometricOpCode::ExecuteManifold("X".into()));
        assert!(enc_exec.starts_with(b"EXECUTE"));

        let enc_coll = encode_opcode(&GeometricOpCode::CollapseManifold("X".into()));
        assert!(enc_coll.starts_with(b"COLLAPSE"));
    }

    // ====================================================================
    // 16. encode_opcode — different IDs produce different encodings
    // ====================================================================

    #[test]
    fn encode_opcode_different_ids_differ() {
        let a = encode_opcode(&GeometricOpCode::ExecuteManifold("A".into()));
        let b = encode_opcode(&GeometricOpCode::ExecuteManifold("B".into()));
        assert_ne!(a, b);
    }

    // ====================================================================
    // 17. Large fundamental group order accepted
    // ====================================================================

    #[test]
    fn large_fundamental_group_order_passes() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let mut pcir = make_valid_pcir(&trusted);
        pcir.fundamental_group_order = Some(u64::MAX);
        assert!(validator.validate(&pcir).is_ok());
    }

    // ====================================================================
    // 18. Error at specific instruction index is reported correctly
    // ====================================================================

    #[test]
    fn error_reports_instruction_index() {
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");
        let h1_bad = proof_hash("UNTRUSTED_H1");

        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());

        // First instruction valid, second has untrusted h1
        let inst_ok = good_instruction(
            GeometricOpCode::InstantiateManifold("A".into()),
            "morph_A",
            h1,
            ent,
        );
        let inst_bad = good_instruction(
            GeometricOpCode::InstantiateManifold("B".into()),
            "morph_B",
            h1_bad,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![inst_ok, inst_bad],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H2Structural(msg)) => {
                assert!(
                    msg.contains("1"),
                    "Should mention instruction index 1: {msg}"
                );
            }
            other => panic!("Expected H2Structural for inst 1, got: {other:?}"),
        }
    }

    // ====================================================================
    // 19. Validation ordering: empty tape checked before pi_1
    // ====================================================================

    #[test]
    fn empty_tape_check_precedes_pi1_check() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());

        // Both empty tape AND infinite pi_1 -- empty tape should be caught first
        let pcir = PCIR {
            instruction_tape: vec![],
            global_betti_certificate: proof_hash("global_betti"),
            fundamental_group_order: None,
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H1Semantic(msg)) => {
                assert!(
                    msg.contains("Empty instruction tape"),
                    "Empty tape should be first: {msg}"
                );
            }
            other => panic!("Expected H1Semantic (empty tape), got: {other:?}"),
        }
    }

    // ====================================================================
    // 20. EagerValidator::new with empty trusted set
    // ====================================================================

    #[test]
    fn empty_trusted_set_rejects_all_certificates() {
        let trusted = make_trusted(&[]);
        let validator = EagerValidator::new(trusted);

        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        let inst = good_instruction(
            GeometricOpCode::InstantiateManifold("A".into()),
            "morph_A",
            h1,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![inst],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        // Should fail at betti certificate check (step 3)
        assert!(validator.validate(&pcir).is_err());
    }

    // ====================================================================
    // 21. InstantiateManifold does not count as execution for collapse
    // ====================================================================

    #[test]
    fn instantiate_does_not_enable_collapse() {
        let trusted = standard_trusted();
        let validator = EagerValidator::new(trusted.clone());
        let h1 = proof_hash("h1_alpha");
        let ent = proof_hash("entropy_alpha");
        let betti = proof_hash("global_betti");

        let instantiate = good_instruction(
            GeometricOpCode::InstantiateManifold("A".into()),
            "morph_init_A",
            h1,
            ent,
        );
        let collapse = good_instruction(
            GeometricOpCode::CollapseManifold("A".into()),
            "morph_collapse_A",
            h1,
            ent,
        );

        let pcir = PCIR {
            instruction_tape: vec![instantiate, collapse],
            global_betti_certificate: betti,
            fundamental_group_order: Some(1),
            heyting_tainted: HashSet::new(),
        };

        match validator.validate(&pcir) {
            Err(SentinelTear::H1Semantic(msg)) => {
                assert!(
                    msg.contains("Collapse without execution"),
                    "Expected collapse error: {msg}"
                );
            }
            other => panic!("Expected H1Semantic, got: {other:?}"),
        }
    }
}
