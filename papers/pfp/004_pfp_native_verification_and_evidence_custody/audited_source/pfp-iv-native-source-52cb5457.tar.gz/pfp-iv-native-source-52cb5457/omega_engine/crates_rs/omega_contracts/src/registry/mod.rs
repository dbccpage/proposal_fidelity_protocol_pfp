//! Canonical contract registry: load & validate the `contract_canonical_definitions`
//! corpus (VALIDATION, not enforcement).
//!
//! The canonical corpus is TWO schemas, not one:
//! * the **math** corpus (`math/**`, 458 files) — validated structurally here via
//!   [`math_corpus`] (it confers no authority and does not map to
//!   [`crate::schema::ContractDescriptor`]);
//! * the **core 00–08** governance corpus — to be loaded and run through the existing
//!   [`crate::validate::validate_registry`] in a follow-up (see
//!   `sprints/105/omega_contracts_readiness_report.md`, commit 2).
//!
//! This module confers no authority and gates nothing at runtime.

pub mod math_corpus;
pub mod v1_loader;
pub mod v1_types;
pub mod v1_validate;
pub mod v1_vocabulary;

pub use math_corpus::{validate_math_corpus, MathCorpusError, MathCorpusReport};
pub use v1_loader::{load_v1_dir, V1LoadError, V1LoadReport};
pub use v1_types::{ContractKind, DescriptorBlock, OmegaContractV1, OmegaContractV1Status};
pub use v1_validate::validate_v1;
