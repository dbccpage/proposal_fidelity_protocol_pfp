//! Task 13 — positive: the migrated trichotomy exemplar loads and validates cleanly.
use omega_contracts::registry::load_v1_dir;
use std::path::Path;

#[test]
fn trichotomy_v1_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures/v1/good");
    let report = load_v1_dir(&dir).expect("fixture dir readable");
    assert_eq!(report.loaded, 1, "expected exactly the trichotomy fixture");
    assert!(
        report.findings.is_empty(),
        "unexpected findings: {:#?}",
        report.findings
    );
    assert!(
        report
            .contract_ids
            .iter()
            .any(|id| id.contains("finite_obstruction_trichotomy")),
        "contract id not found: {:?}",
        report.contract_ids
    );
}
