use logos::Span;
use serde::{Deserialize, Serialize};

use super::lexer::{SpannedToken, Token};

/// A complete `.atp` module — the root of the Topological AST.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AtpModule {
    pub declarations: Vec<Declaration>,
}

/// Top-level declaration kinds. Each maps to a topological construct.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum Declaration {
    Manifold(ManifoldDecl),
    Morphism(MorphismDecl),
    Sheaf(SheafDecl),
    Adjunction(AdjunctionDecl),
    Tensor(TensorDecl),
    Orbit(OrbitDecl),
    Functor(FunctorDecl),
    NaturalTransformation(NaturalTransformationDecl),
    Category(CategoryDecl),
    Network(NetworkDecl),
    Deploy(DeployDecl),
    Operad(OperadDecl),
    Bundle(BundleDecl),
    Topos(ToposDecl),
    Presheaf(PresheafDecl),
    Cohomology(CohomologyDecl),
    Operator(OperatorDecl),
}

/// A manifold declaration: topological space with dimensional bound.
/// `manifold Name : Dim(N) where <sections> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ManifoldDecl {
    pub name: String,
    pub dim_bound: usize,
    pub sections: Vec<SectionDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A morphism declaration: arrow between category objects.
/// `morphism Name : Source -> Target where <equations> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct MorphismDecl {
    pub name: String,
    pub source: TypeExpr,
    pub target: TypeExpr,
    pub equations: Vec<Equation>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// An operator declaration: transformation on topological states/Hilbert spaces.
/// `operator Name : Source -> Target where <equations> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct OperatorDecl {
    pub name: String,
    pub source: TypeExpr,
    pub target: TypeExpr,
    pub equations: Vec<Equation>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A sheaf declaration: module with gluing axiom.
/// `sheaf Name(params) where <sections> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SheafDecl {
    pub name: String,
    pub type_params: Vec<String>,
    pub sections: Vec<SectionDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// An adjunction declaration: paired functors F dashv G.
/// `adjunction Name where left F : A -> B  right G : B -> A  unit ...  counit ...`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AdjunctionDecl {
    pub name: String,
    pub left: AdjointArm,
    pub right: AdjointArm,
    pub unit: ProofDecl,
    pub counit: ProofDecl,
    pub span: Span,
}

/// One arm of an adjunction (left or right functor).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct AdjointArm {
    pub name: String,
    pub source: TypeExpr,
    pub target: TypeExpr,
}

/// A tensor declaration: parallel composition of disjoint sheaves.
/// `tensor Name(params) where disjoint : ... execute : ...`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct TensorDecl {
    pub name: String,
    pub params: Vec<String>,
    pub disjointness_proof: ProofDecl,
    pub execute_expr: Vec<String>,
    pub span: Span,
}

/// An orbit declaration: a blessed cycle (morphism that explicitly closes a loop).
/// `orbit Name : Source -> Target where <equations> <proofs>`
///
/// Orbits tell the boundary checker that a cycle is intentional (e.g. event loops,
/// retry mechanisms, daemons). Without an orbit, a cycle is flagged as an H^1 tear.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct OrbitDecl {
    pub name: String,
    pub source: TypeExpr,
    pub target: TypeExpr,
    pub equations: Vec<Equation>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A section declaration within a manifold or sheaf.
/// `section Name : TypeExpr`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct SectionDecl {
    pub name: String,
    pub type_sig: TypeExpr,
    pub span: Span,
}

/// A proof declaration — statement is opaque (Lean 4 verifies externally).
/// `proof Name : <statement tokens>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ProofDecl {
    pub name: String,
    pub statement: String,
    pub span: Span,
}

/// A functor declaration: mapping between categories.
/// `functor Name : SourceCat -> TargetCat where <object_maps> <morphism_maps>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct FunctorDecl {
    pub name: String,
    pub source_cat: String,
    pub target_cat: String,
    pub object_map: Vec<(String, String)>,
    pub morphism_map: Vec<(String, String)>,
    pub span: Span,
}

/// A natural transformation declaration.
/// `natural Name : F => G where <components>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct NaturalTransformationDecl {
    pub name: String,
    pub source_functor: String,
    pub target_functor: String,
    /// Maps generic object names to component morphism applications: `A -> F(A) -> G(A)`
    pub components: Vec<SectionDecl>,
    pub span: Span,
}

/// A category declaration.
/// `category Name where <objects> <morphisms> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CategoryDecl {
    pub name: String,
    pub objects: Vec<String>,
    pub morphisms: Vec<MorphismDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A network declaration: named topology of deployment nodes.
/// `network Name { node N1  node N2 }`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct NetworkDecl {
    pub name: String,
    pub nodes: Vec<String>,
    pub span: Span,
}

/// A deploy directive: bind a morphism to a network node.
/// `deploy MorphismName on NodeName`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DeployDecl {
    pub morphism: String,
    pub target_node: String,
    pub span: Span,
}

/// An operad declaration: n-ary multi-category compositions.
/// `operad Name where <sections> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct OperadDecl {
    pub name: String,
    pub sections: Vec<SectionDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A fiber bundle declaration: topological manifold over a base space.
/// `bundle Name : Fiber -> Base where <sections> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct BundleDecl {
    pub name: String,
    pub fiber: TypeExpr,
    pub base: TypeExpr,
    pub sections: Vec<SectionDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A topos declaration: Cartesian closed category with subobject classifier.
/// `topos Name where <objects> <morphisms> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ToposDecl {
    pub name: String,
    pub objects: Vec<String>,
    pub morphisms: Vec<MorphismDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A presheaf declaration: structural precursor to sheaf.
/// `presheaf Name(params) where <sections> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct PresheafDecl {
    pub name: String,
    pub type_params: Vec<String>,
    pub sections: Vec<SectionDecl>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// A cohomology declaration: evaluates invariant algebraic boundaries.
/// `cohomology Name : Source -> Target where <equations> <proofs>`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CohomologyDecl {
    pub name: String,
    pub source: TypeExpr,
    pub target: TypeExpr,
    pub equations: Vec<Equation>,
    pub proofs: Vec<ProofDecl>,
    pub span: Span,
}

/// Type expression tree for morphism signatures and section types.
///
/// Discriminated union avoids fragile string matching on operator names.
/// Previously: `TypeExpr { base: String, params: Vec<TypeExpr> }`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum TypeExpr {
    /// Simple named type: `A`, `Natural`, `State`
    Named(String),
    /// Arrow type: `A -> B`
    Arrow(Box<TypeExpr>, Box<TypeExpr>),
    /// Product type: `A * B * C`
    Product(Vec<TypeExpr>),
    /// Parameterized type: `Stack(T)`, `Hom(A, B)`
    Parameterized(String, Vec<TypeExpr>),
}

impl TypeExpr {
    /// Returns the base name for simple Named/Parameterized types.
    /// For Arrow/Product, returns the operator string for backward compat.
    pub fn base_name(&self) -> &str {
        match self {
            TypeExpr::Named(s) | TypeExpr::Parameterized(s, _) => s,
            TypeExpr::Arrow(_, _) => "->",
            TypeExpr::Product(_) => "*",
        }
    }

    /// Returns child type expressions as a Vec (backward compat for .params access).
    /// Named → empty, Arrow → [left, right], Product → factors, Parameterized → params.
    pub fn children(&self) -> Vec<&TypeExpr> {
        match self {
            TypeExpr::Named(_) => vec![],
            TypeExpr::Arrow(left, right) => vec![left.as_ref(), right.as_ref()],
            TypeExpr::Product(factors) => factors.iter().collect(),
            TypeExpr::Parameterized(_, params) => params.iter().collect(),
        }
    }
}

/// Pattern-matching equation: `lhs = rhs`
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct Equation {
    pub lhs: Expr,
    pub rhs: Expr,
    pub span: Span,
}

/// Expression tree for equations.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum Expr {
    Var(String),
    Int(i64),
    App(String, Vec<Expr>),
    Tuple(Vec<Expr>),
    Compose(Box<Expr>, Box<Expr>),
    BinOp(Box<Expr>, BinOpKind, Box<Expr>),
    /// Unary negation: `-expr`
    Neg(Box<Expr>),
}

/// Binary operator kinds for infix expressions.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub enum BinOpKind {
    Add, // +
    Sub, // -
    Mul, // *
    Div, // /
    Pow, // ^
}

// ============================================================
// Parse Error
// ============================================================

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct ParseError {
    pub message: String,
    pub span: Option<Span>,
}

impl std::fmt::Display for ParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match &self.span {
            Some(s) => write!(f, "[{}..{}] {}", s.start, s.end, self.message),
            None => write!(f, "{}", self.message),
        }
    }
}

impl std::error::Error for ParseError {}

// ============================================================
// Token Stream Cursor
// ============================================================

/// Cursor over a slice of SpannedTokens. Tracks position for nom-style parsing.
#[derive(Debug, Clone, Copy)]
struct Cursor<'a> {
    tokens: &'a [SpannedToken],
    pos: usize,
}

impl<'a> Cursor<'a> {
    fn new(tokens: &'a [SpannedToken]) -> Self {
        Self { tokens, pos: 0 }
    }

    fn peek(&self) -> Option<&'a SpannedToken> {
        self.tokens.get(self.pos)
    }

    fn peek_token(&self) -> Option<&Token> {
        self.peek().and_then(|st| st.token.as_ref().ok())
    }

    fn current_span(&self) -> Span {
        self.peek().map(|st| st.span.clone()).unwrap_or(0..0)
    }

    fn advance(&mut self) -> Option<&'a SpannedToken> {
        if self.pos < self.tokens.len() {
            let st = &self.tokens[self.pos];
            self.pos += 1;
            Some(st)
        } else {
            None
        }
    }

    fn at_end(&self) -> bool {
        self.pos >= self.tokens.len()
    }

    /// Expect a specific token, consuming it. Returns error if mismatch.
    fn expect(&mut self, expected: &Token) -> Result<Span, ParseError> {
        match self.peek() {
            Some(st) if st.token.as_ref().ok() == Some(expected) => {
                let span = st.span.clone();
                self.pos += 1;
                Ok(span)
            }
            Some(st) => Err(ParseError {
                message: format!("expected {:?}, found {:?}", expected, st.token),
                span: Some(st.span.clone()),
            }),
            None => Err(ParseError {
                message: format!("expected {:?}, found end of input", expected),
                span: None,
            }),
        }
    }

    /// Expect one of several tokens, consuming it. Returns the matched token variant.
    /// Used for accepting Unicode operator aliases alongside ASCII.
    #[allow(dead_code)]
    fn expect_one_of(&mut self, options: &[Token]) -> Result<(Token, Span), ParseError> {
        match self.peek() {
            Some(st) => {
                if let Ok(ref tok) = st.token {
                    for opt in options {
                        if tok == opt {
                            let span = st.span.clone();
                            let matched = tok.clone();
                            self.pos += 1;
                            return Ok((matched, span));
                        }
                    }
                }
                Err(ParseError {
                    message: format!("expected one of {:?}, found {:?}", options, st.token),
                    span: Some(st.span.clone()),
                })
            }
            None => Err(ParseError {
                message: format!("expected one of {:?}, found end of input", options),
                span: None,
            }),
        }
    }

    /// Check if the peeked token matches any of the given options.
    #[allow(dead_code)]
    fn peek_is_one_of(&self, options: &[Token]) -> bool {
        match self.peek_token() {
            Some(tok) => options.contains(tok),
            None => false,
        }
    }

    /// Consume an Ident token and return its string value.
    fn expect_ident(&mut self) -> Result<(String, Span), ParseError> {
        match self.peek() {
            Some(st) => {
                let span = st.span.clone();
                match &st.token {
                    Ok(Token::Ident(name)) => {
                        let name = name.clone();
                        self.pos += 1;
                        Ok((name, span))
                    }
                    Ok(tok) => {
                        let name = token_to_string(tok);
                        if is_name_keyword(tok) {
                            self.pos += 1;
                            Ok((name, span))
                        } else {
                            Err(ParseError {
                                message: format!("expected identifier, found {:?}", tok),
                                span: Some(span),
                            })
                        }
                    }
                    Err(_) => Err(ParseError {
                        message: "expected identifier, found error token".to_string(),
                        span: Some(span),
                    }),
                }
            }
            None => Err(ParseError {
                message: "expected identifier, found end of input".to_string(),
                span: None,
            }),
        }
    }

    /// Consume an Ident or keyword-as-name and return its string value.
    /// Keywords like `empty`, `unit`, `left`, `right` can appear as names
    /// in section/proof/morphism declarations.
    fn expect_name(&mut self) -> Result<(String, Span), ParseError> {
        match self.peek() {
            Some(st) => {
                let span = st.span.clone();
                match &st.token {
                    Ok(Token::Ident(name)) => {
                        let name = name.clone();
                        self.pos += 1;
                        Ok((name, span))
                    }
                    Ok(tok) => {
                        let name = token_to_string(tok);
                        // Accept keywords that can double as names
                        if is_name_keyword(tok) {
                            self.pos += 1;
                            Ok((name, span))
                        } else {
                            Err(ParseError {
                                message: format!("expected name, found {:?}", tok),
                                span: Some(span),
                            })
                        }
                    }
                    Err(_) => Err(ParseError {
                        message: "expected name, found error token".to_string(),
                        span: Some(span),
                    }),
                }
            }
            None => Err(ParseError {
                message: "expected name, found end of input".to_string(),
                span: None,
            }),
        }
    }
}

// No nom needed, pure recursive descent for safety and error propagation.
pub fn parse(tokens: &[SpannedToken]) -> Result<AtpModule, ParseError> {
    let mut input = tokens;
    // Strip trailing EOFs
    while let Some(last) = input.last() {
        if last.token == Ok(Token::EOF) {
            input = &input[..input.len() - 1];
        } else {
            break;
        }
    }

    let mut cursor = Cursor::new(input);
    let mut declarations = Vec::with_capacity(16);

    while !cursor.at_end() {
        let start_pos = cursor.pos;
        let decl = parse_declaration(&mut cursor)?;
        if cursor.pos == start_pos {
            return Err(ParseError {
                message: "Infinite loop detected: parser did not consume input".to_string(),
                span: Some(cursor.current_span()),
            });
        }
        declarations.push(decl);
    }

    Ok(AtpModule { declarations })
}

// ============================================================
// Declaration Parsers
// ============================================================

fn parse_declaration(c: &mut Cursor) -> Result<Declaration, ParseError> {
    match c.peek_token() {
        Some(Token::Manifold) => Ok(Declaration::Manifold(parse_manifold(c)?)),
        Some(Token::Morphism) => Ok(Declaration::Morphism(parse_morphism(c)?)),
        Some(Token::Sheaf) => Ok(Declaration::Sheaf(parse_sheaf(c)?)),
        Some(Token::Adjunction) => Ok(Declaration::Adjunction(parse_adjunction(c)?)),
        Some(Token::Tensor) => Ok(Declaration::Tensor(parse_tensor(c)?)),
        Some(Token::Orbit) => Ok(Declaration::Orbit(parse_orbit(c)?)),
        Some(Token::Functor) => Ok(Declaration::Functor(parse_functor(c)?)),
        Some(Token::Natural) => Ok(Declaration::NaturalTransformation(parse_natural(c)?)),
        Some(Token::Category) => Ok(Declaration::Category(parse_category(c)?)),
        Some(Token::Network) => Ok(Declaration::Network(parse_network(c)?)),
        Some(Token::Deploy) => Ok(Declaration::Deploy(parse_deploy(c)?)),
        Some(Token::Operad) => Ok(Declaration::Operad(parse_operad(c)?)),
        Some(Token::Bundle) => Ok(Declaration::Bundle(parse_bundle(c)?)),
        Some(Token::Topos) => Ok(Declaration::Topos(parse_topos(c)?)),
        Some(Token::Presheaf) => Ok(Declaration::Presheaf(parse_presheaf(c)?)),
        Some(Token::Cohomology) => Ok(Declaration::Cohomology(parse_cohomology(c)?)),
        Some(Token::Operator) => Ok(Declaration::Operator(parse_operator(c)?)),
        Some(tok) => Err(ParseError {
            message: format!(
                "expected declaration (manifold/morphism/sheaf/adjunction/tensor/orbit/functor/natural/category/network/deploy/operad/bundle/topos/presheaf/cohomology/operator), found {:?}",
                tok
            ),
            span: Some(c.current_span()),
        }),
        None => Err(ParseError {
            message: "unexpected end of input".to_string(),
            span: None,
        }),
    }
}

/// Parse: `manifold Name : Dim(N) where <body>`
fn parse_manifold(c: &mut Cursor) -> Result<ManifoldDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Manifold)?;
    let (name, _) = c.expect_ident()?;
    c.expect(&Token::Colon)?;

    let dim_bound = match c.peek_token() {
        Some(Token::Dim) => {
            c.advance();
            c.expect(&Token::LParen)?;
            match c.peek_token() {
                Some(Token::IntLit(n)) => {
                    let val = *n;
                    c.advance();
                    c.expect(&Token::RParen)?;
                    val
                }
                _ => {
                    return Err(ParseError {
                        message: "expected integer bound inside Dim(...)".to_string(),
                        span: Some(c.current_span()),
                    })
                }
            }
        }
        _ => {
            return Err(ParseError {
                message: "expected Dim(N) after manifold name".to_string(),
                span: Some(c.current_span()),
            })
        }
    };

    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (sections, proofs) = parse_body_sections_proofs(c)?;
    let end = if !sections.is_empty() || !proofs.is_empty() {
        proofs
            .last()
            .map(|p| p.span.end)
            .or(sections.last().map(|s| s.span.end))
            .unwrap_or(c.current_span().start)
    } else {
        c.current_span().start
    };

    Ok(ManifoldDecl {
        name,
        dim_bound: dim_bound as usize,
        sections,
        proofs,
        span: start..end,
    })
}

/// Parse: `morphism Name : TypeExpr -> TypeExpr where <body>`
///
/// Uses `parse_product_type` (not `parse_type_expr`) for source and target
/// because `->` is structural syntax here, not part of the type expression.
/// Nested arrows like `(A -> B) * C -> D` still work via parenthesized exprs.
fn parse_morphism(c: &mut Cursor) -> Result<MorphismDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Morphism)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let source = parse_product_type(c, 0)?;
    c.expect(&Token::Arrow)?;
    let target = parse_product_type(c, 0)?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (equations, proofs) = parse_body_equations_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(equations.last().map(|e| e.span.end))
        .unwrap_or(c.current_span().start);

    Ok(MorphismDecl {
        name,
        source,
        target,
        equations,
        proofs,
        span: start..end,
    })
}

/// Parse: `sheaf Name(Params) where <body>`
fn parse_sheaf(c: &mut Cursor) -> Result<SheafDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Sheaf)?;
    let (name, _) = c.expect_ident()?;

    let type_params = if c.peek_token() == Some(&Token::LParen) {
        parse_param_list(c)?
    } else {
        Vec::new()
    };

    c.expect(&Token::Where)?;

    let (sections, proofs) = parse_body_sections_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(sections.last().map(|s| s.span.end))
        .unwrap_or(c.current_span().start);

    Ok(SheafDecl {
        name,
        type_params,
        sections,
        proofs,
        span: start..end,
    })
}

/// Parse: `adjunction Name where left F : A -> B  right G : B -> A  unit : ...  counit : ...`
fn parse_adjunction(c: &mut Cursor) -> Result<AdjunctionDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Adjunction)?;
    let (name, _) = c.expect_ident()?;
    c.expect(&Token::Where)?;

    // left arm
    c.expect(&Token::Left)?;
    let left = parse_adjoint_arm(c)?;

    // right arm
    c.expect(&Token::Right)?;
    let right = parse_adjoint_arm(c)?;

    // unit proof
    c.expect(&Token::Unit)?;
    c.expect(&Token::Colon)?;
    let unit = parse_proof_statement(c, "unit")?;

    // counit proof
    c.expect(&Token::Counit)?;
    c.expect(&Token::Colon)?;
    let counit = parse_proof_statement(c, "counit")?;

    let end = counit.span.end;

    Ok(AdjunctionDecl {
        name,
        left,
        right,
        unit,
        counit,
        span: start..end,
    })
}

/// Parse: `tensor Name(params) where disjoint : ... execute : ...`
fn parse_tensor(c: &mut Cursor) -> Result<TensorDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Tensor)?;
    let (name, _) = c.expect_ident()?;

    let params = if c.peek_token() == Some(&Token::LParen) {
        parse_param_list(c)?
    } else {
        Vec::new()
    };

    c.expect(&Token::Where)?;

    // disjoint proof
    c.expect(&Token::Disjoint)?;
    c.expect(&Token::Colon)?;
    let disj_proof = parse_proof_statement(c, "disjoint")?;

    // execute expr
    c.expect(&Token::Execute)?;
    c.expect(&Token::Colon)?;
    let _exec_start = c.pos;
    let mut exec_names = Vec::new();
    // Collect ident || ident pattern
    loop {
        match c.peek_token() {
            Some(Token::Ident(s)) => {
                exec_names.push(s.clone());
                c.advance();
            }
            Some(Token::Parallel) => {
                c.advance();
            }
            _ => break,
        }
    }
    let end = if exec_names.is_empty() {
        disj_proof.span.end
    } else {
        c.tokens
            .get(c.pos.saturating_sub(1))
            .map(|st| st.span.end)
            .unwrap_or(disj_proof.span.end)
    };

    Ok(TensorDecl {
        name,
        params,
        disjointness_proof: disj_proof,
        execute_expr: exec_names,
        span: start..end,
    })
}

/// Parse: `orbit Name : TypeExpr -> TypeExpr where <body>`
///
/// Syntactically identical to a morphism, but semantically marks the cycle as
/// intentional. The boundary checker uses orbit declarations to distinguish
/// blessed operational cycles from unblessed semantic tears.
fn parse_orbit(c: &mut Cursor) -> Result<OrbitDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Orbit)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let source = parse_product_type(c, 0)?;
    c.expect(&Token::Arrow)?;
    let target = parse_product_type(c, 0)?;
    c.expect(&Token::Where)?;

    let (equations, proofs) = parse_body_equations_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(equations.last().map(|e| e.span.end))
        .unwrap_or(c.current_span().start);

    Ok(OrbitDecl {
        name,
        source,
        target,
        equations,
        proofs,
        span: start..end,
    })
}

/// Parse: `functor F : C -> D where ...`
fn parse_functor(c: &mut Cursor) -> Result<FunctorDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Functor)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let (source_cat, _) = c.expect_name()?;
    c.expect(&Token::Arrow)?;
    let (target_cat, _) = c.expect_name()?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let mut object_map = Vec::new();
    let mut morphism_map = Vec::new();

    loop {
        match c.peek_token() {
            Some(Token::Object) => {
                c.advance();
                let (src, _) = c.expect_ident()?;
                c.expect(&Token::Arrow)?;
                let (tgt, _) = c.expect_ident()?;
                object_map.push((src, tgt));
            }
            Some(Token::Morphism) => {
                // Lookahead: distinguish functor mapping (ident -> ident)
                // from a new top-level declaration (ident : Type -> Type where).
                // If the third token is Colon, this is a new declaration — break.
                if c.pos + 2 < c.tokens.len() {
                    if let Ok(Token::Colon) = &c.tokens[c.pos + 2].token {
                        break;
                    }
                }
                c.advance();
                let (src, _) = c.expect_ident()?;
                c.expect(&Token::Arrow)?;
                let (tgt, _) = c.expect_ident()?;
                morphism_map.push((src, tgt));
            }
            _ => break,
        }
    }

    let end = c.current_span().start;

    Ok(FunctorDecl {
        name,
        source_cat,
        target_cat,
        object_map,
        morphism_map,
        span: start..end,
    })
}

/// Parse: `natural eta : F => G where ...`
fn parse_natural(c: &mut Cursor) -> Result<NaturalTransformationDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Natural)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let (source_functor, _) = c.expect_name()?;
    c.expect(&Token::DoubleArrow)?;
    let (target_functor, _) = c.expect_name()?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    // In AutoP, components are parsed as sections inside natural transformations
    let mut components = Vec::new();
    loop {
        if c.peek_token() == Some(&Token::Component) {
            c.advance();
            let (comp_name, _) = c.expect_ident()?;
            c.expect(&Token::Colon)?;
            let type_sig = parse_type_expr(c, 0)?;
            let span = c.current_span();
            components.push(SectionDecl {
                name: comp_name,
                type_sig,
                span,
            });
        } else {
            break;
        }
    }

    let end = components
        .last()
        .map(|c| c.span.end)
        .unwrap_or(c.current_span().start);

    Ok(NaturalTransformationDecl {
        name,
        source_functor,
        target_functor,
        components,
        span: start..end,
    })
}

/// Parse: `category C where ...` or `category C { ... }`
///
/// The brace-delimited form enables embedded morphisms.
/// The `where`-form only accepts `object` and `proof` (backward compat).
/// Both forms accept `end` as a terminator.
fn parse_category(c: &mut Cursor) -> Result<CategoryDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Category)?;
    let (name, _) = c.expect_name()?;

    // Determine block style: brace-delimited or where-delimited
    let brace_style = c.peek_token() == Some(&Token::LBrace);
    if brace_style {
        c.advance(); // consume '{'
    } else if c.peek_token() == Some(&Token::Where) {
        c.advance(); // consume 'where'
    }

    let mut objects = Vec::new();
    let mut morphisms = Vec::new();
    let mut proofs = Vec::new();

    loop {
        match c.peek_token() {
            Some(Token::Object) => {
                c.advance();
                let (obj, _) = c.expect_ident()?;
                objects.push(obj);
            }
            Some(Token::Proof) => {
                proofs.push(parse_proof(c)?);
            }
            Some(Token::Morphism) if brace_style => {
                // Embedded morphism: only in brace-delimited blocks.
                morphisms.push(parse_morphism(c)?);
            }
            Some(Token::End) => {
                c.advance(); // consume 'end'
                break;
            }
            Some(Token::RBrace) if brace_style => {
                c.advance(); // consume '}'
                break;
            }
            _ => break, // backward compat: no 'end' for simple where-categories
        }
    }

    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(morphisms.last().map(|m| m.span.end))
        .unwrap_or(c.current_span().start);

    Ok(CategoryDecl {
        name,
        objects,
        morphisms,
        proofs,
        span: start..end,
    })
}

/// Parse: `network Name { node N1  node N2 ... }`
fn parse_network(c: &mut Cursor) -> Result<NetworkDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Network)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::LBrace)?;

    let mut nodes = Vec::new();
    loop {
        match c.peek_token() {
            Some(Token::Node) => {
                c.advance();
                let (node_name, _) = c.expect_ident()?;
                nodes.push(node_name);
            }
            Some(Token::RBrace) => {
                c.advance();
                break;
            }
            Some(tok) => {
                return Err(ParseError {
                    message: format!("expected 'node' or '}}' in network block, found {:?}", tok),
                    span: Some(c.current_span()),
                });
            }
            None => {
                return Err(ParseError {
                    message: "unexpected end of input in network block".to_string(),
                    span: None,
                });
            }
        }
    }

    let end = c.current_span().start;
    Ok(NetworkDecl {
        name,
        nodes,
        span: start..end,
    })
}

/// Parse: `deploy MorphismName on NodeName`
fn parse_deploy(c: &mut Cursor) -> Result<DeployDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Deploy)?;
    let (morphism, _) = c.expect_name()?;
    c.expect(&Token::On)?;
    let (target_node, _) = c.expect_name()?;
    let end = c.current_span().start;

    Ok(DeployDecl {
        morphism,
        target_node,
        span: start..end,
    })
}

/// Parse: `operad Name where <sections> <proofs>`
fn parse_operad(c: &mut Cursor) -> Result<OperadDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Operad)?;
    let (name, _) = c.expect_name()?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (sections, proofs) = parse_body_sections_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(sections.last().map(|s| s.span.end))
        .unwrap_or(c.current_span().start);

    Ok(OperadDecl {
        name,
        sections,
        proofs,
        span: start..end,
    })
}

/// Parse: `bundle Name : Fiber -> Base where <sections> <proofs>`
fn parse_bundle(c: &mut Cursor) -> Result<BundleDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Bundle)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let fiber = parse_product_type(c, 0)?;
    c.expect(&Token::Arrow)?;
    let base = parse_product_type(c, 0)?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (sections, proofs) = parse_body_sections_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(sections.last().map(|s| s.span.end))
        .unwrap_or(c.current_span().start);

    Ok(BundleDecl {
        name,
        fiber,
        base,
        sections,
        proofs,
        span: start..end,
    })
}

/// Parse: `topos Name where <objects> <morphisms> <proofs>`
fn parse_topos(c: &mut Cursor) -> Result<ToposDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Topos)?;
    let (name, _) = c.expect_name()?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let mut objects = Vec::new();
    let mut morphisms = Vec::new();
    let mut proofs = Vec::new();

    loop {
        match c.peek_token() {
            Some(Token::Object) => {
                c.advance();
                let (obj, _) = c.expect_ident()?;
                objects.push(obj);
            }
            Some(Token::Morphism) => {
                morphisms.push(parse_morphism(c)?);
            }
            Some(Token::Proof) => {
                proofs.push(parse_proof(c)?);
            }
            _ => break,
        }
    }

    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(morphisms.last().map(|m| m.span.end))
        .unwrap_or(c.current_span().start);

    Ok(ToposDecl {
        name,
        objects,
        morphisms,
        proofs,
        span: start..end,
    })
}

/// Parse: `presheaf Name(params) where <sections> <proofs>`
fn parse_presheaf(c: &mut Cursor) -> Result<PresheafDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Presheaf)?;
    let (name, _) = c.expect_name()?;

    let type_params = if c.peek_token() == Some(&Token::LParen) {
        parse_param_list(c)?
    } else {
        Vec::new()
    };

    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (sections, proofs) = parse_body_sections_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(sections.last().map(|s| s.span.end))
        .unwrap_or(c.current_span().start);

    Ok(PresheafDecl {
        name,
        type_params,
        sections,
        proofs,
        span: start..end,
    })
}

/// Parse: `cohomology Name : Source -> Target where <equations> <proofs>`
fn parse_cohomology(c: &mut Cursor) -> Result<CohomologyDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Cohomology)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let source = parse_product_type(c, 0)?;
    c.expect(&Token::Arrow)?;
    let target = parse_product_type(c, 0)?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (equations, proofs) = parse_body_equations_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(equations.last().map(|e| e.span.end))
        .unwrap_or(c.current_span().start);

    Ok(CohomologyDecl {
        name,
        source,
        target,
        equations,
        proofs,
        span: start..end,
    })
}

/// Parse: `operator Name : Source -> Target where <equations> <proofs>`
fn parse_operator(c: &mut Cursor) -> Result<OperatorDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Operator)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;

    let source = parse_product_type(c, 0)?;
    c.expect(&Token::Arrow)?;
    let target = parse_product_type(c, 0)?;
    if c.peek_token() == Some(&Token::Where) {
        c.advance();
    }

    let (equations, proofs) = parse_body_equations_proofs(c)?;
    let end = proofs
        .last()
        .map(|p| p.span.end)
        .or(equations.last().map(|e| e.span.end))
        .unwrap_or(c.current_span().start);

    Ok(OperatorDecl {
        name,
        source,
        target,
        equations,
        proofs,
        span: start..end,
    })
}

// ============================================================
// Body Parsers
// ============================================================

/// Parse mixed section/proof body until next top-level declaration or EOF.
fn parse_body_sections_proofs(
    c: &mut Cursor,
) -> Result<(Vec<SectionDecl>, Vec<ProofDecl>), ParseError> {
    let mut sections = Vec::new();
    let mut proofs = Vec::new();

    loop {
        match c.peek_token() {
            Some(Token::Section) => sections.push(parse_section(c)?),
            Some(Token::Proof) => proofs.push(parse_proof(c)?),
            _ => break,
        }
    }

    Ok((sections, proofs))
}

/// Parse mixed equation/proof body until next top-level declaration or EOF.
fn parse_body_equations_proofs(
    c: &mut Cursor,
) -> Result<(Vec<Equation>, Vec<ProofDecl>), ParseError> {
    let mut equations = Vec::new();
    let mut proofs = Vec::new();

    loop {
        match c.peek_token() {
            Some(Token::Proof) => proofs.push(parse_proof(c)?),
            Some(Token::Ident(_)) | Some(Token::LParen) | Some(Token::IntLit(_)) => {
                // Red Team Fix 8 (revised): Ident tokens inside a body are always
                // equation starts. Keywords (manifold, morphism, proof, section, etc.)
                // lex as their own Token variants, never as Ident. So any Ident here
                // cannot be the start of a new top-level declaration.
                // LParen and IntLit also start valid equation LHS expressions.
                equations.push(parse_equation(c)?);
            }
            _ => break,
        }
    }

    Ok((equations, proofs))
}

/// Parse: `section Name : TypeExpr`
fn parse_section(c: &mut Cursor) -> Result<SectionDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Section)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;
    let type_sig = parse_type_expr(c, 0)?;
    let end = c.current_span().start;

    Ok(SectionDecl {
        name,
        type_sig,
        span: start..end,
    })
}

/// Parse: `proof Name : <statement tokens>`
fn parse_proof(c: &mut Cursor) -> Result<ProofDecl, ParseError> {
    let start = c.current_span().start;
    c.expect(&Token::Proof)?;
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;
    let stmt = parse_proof_statement(c, &name)?;
    Ok(ProofDecl {
        name,
        statement: stmt.statement,
        span: start..stmt.span.end,
    })
}

/// Consume tokens as a proof statement string until we hit a token that
/// starts a new clause (section, proof, left, right, unit, counit,
/// disjoint, execute) or a new top-level declaration or EOF.
fn parse_proof_statement(c: &mut Cursor, name: &str) -> Result<ProofDecl, ParseError> {
    let start = c.current_span().start;
    let mut statement = String::new();
    let mut end = start;

    loop {
        match c.peek_token() {
            Some(Token::Execute) => {
                if c.pos + 1 < c.tokens.len()
                    && c.tokens[c.pos + 1].token.as_ref().ok() == Some(&Token::Colon)
                {
                    break;
                }
                statement.push_str("execute ");
                end = c.peek().unwrap().span.end;
                c.advance();
            }
            // Stop tokens: new clause or new top-level declaration
            Some(Token::Section)
            | Some(Token::Proof)
            | Some(Token::Left)
            | Some(Token::Right)
            | Some(Token::Unit)
            | Some(Token::Counit)
            | Some(Token::Disjoint)
            | Some(Token::Manifold)
            | Some(Token::Morphism)
            | Some(Token::Sheaf)
            | Some(Token::Adjunction)
            | Some(Token::Tensor)
            | Some(Token::Orbit)
            | Some(Token::Functor)
            | Some(Token::Natural)
            | Some(Token::Category)
            | Some(Token::Object)
            | Some(Token::Component)
            | Some(Token::Network)
            | Some(Token::Deploy)
            | Some(Token::Operad)
            | Some(Token::Bundle)
            | Some(Token::Topos)
            | Some(Token::Presheaf)
            | Some(Token::Cohomology)
            | Some(Token::Operator)
            | Some(Token::EOF) => break,
            None => break,
            Some(tok) => {
                statement.push_str(&token_to_string(tok));
                statement.push(' ');
                end = c.peek().unwrap().span.end;
                c.advance();
            }
        }
    }

    Ok(ProofDecl {
        name: name.to_string(),
        statement: statement.trim_end().to_string(),
        span: start..end,
    })
}

// ============================================================
// Type Expression Parser
// ============================================================

/// Parse a type expression: handles products (`A * B`), arrows (`A -> B`),
/// and parameterized types (`Stack(T)`).
///
/// Grammar:
///   type_expr  = product_type ("->" product_type)*
///   product_type = atom_type ("*" atom_type)*
///   atom_type  = Ident ("(" type_expr ("," type_expr)* ")")?
///              | "(" type_expr ")"
fn parse_type_expr(c: &mut Cursor, depth: usize) -> Result<TypeExpr, ParseError> {
    if depth > 128 {
        return Err(ParseError {
            message: "Stack overflow risk: type expression too deep".to_string(),
            span: Some(c.current_span()),
        });
    }
    let left = parse_product_type(c, depth + 1)?;

    if c.peek_token() == Some(&Token::Arrow) {
        c.advance();
        let right = parse_type_expr(c, depth + 1)?;
        Ok(TypeExpr::Arrow(Box::new(left), Box::new(right)))
    } else {
        Ok(left)
    }
}

fn parse_product_type(c: &mut Cursor, depth: usize) -> Result<TypeExpr, ParseError> {
    let mut factors = vec![parse_atom_type(c, depth + 1)?];

    while c.peek_token() == Some(&Token::Product) {
        c.advance();
        factors.push(parse_atom_type(c, depth + 1)?);
    }

    if factors.len() == 1 {
        Ok(factors.pop().unwrap())
    } else {
        Ok(TypeExpr::Product(factors))
    }
}

fn parse_atom_type(c: &mut Cursor, depth: usize) -> Result<TypeExpr, ParseError> {
    // Parenthesized type expression
    if c.peek_token() == Some(&Token::LParen) {
        c.advance();
        let inner = parse_type_expr(c, depth + 1)?;
        c.expect(&Token::RParen)?;
        return Ok(inner);
    }

    let (name, _) = c.expect_ident()?;

    // Check for type parameters: `Stack(T, U)`
    if c.peek_token() == Some(&Token::LParen) {
        c.advance();
        let mut params = vec![parse_type_expr(c, depth + 1)?];
        while c.peek_token() == Some(&Token::Comma) {
            c.advance();
            params.push(parse_type_expr(c, depth + 1)?);
        }
        c.expect(&Token::RParen)?;
        Ok(TypeExpr::Parameterized(name, params))
    } else {
        Ok(TypeExpr::Named(name))
    }
}

// ============================================================
// Equation and Expression Parsers
// ============================================================

/// Parse: `name(args) = expr`
fn parse_equation(c: &mut Cursor) -> Result<Equation, ParseError> {
    let start = c.current_span().start;
    let lhs = parse_expr(c)?;
    c.expect(&Token::Equals)?;
    let rhs = parse_expr(c)?;
    let end = c.current_span().start;

    Ok(Equation {
        lhs,
        rhs,
        span: start..end,
    })
}

/// Parse an expression: function application, tuples, variables, composition, or infix ops.
///
/// Grammar (precedence low to high):
///   expr       = comp_expr
///   comp_expr  = add_expr (">>>" add_expr)*
///   add_expr   = mul_expr (("+" | "-") mul_expr)*
///   mul_expr   = pow_expr (("*" | "/") pow_expr)*
///   pow_expr   = base_expr ("^" base_expr)?              -- right-associative
///   base_expr  = Ident "(" expr ("," expr)* ")"          -- application
///              | "(" expr ("," expr)+ ")"                -- tuple
///              | "(" expr ")"                            -- parenthesized
///              | IntLit                                   -- integer literal
///              | Ident                                    -- variable
fn parse_expr(c: &mut Cursor) -> Result<Expr, ParseError> {
    let mut left = parse_add_expr(c)?;

    while c.peek_token() == Some(&Token::Compose) {
        c.advance();
        let right = parse_add_expr(c)?;
        left = Expr::Compose(Box::new(left), Box::new(right));
    }

    Ok(left)
}

/// Parse additive expressions: `a + b`, `a - b`
fn parse_add_expr(c: &mut Cursor) -> Result<Expr, ParseError> {
    let mut left = parse_mul_expr(c)?;

    loop {
        let op = match c.peek_token() {
            Some(Token::Plus) => BinOpKind::Add,
            Some(Token::Minus) => BinOpKind::Sub,
            _ => break,
        };
        c.advance();
        let right = parse_mul_expr(c)?;
        left = Expr::BinOp(Box::new(left), op, Box::new(right));
    }

    Ok(left)
}

/// Parse multiplicative expressions: `a * b`, `a / b`
fn parse_mul_expr(c: &mut Cursor) -> Result<Expr, ParseError> {
    let mut left = parse_pow_expr(c)?;

    loop {
        let op = match c.peek_token() {
            Some(Token::Product) => BinOpKind::Mul,
            Some(Token::Slash) => BinOpKind::Div,
            _ => break,
        };
        c.advance();
        let right = parse_pow_expr(c)?;
        left = Expr::BinOp(Box::new(left), op, Box::new(right));
    }

    Ok(left)
}

/// Parse power expressions: `a ^ b` (right-associative)
fn parse_pow_expr(c: &mut Cursor) -> Result<Expr, ParseError> {
    let base = parse_base_expr(c)?;

    if c.peek_token() == Some(&Token::Caret) {
        c.advance();
        let exp = parse_pow_expr(c)?; // right-associative recursion
        Ok(Expr::BinOp(Box::new(base), BinOpKind::Pow, Box::new(exp)))
    } else {
        Ok(base)
    }
}

fn parse_base_expr(c: &mut Cursor) -> Result<Expr, ParseError> {
    // Unary minus: -expr
    if c.peek_token() == Some(&Token::Minus) {
        c.advance();
        let inner = parse_base_expr(c)?;
        return Ok(Expr::Neg(Box::new(inner)));
    }

    // Parenthesized expression or tuple
    if c.peek_token() == Some(&Token::LParen) {
        c.advance();
        let first = parse_expr(c)?;

        if c.peek_token() == Some(&Token::Comma) {
            // Tuple: (a, b, ...)
            let mut elements = vec![first];
            while c.peek_token() == Some(&Token::Comma) {
                c.advance();
                elements.push(parse_expr(c)?);
            }
            c.expect(&Token::RParen)?;
            return Ok(Expr::Tuple(elements));
        }

        c.expect(&Token::RParen)?;
        return Ok(first);
    }

    if let Some(Token::IntLit(n)) = c.peek_token() {
        let val = *n as i64;
        c.advance();
        return Ok(Expr::Int(val));
    }

    let (name, _) = c.expect_name()?;

    // Function application: f(args)
    if c.peek_token() == Some(&Token::LParen) {
        c.advance();
        let mut args = Vec::new();
        if c.peek_token() != Some(&Token::RParen) {
            args.push(parse_expr(c)?);
            while c.peek_token() == Some(&Token::Comma) {
                c.advance();
                args.push(parse_expr(c)?);
            }
        }
        c.expect(&Token::RParen)?;
        Ok(Expr::App(name, args))
    } else {
        Ok(Expr::Var(name))
    }
}

// ============================================================
// Helper Parsers
// ============================================================

/// Parse a parenthesized identifier list: `(a, b, c)`
fn parse_param_list(c: &mut Cursor) -> Result<Vec<String>, ParseError> {
    c.expect(&Token::LParen)?;
    let mut params = Vec::new();

    if c.peek_token() != Some(&Token::RParen) {
        let (name, _) = c.expect_name()?;
        params.push(name);
        while c.peek_token() == Some(&Token::Comma) {
            c.advance();
            let (name, _) = c.expect_name()?;
            params.push(name);
        }
    }

    c.expect(&Token::RParen)?;
    Ok(params)
}

/// Parse an adjoint arm: `name : Source -> Target`
///
/// Uses `parse_product_type` because `->` is structural syntax, not a type arrow.
fn parse_adjoint_arm(c: &mut Cursor) -> Result<AdjointArm, ParseError> {
    let (name, _) = c.expect_name()?;
    c.expect(&Token::Colon)?;
    let source = parse_product_type(c, 0)?;
    c.expect(&Token::Arrow)?;
    let target = parse_product_type(c, 0)?;

    Ok(AdjointArm {
        name,
        source,
        target,
    })
}

/// Keywords that can appear as names in section/proof/morphism declarations.
fn is_name_keyword(tok: &Token) -> bool {
    matches!(
        tok,
        Token::Empty
            | Token::Unit
            | Token::Counit
            | Token::Left
            | Token::Right
            | Token::Disjoint
            | Token::Execute
            | Token::Intersect
            | Token::Forall
            | Token::Exists
            | Token::Object
            | Token::Component
            | Token::Operator
    )
}

/// Convert a token to its string representation for proof statement collection.
fn token_to_string(tok: &Token) -> String {
    match tok {
        Token::Ident(s) => s.clone(),
        Token::IntLit(n) => n.to_string(),
        Token::Dim => "Dim".to_string(),
        Token::DimLower => "dim".to_string(),
        Token::Manifold => "manifold".to_string(),
        Token::Morphism => "morphism".to_string(),
        Token::Functor => "functor".to_string(),
        Token::Adjunction => "adjunction".to_string(),
        Token::Sheaf => "sheaf".to_string(),
        Token::Section => "section".to_string(),
        Token::Proof => "proof".to_string(),
        Token::Tensor => "tensor".to_string(),
        Token::Orbit => "orbit".to_string(),
        Token::Where => "where".to_string(),
        Token::Operad => "operad".to_string(),
        Token::Bundle => "bundle".to_string(),
        Token::Topos => "topos".to_string(),
        Token::Presheaf => "presheaf".to_string(),
        Token::Cohomology => "cohomology".to_string(),
        Token::Operator => "operator".to_string(),
        Token::Forall => "forall".to_string(),
        Token::Exists => "exists".to_string(),
        Token::Left => "left".to_string(),
        Token::Right => "right".to_string(),
        Token::Unit => "unit".to_string(),
        Token::Counit => "counit".to_string(),
        Token::Disjoint => "disjoint".to_string(),
        Token::Execute => "execute".to_string(),
        Token::Intersect => "intersect".to_string(),
        Token::Empty => "empty".to_string(),
        Token::Arrow => "->".to_string(),
        Token::Product => "*".to_string(),
        Token::Parallel => "||".to_string(),
        Token::Colon => ":".to_string(),
        Token::Equals => "=".to_string(),
        Token::NotEquals => "!=".to_string(),
        Token::LParen => "(".to_string(),
        Token::RParen => ")".to_string(),
        Token::Comma => ",".to_string(),
        Token::End => "end".to_string(),
        Token::Invariant => "invariant".to_string(),
        Token::Detect => "detect".to_string(),
        Token::Object => "object".to_string(),
        Token::Component => "component".to_string(),
        Token::Category => "category".to_string(),
        Token::Natural => "natural".to_string(),
        Token::DoubleArrow => "=>".to_string(),
        Token::Compose => ">>>".to_string(),
        Token::LBrace => "{".to_string(),
        Token::RBrace => "}".to_string(),
        Token::Bar => "|".to_string(),
        Token::Semi => ";".to_string(),
        Token::LBracket => "[".to_string(),
        Token::RBracket => "]".to_string(),
        Token::Network => "network".to_string(),
        Token::Node => "node".to_string(),
        Token::Deploy => "deploy".to_string(),
        Token::On => "on".to_string(),
        Token::Plus => "+".to_string(),
        Token::Minus => "-".to_string(),
        Token::Slash => "/".to_string(),
        Token::Caret => "^".to_string(),
        Token::Less => "<".to_string(),
        Token::Greater => ">".to_string(),
        Token::LessEq => "<=".to_string(),
        Token::GreaterEq => ">=".to_string(),
        Token::EOF => "<EOF>".to_string(),
    }
}

// ============================================================
// Tests
// ============================================================

#[cfg(test)]
mod tests {
    use super::*;
    use crate::compiler::lexer::tokenize;

    /// Helper: lex then parse.
    fn parse_source(source: &str) -> Result<AtpModule, ParseError> {
        let tokens = tokenize(source);
        parse(&tokens)
    }

    // ----- Manifold -----

    #[test]
    fn test_parse_manifold_basic() {
        let module = parse_source(
            "manifold Natural : Dim(1) where\n  \
             section zero : Natural\n  \
             section succ : Natural -> Natural\n  \
             proof bounded : forall n, dim(n) = 1",
        )
        .unwrap();

        assert_eq!(module.declarations.len(), 1);
        match &module.declarations[0] {
            Declaration::Manifold(m) => {
                assert_eq!(m.name, "Natural");
                assert_eq!(m.dim_bound, 1);
                assert_eq!(m.sections.len(), 2);
                assert_eq!(m.proofs.len(), 1);
                assert_eq!(m.sections[0].name, "zero");
                assert_eq!(m.sections[1].name, "succ");
                assert_eq!(m.proofs[0].name, "bounded");
            }
            other => panic!("expected Manifold, got {:?}", other),
        }
    }

    #[test]
    fn test_manifold_section_type_arrow() {
        let module = parse_source("manifold M : Dim(2) where\n  section f : A -> B").unwrap();

        if let Declaration::Manifold(m) = &module.declarations[0] {
            assert_eq!(m.sections[0].type_sig.base_name(), "->");
            assert_eq!(m.sections[0].type_sig.children().len(), 2);
        } else {
            panic!("expected Manifold");
        }
    }

    // ----- Morphism -----

    #[test]
    fn test_parse_morphism() {
        let module = parse_source(
            "morphism add : Natural * Natural -> Natural where\n  \
             add(zero, n) = n\n  \
             add(succ(m), n) = succ(add(m, n))\n  \
             proof total : forall m n, exists k, add(m, n) = k",
        )
        .unwrap();

        match &module.declarations[0] {
            Declaration::Morphism(m) => {
                assert_eq!(m.name, "add");
                assert_eq!(m.source.base_name(), "*");
                assert_eq!(m.target.base_name(), "Natural");
                assert_eq!(m.equations.len(), 2);
                assert_eq!(m.proofs.len(), 1);
            }
            other => panic!("expected Morphism, got {:?}", other),
        }
    }

    #[test]
    fn test_morphism_equation_structure() {
        let module =
            parse_source("morphism inc : Natural -> Natural where\n  inc(n) = succ(n)").unwrap();

        if let Declaration::Morphism(m) = &module.declarations[0] {
            let eq = &m.equations[0];
            assert!(matches!(&eq.lhs, Expr::App(name, _) if name == "inc"));
            assert!(matches!(&eq.rhs, Expr::App(name, _) if name == "succ"));
        } else {
            panic!("expected Morphism");
        }
    }

    // ----- Sheaf -----

    #[test]
    fn test_parse_sheaf() {
        let module = parse_source(
            "sheaf Stack(T) where\n  \
             section empty : Stack(T)\n  \
             section push : T * Stack(T) -> Stack(T)\n  \
             section pop : Stack(T) -> T * Stack(T)\n  \
             proof inverse : forall t s, pop(push(t, s)) = (t, s)",
        )
        .unwrap();

        match &module.declarations[0] {
            Declaration::Sheaf(s) => {
                assert_eq!(s.name, "Stack");
                assert_eq!(s.type_params, vec!["T"]);
                assert_eq!(s.sections.len(), 3);
                assert_eq!(s.proofs.len(), 1);
                assert_eq!(s.sections[1].name, "push");
            }
            other => panic!("expected Sheaf, got {:?}", other),
        }
    }

    #[test]
    fn test_sheaf_no_type_params() {
        let module = parse_source("sheaf Unit where\n  section val : Unit").unwrap();

        if let Declaration::Sheaf(s) = &module.declarations[0] {
            assert_eq!(s.name, "Unit");
            assert!(s.type_params.is_empty());
        } else {
            panic!("expected Sheaf");
        }
    }

    // ----- Adjunction -----

    #[test]
    fn test_parse_adjunction() {
        let module = parse_source(
            "adjunction FileIO where\n  \
             left open_file : Path -> FileHandle\n  \
             right close_file : FileHandle -> Path\n  \
             unit : forall p, close_file(open_file(p)) = p\n  \
             counit : forall h, open_file(close_file(h)) = h",
        )
        .unwrap();

        match &module.declarations[0] {
            Declaration::Adjunction(a) => {
                assert_eq!(a.name, "FileIO");
                assert_eq!(a.left.name, "open_file");
                assert_eq!(a.left.source.base_name(), "Path");
                assert_eq!(a.left.target.base_name(), "FileHandle");
                assert_eq!(a.right.name, "close_file");
                assert_eq!(a.right.source.base_name(), "FileHandle");
                assert_eq!(a.right.target.base_name(), "Path");
                assert!(a.unit.statement.contains("forall"));
                assert!(a.counit.statement.contains("forall"));
            }
            other => panic!("expected Adjunction, got {:?}", other),
        }
    }

    // ----- Tensor -----

    #[test]
    fn test_parse_tensor() {
        let module = parse_source(
            "tensor parallel(a, b) where\n  \
             disjoint : a intersect b = empty\n  \
             execute : a || b",
        )
        .unwrap();

        match &module.declarations[0] {
            Declaration::Tensor(t) => {
                assert_eq!(t.name, "parallel");
                assert_eq!(t.params, vec!["a", "b"]);
                assert!(t.disjointness_proof.statement.contains("intersect"));
                assert_eq!(t.execute_expr, vec!["a", "b"]);
            }
            other => panic!("expected Tensor, got {:?}", other),
        }
    }

    // ----- Full Module -----

    #[test]
    fn test_parse_full_module() {
        let source = r#"manifold Natural : Dim(1) where
  section zero : Natural
  section succ : Natural -> Natural
  proof bounded : forall n, dim(n) = 1

morphism add : Natural * Natural -> Natural where
  add(zero, n) = n
  add(succ(m), n) = succ(add(m, n))
  proof total : forall m n, exists k, add(m, n) = k

sheaf Stack(T) where
  section empty : Stack(T)
  section push : T * Stack(T) -> Stack(T)
  section pop : Stack(T) -> T * Stack(T)
  proof inverse : forall t s, pop(push(t, s)) = (t, s)

adjunction FileIO where
  left open_file : Path -> FileHandle
  right close_file : FileHandle -> Path
  unit : forall p, close_file(open_file(p)) = p
  counit : forall h, open_file(close_file(h)) = h

tensor parallel(a, b) where
  disjoint : a intersect b = empty
  execute : a || b"#;

        let module = parse_source(source).unwrap();
        assert_eq!(module.declarations.len(), 5);

        assert!(matches!(&module.declarations[0], Declaration::Manifold(_)));
        assert!(matches!(&module.declarations[1], Declaration::Morphism(_)));
        assert!(matches!(&module.declarations[2], Declaration::Sheaf(_)));
        assert!(matches!(
            &module.declarations[3],
            Declaration::Adjunction(_)
        ));
        assert!(matches!(&module.declarations[4], Declaration::Tensor(_)));
    }

    // ----- Type Expressions -----

    #[test]
    fn test_type_expr_simple() {
        let tokens = tokenize("Natural");
        let mut c = Cursor::new(&tokens);
        let ty = parse_type_expr(&mut c, 0).unwrap();
        assert_eq!(ty.base_name(), "Natural");
        assert!(ty.children().is_empty());
    }

    #[test]
    fn test_type_expr_product() {
        let tokens = tokenize("Natural * Natural");
        let mut c = Cursor::new(&tokens);
        let ty = parse_type_expr(&mut c, 0).unwrap();
        assert_eq!(ty.base_name(), "*");
        assert_eq!(ty.children().len(), 2);
    }

    #[test]
    fn test_type_expr_arrow() {
        let tokens = tokenize("Natural -> Natural");
        let mut c = Cursor::new(&tokens);
        let ty = parse_type_expr(&mut c, 0).unwrap();
        assert_eq!(ty.base_name(), "->");
        assert_eq!(ty.children().len(), 2);
    }

    #[test]
    fn test_type_expr_parameterized() {
        let tokens = tokenize("Stack(T)");
        let mut c = Cursor::new(&tokens);
        let ty = parse_type_expr(&mut c, 0).unwrap();
        assert_eq!(ty.base_name(), "Stack");
        assert_eq!(ty.children().len(), 1);
        assert_eq!(ty.children()[0].base_name(), "T");
    }

    #[test]
    fn test_type_expr_product_arrow_precedence() {
        // A * B -> C should parse as (A * B) -> C
        let tokens = tokenize("A * B -> C");
        let mut c = Cursor::new(&tokens);
        let ty = parse_type_expr(&mut c, 0).unwrap();
        assert_eq!(ty.base_name(), "->");
        assert_eq!(ty.children()[0].base_name(), "*");
        assert_eq!(ty.children()[1].base_name(), "C");
    }

    // ----- Expressions -----

    #[test]
    fn test_expr_var() {
        let tokens = tokenize("x");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        assert_eq!(e, Expr::Var("x".to_string()));
    }

    #[test]
    fn test_expr_app() {
        let tokens = tokenize("succ(n)");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        assert_eq!(
            e,
            Expr::App("succ".to_string(), vec![Expr::Var("n".to_string())])
        );
    }

    #[test]
    fn test_expr_nested_app() {
        let tokens = tokenize("succ(add(m, n))");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        assert!(matches!(e, Expr::App(name, _) if name == "succ"));
    }

    #[test]
    fn test_expr_tuple() {
        let tokens = tokenize("(a, b)");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        assert_eq!(
            e,
            Expr::Tuple(vec![Expr::Var("a".to_string()), Expr::Var("b".to_string()),])
        );
    }

    // ----- Error Cases -----

    #[test]
    fn test_manifold_optional_where() {
        // `where` is optional — a manifold with Dim but no body is valid.
        let module = parse_source("manifold Natural : Dim(1)").unwrap();
        if let Declaration::Manifold(m) = &module.declarations[0] {
            assert_eq!(m.name, "Natural");
            assert_eq!(m.dim_bound, 1);
            assert!(m.sections.is_empty());
        } else {
            panic!("expected Manifold");
        }
    }

    #[test]
    fn test_error_missing_dim() {
        let result = parse_source("manifold Natural : where");
        assert!(result.is_err());
    }

    #[test]
    fn test_error_unexpected_token() {
        let result = parse_source("where");
        assert!(result.is_err());
        assert!(result.unwrap_err().message.contains("expected declaration"));
    }

    #[test]
    fn test_empty_module() {
        let module = parse_source("").unwrap();
        assert!(module.declarations.is_empty());
    }

    // ----- Orbit -----

    #[test]
    fn test_parse_orbit() {
        let module = parse_source(
            "orbit event_loop : State -> State where\n  \
             step(s) = next(s)\n  \
             proof liveness : forall s, exists s2, step(s) = s2",
        )
        .unwrap();

        assert_eq!(module.declarations.len(), 1);
        match &module.declarations[0] {
            Declaration::Orbit(o) => {
                assert_eq!(o.name, "event_loop");
                assert_eq!(o.source.base_name(), "State");
                assert_eq!(o.target.base_name(), "State");
                assert_eq!(o.equations.len(), 1);
                assert_eq!(o.proofs.len(), 1);
                assert_eq!(o.proofs[0].name, "liveness");
            }
            other => panic!("expected Orbit, got {:?}", other),
        }
    }

    #[test]
    fn test_orbit_in_full_module() {
        let source = r#"manifold State : Dim(1) where
  section idle : State
  proof p : ok

orbit event_loop : State -> State where
  step(s) = next(s)
  proof liveness : forall s, exists s2, step(s) = s2"#;

        let module = parse_source(source).unwrap();
        assert_eq!(module.declarations.len(), 2);
        assert!(matches!(&module.declarations[0], Declaration::Manifold(_)));
        assert!(matches!(&module.declarations[1], Declaration::Orbit(_)));
    }

    // =========================================================
    // Malformed Input Tests — Parser must never panic
    // =========================================================

    #[test]
    fn test_malformed_manifold_missing_name() {
        let result = parse_source("manifold : Dim(1) where");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_manifold_missing_colon() {
        let result = parse_source("manifold M Dim(1) where");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_morphism_missing_arrow() {
        let result = parse_source("morphism f : A B where\n  f(x) = x");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_morphism_missing_name() {
        let result = parse_source("morphism : A -> B where\n  f(x) = x");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_adjunction_missing_right() {
        let result = parse_source(
            "adjunction Bad where\n  \
             left f : A -> B\n  \
             unit : ok\n  \
             counit : ok",
        );
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_tensor_missing_disjoint() {
        let result = parse_source(
            "tensor t(a, b) where\n  \
             execute : a || b",
        );
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_sheaf_unclosed_paren() {
        let result = parse_source("sheaf S(T where\n  section x : S");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_equation_missing_equals() {
        let result = parse_source("morphism f : A -> B where\n  f(x) x\n  proof p : ok");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_type_unclosed_paren() {
        let result = parse_source("morphism f : Stack(T -> B where\n  f(x) = x\n  proof p : ok");
        assert!(result.is_err());
    }

    #[test]
    fn test_malformed_manifold_unclosed_dim() {
        let result = parse_source("manifold M : Dim(1 where");
        assert!(result.is_err());
    }

    #[test]
    fn test_deeply_nested_type_expr() {
        // Deeply nested but valid: Stack(Stack(Stack(T)))
        let module =
            parse_source("sheaf Deep(T) where\n  section x : Stack(Stack(Stack(T)))").unwrap();
        if let Declaration::Sheaf(s) = &module.declarations[0] {
            let ty = &s.sections[0].type_sig;
            assert_eq!(ty.base_name(), "Stack");
            assert_eq!(ty.children()[0].base_name(), "Stack");
            assert_eq!(ty.children()[0].children()[0].base_name(), "Stack");
            assert_eq!(
                ty.children()[0].children()[0].children()[0].base_name(),
                "T"
            );
        } else {
            panic!("expected Sheaf");
        }
    }

    #[test]
    fn test_complex_product_arrow_type() {
        // (A * B) -> (C * D) in morphism
        let module =
            parse_source("morphism f : A * B -> C * D where\n  f(x, y) = (a, b)\n  proof p : ok")
                .unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.source.base_name(), "*");
            assert_eq!(m.source.children().len(), 2);
            assert_eq!(m.target.base_name(), "*");
            assert_eq!(m.target.children().len(), 2);
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_multiple_equations_morphism() {
        let module = parse_source(
            "morphism fib : Nat -> Nat where\n  \
             fib(zero) = zero\n  \
             fib(one) = one\n  \
             fib(succ(succ(n))) = add(fib(succ(n)), fib(n))\n  \
             proof total : ok",
        )
        .unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.equations.len(), 3);
            assert_eq!(m.proofs.len(), 1);
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_parse_error_has_span() {
        let result = parse_source("manifold M : where");
        let err = result.unwrap_err();
        assert!(err.span.is_some(), "error should carry span: {}", err);
    }

    #[test]
    fn test_parse_error_display() {
        let result = parse_source("manifold M : where");
        let err = result.unwrap_err();
        let msg = format!("{}", err);
        assert!(msg.contains("expected"), "error display: {}", msg);
    }

    #[test]
    fn test_only_whitespace_and_comments() {
        let module = parse_source("   \n\t  // just comments\n  // more").unwrap();
        assert!(module.declarations.is_empty());
    }

    #[test]
    fn test_multiple_manifolds() {
        let module = parse_source(
            "manifold A : Dim(1) where\n  section x : A\n  proof pa : ok\n\n\
             manifold B : Dim(2) where\n  section y : B\n  proof pb : ok\n\n\
             manifold C : Dim(3) where\n  section z : C\n  proof pc : ok",
        )
        .unwrap();
        assert_eq!(module.declarations.len(), 3);
    }

    #[test]
    fn test_manifold_many_sections() {
        let module = parse_source(
            "manifold Big : Dim(4) where\n  \
             section a : Big\n  \
             section b : Big\n  \
             section c : Big\n  \
             section d : Big\n  \
             section e : Big\n  \
             proof p : ok",
        )
        .unwrap();
        if let Declaration::Manifold(m) = &module.declarations[0] {
            assert_eq!(m.sections.len(), 5);
        } else {
            panic!("expected Manifold");
        }
    }

    #[test]
    fn test_expr_empty_arg_list() {
        // f() should parse as App("f", [])
        let tokens = tokenize("f()");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        assert_eq!(e, Expr::App("f".to_string(), vec![]));
    }

    #[test]
    fn test_integer_literal_not_valid_identifier() {
        // "42" alone is not a valid declaration start
        let result = parse_source("42");
        assert!(result.is_err());
    }

    #[test]
    fn test_error_token_in_stream() {
        // A lexer error token (e.g. '@') should cause a parse error, not a panic
        let result = parse_source("manifold M @ Dim(1) where");
        assert!(result.is_err());
    }

    // ─── Category boundary tests (Sprint 308-0, STORY-308-0-002) ───────────

    #[test]
    fn test_category_objects_and_proof() {
        let module =
            parse_source("category C where\n  object A\n  object B\n  proof p : ok").unwrap();
        assert_eq!(module.declarations.len(), 1);
        if let Declaration::Category(c) = &module.declarations[0] {
            assert_eq!(c.objects.len(), 2);
            assert!(c.morphisms.is_empty());
            assert_eq!(c.proofs.len(), 1);
        } else {
            panic!("expected Category");
        }
    }

    #[test]
    fn test_category_followed_by_toplevel_morphism() {
        // Category must NOT consume the following morphism declaration
        let module = parse_source(
            "category C where\n  object A\n  object B\n  proof p : ok\n\n\
             morphism f : A -> B where\n  f(x) = x\n  proof total : ok",
        )
        .unwrap();
        assert_eq!(
            module.declarations.len(),
            2,
            "expected 2 declarations (category + morphism)"
        );
        assert!(matches!(&module.declarations[0], Declaration::Category(_)));
        assert!(matches!(&module.declarations[1], Declaration::Morphism(_)));
    }

    #[test]
    fn test_category_followed_by_category() {
        let module = parse_source(
            "category A where\n  object X\n  proof pa : ok\n\n\
             category B where\n  object Y\n  proof pb : ok",
        )
        .unwrap();
        assert_eq!(module.declarations.len(), 2);
        assert!(matches!(&module.declarations[0], Declaration::Category(_)));
        assert!(matches!(&module.declarations[1], Declaration::Category(_)));
    }

    #[test]
    fn test_category_objects_only_no_proof() {
        // Category with only objects and no proof — should still parse
        let module = parse_source("category C where\n  object A\n  object B").unwrap();
        assert_eq!(module.declarations.len(), 1);
        if let Declaration::Category(c) = &module.declarations[0] {
            assert_eq!(c.objects.len(), 2);
            assert!(c.proofs.is_empty());
        } else {
            panic!("expected Category");
        }
    }

    #[test]
    fn test_category_brace_with_morphisms() {
        // Brace-delimited category accepts embedded morphisms
        let module = parse_source(
            "category Grp {\n  object G\n  object H\n  morphism phi : G -> H where\n    phi(g) = h\n    proof surj : ok\n}",
        )
        .unwrap();
        assert_eq!(module.declarations.len(), 1);
        if let Declaration::Category(c) = &module.declarations[0] {
            assert_eq!(c.objects.len(), 2);
            assert_eq!(c.morphisms.len(), 1);
            assert_eq!(c.morphisms[0].name, "phi");
        } else {
            panic!("expected Category");
        }
    }

    #[test]
    fn test_category_with_end() {
        // end-terminated category (no morphisms in where form, but end accepted)
        let module =
            parse_source("category C where\n  object A\n  object B\n  proof p : ok\nend").unwrap();
        assert_eq!(module.declarations.len(), 1);
        if let Declaration::Category(c) = &module.declarations[0] {
            assert_eq!(c.objects.len(), 2);
        } else {
            panic!("expected Category");
        }
    }

    // ─── Functor boundary tests (Sprint 308-0, STORY-308-0-003) ────────────

    #[test]
    fn test_functor_object_and_morphism_mappings() {
        let module =
            parse_source("functor F : C -> D where\n  object A -> B\n  morphism f -> g").unwrap();
        assert_eq!(module.declarations.len(), 1);
        if let Declaration::Functor(f) = &module.declarations[0] {
            assert_eq!(f.object_map.len(), 1);
            assert_eq!(f.morphism_map.len(), 1);
            assert_eq!(f.morphism_map[0], ("f".to_string(), "g".to_string()));
        } else {
            panic!("expected Functor");
        }
    }

    #[test]
    fn test_functor_followed_by_toplevel_morphism() {
        // Functor must NOT consume a following `morphism name : Type -> Type where`
        let module = parse_source(
            "functor F : C -> D where\n  object A -> B\n  morphism f -> g\n\n\
             morphism h : X -> Y where\n  h(x) = x\n  proof total : ok",
        )
        .unwrap();
        assert_eq!(
            module.declarations.len(),
            2,
            "expected 2 declarations (functor + morphism)"
        );
        assert!(matches!(&module.declarations[0], Declaration::Functor(_)));
        assert!(matches!(&module.declarations[1], Declaration::Morphism(_)));
    }

    #[test]
    fn test_functor_followed_by_functor() {
        let module = parse_source(
            "functor F : A -> B where\n  object X -> Y\n\n\
             functor G : B -> C where\n  object Y -> Z",
        )
        .unwrap();
        assert_eq!(module.declarations.len(), 2);
        assert!(matches!(&module.declarations[0], Declaration::Functor(_)));
        assert!(matches!(&module.declarations[1], Declaration::Functor(_)));
    }

    #[test]
    fn test_functor_empty_body() {
        // Functor with no mappings — should still parse
        let module = parse_source("functor F : C -> D where").unwrap();
        assert_eq!(module.declarations.len(), 1);
        if let Declaration::Functor(f) = &module.declarations[0] {
            assert!(f.object_map.is_empty());
            assert!(f.morphism_map.is_empty());
        } else {
            panic!("expected Functor");
        }
    }

    // ─── Infix expression tests (equation parser fix) ───────────────────

    #[test]
    fn test_bare_equation_a_plus_b() {
        // The "a + b = c" case that previously failed
        let module =
            parse_source("morphism f : A -> B where\n  a + b = c\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.equations.len(), 1);
            let eq = &m.equations[0];
            assert!(matches!(&eq.lhs, Expr::BinOp(_, BinOpKind::Add, _)));
            assert!(matches!(&eq.rhs, Expr::Var(name) if name == "c"));
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_bare_variable_equation() {
        // "x = y" without function application
        let module = parse_source("morphism f : A -> B where\n  x = y\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.equations.len(), 1);
            assert!(matches!(&m.equations[0].lhs, Expr::Var(name) if name == "x"));
            assert!(matches!(&m.equations[0].rhs, Expr::Var(name) if name == "y"));
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_infix_precedence() {
        // a + b * c should parse as a + (b * c)
        let tokens = tokenize("a + b * c");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        // Top level should be Add
        assert!(matches!(&e, Expr::BinOp(_, BinOpKind::Add, _)));
        if let Expr::BinOp(left, BinOpKind::Add, right) = &e {
            assert!(matches!(left.as_ref(), Expr::Var(n) if n == "a"));
            assert!(matches!(right.as_ref(), Expr::BinOp(_, BinOpKind::Mul, _)));
        }
    }

    #[test]
    fn test_infix_power_right_associative() {
        // a ^ b ^ c should parse as a ^ (b ^ c)
        let tokens = tokenize("a ^ b ^ c");
        let mut c = Cursor::new(&tokens);
        let e = parse_expr(&mut c).unwrap();
        if let Expr::BinOp(base, BinOpKind::Pow, exp) = &e {
            assert!(matches!(base.as_ref(), Expr::Var(n) if n == "a"));
            // exp should be b ^ c
            assert!(matches!(exp.as_ref(), Expr::BinOp(_, BinOpKind::Pow, _)));
        } else {
            panic!("expected Pow, got {:?}", e);
        }
    }

    #[test]
    fn test_hamiltonian_equation() {
        // H(psi) = kinetic(psi) + potential(psi) — the physics use case
        let module = parse_source(
            "operator H : Space -> Space where\n  \
             H(psi) = kinetic(psi) + potential(psi)\n  \
             proof hermitian : ok",
        )
        .unwrap();
        if let Declaration::Operator(op) = &module.declarations[0] {
            assert_eq!(op.equations.len(), 1);
            let eq = &op.equations[0];
            assert!(matches!(&eq.lhs, Expr::App(name, _) if name == "H"));
            assert!(matches!(&eq.rhs, Expr::BinOp(_, BinOpKind::Add, _)));
        } else {
            panic!("expected Operator");
        }
    }

    #[test]
    fn test_mixed_app_and_infix() {
        // f(x) + g(y) = h(x, y)
        let module =
            parse_source("morphism m : A -> B where\n  f(x) + g(y) = h(x, y)\n  proof p : ok")
                .unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.equations.len(), 1);
            assert!(matches!(
                &m.equations[0].lhs,
                Expr::BinOp(_, BinOpKind::Add, _)
            ));
            assert!(matches!(&m.equations[0].rhs, Expr::App(name, _) if name == "h"));
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_cohomology_bare_equation() {
        // cohomology requires `: Source -> Target` signature
        let module = parse_source(
            "cohomology C : Chain -> Cochain where\n  delta(sigma) = sum(edges)\n  proof p : ok",
        )
        .unwrap();
        if let Declaration::Cohomology(ch) = &module.declarations[0] {
            assert_eq!(ch.equations.len(), 1);
        } else {
            panic!("expected Cohomology");
        }
    }

    #[test]
    fn test_integer_in_equation() {
        // f(x) = 0 — integer literal on RHS
        let module = parse_source("morphism f : A -> B where\n  f(x) = 0\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.equations.len(), 1);
            assert!(matches!(&m.equations[0].rhs, Expr::Int(0)));
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_existing_app_equations_still_work() {
        // Ensure the original f(x) = g(x) form still parses correctly
        let module = parse_source(
            "morphism add : Nat -> Natural where\n  \
             add(zero, n) = n\n  \
             add(succ(m), n) = succ(add(m, n))\n  \
             proof total : forall m n, exists k, add(m, n) = k",
        )
        .unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert_eq!(m.equations.len(), 2);
            assert_eq!(m.proofs.len(), 1);
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_parse_neg_variable() {
        // -x should parse as Neg(Var("x"))
        let module =
            parse_source("morphism f : A -> B where\n  f(x) = -x\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert!(
                matches!(&m.equations[0].rhs, Expr::Neg(inner) if matches!(inner.as_ref(), Expr::Var(n) if n == "x"))
            );
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_parse_neg_function_app() {
        // -f(x) should parse as Neg(App("f", [Var("x")]))
        let module =
            parse_source("morphism g : A -> B where\n  g(x) = -h(x)\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            assert!(
                matches!(&m.equations[0].rhs, Expr::Neg(inner) if matches!(inner.as_ref(), Expr::App(n, _) if n == "h"))
            );
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_parse_neg_in_binop() {
        // a + -b should parse as BinOp(Var(a), Add, Neg(Var(b)))
        let module =
            parse_source("morphism f : A -> B where\n  f(x) = a + -b\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            match &m.equations[0].rhs {
                Expr::BinOp(_, BinOpKind::Add, rhs) => {
                    assert!(matches!(rhs.as_ref(), Expr::Neg(_)));
                }
                other => panic!("expected BinOp(_, Add, Neg(_)), got {:?}", other),
            }
        } else {
            panic!("expected Morphism");
        }
    }

    #[test]
    fn test_parse_neg_mul_expr() {
        // -E * psi should parse as BinOp(Neg(Var(E)), Mul, Var(psi))
        let module =
            parse_source("morphism f : A -> B where\n  f(x) = -E * psi\n  proof p : ok").unwrap();
        if let Declaration::Morphism(m) = &module.declarations[0] {
            match &m.equations[0].rhs {
                Expr::BinOp(lhs, BinOpKind::Mul, _rhs) => {
                    assert!(matches!(lhs.as_ref(), Expr::Neg(_)));
                }
                other => panic!("expected BinOp(Neg(_), Mul, _), got {:?}", other),
            }
        } else {
            panic!("expected Morphism");
        }
    }
}
