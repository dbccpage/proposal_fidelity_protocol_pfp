pub use omega_contract_core::registry::v1_vocabulary::*;

include!(concat!(env!("OUT_DIR"), "/generated_v1_vocabulary.rs"));
