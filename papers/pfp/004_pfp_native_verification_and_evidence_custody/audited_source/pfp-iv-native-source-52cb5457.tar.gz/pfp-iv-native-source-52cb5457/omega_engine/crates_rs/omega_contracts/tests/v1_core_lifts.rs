//! 08_lifts — both declared migrated identities load and validate structurally.
//! Neither a matching population nor declared machinery proves runtime licensing.
use omega_contracts::registry::{load_v1_dir, OmegaContractV1};
use std::collections::BTreeSet;
use std::path::Path;

#[test]
fn lift_license_loads_and_validates() {
    let dir = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("src/contract_canonical_definitions/08_core_lifts");
    let report = load_v1_dir(&dir).expect("dir readable");
    let expected = BTreeSet::from([
        "urn:omega:lifts:lift_license:v1.0.0".to_owned(),
        "urn:omega:lifts:semantic_lift_category:v1.0.0".to_owned(),
    ]);
    assert_eq!(
        report.contract_ids.iter().cloned().collect::<BTreeSet<_>>(),
        expected,
        "migrated lift identities must match, not merely their count"
    );
    assert_eq!(
        report.contract_ids.len(),
        expected.len(),
        "duplicate lift identity"
    );
    assert_eq!(report.seen, expected.len(), "unaccounted lift document");
    assert_eq!(report.loaded, expected.len(), "unparsed lift document");
    assert!(
        report.non_v1_documents.is_empty(),
        "unexpected non-v1 lift document"
    );
    assert!(
        report.findings.is_empty(),
        "findings: {:#?}",
        report.findings
    );
}

// Proves the authority machinery is ENFORCED: a LiftLicense missing constitution/constraints/
// replay/witnesses passes validate_v1 (role present) but is rejected by validate_registry.
#[test]
fn lift_license_without_machinery_is_rejected_by_registry() {
    let p = Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures/v1/poison/lift_missing_machinery.yaml");
    let c: OmegaContractV1 = serde_yaml::from_str(&std::fs::read_to_string(p).unwrap()).unwrap();
    let err = omega_contracts::validate::validate_registry(&[c.to_descriptor()]).unwrap_err();
    let e = err.to_lowercase();
    assert!(
        e.contains("constitution") || e.contains("lift license") || e.contains("scope bound"),
        "expected lift-license machinery rejection, got: {err}"
    );
}
