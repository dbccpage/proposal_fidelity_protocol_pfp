#[cfg(test)]
mod __omega_contracts_property_witnesses {
    use crate::traits::fixed_layer::OperatorClass;

    #[test]
    fn operator_class_symbol_has_compiled_witness() {
        assert!(core::any::type_name::<OperatorClass>().contains("OperatorClass"));
    }
}
