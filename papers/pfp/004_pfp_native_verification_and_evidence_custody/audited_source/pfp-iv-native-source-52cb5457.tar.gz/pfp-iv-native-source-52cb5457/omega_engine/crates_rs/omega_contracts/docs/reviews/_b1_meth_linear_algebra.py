"""B1 meth-level object-specific repair: linear-algebra storage family.

Stems: basic_matrix, matrix, vector, vector_space, gram_schmidt, scalar.
AuthorityEffect None. Not PROVED. Not GlobalGreen. Not LEAN4.
"""
from __future__ import annotations

from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parents[5]
MATH = REPO / "omega_engine/crates/omega_contracts/src/contract_canonical_definitions/math"
RECEIPT = REPO / "omega_engine/crates/omega_contracts/docs/reviews/rip_math_b1_linear_algebra_meth_receipt.md"

B1 = [
    "basic_matrix.contract.yaml",
    "matrix.contract.yaml",
    "vector.contract.yaml",
    "vector_space.contract.yaml",
    "gram_schmidt.contract.yaml",
    "scalar.contract.yaml",
]


def dump(data: dict) -> str:
    preferred = [
        "schema_version",
        "contract_id",
        "title",
        "kind",
        "status",
        "layer",
        "descriptor",
        "math",
        "requirements",
        "laws",
        "replay",
        "relationships",
        "rust_binding",
        "negative_tests",
        "doctrine",
        "wip",
        "nomos_debate_NOT_CANONICAL",
    ]
    ordered = {k: data[k] for k in preferred if k in data}
    for k, v in data.items():
        if k not in ordered:
            ordered[k] = v
    return yaml.safe_dump(
        ordered,
        sort_keys=False,
        allow_unicode=True,
        default_flow_style=False,
        width=100,
    )


def base_descriptor() -> dict:
    return {
        "authority_effect": "none",
        "evidence_ceiling": "ShapeOnly",
        "runtime_enforcement": False,
        "customer_claim_allowed": False,
        "dependencies": {"contracts": [], "proof_obligations": []},
        "terminals": {"may_emit": [], "may_support": []},
        "refusals": {"may_emit": []},
        "operator_classes": {"may_support": [], "must_not_self_assign": True},
    }


def debate(
    defects: list[dict],
    deltas: list[dict],
) -> dict:
    return {
        "banner": (
            "NON-CANONICAL DEBATE ONLY — not contract law; not enforced; "
            "AuthorityEffect None"
        ),
        "not_part_of_contract_law": True,
        "authority_effect": "none",
        "potential_defects": defects,
        "realization_delta_vs_implemented_math_file": deltas,
    }


def meth_note(detail: str) -> dict:
    return {
        "reviewer": "panepistimion-math-prof",
        "role": "MATH_CANONICAL_REVIEW",
        "code": "METH_B1_LINEAR_ALGEBRA",
        "severity": "info",
        "claim_class": "[STANDARD]",
        "detail": detail,
        "recommendation": (
            "Continue object-specific meth; align code under ADR-007a after YAML settles. "
            "Not PROVED; not GlobalGreen; not LEAN4."
        ),
        "pass": "b1_linear_algebra_meth",
    }


def build_basic_matrix() -> dict:
    return {
        "schema_version": "omega.contract.v1",
        "contract_id": "urn:omega:math:basic_matrix:v1.0.0",
        "title": "Basic Matrix Contract (finite rectangular storage)",
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": base_descriptor(),
        "math": {
            "object_kind": "finite_rectangular_storage_matrix",
            "symbol": "A ∈ T^{m×n}",
            "ascii_symbol": "basic_matrix",
            "notation": "A ∈ T^{m×n} (row-major dense storage)",
            "domain": [
                "rows: finite natural number m ≥ 0 (usize)",
                "cols: finite natural number n ≥ 0 (usize)",
                "entries: length-m*n sequence of scalar type T",
            ],
            "codomain": {
                "description": (
                    "Finite rectangular dense array of shape (m, n) with m, n ≥ 0. "
                    "This is a *storage* object (cochain maps, incidence, numeric backend), "
                    "not a basis-aware linear map V→W (see matrix.contract.yaml)."
                )
            },
        },
        "requirements": {
            "required_structures": [
                "m, n are finite natural numbers including zero (ℕ₀)",
                "len(entries) = m * n (with 0×n, m×0, 0×0 all length 0)",
                "Indexing get(i,j) is defined only when i < m and j < n",
                "Shape is part of identity: operations must not silently coerce shape",
                "Scalar type T is fixed by the carrier (type parameter); not multi-field runtime tags",
            ]
        },
        "laws": [
            "Shape law: A has shape (m, n) with m, n ∈ ℕ₀ (including zero dimensions).",
            "Length law: len(entries) = m · n always (empty product when m=0 or n=0).",
            "Access law: get(i,j) defined ⇔ 0 ≤ i < m ∧ 0 ≤ j < n; OOB is reject, never wrap.",
            "Add/sub law: A ± B defined only when shape(A)=shape(B); result has same shape.",
            "Matmul law: A·B defined only when cols(A)=rows(B); result shape (rows(A), cols(B)).",
            "Object fence: BasicMatrix is storage, not the linear-map object of matrix.contract.yaml.",
            "Authority law: this contract confers no authority and mints no GlobalGreen/PROVED.",
        ],
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No wall-clock dependence",
                "Row-major entry order is canonical for serialization",
                "Deterministic pure functions only",
            ]
        },
        "relationships": [
            "urn:omega:math:scalar:v0.1.0 — entry scalar language (aspirational type story)",
            "urn:omega:math:matrix:v0.1.0 — distinct linear-map object (007a: do not smash)",
            "urn:omega:math:field:v0.1.0 — field language deferred to linear-map / field contracts",
        ],
        "rust_binding": {
            "crate": "omega_linear_algebra",
            "module": "backend::basic_matrix",
            "symbols": ["BasicMatrix", "MatrixError"],
        },
        "negative_tests": [
            "Data length not equal to m*n must be rejected",
            "Access with i ≥ m or j ≥ n must fail (including any access on empty shape)",
            "Add/sub of unequal shapes must be rejected",
            "Matmul with lhs.cols ≠ rhs.rows must be rejected",
            "Implicit shape coercion (e.g. broadcast) must be rejected",
            "Artifact claiming to be the linear-map matrix object solely via BasicMatrix storage must be rejected",
            "Artifact claiming PROVED/GlobalGreen/HoTT discharge from this contract alone must be rejected",
        ],
        "doctrine": {
            "summary": (
                "BasicMatrix is the canonical finite rectangular *storage* matrix used by "
                "numeric backends, cochain maps, and incidence data. Shapes may be zero "
                "(empty free modules / zero maps) per ADR-007a meth decision 2026-08-01. "
                "Not a basis-aware linear map; not authority. Nonclaim: does not claim PROVED; "
                "does not claim GlobalGreen; does not claim HoTT discharge."
            ),
            "non_role": [
                "Linear map V→W with ordered bases (matrix.contract.yaml)",
                "Symbolic tensor algebra",
                "Infinite-dimensional operators",
                "Sparse/compressed storage formats",
                "Authority minting, customer claims, PROVED/GlobalGreen/HoTT discharge",
                "Floating-point numeric stability policy (separate)",
            ],
        },
        "wip": [
            "Whether T must be a field vs Numeric/semiring at the storage layer remains open; "
            "current RS backend is Numeric. Full field axioms belong on field/matrix objects.",
            "Multi-field same-T runtime tags deferred.",
        ],
        "nomos_debate_NOT_CANONICAL": debate(
            [
                meth_note(
                    "B1 meth: repaired zero-dim law — m,n ∈ ℕ₀ allowed (storage for empty "
                    "cochain maps). Removed negative_tests that rejected rows=0/cols=0. "
                    "Object fence vs matrix linear-map preserved (007a)."
                ),
                {
                    "reviewer": "panepistimion-math-prof",
                    "role": "MATH_CANONICAL_REVIEW",
                    "code": "MATH_ZERO_DIM_STORAGE",
                    "severity": "info",
                    "claim_class": "[STANDARD]",
                    "detail": (
                        "Zero-dimensional rectangular storage is mathematically legitimate "
                        "for free modules of rank 0 and zero maps. Enforcing m,n>0 was a "
                        "YAML defect relative to homology consumers (ADR-007a)."
                    ),
                },
            ],
            [
                {
                    "reviewer": "panepistimion-cs-prof-ml-ai-info",
                    "role": "CS_IMPL_DELTA_REVIEW",
                    "code": "SHAPE_CORE_MATCH_ZERO_DIM",
                    "severity": "info",
                    "claim_class": "[CODE_DEMO_RUST]",
                    "file": "omega_engine/crates/omega_linear_algebra/src/backend/basic_matrix.rs",
                    "yaml_law": "m,n ≥ 0; len = m*n; OOB/add/matmul shape refuse",
                    "code_behavior": "BasicMatrix permits 0-dim; Numeric T; structural shape checks",
                    "detail": (
                        "After B1 YAML repair, zero-dim is no longer CODE_MORE_PERMISSIVE on "
                        "shape positivity. Residual: field language vs Numeric T. Not PROVED."
                    ),
                    "delta": "MATCH_ON_SHAPE_WITH_SCALAR_RESIDUAL",
                }
            ],
        ),
    }


def build_matrix() -> dict:
    return {
        "schema_version": "omega.contract.v1",
        "contract_id": "urn:omega:math:matrix:v0.1.0",
        "title": "Matrix Contract (linear map representation)",
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": base_descriptor(),
        "math": {
            "object_kind": "linear_map_representation",
            "symbol": "M: V → W, dim V = n, dim W = m",
            "ascii_symbol": "matrix",
            "notation": "M ∈ Mat_{m×n}(K) representing a K-linear map V→W in ordered bases",
            "domain": [
                "field K (exact field artifact preferred)",
                "domain space V: finite-dim vector space over K, dim n ≥ 0, ordered basis",
                "codomain space W: finite-dim vector space over same K, dim m ≥ 0, ordered basis",
                "entries: dense m×n array of elements of K (row-major)",
            ],
            "codomain": {
                "description": (
                    "Representation of a K-linear map V→W as a dense matrix of its "
                    "coordinates in chosen ordered bases. Distinct from basic_matrix storage."
                )
            },
        },
        "requirements": {
            "required_structures": [
                "m = dim(W), n = dim(V) with m, n ∈ ℕ₀",
                "entries shape is exactly m×n over field K",
                "domain and codomain declare the same field K",
                "ordered bases of V and W are part of the representation (hashes or explicit lists)",
                "zero map (m=0 or n=0) is representable with empty entry list",
            ]
        },
        "laws": [
            "Representation law: M encodes a unique K-linear map V→W relative to fixed ordered bases.",
            "Shape law: entries form an m×n array with m=dim(W), n=dim(V), m,n ≥ 0.",
            "Field law: every entry is an element of K; domain and codomain share K.",
            "Composition shape law: product M·N defined only when domain dim of M equals codomain dim of N.",
            "Object fence: this is not BasicMatrix storage (basic_matrix.contract.yaml).",
            "Authority law: no authority, no PROVED/GlobalGreen from this contract alone.",
        ],
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No wall-clock dependence",
                "Row-major entry serialization",
                "Basis identity is content-addressed when hashes are used",
            ]
        },
        "relationships": [
            "urn:omega:math:basic_matrix:v1.0.0 — storage substrate (distinct object)",
            "urn:omega:math:vector_space:v0.1.0 — domain/codomain spaces",
            "urn:omega:math:vector:v0.1.0 — action on vectors",
            "urn:omega:math:field:v0.1.0 — scalar field K",
            "urn:omega:math:scalar:v0.1.0 — entry type language",
        ],
        "negative_tests": [
            "m×n claim with entries shape ≠ m×n must be rejected",
            "Domain and codomain over different fields must be rejected",
            "Basis hash inconsistent with declared basis list must be rejected",
            "Matmul with inner dimensions unequal must be rejected",
            "Claiming BasicMatrix storage alone realizes this linear-map object must be rejected",
            "Trace/eigenvalue authority claims without separate property contracts must be rejected",
            "Artifact claiming PROVED/GlobalGreen/HoTT from this contract alone must be rejected",
        ],
        "doctrine": {
            "summary": (
                "Matrix is a finite-dimensional K-linear map V→W represented in ordered bases "
                "as a dense m×n array. Zero dimensions allowed (zero maps). Pure structure; "
                "no authority. Nonclaim: does not claim PROVED; does not claim GlobalGreen; "
                "does not claim HoTT discharge. No dedicated RS linear-map module yet (007a)."
            ),
            "non_role": [
                "Dense storage backend alone (basic_matrix)",
                "Spectral theory, rank, definiteness (separate property contracts)",
                "Sparse formats",
                "Infinite-dimensional operators",
                "Authority, customer claims, PROVED/GlobalGreen/HoTT discharge",
            ],
        },
        "wip": [
            "Dedicated rust_binding for linear-map representation not yet chosen.",
            "Canonical basis encoding (NFKC string lists vs coordinate bases) open.",
            "Floating-point K deferred until rounding/field contract exists.",
        ],
        "nomos_debate_NOT_CANONICAL": debate(
            [
                meth_note(
                    "B1 meth: clarified linear-map object vs storage; allowed zero maps "
                    "(m,n ≥ 0); fixed relationship URNs toward urn:omega:math:*; kept "
                    "mathematical_wip until dedicated realization exists."
                )
            ],
            [
                {
                    "reviewer": "panepistimion-cs-prof-ml-ai-info",
                    "role": "CS_IMPL_DELTA_REVIEW",
                    "code": "NO_DEDICATED_REALIZATION",
                    "severity": "medium",
                    "claim_class": "[SCOPE FENCE]",
                    "file": "(none — do not bind omega_homological matrix wrappers as this object)",
                    "detail": "YAML_AHEAD_OF_CODE: linear-map matrix has no dedicated RS module. Not PROVED.",
                    "delta": "YAML_AHEAD_OF_CODE",
                }
            ],
        ),
    }


def build_vector() -> dict:
    return {
        "schema_version": "omega.contract.v1",
        "contract_id": "urn:omega:math:vector:v0.1.0",
        "title": "Vector Contract (coordinate vector)",
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": base_descriptor(),
        "math": {
            "object_kind": "coordinate_vector",
            "symbol": "v ∈ V ≅ K^n (column)",
            "ascii_symbol": "vector",
            "notation": "v = (v_1,…,v_n)^T relative to ordered basis of V",
            "domain": [
                "field K",
                "codomain space V over K with dim n ≥ 0 and ordered basis",
                "components: length-n sequence of elements of K",
            ],
            "codomain": {
                "description": (
                    "Element of finite-dimensional vector space V over K as a column "
                    "of coordinates in a fixed ordered basis. n=0 is the unique zero vector "
                    "of the zero space."
                )
            },
        },
        "requirements": {
            "required_structures": [
                "n = dim(V) ∈ ℕ₀",
                "len(components) = n",
                "each component ∈ K",
                "basis identity of V is recorded (hash or explicit list)",
                "column convention (map K→V) unless a separate row-vector object is introduced",
            ]
        },
        "laws": [
            "Length law: number of components equals dim(V).",
            "Field law: every component is an element of K.",
            "Zero-space law: if n=0 then components is empty and v is the unique zero vector.",
            "Addition law: u+v defined only for equal V (same field, dim, basis identity).",
            "Scalar law: α·v stays in V; α ∈ K.",
            "Authority law: no PROVED/GlobalGreen/HoTT from this contract alone.",
        ],
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No wall-clock dependence",
                "Component order is basis order",
            ]
        },
        "relationships": [
            "urn:omega:math:vector_space:v0.1.0 — ambient space V",
            "urn:omega:math:scalar:v0.1.0 — scalar multiplication",
            "urn:omega:math:field:v0.1.0 — field K",
            "urn:omega:math:matrix:v0.1.0 — linear action",
            "urn:omega:math:basic_matrix:v1.0.0 — optional n×1 storage view (not identity of objects)",
        ],
        "rust_binding": {
            "crate": "omega_linear_algebra",
            "module": "vector",
            "symbols": ["CoordinateVector"],
        },
        "negative_tests": [
            "components.len() ≠ dim(V) must be rejected",
            "Component not in K must be rejected",
            "Adding vectors with different space/basis identity must be rejected",
            "Scalar from a different field must be rejected",
            "Row-vector claims under column-only convention without a row object must be rejected",
            "Artifact claiming PROVED/GlobalGreen/HoTT from this contract alone must be rejected",
        ],
        "doctrine": {
            "summary": (
                "Vector is a coordinate representation of an element of finite-dim V over K "
                "in an ordered basis (column convention). Zero-dimensional V allowed. "
                "Nonclaim: does not claim PROVED; does not claim GlobalGreen; does not claim "
                "HoTT discharge."
            ),
            "non_role": [
                "Norm/inner-product geometry (separate contracts)",
                "Row vectors as maps V→K (separate object if needed)",
                "Infinite-dimensional vectors",
                "Authority / PROVED / GlobalGreen / HoTT discharge",
            ],
        },
        "wip": [
            "Canonical '1_K' domain basis encoding for the K→V column view.",
            "Parity between CoordinateVector RS and full field/hash artifact layer.",
        ],
        "nomos_debate_NOT_CANONICAL": debate(
            [
                meth_note(
                    "B1 meth: allowed n=0 zero vector; clarified column convention; "
                    "pointed rust_binding to omega_linear_algebra::vector with residual "
                    "YAML_AHEAD on field-hash artifact layer."
                )
            ],
            [
                {
                    "reviewer": "panepistimion-cs-prof-ml-ai-info",
                    "role": "CS_IMPL_DELTA_REVIEW",
                    "code": "PARTIAL_REALIZATION",
                    "severity": "medium",
                    "claim_class": "[CODE_DEMO_RUST]",
                    "file": "omega_engine/crates/omega_linear_algebra/src/vector.rs",
                    "detail": "CoordinateVector exists; full field/basis-hash envelope still YAML-ahead. Not PROVED.",
                    "delta": "YAML_AHEAD_OF_CODE",
                }
            ],
        ),
    }


def build_vector_space() -> dict:
    return {
        "schema_version": "omega.contract.v1",
        "contract_id": "urn:omega:math:vector_space:v0.1.0",
        "title": "VectorSpace Contract (finite-dimensional, ordered basis)",
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": base_descriptor(),
        "math": {
            "object_kind": "finite_dimensional_vector_space",
            "symbol": "V ∈ Vect_K^{fin}",
            "ascii_symbol": "vector_space",
            "notation": "V ≅ K^n with ordered basis (n ≥ 0)",
            "domain": [
                "field K",
                "dimension n ∈ ℕ₀",
                "ordered basis B = (b_1,…,b_n) with |B|=n (empty when n=0)",
            ],
            "codomain": {
                "description": (
                    "Finite-dimensional vector space over K equipped with an ordered basis. "
                    "n=0 is the zero space with empty basis."
                )
            },
        },
        "requirements": {
            "required_structures": [
                "n ∈ ℕ₀ (zero space allowed)",
                "len(ordered_basis) = n",
                "field K is declared and shared by all vectors in V",
                "basis identity is content-addressable when hashed",
                "linear independence of B is required when a verifier is attached; hash-only admission is wip residual",
            ]
        },
        "laws": [
            "Dimension law: dim(V)=n with n ≥ 0.",
            "Basis length law: ordered basis has exactly n elements.",
            "Zero-space law: n=0 ⇒ unique zero vector and empty basis.",
            "Field law: V is a vector space over a single field K.",
            "Span law: declared basis is intended as a basis (span + independence) when verified.",
            "Authority law: no PROVED/GlobalGreen/HoTT from this contract alone.",
        ],
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No wall-clock dependence",
                "Deterministic basis serialization when hashes are used",
            ]
        },
        "relationships": [
            "urn:omega:math:field:v0.1.0 — scalar field K",
            "urn:omega:math:vector:v0.1.0 — elements of V",
            "urn:omega:math:matrix:v0.1.0 — linear maps between spaces",
        ],
        "rust_binding": {
            "crate": "omega_linear_algebra",
            "module": "linear_algebra::vector_space",
            "symbols": ["FiniteVectorSpace"],
        },
        "negative_tests": [
            "len(ordered_basis) ≠ n must be rejected",
            "Mismatched basis hash vs basis list must be rejected",
            "Invalid or missing field declaration must be rejected",
            "Dependent basis must be rejected when independence verifier is engaged",
            "Vectors claiming membership with wrong space identity must be rejected",
            "Artifact claiming PROVED/GlobalGreen/HoTT from this contract alone must be rejected",
        ],
        "doctrine": {
            "summary": (
                "VectorSpace is a finite-dimensional K-vector space with an ordered basis, "
                "including the zero space n=0. Carrier for vectors and domain/codomain of "
                "linear maps. Nonclaim: does not claim PROVED; does not claim GlobalGreen; "
                "does not claim HoTT discharge."
            ),
            "non_role": [
                "Normed/inner-product/topological structure",
                "Infinite-dimensional spaces",
                "Abstract spaces without any declared basis presentation",
                "Authority / PROVED / GlobalGreen / HoTT discharge",
            ],
        },
        "wip": [
            "Independence verification may be deferred; hash-only admission is residual.",
            "Isomorphism classes vs concrete basis presentations are intentionally distinct.",
        ],
        "nomos_debate_NOT_CANONICAL": debate(
            [
                meth_note(
                    "B1 meth: allowed dim n=0 zero space; removed hard reject of dimension=0; "
                    "kept independence verification as conditional/wip."
                )
            ],
            [
                {
                    "reviewer": "panepistimion-cs-prof-ml-ai-info",
                    "role": "CS_IMPL_DELTA_REVIEW",
                    "code": "PARTIAL_REALIZATION",
                    "severity": "medium",
                    "claim_class": "[CODE_DEMO_RUST]",
                    "file": "omega_engine/crates/omega_linear_algebra/src/linear_algebra/vector_space.rs",
                    "detail": "FiniteVectorSpace metadata present; ordered-basis hash verifier residual. Not PROVED.",
                    "delta": "YAML_AHEAD_OF_CODE",
                }
            ],
        ),
    }


def build_gram_schmidt() -> dict:
    return {
        "schema_version": "omega.contract.v1",
        "contract_id": "urn:omega:math:gram_schmidt:v0.1.0",
        "title": "Gram-Schmidt Orthogonalization Contract (exact rational)",
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": base_descriptor(),
        "math": {
            "object_kind": "exact_gram_schmidt_orthogonalization",
            "symbol": "GS(v_1,…,v_n)=(u_1,…,u_n, certificate)",
            "ascii_symbol": "gram_schmidt",
            "notation": "classical Gram-Schmidt over Q with standard dot product",
            "domain": [
                "field: rational field Q (exact Ratio arithmetic)",
                "input family: linearly independent coordinate vectors in a common basis",
                "inner product: standard coordinate dot product",
            ],
            "codomain": {
                "description": (
                    "Pairwise orthogonal family u_i of same length as input, with algebraic "
                    "certificate of orthogonality, nonzero outputs, and span preservation."
                )
            },
        },
        "requirements": {
            "required_structures": [
                "Input family non-empty when n≥1; n=0 is empty GS (optional residual)",
                "All input vectors share the same ambient basis/space identity",
                "All input vectors have matching dimension",
                "Linear independence of inputs (no zero pivot) for full n-output success",
                "Exact arithmetic (no floating-point rounding)",
            ]
        },
        "laws": [
            "Orthogonality: ⟨u_i, u_j⟩ = 0 for i ≠ j (exact zero).",
            "Nonzero: u_i ≠ 0 for each produced i (dependence detected by zero pivot).",
            "Span: span{u_1,…,u_i} = span{v_1,…,v_i} for all i.",
            "Triangular reconstruction: u_i = v_i − Σ_{j<i} c_{ij} u_j with diagonal 1.",
            "Cardinality: successful full run yields |u|=|v|.",
            "Exactness: all coefficients in Q; no float.",
            "Authority law: no PROVED/GlobalGreen/HoTT from this contract alone.",
        ],
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No wall-clock dependence",
                "Deterministic input order",
                "Exact rational only",
            ]
        },
        "relationships": [
            "urn:omega:math:vector:v0.1.0 — coordinate vectors",
            "urn:omega:math:vector_space:v0.1.0 — ambient space",
            "urn:omega:math:inner_product:v0.1.0 — standard dot product instance",
            "urn:omega:math:field:v0.1.0 — rational field story",
        ],
        "rust_binding": {
            "crate": "omega_linear_algebra",
            "module": "gram_schmidt",
            "symbols": [
                "gram_schmidt_exact_standard",
                "OrthogonalFamily",
                "GramSchmidtCertificate",
                "OrthogonalityWitness",
                "SpanPreservationWitness",
                "GramSchmidtError",
            ],
        },
        "negative_tests": [
            "Linearly dependent inputs must fail (zero pivot) rather than emit fake orthogonal family",
            "Empty input family policy must be explicit (reject or empty certificate — no silent invent)",
            "Mismatched dimensions among inputs must be rejected",
            "Mismatched basis/space identity among inputs must be rejected",
            "Corrupted non-orthogonal output must fail verification",
            "Span-preservation failure must fail verification",
            "Artifact claiming PROVED/GlobalGreen/HoTT from this contract alone must be rejected",
        ],
        "doctrine": {
            "summary": (
                "Exact rational classical Gram-Schmidt under the standard coordinate dot "
                "product, with algebraic certificates. Orthogonal not orthonormal. "
                "Nonclaim: does not claim PROVED; does not claim GlobalGreen; does not claim "
                "HoTT discharge."
            ),
            "non_role": [
                "Orthonormalization (normalization separate)",
                "Floating-point numerical GS",
                "Arbitrary Gram-matrix inner products",
                "Complex/Hermitian GS",
                "QR factorization as product object",
                "Modified Gram-Schmidt algorithm",
                "Authority / PROVED / GlobalGreen / HoTT discharge",
            ],
        },
        "wip": [
            "Empty family policy: reject vs empty success certificate.",
            "Extension to arbitrary Gram matrices deferred.",
        ],
        "nomos_debate_NOT_CANONICAL": debate(
            [
                meth_note(
                    "B1 meth: restored domain/codomain/object_kind after shell damage; "
                    "laws already largely correct for exact classical GS; residual empty-family policy."
                )
            ],
            [
                {
                    "reviewer": "panepistimion-cs-prof-ml-ai-info",
                    "role": "CS_IMPL_DELTA_REVIEW",
                    "code": "STRUCTURAL_MATCH",
                    "severity": "info",
                    "claim_class": "[CODE_DEMO_RUST]",
                    "file": "omega_engine/crates/omega_linear_algebra/src/gram_schmidt.rs",
                    "detail": "Exact GS symbols bound; treat as CODE_DEMO_RUST certificate path. Not PROVED.",
                    "delta": "MATCH",
                }
            ],
        ),
    }


def build_scalar() -> dict:
    return {
        "schema_version": "omega.contract.v1",
        "contract_id": "urn:omega:math:scalar:v0.1.0",
        "title": "Scalar Contract (field element as K^1)",
        "kind": "math_contract",
        "status": "mathematical_wip",
        "layer": "math",
        "descriptor": base_descriptor(),
        "math": {
            "object_kind": "field_element_as_1d_vector",
            "symbol": "s ∈ K ≅ K^1",
            "ascii_symbol": "scalar",
            "notation": "s as the unique coordinate of an element of the 1-dimensional space K",
            "domain": [
                "field K",
                "dimension 1",
                "canonical basis [1_K]",
            ],
            "codomain": {
                "description": (
                    "An element of field K, optionally viewed as a 1×1 matrix / 1-dimensional "
                    "vector over K."
                )
            },
        },
        "requirements": {
            "required_structures": [
                "Declared dimension is 1 when using the K^1 view",
                "Value is a valid element of K",
                "Field identity is consistent across operations",
                "0 has no multiplicative inverse",
            ]
        },
        "laws": [
            "Element law: s ∈ K.",
            "One-dim law: as a vector, dim=1 and basis is canonical [1_K].",
            "Field ops: + and · are the field operations of K.",
            "Inverse law: s^{-1} defined only for s ≠ 0.",
            "Authority law: no PROVED/GlobalGreen/HoTT from this contract alone.",
        ],
        "replay": {
            "requirements": [
                "No external state",
                "No randomness",
                "No wall-clock dependence",
                "Canonical field element encoding when serialized",
            ]
        },
        "relationships": [
            "urn:omega:math:field:v0.1.0 — ambient field K",
            "urn:omega:math:vector:v0.1.0 — optional 1-d vector view",
            "urn:omega:math:basic_matrix:v1.0.0 — entry type language for storage",
        ],
        "negative_tests": [
            "Dimension ≠ 1 under K^1 view must be rejected",
            "Value not in K must be rejected",
            "invert(0) must error",
            "Operations across different field identities must be rejected",
            "Artifact claiming PROVED/GlobalGreen/HoTT from this contract alone must be rejected",
        ],
        "doctrine": {
            "summary": (
                "Scalar is an element of a field K, optionally as the unique coordinate of K^1. "
                "Atomic value type for products and scaling. Nonclaim: does not claim PROVED; "
                "does not claim GlobalGreen; does not claim HoTT discharge."
            ),
            "non_role": [
                "Ordered-field positivity facts (separate)",
                "Floating-point rounding policy",
                "Authority / PROVED / GlobalGreen / HoTT discharge",
            ],
        },
        "wip": [
            "Whether Scalar is a special case of Vector(n=1) or a distinct primitive remains open.",
            "Dedicated rust_binding for a Scalar newtype may be absent (type-parameter realization).",
        ],
        "nomos_debate_NOT_CANONICAL": debate(
            [
                meth_note(
                    "B1 meth: clarified K^1 view and inverse law; relationship URNs omega-normalized; "
                    "realization often type-parameter only (no Scalar struct) — residual OK."
                )
            ],
            [
                {
                    "reviewer": "panepistimion-cs-prof-ml-ai-info",
                    "role": "CS_IMPL_DELTA_REVIEW",
                    "code": "TYPE_PARAM_REALIZATION",
                    "severity": "info",
                    "claim_class": "[CODE_DEMO_RUST]",
                    "file": "(type parameter T / Numeric rather than Scalar struct)",
                    "detail": "No dedicated Scalar module required if T carries field/numeric ops. Residual documentation only. Not PROVED.",
                    "delta": "MATCH_VIA_TYPE_PARAM",
                }
            ],
        ),
    }


BUILDERS = {
    "basic_matrix.contract.yaml": build_basic_matrix,
    "matrix.contract.yaml": build_matrix,
    "vector.contract.yaml": build_vector,
    "vector_space.contract.yaml": build_vector_space,
    "gram_schmidt.contract.yaml": build_gram_schmidt,
    "scalar.contract.yaml": build_scalar,
}


def main() -> None:
    rows = []
    for stem, builder in BUILDERS.items():
        data = builder()
        text = dump(data)
        yaml.safe_load(text)  # round-trip
        path = MATH / stem
        path.write_text(text, encoding="utf-8")
        # unique top-level keys check
        loaded = yaml.safe_load(path.read_text(encoding="utf-8"))
        assert "nomos_debate_NOT_CANONICAL" in loaded
        rows.append(stem)
        print("wrote", stem)

    receipt = [
        "# B1 meth-level linear-algebra storage family",
        "",
        "**AuthorityEffect:** None",
        "**Pass:** b1_linear_algebra_meth",
        "**Date:** 2026-08-01",
        "",
        "## Stems",
        "",
        "| Stem | Headline meth decision |",
        "| --- | --- |",
        "| `basic_matrix` | Allow m,n ∈ ℕ₀ storage; fence vs linear-map `matrix` (007a zero-dim) |",
        "| `matrix` | Linear-map object; zero maps allowed; no dedicated RS yet |",
        "| `vector` | Coordinate column vectors; n=0 zero vector allowed |",
        "| `vector_space` | Finite dim n≥0 including zero space |",
        "| `gram_schmidt` | Restore exact classical GS domain/object_kind |",
        "| `scalar` | Field element as K¹; invert(0) refuse |",
        "",
        "## Nonclaims",
        "",
        "- Not PROVED / not GlobalGreen / not HoTT discharge",
        "- Not LEAN4 golden step (YAML perfecting only)",
        "- Code-follows-YAML: realization residuals recorded; code not auto-weakened into YAML",
        "",
        f"**Files written:** {len(rows)}",
        "",
        "**AuthorityEffect: None.**",
        "",
    ]
    RECEIPT.write_text("\n".join(receipt), encoding="utf-8")
    print("receipt", RECEIPT)


if __name__ == "__main__":
    main()
