//! Discrete Deformation Algebra (DDA) Orbit State & Equational Reasoning Solver.
//!
//! Implements Quantum Normal Form Reduction and Matrix Product State (MPS)
//! algorithms for discrete term rewriting systems based on:
//! - Rattacaso et al., *Quantum algorithms for equational reasoning*,
//!   Science Advances 2025/2026, DOI: 10.1126/sciadv.aec2736, arXiv: 2508.21122.
//!
//! # Core Algebraic Constructs:
//! 1. **DdaRewriteRule**: Invertible string rewriting rule \(r_l = (\alpha \approx \beta)\).
//! 2. **DdaGraphLaplacian**: Sparse discrete Laplacian \(\hat{L}_S = \sum (\hat{r}_l^2 - \hat{r}_l)\)
//!    acting on \(L\)-qudit configuration graphs.
//! 3. **DdaMpsState**: 1D Matrix Product State with local rank-3 tensors and SVD bond truncation.
//! 4. **DdaOrbitStateSolver**: Imaginary Quantum Annealing (IQA) solver preparing uniform
//!    orbit states \(|X_{S, \tilde{\omega}}\rangle = \frac{1}{\sqrt{|X|}} \sum |\omega\rangle\)
//!    for Word Problem verification and Equivalence Class counting in polynomial time.
//!
//! AuthorityEffect: None. Mathematical modeling & automated reasoning diagnostics only.

use nalgebra::DMatrix;
use omega_types::authority::AuthorityEffect;
use serde::{Deserialize, Serialize};

/// Maximum default bond dimension for MPS simulation.
pub const DEFAULT_MAX_BOND_DIM: usize = 32;

/// Default singular value cutoff threshold.
pub const DEFAULT_SVD_CUTOFF: f64 = 1e-12;

/// An invertible string rewriting rule acting on substrings of length 2.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct DdaRewriteRule {
    /// Pattern characters before rewrite (length 2).
    pub from: [usize; 2],
    /// Pattern characters after rewrite (length 2).
    pub to: [usize; 2],
}

impl DdaRewriteRule {
    /// Create a new 2-character rewrite rule.
    pub fn new(from: [usize; 2], to: [usize; 2]) -> Self {
        Self { from, to }
    }

    /// Construct the local 2-site Laplacian matrix \(h_l \in \mathbb{R}^{d^2 \times d^2}\).
    ///
    /// \(h_l = |from\rangle\langle from| + |to\rangle\langle to| - |from\rangle\langle to| - |to\rangle\langle from|\)
    pub fn local_laplacian_matrix(&self, alphabet_size: usize) -> DMatrix<f64> {
        let dim = alphabet_size * alphabet_size;
        let mut mat = DMatrix::<f64>::zeros(dim, dim);

        let idx_from = self.from[0] * alphabet_size + self.from[1];
        let idx_to = self.to[0] * alphabet_size + self.to[1];

        if idx_from == idx_to {
            return mat;
        }

        mat[(idx_from, idx_from)] += 1.0;
        mat[(idx_to, idx_to)] += 1.0;
        mat[(idx_from, idx_to)] -= 1.0;
        mat[(idx_to, idx_from)] -= 1.0;

        mat
    }

    /// Construct the local imaginary time evolution gate \(U = \exp(-\delta \tau h_l)\).
    pub fn local_ite_gate(&self, alphabet_size: usize, dt: f64) -> DMatrix<f64> {
        let dim = alphabet_size * alphabet_size;
        let mut u = DMatrix::<f64>::identity(dim, dim);

        let idx_from = self.from[0] * alphabet_size + self.from[1];
        let idx_to = self.to[0] * alphabet_size + self.to[1];

        if idx_from == idx_to {
            return u;
        }

        // For projector h = [[1, -1], [-1, 1]], eigenvalues are 2 and 0.
        // exp(-dt * h) = I - (1 - exp(-2*dt)) * 0.5 * h.
        let factor = 0.5 * (1.0 - (-2.0 * dt).exp());
        u[(idx_from, idx_from)] -= factor;
        u[(idx_to, idx_to)] -= factor;
        u[(idx_from, idx_to)] += factor;
        u[(idx_to, idx_from)] += factor;

        u
    }
}

/// A 1D Matrix Product State (MPS) representing a quantum state over \(L\) qudits.
#[derive(Debug, Clone, PartialEq)]
pub struct DdaMpsState {
    /// Number of sites (string length \(L\)).
    pub length: usize,
    /// Physical dimension \(d\) (alphabet size).
    pub alphabet_size: usize,
    /// Local tensors for each site: `tensors[i][sigma]` has shape \((D_{i-1}, D_i)\).
    pub tensors: Vec<Vec<DMatrix<f64>>>,
}

impl DdaMpsState {
    /// Construct an exact pure product state representing a single string \(\tilde{\omega}\).
    pub fn from_product_state(sequence: &[usize], alphabet_size: usize) -> Result<Self, String> {
        if sequence.is_empty() {
            return Err("Sequence cannot be empty".to_string());
        }
        for &s in sequence {
            if s >= alphabet_size {
                return Err(format!("Character {s} exceeds alphabet size {alphabet_size}"));
            }
        }

        let length = sequence.len();
        let mut tensors = Vec::with_capacity(length);

        for &target_char in sequence {
            let mut site_mats = Vec::with_capacity(alphabet_size);
            for sigma in 0..alphabet_size {
                let val = if sigma == target_char { 1.0 } else { 0.0 };
                site_mats.push(DMatrix::from_element(1, 1, val));
            }
            tensors.push(site_mats);
        }

        Ok(Self {
            length,
            alphabet_size,
            tensors,
        })
    }

    /// Construct an exact uniform superposition state \(|All\rangle = \frac{1}{\sqrt{d^L}} \sum |\omega\rangle\).
    pub fn uniform_superposition(length: usize, alphabet_size: usize) -> Result<Self, String> {
        if length == 0 || alphabet_size == 0 {
            return Err("Length and alphabet size must be positive".to_string());
        }

        let val = 1.0 / (alphabet_size as f64).sqrt();
        let mut tensors = Vec::with_capacity(length);

        for _ in 0..length {
            let mut site_mats = Vec::with_capacity(alphabet_size);
            for _ in 0..alphabet_size {
                site_mats.push(DMatrix::from_element(1, 1, val));
            }
            tensors.push(site_mats);
        }

        Ok(Self {
            length,
            alphabet_size,
            tensors,
        })
    }

    /// Compute the exact inner product \(\langle \psi | \phi \rangle\) in \(O(L \cdot d \cdot \chi^3)\) time.
    pub fn inner_product(&self, other: &DdaMpsState) -> Result<f64, String> {
        if self.length != other.length || self.alphabet_size != other.alphabet_size {
            return Err("MPS dimension mismatch in inner product".to_string());
        }

        // Initialize transfer matrix E_0 = [[1.0]] of shape (D_left_self, D_left_other) = (1, 1).
        let mut transfer = DMatrix::<f64>::from_element(1, 1, 1.0);

        for site in 0..self.length {
            let mut next_transfer = DMatrix::<f64>::zeros(
                self.tensors[site][0].ncols(),
                other.tensors[site][0].ncols(),
            );

            for sigma in 0..self.alphabet_size {
                let a_mat = &self.tensors[site][sigma];
                let b_mat = &other.tensors[site][sigma];
                // next_transfer += A^T * transfer * B
                let temp = a_mat.transpose() * &transfer;
                next_transfer += temp * b_mat;
            }

            transfer = next_transfer;
        }

        if transfer.nrows() == 1 && transfer.ncols() == 1 {
            Ok(transfer[(0, 0)])
        } else {
            Err("Transfer matrix failed to contract to scalar".to_string())
        }
    }

    /// Compute the norm squared \(\|\psi\|^2 = \langle \psi | \psi \rangle\).
    pub fn norm_squared(&self) -> f64 {
        self.inner_product(self).unwrap_or(0.0)
    }

    /// Compute the norm \(\|\psi\|\).
    pub fn norm(&self) -> f64 {
        self.norm_squared().max(0.0).sqrt()
    }

    /// Normalize the MPS state such that \(\|\psi\| = 1.0\).
    pub fn normalize(&mut self) -> Result<(), String> {
        let n = self.norm();
        if n < 1e-15 {
            return Err("Cannot normalize state with zero norm".to_string());
        }
        let factor = 1.0 / n.powf(1.0 / self.length as f64);
        for site_mats in &mut self.tensors {
            for mat in site_mats {
                *mat *= factor;
            }
        }
        Ok(())
    }

    /// Compute the quantum fidelity \(F(\psi, \phi) = \frac{|\langle \psi | \phi \rangle|^2}{\|\psi\|^2 \|\phi\|^2}\).
    pub fn fidelity(&self, other: &DdaMpsState) -> Result<f64, String> {
        let overlap = self.inner_product(other)?;
        let n1 = self.norm_squared();
        let n2 = other.norm_squared();
        if n1 < 1e-15 || n2 < 1e-15 {
            return Ok(0.0);
        }
        let f = (overlap * overlap) / (n1 * n2);
        Ok(f.clamp(0.0, 1.0))
    }

    /// Apply a two-site gate to adjacent sites `(site, site + 1)` with SVD truncation.
    pub fn apply_two_site_gate(
        &mut self,
        site: usize,
        gate: &DMatrix<f64>,
        max_bond_dim: usize,
        cutoff: f64,
    ) -> Result<(), String> {
        if site + 1 >= self.length {
            return Err("Gate application site out of bounds".to_string());
        }
        let d = self.alphabet_size;
        if gate.nrows() != d * d || gate.ncols() != d * d {
            return Err("Gate dimension mismatch".to_string());
        }

        let d_left = self.tensors[site][0].nrows();
        let _d_mid = self.tensors[site][0].ncols();
        let d_right = self.tensors[site + 1][0].ncols();

        // 1. Construct two-site tensor Theta of shape (d_left * d, d * d_right).
        let mut theta = DMatrix::<f64>::zeros(d_left * d, d * d_right);

        for s1 in 0..d {
            let a_mat = &self.tensors[site][s1];
            for s2 in 0..d {
                let b_mat = &self.tensors[site + 1][s2];
                let prod = a_mat * b_mat; // shape: (d_left, d_right)

                for (alpha, sigma1) in (0..d_left).zip(std::iter::repeat(s1)) {
                    let row = alpha * d + sigma1;
                    for (beta, sigma2) in (0..d_right).zip(std::iter::repeat(s2)) {
                        let col = sigma2 * d_right + beta;
                        theta[(row, col)] = prod[(alpha, beta)];
                    }
                }
            }
        }

        // 2. Apply gate U: Theta_prime = (U (x) I) Theta.
        let mut theta_prime = DMatrix::<f64>::zeros(d_left * d, d * d_right);

        for s1_prime in 0..d {
            for s2_prime in 0..d {
                let row_gate = s1_prime * d + s2_prime;

                for s1 in 0..d {
                    for s2 in 0..d {
                        let col_gate = s1 * d + s2;
                        let weight = gate[(row_gate, col_gate)];
                        if weight.abs() < 1e-15 {
                            continue;
                        }

                        for alpha in 0..d_left {
                            let old_row = alpha * d + s1;
                            let new_row = alpha * d + s1_prime;
                            for beta in 0..d_right {
                                let old_col = s2 * d_right + beta;
                                let new_col = s2_prime * d_right + beta;
                                theta_prime[(new_row, new_col)] += weight * theta[(old_row, old_col)];
                            }
                        }
                    }
                }
            }
        }

        // 3. SVD decomposition of Theta_prime = U S V^T.
        // Reshape to matrix of size (d_left * d, d * d_right).
        let svd = theta_prime.svd(true, true);
        let u_mat = svd.u.ok_or("SVD failed to compute U")?;
        let v_t_mat = svd.v_t.ok_or("SVD failed to compute V^T")?;
        let s_vals = &svd.singular_values;

        // Determine truncated bond dimension.
        let mut new_bond = 0;
        for &s in s_vals.iter() {
            if s > cutoff && new_bond < max_bond_dim {
                new_bond += 1;
            }
        }
        new_bond = new_bond.max(1);

        // 4. Update site tensors.
        // Site i: A_new[s1](alpha, k) = U[(alpha*d + s1), k] * sqrt(S[k])
        let mut new_a = Vec::with_capacity(d);
        for s1 in 0..d {
            let mut mat_a = DMatrix::<f64>::zeros(d_left, new_bond);
            for alpha in 0..d_left {
                let row = alpha * d + s1;
                for k in 0..new_bond {
                    mat_a[(alpha, k)] = u_mat[(row, k)] * s_vals[k].sqrt();
                }
            }
            new_a.push(mat_a);
        }

        // Site i+1: B_new[s2](k, beta) = sqrt(S[k]) * V^T[k, (s2*d_right + beta)]
        let mut new_b = Vec::with_capacity(d);
        for s2 in 0..d {
            let mut mat_b = DMatrix::<f64>::zeros(new_bond, d_right);
            for k in 0..new_bond {
                for beta in 0..d_right {
                    let col = s2 * d_right + beta;
                    mat_b[(k, beta)] = s_vals[k].sqrt() * v_t_mat[(k, col)];
                }
            }
            new_b.push(mat_b);
        }

        self.tensors[site] = new_a;
        self.tensors[site + 1] = new_b;

        Ok(())
    }
}

/// Diagnostic result from solving the Word Problem between two symbolic expressions.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct WordProblemResult {
    pub connected: bool,
    pub fidelity: f64,
    pub word_1: Vec<usize>,
    pub word_2: Vec<usize>,
    pub annealing_steps: usize,
    pub authority_effect: AuthorityEffect,
}

/// Diagnostic result from estimating the equivalence class cardinality.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct CountingResult {
    pub seed_word: Vec<usize>,
    pub estimated_class_size: f64,
    pub fidelity_to_all: f64,
    pub total_hilbert_space_dim: usize,
    pub authority_effect: AuthorityEffect,
}

/// DDA Orbit State Solver for equational reasoning and equivalence class operations.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct DdaOrbitStateSolver {
    /// Alphabet size \(d\).
    pub alphabet_size: usize,
    /// String length \(L\).
    pub length: usize,
    /// Active rewriting rules \(R\).
    pub rules: Vec<DdaRewriteRule>,
    /// Maximum bond dimension \(\chi\).
    pub max_bond_dim: usize,
    /// Singular value cutoff threshold.
    pub svd_cutoff: f64,
}

impl DdaOrbitStateSolver {
    /// Create a new DDA Orbit State Solver.
    pub fn new(alphabet_size: usize, length: usize, rules: Vec<DdaRewriteRule>) -> Self {
        Self {
            alphabet_size,
            length,
            rules,
            max_bond_dim: DEFAULT_MAX_BOND_DIM,
            svd_cutoff: DEFAULT_SVD_CUTOFF,
        }
    }

    /// Set custom maximum bond dimension.
    pub fn with_max_bond_dim(mut self, max_bond_dim: usize) -> Self {
        self.max_bond_dim = max_bond_dim.max(1);
        self
    }

    /// Prepare an orbit state \(|X_{S, \tilde{\omega}}\rangle\) via Imaginary Quantum Annealing.
    pub fn prepare_orbit_state(
        &self,
        seed_word: &[usize],
        annealing_steps: usize,
        dt: f64,
    ) -> Result<DdaMpsState, String> {
        if seed_word.len() != self.length {
            return Err(format!(
                "Seed word length {} does not match solver length {}",
                seed_word.len(),
                self.length
            ));
        }

        let mut mps = DdaMpsState::from_product_state(seed_word, self.alphabet_size)?;

        for _ in 0..annealing_steps {
            // Apply imaginary time gates for each rule across all valid adjacent pairs.
            for rule in &self.rules {
                let gate = rule.local_ite_gate(self.alphabet_size, dt);
                for site in 0..(self.length - 1) {
                    mps.apply_two_site_gate(site, &gate, self.max_bond_dim, self.svd_cutoff)?;
                }
            }
            mps.normalize()?;
        }

        Ok(mps)
    }

    /// Solve the Word Problem: Determine if `word1` and `word2` belong to the same equivalence class.
    pub fn solve_word_problem(
        &self,
        word1: &[usize],
        word2: &[usize],
        annealing_steps: usize,
        dt: f64,
        fidelity_threshold: f64,
    ) -> Result<WordProblemResult, String> {
        let mps1 = self.prepare_orbit_state(word1, annealing_steps, dt)?;
        let mps2 = self.prepare_orbit_state(word2, annealing_steps, dt)?;

        let fidelity = mps1.fidelity(&mps2)?;
        let connected = fidelity >= fidelity_threshold;

        Ok(WordProblemResult {
            connected,
            fidelity,
            word_1: word1.to_vec(),
            word_2: word2.to_vec(),
            annealing_steps,
            authority_effect: AuthorityEffect::None,
        })
    }

    /// Estimate the number of equivalent expressions connected to `seed_word`.
    pub fn estimate_class_size(
        &self,
        seed_word: &[usize],
        annealing_steps: usize,
        dt: f64,
    ) -> Result<CountingResult, String> {
        let orbit = self.prepare_orbit_state(seed_word, annealing_steps, dt)?;
        let all_state = DdaMpsState::uniform_superposition(self.length, self.alphabet_size)?;

        let fid = orbit.fidelity(&all_state)?;
        let total_dim = self.alphabet_size.pow(self.length as u32);
        let estimated_size = (total_dim as f64) * fid;

        Ok(CountingResult {
            seed_word: seed_word.to_vec(),
            estimated_class_size: estimated_size,
            fidelity_to_all: fid,
            total_hilbert_space_dim: total_dim,
            authority_effect: AuthorityEffect::None,
        })
    }
}
