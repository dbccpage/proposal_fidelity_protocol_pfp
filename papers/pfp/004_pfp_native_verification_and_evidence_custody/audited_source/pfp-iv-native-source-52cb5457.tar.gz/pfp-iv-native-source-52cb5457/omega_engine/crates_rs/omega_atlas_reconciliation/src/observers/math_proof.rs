//! math-proof observer: the two-axis honesty rule for proofs.
//!
//! Prose mechanization is not Lean machine-checking: a `MECHANIZED` prose status whose Lean
//! status is anything other than `MECHANIZED` overstates the proof. Independently, any proof
//! carrying declared relative axioms is conditional on those axioms and must never be reported
//! as "unconditionally proved".
use super::ObserverReading;
use crate::row::ReconciliationRow;

/// Deterministic math-proof reading for a row.
pub fn check(row: &ReconciliationRow) -> ObserverReading {
    let mut findings = Vec::new();

    if row.proof_status.status == "MECHANIZED" && row.proof_status.lean_status != "MECHANIZED" {
        findings.push("prose MECHANIZED != lean machine-checked (two-axis)".to_string());
    }
    if !row.proof_status.relative_axioms.is_empty() {
        findings.push(
            "proof is relative to a declared axiom — never 'unconditionally proved'".to_string(),
        );
    }

    ObserverReading {
        observer: "math-proof",
        findings,
    }
}
