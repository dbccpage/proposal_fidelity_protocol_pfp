# Change log

## 2026-10-23 — 0.1.0 author review

Added the implemented harness-evolution method, owner mapping, frozen $40 protocol,
page-level source map, evidence boundaries and reproduction instructions. The
live experiment remains NOT_RUN pending the verified Ubuntu SSH handoff. No
external deposit, improvement claim or new formal theorem is made.

## PR review repairs — 2026-10-23

Rebased the task delta onto main at `59dde95a7860063c25d75db37f40af556e9f28ee`,
excluding unrelated unmerged commits. Rebuilt author-review artifacts after
provider-status, replay-custody and package-traversal repairs. Linux containment
and all paid measurements remain deferred; no empirical improvement claim changed.
