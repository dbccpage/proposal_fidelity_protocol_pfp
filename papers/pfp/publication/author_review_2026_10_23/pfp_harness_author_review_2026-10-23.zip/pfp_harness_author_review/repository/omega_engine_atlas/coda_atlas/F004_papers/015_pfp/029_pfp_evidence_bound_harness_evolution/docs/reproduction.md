# Reproduction

Use the retained source revision and source manifest, Python 3.12, and the existing
native `omega_symbol_game` executable for the budget and typed-operation tests.
The verification receipt identifies the actual executable bytes used locally;
it does not assert a fresh source-to-binary build. Live execution requires a
separate observed Linux container preflight.

From the repository root:

```powershell
py -3.12 -m pytest omega_engine_woland/tests/research/test_harness_contracts.py omega_engine_woland/tests/providers/test_harness_anthropic_budget.py -q
py -3.12 -m pytest omega_engine_woland/tests/test_ddc_code_repair.py omega_engine_woland/tests/providers/test_completion_failure_bytes.py omega_engine_operads/tests/autopoiesis/test_learning_loop.py -q
py -3.12 -m omega_engine_woland.entrypoints.research.harness_cli replay --output omega_engine_woland/documentation/harness_evolution/campaign
py -3.12 -m omega_engine_woland.entrypoints.research.harness_cli report --output omega_engine_woland/documentation/harness_evolution/campaign
```

If Windows temporary-directory ACLs prevent pytest allocation, pass a new writable
`--basetemp` path. Do not change test semantics to suppress an allocation failure.
No API key is needed for these offline checks. No candidate code is executed
outside the rootless runner by the live campaign.

The report must remain NOT_RUN and all model effects NOT_MEASURED until actual
provider calls and evaluations have been retained. Historical traces in other
papers are not inputs to these empirical tables. The supplied PDF is identified
by exact file digest and page text digests in `source_manifest.json`; obtain the
same v1 bytes to re-extract page references.

Rebuild the selected author-review PDFs through the existing collection tool:

```powershell
py -3.12 omega_engine_atlas/coda_atlas/F004_papers/015_pfp/tools/build_publications.py --author-review --pdf
```

This writes a separate dated review collection, without `--deposit`. Historical
release ZIPs, deposited metadata and package renderings keep their identities.
The review package has a source manifest and SHA-256 manifest. External deposit
is outside this work. Existing finite proof sources are unchanged; no new Lean
claim is introduced by the experimental extension.
