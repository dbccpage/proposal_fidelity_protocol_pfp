from pathlib import Path
import sys
root = Path(__file__).resolve().parent / "repository"
sys.path.insert(0, str(root))
from omega_engine_woland.entrypoints.research.harness_cli import main
docs = root / "omega_engine_woland/documentation/harness_evolution"
raise SystemExit(main(["replay", "--output", str(docs / "campaign"), "--prices", str(docs / "pricing_observation.json"), "--pricing-evidence", str(docs / "pricing_evidence.json")]))
