# Evidence-Bound Harness Evolution — author review

This package contains the implemented research loop, frozen offline protocol,
retained local verification, eleven revised papers and new Paper 029. It is an
author-review delivery, with no external deposit or production admission.

The campaign is NOT_RUN: zero provider calls, zero spend, zero model trials.
Linux containment testing and the paid campaign were deferred by the operator.
Focused test counts and receipts are in verification/summary.json. The 158
task-calibration cases are host fixtures, not
independent model trials. Paper 027's unavailable historical model receipts are
explicitly unverified; its finite examples were checked separately.

From this directory, with Python 3.12 and the observed dependencies installed:

```text
python replay_offline.py
python tools/rebuild_release.py . --check
```

The archive must be beside MANIFEST.sha256 for the second command's archive
comparison. The extracted source replay was checked with Python isolated mode
and an explicit path to existing installed dependencies. A fresh dependency
installation and a hermetic environment were not tested. Replay makes no network
requests. The report honestly remains NOT_RUN; checker replay is not a trial.

Read repository/omega_engine_woland/documentation/harness_evolution/README.md
for the CLI, original budget ledger, frozen source identities, admission rules,
Linux handoff and pricing refresh procedure. That directory contains campaign/
and verification/ with retained receipts and diagnostic drafts.

The PDFs, exact Markdown sources, LaTeX and build manifest are under
repository/omega_engine_atlas/coda_atlas/F004_papers/015_pfp/publication/
author_review_2026_10_23/. Paper 029 is in 029/paper.pdf. The source-to-claim map
binds the supplied PDF hash and individual pages without redistributing it.

The repository directory is the frozen replay source subset, not a complete
checkout or native build workspace. Full native builds and unit-test reproduction
require the full repository at the recorded base plus this delivery's changes.
The existing Windows native binary was reused; only its identity is retained.
The current-policy baseline is a projection into the common adapter. The ignition
design is exploratory. No measured improvement, transfer or acceleration is claimed.

MANIFEST.sha256 and SHA256SUMS bind this package's files; nested historical
manifests retain their original scope. Historical release archives and deposited
identities were not updated. Licenses are supplied separately for text and code.
