"""Extraction and offline-execution controls for the historical review handoff."""

import stat
import subprocess
import sys
import zipfile

import pytest

from omega_engine_woland.documentation.harness_evolution import replay_review_archive as replay


def archive_at(tmp_path, members):
    archive = tmp_path / "fixture.zip"
    with zipfile.ZipFile(archive, "w") as output:
        for name, mode in members:
            item = zipfile.ZipInfo(name)
            # ZipInfo normalizes Windows separators during construction; retain
            # the hostile wire spelling so the extraction boundary sees it.
            item.filename = name
            item.external_attr = mode << 16
            output.writestr(item, b"retained bytes")
    return archive


@pytest.mark.parametrize("name", [
    "../escape", "/absolute", "foreign/file", "pfp_harness_author_review/../escape",
    "pfp_harness_author_review/a\\b", "pfp_harness_author_review/x:stream",
    "pfp_harness_author_review/CON.txt", "pfp_harness_author_review/trailing.",
])
def test_unsafe_members_are_refused_before_any_extraction(tmp_path, name):
    archive = archive_at(tmp_path, [(name, stat.S_IFREG | 0o644)])
    target = tmp_path / "output"
    with pytest.raises(ValueError, match="UNSAFE_ARCHIVE_MEMBER"):
        replay.extract(archive, target, replay.sha(archive))
    assert not target.exists()


@pytest.mark.parametrize("members,reason", [
    ([(replay.PACKAGE + "/link", stat.S_IFLNK | 0o777)], "NONREGULAR"),
    ([(replay.PACKAGE + "/A", stat.S_IFREG), (replay.PACKAGE + "/a", stat.S_IFREG)], "DUPLICATE"),
])
def test_link_and_case_collisions_fail_closed(tmp_path, members, reason):
    archive = archive_at(tmp_path, members)
    with pytest.raises(ValueError, match=reason):
        replay.extract(archive, tmp_path / "output", replay.sha(archive))
    assert not (tmp_path / "output").exists()


def test_digest_is_checked_and_existing_work_is_preserved(tmp_path):
    archive = archive_at(tmp_path, [(replay.PACKAGE + "/payload", stat.S_IFREG | 0o644)])
    target = tmp_path / "output"
    with pytest.raises(ValueError, match="DIGEST_MISMATCH"):
        replay.extract(archive, target, "0" * 64)
    assert not target.exists()
    package = replay.extract(archive, target, replay.sha(archive))
    (package / "payload").write_text("user changes")
    with pytest.raises(ValueError, match="DESTINATION_EXISTS"):
        replay.extract(archive, target, replay.sha(archive))
    assert (package / "payload").read_text() == "user changes"


@pytest.mark.parametrize("probe", [
    "import socket; socket.socket()",
    "import subprocess, sys; subprocess.run([sys.executable, '-c', 'pass'], check=True)",
])
def test_replay_child_refuses_network_and_process_execution(tmp_path, probe):
    (tmp_path / "tools").mkdir()
    (tmp_path / "tools/rebuild_release.py").write_text(probe)
    result = subprocess.run(
        [sys.executable, "-I", "-S", "-B", "-c", replay.CHILD, str(tmp_path), "[]"],
        capture_output=True, text=True, check=False,
    )
    assert result.returncode != 0
    assert "OFFLINE_REPLAY_EXTERNAL_EXECUTION_REFUSED" in result.stderr
