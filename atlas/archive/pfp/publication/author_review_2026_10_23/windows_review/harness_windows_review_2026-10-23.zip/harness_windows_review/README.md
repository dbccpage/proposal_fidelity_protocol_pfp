# Windows review supplement

This overlay contains the offline completion and subsequent review repairs.
Apply repository/ only to an isolated checkout of
 e7420ae75737df9dbb0785cc102e8179fa6feb8c, never over a dirty checkout.
The original full author-review archive remains required for frozen replay:
SHA-256 83bd2f2d6452ea0a63edd915305f6290c98b00de99b975e3e01d7bf3321a9e7d.

Read repository/omega_engine_woland/documentation/harness_evolution/README.md
and verification/windows_review/summary.json for commands and retained results.
The updated Paper 029 is in the corresponding repository publication path.
This is an overlay, not a standalone runtime; sibling publications and existing
installed dependencies come from the complete checkout. It supersedes the
previous offline supplement for the changed files but preserves that archive.

Windows offline regression checks and frozen replay passed. Linux testing is
outside current scope; paid calls remain deferred. The frozen candidate runner
is Linux-specific and is not represented as Windows containment. The requested
Anthropic key was checked for presence through the canonical .env resolver;
no key was displayed, packaged, or used for a model request.

Verify this supplement after extraction with Python 3.12:
python tools/rebuild_release.py . --check
Place the ZIP beside MANIFEST.sha256 for the archive comparison.
No new provider trials, empirical improvement, external deposit, or production
admission is claimed. Historical campaign and deposit bytes remain unchanged.
